/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      230636130
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   uint32_t  f0;
   uint32_t  f1;
};

union U1 {
   volatile signed f0 : 26;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3[8] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static int32_t *g_5 = &g_3[2];
static int32_t ** volatile g_4[6] = {&g_5,&g_5,&g_5,&g_5,&g_5,&g_5};
static const int32_t *g_11 = &g_3[2];
static const int32_t **g_10[9] = {&g_11,&g_11,&g_11,&g_11,&g_11,&g_11,&g_11,&g_11,&g_11};
static int32_t g_34 = (-10L);
static volatile uint32_t g_40 = 0x599F3DF3L;/* VOLATILE GLOBAL g_40 */
static uint8_t g_69 = 253UL;
static uint32_t g_83 = 0xD7C5F07BL;
static int32_t * volatile g_90 = (void*)0;/* VOLATILE GLOBAL g_90 */
static int32_t * volatile g_91 = &g_34;/* VOLATILE GLOBAL g_91 */
static uint64_t g_101 = 0xDFA0F4C7584E37E4LL;
static int8_t g_112 = 0xCBL;
static uint32_t g_118 = 0x3F6BE185L;
static int64_t g_140 = (-2L);
static volatile union U1 g_146 = {0x28329125L};/* VOLATILE GLOBAL g_146 */
static volatile union U1 * volatile g_145 = &g_146;/* VOLATILE GLOBAL g_145 */
static volatile union U1 * volatile * volatile g_148 = &g_145;/* VOLATILE GLOBAL g_148 */
static union U1 g_152 = {0x11B79EC1L};/* VOLATILE GLOBAL g_152 */
static union U1 g_153 = {-2L};/* VOLATILE GLOBAL g_153 */
static uint16_t g_185 = 1UL;
static volatile union U0 g_220 = {0x78FF907EL};/* VOLATILE GLOBAL g_220 */
static volatile uint64_t g_238 = 18446744073709551615UL;/* VOLATILE GLOBAL g_238 */
static volatile uint64_t * const g_237 = &g_238;
static volatile uint64_t * const *g_236 = &g_237;
static union U1 g_302 = {0xBCA180FCL};/* VOLATILE GLOBAL g_302 */
static union U1 *g_301 = &g_302;
static uint16_t g_404 = 9UL;
static int32_t **g_437[7] = {&g_5,&g_5,&g_5,&g_5,&g_5,&g_5,&g_5};
static int32_t ***g_436 = &g_437[6];
static int32_t ***g_439 = &g_437[6];
static uint64_t g_450[5][10] = {{0x1A51A77CA87C93DALL,0UL,0x1A51A77CA87C93DALL,0x1A51A77CA87C93DALL,0UL,0x1A51A77CA87C93DALL,0x1A51A77CA87C93DALL,0UL,0x1A51A77CA87C93DALL,0x1A51A77CA87C93DALL},{0UL,0UL,1UL,0UL,0UL,1UL,0x1A51A77CA87C93DALL,0x1A51A77CA87C93DALL,0UL,0x1A51A77CA87C93DALL},{0x1A51A77CA87C93DALL,1UL,1UL,0x1A51A77CA87C93DALL,1UL,1UL,0x1A51A77CA87C93DALL,1UL,1UL,0x1A51A77CA87C93DALL},{1UL,0x1A51A77CA87C93DALL,1UL,1UL,0x1A51A77CA87C93DALL,1UL,1UL,0x1A51A77CA87C93DALL,1UL,1UL},{0x1A51A77CA87C93DALL,0x1A51A77CA87C93DALL,0UL,0x1A51A77CA87C93DALL,0x1A51A77CA87C93DALL,0UL,0x1A51A77CA87C93DALL,0x1A51A77CA87C93DALL,0UL,0x1A51A77CA87C93DALL}};
static uint32_t g_491[8] = {0xE2B29876L,0xE2B29876L,0xE2B29876L,0xE2B29876L,0xE2B29876L,0xE2B29876L,0xE2B29876L,0xE2B29876L};
static int32_t g_492[7][4] = {{(-9L),0xC101DCEBL,0x57F0AEE7L,0L},{(-9L),0x57F0AEE7L,(-9L),0x6DBF5711L},{0xC101DCEBL,0L,0x6DBF5711L,0x6DBF5711L},{0x57F0AEE7L,0x57F0AEE7L,0x2C09EE8CL,0L},{0L,0xC101DCEBL,0x2C09EE8CL,0xC101DCEBL},{0x57F0AEE7L,(-9L),0x6DBF5711L,0x2C09EE8CL},{0xC101DCEBL,(-9L),(-9L),0xC101DCEBL}};
static uint32_t g_583 = 4294967288UL;
static int8_t *g_607 = &g_112;
static int8_t **g_606 = &g_607;
static const uint16_t ** volatile g_632 = (void*)0;/* VOLATILE GLOBAL g_632 */
static volatile uint16_t g_646 = 65535UL;/* VOLATILE GLOBAL g_646 */
static volatile uint16_t g_647 = 6UL;/* VOLATILE GLOBAL g_647 */
static volatile uint16_t g_648[8] = {65535UL,1UL,1UL,65535UL,1UL,1UL,65535UL,1UL};
static volatile uint16_t g_649[8] = {7UL,7UL,7UL,7UL,7UL,7UL,7UL,7UL};
static volatile uint16_t *g_645[2][4][7] = {{{&g_646,&g_646,&g_646,&g_646,&g_646,&g_646,&g_646},{&g_649[7],&g_647,&g_649[7],&g_647,&g_649[7],&g_647,&g_649[7]},{&g_646,&g_646,&g_646,&g_646,&g_646,&g_646,&g_646},{&g_649[7],&g_647,&g_649[7],&g_647,&g_649[7],&g_647,&g_649[7]}},{{&g_646,&g_646,&g_646,&g_646,&g_646,&g_646,&g_646},{&g_649[7],&g_647,&g_649[7],&g_647,&g_649[7],&g_647,&g_649[7]},{&g_646,&g_646,&g_646,&g_646,&g_646,&g_646,&g_646},{&g_649[7],&g_647,&g_649[7],&g_647,&g_649[7],&g_647,&g_649[7]}}};
static volatile uint16_t **g_644 = &g_645[0][3][0];
static uint32_t g_705 = 0x88DD9AC1L;
static union U0 g_718[9][2][8] = {{{{0xD838F2AFL},{1UL},{0x9F97B4E5L},{0x9F97B4E5L},{1UL},{0xD838F2AFL},{6UL},{4UL}},{{0xD838F2AFL},{1UL},{0xB4B1E955L},{1UL},{6UL},{1UL},{0xB4B1E955L},{1UL}}},{{{0xA6D78802L},{0xB4B1E955L},{4294967292UL},{1UL},{4UL},{0x43DE63ADL},{0x43DE63ADL},{4UL}},{{0x9F97B4E5L},{4UL},{4UL},{0x9F97B4E5L},{0xA6D78802L},{1UL},{0x43DE63ADL},{0xD838F2AFL}}},{{{0xB4B1E955L},{0x9F97B4E5L},{4294967292UL},{0x43DE63ADL},{4294967292UL},{0x9F97B4E5L},{0xB4B1E955L},{6UL}},{{4294967292UL},{0x9F97B4E5L},{0xB4B1E955L},{6UL},{1UL},{1UL},{6UL},{0xB4B1E955L}}},{{{4UL},{0x43DE63ADL},{4UL},{1UL},{4294967292UL},{0xB4B1E955L},{0xA6D78802L},{0xB4B1E955L}},{{0xD838F2AFL},{0x834AE2CFL},{1UL},{0x834AE2CFL},{0xD838F2AFL},{0x9F97B4E5L},{0x43DE63ADL},{0xB4B1E955L}}},{{{0x834AE2CFL},{4294967292UL},{0xA6D78802L},{1UL},{1UL},{0xA6D78802L},{4294967292UL},{0x834AE2CFL}},{{4UL},{0x9F97B4E5L},{0xA6D78802L},{1UL},{0x43DE63ADL},{0xD838F2AFL},{0x43DE63ADL},{1UL}}},{{{1UL},{6UL},{1UL},{0xB4B1E955L},{1UL},{0xD838F2AFL},{0xA6D78802L},{0xA6D78802L}},{{0xA6D78802L},{0x9F97B4E5L},{4UL},{4UL},{0x9F97B4E5L},{0xA6D78802L},{1UL},{0x43DE63ADL}}},{{{0xA6D78802L},{4294967292UL},{0x834AE2CFL},{0x9F97B4E5L},{1UL},{0x9F97B4E5L},{0x834AE2CFL},{4294967292UL}},{{1UL},{0x834AE2CFL},{0xD838F2AFL},{0x9F97B4E5L},{0x43DE63ADL},{0xB4B1E955L},{0xB4B1E955L},{0x43DE63ADL}}},{{{4UL},{0x43DE63ADL},{0x43DE63ADL},{4UL},{1UL},{4294967292UL},{0xB4B1E955L},{0xA6D78802L}},{{0x834AE2CFL},{4UL},{0xD838F2AFL},{0xB4B1E955L},{0xD838F2AFL},{4UL},{0x834AE2CFL},{1UL}}},{{{0xD838F2AFL},{4UL},{0x834AE2CFL},{1UL},{4294967292UL},{4294967292UL},{1UL},{0x834AE2CFL}},{{0x43DE63ADL},{0x43DE63ADL},{4UL},{1UL},{4294967292UL},{0xB4B1E955L},{0xA6D78802L},{0xB4B1E955L}}}};
static int32_t g_785 = 1L;
static volatile union U1 g_795 = {-1L};/* VOLATILE GLOBAL g_795 */
static int8_t g_816 = 0xD7L;
static volatile union U1 g_819 = {0xE53BC5F1L};/* VOLATILE GLOBAL g_819 */
static uint8_t g_882 = 0x7DL;
static uint32_t g_891 = 0x2DD85345L;
static int16_t g_911[2] = {0xD9FEL,0xD9FEL};
static volatile uint32_t g_931 = 0x371B0E2AL;/* VOLATILE GLOBAL g_931 */
static volatile uint32_t *g_930 = &g_931;
static volatile uint32_t **g_929[10] = {&g_930,&g_930,&g_930,&g_930,&g_930,&g_930,&g_930,&g_930,&g_930,&g_930};
static int32_t ** volatile g_939 = &g_5;/* VOLATILE GLOBAL g_939 */
static int32_t *g_940 = &g_492[0][0];
static union U0 *g_1017 = (void*)0;
static union U0 **g_1016 = &g_1017;
static union U0 ***g_1015 = &g_1016;
static union U0 ****g_1014 = &g_1015;
static volatile uint64_t ** volatile ** volatile g_1068 = (void*)0;/* VOLATILE GLOBAL g_1068 */
static volatile uint64_t ** volatile ** volatile * volatile g_1067 = &g_1068;/* VOLATILE GLOBAL g_1067 */
static int32_t ** const *g_1104 = &g_437[6];
static int32_t ** const **g_1103[7] = {&g_1104,&g_1104,&g_1104,&g_1104,&g_1104,&g_1104,&g_1104};
static union U1 ** volatile g_1225 = (void*)0;/* VOLATILE GLOBAL g_1225 */
static union U1 ** volatile *g_1263 = &g_1225;
static union U1 ** volatile * volatile * volatile g_1262 = &g_1263;/* VOLATILE GLOBAL g_1262 */
static uint32_t g_1326 = 0x9F997EAFL;
static const int32_t g_1330 = 0xF9578DB2L;
static volatile uint16_t g_1348[2][6][10] = {{{65535UL,65535UL,1UL,0UL,7UL,0UL,1UL,65535UL,65535UL,8UL},{0UL,0UL,7UL,0x1586L,65535UL,1UL,65532UL,65535UL,1UL,65535UL},{0x7855L,0x0BD7L,0x1D76L,0x1586L,65535UL,1UL,65535UL,1UL,65535UL,0UL},{0x674CL,65535UL,1UL,0UL,0x31C0L,4UL,65535UL,65535UL,0x1586L,0x6DA6L},{0x1D76L,65535UL,7UL,1UL,0x0BD7L,65535UL,0xB225L,0xEDDDL,0UL,65535UL},{0UL,65535UL,0x31C0L,65529UL,0x0252L,0x9944L,0x9944L,0x0252L,65529UL,0x31C0L}},{{1UL,1UL,0x4A33L,7UL,0xB225L,0xB01BL,65529UL,0UL,65535UL,65528UL},{65532UL,65535UL,65535UL,65535UL,65535UL,1UL,0xDC8EL,8UL,0x4A33L,65535UL},{0xB225L,65535UL,0UL,1UL,0UL,0x0252L,65535UL,0xD334L,0x0734L,0x6DA6L},{65532UL,65535UL,0x4A33L,0x31C0L,65528UL,0xEDDDL,65535UL,1UL,0x9944L,7UL},{0x7855L,65535UL,0x977EL,1UL,0x0BD7L,65535UL,0x0252L,1UL,0x0252L,65535UL},{0x474FL,4UL,4UL,4UL,0x474FL,1UL,0x4A33L,7UL,65535UL,0xD334L}}};
static union U1 ****g_1351 = (void*)0;
static volatile union U1 g_1381 = {0x31C55A6AL};/* VOLATILE GLOBAL g_1381 */
static const uint8_t g_1456 = 3UL;
static int32_t g_1534 = 0L;
static union U1 g_1577 = {0xC7849789L};/* VOLATILE GLOBAL g_1577 */
static union U1 g_1645 = {0x43CDD44AL};/* VOLATILE GLOBAL g_1645 */
static int8_t g_1695 = 0xDAL;
static volatile union U1 g_1700 = {0x678E1B87L};/* VOLATILE GLOBAL g_1700 */
static uint32_t *g_1701 = (void*)0;
static uint64_t g_1737 = 18446744073709551615UL;
static int32_t g_1828 = 0xA61AB04FL;
static int32_t *g_1834 = &g_1828;
static union U1 g_1836 = {-5L};/* VOLATILE GLOBAL g_1836 */
static volatile union U1 g_1870 = {0x50387BAAL};/* VOLATILE GLOBAL g_1870 */
static volatile union U1 g_1897 = {-1L};/* VOLATILE GLOBAL g_1897 */
static const union U0 *g_1916 = &g_718[6][1][4];
static const union U0 * volatile *g_1915 = &g_1916;
static const union U0 * volatile **g_1914 = &g_1915;
static volatile union U1 g_1954 = {0x459B6814L};/* VOLATILE GLOBAL g_1954 */
static uint8_t **g_1967 = (void*)0;
static volatile int32_t g_2038[1] = {1L};
static volatile union U1 g_2046 = {0xCBC11856L};/* VOLATILE GLOBAL g_2046 */
static int16_t g_2097[9] = {(-1L),(-1L),0x474FL,(-1L),(-1L),0x474FL,(-1L),(-1L),0x474FL};
static const uint16_t **g_2146 = (void*)0;
static uint16_t g_2194 = 65529UL;
static union U1 g_2271[6] = {{0xE38D54B9L},{0xE38D54B9L},{0xE38D54B9L},{0xE38D54B9L},{0xE38D54B9L},{0xE38D54B9L}};
static volatile union U1 g_2308 = {0xF3D90223L};/* VOLATILE GLOBAL g_2308 */
static union U1 **g_2413 = &g_301;
static union U1 ***g_2412 = &g_2413;
static uint16_t *g_2427 = &g_2194;
static uint16_t **g_2426 = &g_2427;
static uint64_t *g_2467 = (void*)0;
static int16_t g_2607 = 0L;


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int32_t  func_7(const int32_t ** p_8, const uint64_t  p_9);
static int32_t * func_12(int32_t ** p_13, uint32_t  p_14, int32_t ** p_15, int32_t  p_16, uint32_t  p_17);
static int32_t ** func_18(int32_t ** p_19);
static const int64_t  func_20(int32_t ** p_21, const int32_t ** p_22);
static const int32_t ** func_24(int32_t * p_25, int32_t * p_26, uint8_t  p_27);
static int32_t * func_28(int32_t ** p_29, int32_t * p_30);
static int32_t ** func_31(int32_t  p_32);
static int32_t  func_43(uint32_t  p_44, int32_t ** p_45, uint32_t  p_46, union U0  p_47);
static uint32_t  func_50(uint64_t  p_51);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_10 g_3 g_40 g_4 g_83 g_5 g_91 g_34 g_491 g_436 g_718 g_607 g_112 g_238 g_140 g_101 g_705 g_648 g_69 g_606 g_185 g_450 g_785 g_492 g_795 g_583 g_819 g_11 g_237 g_816 g_236 g_911 g_404 g_929 g_437 g_939 g_940 g_882 g_302.f0 g_1534 g_2426 g_2427 g_2194 g_1914 g_1915 g_1916 g_1695 g_930 g_931 g_2607
 * writes: g_40 g_69 g_34 g_83 g_437 g_404 g_112 g_185 g_785 g_816 g_140 g_882 g_891 g_5 g_492 g_705 g_2194 g_1834 g_2097 g_3 g_1695 g_436
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_2[6][3][9] = {{{&g_3[0],&g_3[7],&g_3[7],&g_3[0],&g_3[2],&g_3[0],&g_3[7],&g_3[7],&g_3[0]},{&g_3[2],&g_3[5],&g_3[2],&g_3[5],&g_3[2],&g_3[2],&g_3[5],&g_3[2],&g_3[5]},{&g_3[7],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[7],&g_3[2],&g_3[2],&g_3[2]}},{{&g_3[2],&g_3[2],&g_3[5],&g_3[2],&g_3[5],&g_3[2],&g_3[2],&g_3[5],&g_3[2]},{&g_3[0],&g_3[2],&g_3[0],&g_3[7],&g_3[7],&g_3[0],&g_3[2],&g_3[0],&g_3[7]},{&g_3[2],&g_3[5],&g_3[5],&g_3[2],&g_3[2],&g_3[2],&g_3[5],&g_3[5],&g_3[2]}},{{&g_3[6],&g_3[7],&g_3[2],&g_3[7],&g_3[6],&g_3[6],&g_3[7],&g_3[2],&g_3[7]},{&g_3[5],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[5],&g_3[2],&g_3[2],&g_3[2]},{&g_3[6],&g_3[6],&g_3[7],&g_3[2],&g_3[7],&g_3[6],&g_3[6],&g_3[7],&g_3[2]}},{{&g_3[2],&g_3[2],&g_3[2],&g_3[5],&g_3[5],&g_3[2],&g_3[2],&g_3[2],&g_3[5]},{&g_3[0],&g_3[7],&g_3[7],&g_3[0],&g_3[2],&g_3[0],&g_3[7],&g_3[7],&g_3[0]},{&g_3[2],&g_3[5],&g_3[2],&g_3[5],&g_3[2],&g_3[2],&g_3[5],&g_3[2],&g_3[5]}},{{&g_3[7],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[7],&g_3[2],&g_3[2],&g_3[2]},{&g_3[2],&g_3[2],&g_3[5],&g_3[2],&g_3[5],&g_3[2],&g_3[2],&g_3[5],&g_3[2]},{&g_3[0],&g_3[2],&g_3[0],&g_3[7],&g_3[7],&g_3[2],&g_3[6],&g_3[2],&g_3[0]}},{{&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[2]},{&g_3[7],&g_3[0],&g_3[2],&g_3[0],&g_3[7],&g_3[7],&g_3[0],&g_3[2],&g_3[0]},{&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[2],&g_3[2]}}};
    int32_t **l_6 = &l_2[1][1][1];
    int64_t *l_2508 = &g_140;
    uint8_t l_2531 = 0x45L;
    uint32_t l_2553 = 4294967288UL;
    int32_t **l_2556 = &g_1834;
    int16_t *l_2567 = &g_2097[7];
    int64_t *l_2568 = (void*)0;
    uint32_t l_2573 = 4294967292UL;
    uint32_t *l_2575 = &g_118;
    uint16_t l_2582 = 0x2474L;
    uint64_t **l_2593 = &g_2467;
    int i, j, k;
    (*l_6) = l_2[1][1][1];
    if (func_7(g_10[5], g_3[2]))
    { /* block id: 1131 */
        int64_t l_2501[8][5] = {{0x9B67DD0373ED51ECLL,5L,0x1CDACF365B592645LL,0x7623ED612DC27EC8LL,0x902EB36CBB593F72LL},{(-6L),(-1L),1L,0xB56F42C5B4D69B39LL,0xB56F42C5B4D69B39LL},{(-1L),0x9B67DD0373ED51ECLL,(-1L),0xA63FC2EAE26FEAEDLL,0x338B0924C67C2201LL},{(-1L),0x7ADAEF8A7BE5B9AELL,0x7623ED612DC27EC8LL,0x9B67DD0373ED51ECLL,0x93A0BA7A9EBB3AC4LL},{(-6L),1L,5L,0x1239C5FE490B1D1ELL,1L},{0x9B67DD0373ED51ECLL,0xB56F42C5B4D69B39LL,0x7623ED612DC27EC8LL,0x93A0BA7A9EBB3AC4LL,0x7623ED612DC27EC8LL},{0x1CDACF365B592645LL,0x1CDACF365B592645LL,(-1L),0x7ADAEF8A7BE5B9AELL,0x7623ED612DC27EC8LL},{0xA63FC2EAE26FEAEDLL,0x338B0924C67C2201LL,1L,0x902EB36CBB593F72LL,1L}};
        uint8_t l_2518[7];
        int32_t **l_2534 = &l_2[4][0][5];
        int i, j;
        for (i = 0; i < 7; i++)
            l_2518[i] = 0xADL;
        for (g_2194 = 0; (g_2194 <= 5); g_2194 += 1)
        { /* block id: 1134 */
            union U0 l_2509[7][6] = {{{0x98B0A5F2L},{0x3E8C0B43L},{0x98B0A5F2L},{0x3E8C0B43L},{0x98B0A5F2L},{0x3E8C0B43L}},{{0x03D59267L},{0x3E8C0B43L},{0x03D59267L},{0x3E8C0B43L},{0x03D59267L},{0x3E8C0B43L}},{{0x98B0A5F2L},{0x3E8C0B43L},{0x98B0A5F2L},{0x3E8C0B43L},{0x98B0A5F2L},{0x3E8C0B43L}},{{0x03D59267L},{0x3E8C0B43L},{0x03D59267L},{0x3E8C0B43L},{0x03D59267L},{0x3E8C0B43L}},{{0x98B0A5F2L},{0x3E8C0B43L},{0x98B0A5F2L},{0x3E8C0B43L},{0x98B0A5F2L},{0x3E8C0B43L}},{{0x03D59267L},{0x3E8C0B43L},{0x03D59267L},{0x3E8C0B43L},{0x03D59267L},{0x3E8C0B43L}},{{0x98B0A5F2L},{0x3E8C0B43L},{0x98B0A5F2L},{0x3E8C0B43L},{0x98B0A5F2L},{0x3E8C0B43L}}};
            int32_t *l_2519[9];
            union U0 ****l_2523 = &g_1015;
            union U0 *****l_2524 = &g_1014;
            union U1 ** const ***l_2529 = (void*)0;
            uint32_t *l_2530 = &g_1326;
            int i, j;
            for (i = 0; i < 9; i++)
                l_2519[i] = &g_34;
        }
        for (g_705 = (-22); (g_705 >= 15); g_705 = safe_add_func_uint8_t_u_u(g_705, 9))
        { /* block id: 1145 */
            uint32_t l_2535 = 18446744073709551611UL;
            (*l_2534) = func_28(l_2534, (*g_939));
            l_2535++;
            if ((**l_2534))
                break;
        }
    }
    else
    { /* block id: 1150 */
        int8_t l_2538 = 4L;
        int32_t l_2539 = 7L;
        uint8_t l_2540[6][2][6] = {{{0x12L,246UL,246UL,0x12L,246UL,246UL},{0x12L,246UL,246UL,0x12L,246UL,246UL}},{{0x12L,246UL,246UL,0x12L,246UL,246UL},{0x12L,246UL,246UL,0x12L,246UL,246UL}},{{0x12L,246UL,246UL,0x12L,246UL,246UL},{0x12L,246UL,246UL,0x12L,246UL,246UL}},{{0x12L,246UL,246UL,0x12L,246UL,246UL},{0x12L,246UL,246UL,0x12L,246UL,246UL}},{{0x12L,246UL,246UL,0x12L,246UL,246UL},{0x12L,246UL,246UL,0x12L,246UL,246UL}},{{0x12L,246UL,246UL,0x12L,246UL,246UL},{0x12L,246UL,246UL,0x12L,246UL,246UL}}};
        int32_t l_2543[5][5][7] = {{{(-9L),0L,7L,7L,0L,(-9L),0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L}},{{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L}},{{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L}},{{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L}},{{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L},{0x19E3E834L,7L,0L,0L,7L,0x19E3E834L,0L}}};
        uint64_t l_2544 = 0x56A263E370EC8427LL;
        int i, j, k;
        l_2540[0][1][2]--;
        ++l_2544;
    }
    if ((safe_add_func_uint64_t_u_u(((safe_mod_func_int64_t_s_s((safe_mod_func_int8_t_s_s((l_2553 < ((safe_mul_func_int16_t_s_s((((*l_2556) = l_2[1][1][1]) != (void*)0), (safe_mul_func_uint16_t_u_u((safe_mod_func_int16_t_s_s(g_3[2], g_648[1])), (**l_6))))) , ((**g_606) < (safe_mul_func_int64_t_s_s(((safe_rshift_func_uint32_t_u_s((l_2508 == ((safe_add_func_int16_t_s_s(((*l_2567) = ((***g_1914) , g_112)), 0xC539L)) , l_2568)), 4)) , 9L), 5L))))), (**g_606))), (-3L))) <= 0xDD01L), 0x78C3FE490596F0A6LL)))
    { /* block id: 1156 */
        int32_t **l_2569 = &l_2[1][1][1];
        uint32_t *l_2572[5][5][1] = {{{(void*)0},{(void*)0},{&g_891},{&g_891},{&g_118}},{{&g_1326},{(void*)0},{&g_1326},{&g_118},{&g_891}},{{&g_891},{(void*)0},{(void*)0},{&g_891},{&g_891}},{{&g_118},{&g_1326},{(void*)0},{&g_1326},{&g_118}},{{&g_891},{&g_891},{&g_1326},{&g_1326},{&g_1326}}};
        uint32_t **l_2574[3];
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2574[i] = &l_2572[4][3][0];
        (**l_6) = (((18446744073709551614UL > ((l_2575 = func_28((*g_436), (*l_2569))) == (void*)0)) & g_1534) && 0UL);
    }
    else
    { /* block id: 1161 */
        int16_t l_2576 = 0x4FFAL;
        int32_t l_2577 = 8L;
        int32_t l_2578 = 0xE227A8FBL;
        int32_t l_2579 = 1L;
        int32_t l_2580[3];
        int32_t l_2581 = (-1L);
        int64_t **l_2591 = (void*)0;
        int64_t **l_2592[5][6][1] = {{{&l_2508},{&l_2568},{&l_2568},{&l_2568},{&l_2508},{&l_2508}},{{&l_2568},{&l_2568},{&l_2568},{&l_2508},{&l_2508},{&l_2568}},{{&l_2568},{&l_2568},{&l_2508},{&l_2508},{&l_2568},{&l_2568}},{{&l_2568},{&l_2508},{&l_2508},{&l_2568},{&l_2568},{&l_2568}},{{&l_2508},{&l_2508},{&l_2568},{&l_2568},{&l_2568},{&l_2508}}};
        uint64_t * const *l_2594 = &g_2467;
        int8_t *l_2597 = &g_1695;
        int32_t **l_2598[7] = {(void*)0,(void*)0,&g_940,(void*)0,(void*)0,&g_940,(void*)0};
        int32_t ****l_2599 = (void*)0;
        int32_t ****l_2600 = &g_436;
        uint32_t l_2608 = 0x29837082L;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2580[i] = 0xB2F754FDL;
        l_2582--;
        l_2580[0] ^= (((*l_2597) ^= ((safe_rshift_func_uint16_t_u_u((safe_mul_func_int32_t_s_s(((18446744073709551612UL >= (safe_sub_func_int32_t_s_s(((0xB083L && ((l_2508 = &g_140) != l_2568)) == 0UL), l_2581))) == ((l_2593 == l_2594) , ((safe_sub_func_int8_t_s_s((1UL | (**l_6)), (*g_607))) > (*g_237)))), (*g_940))), 6)) , l_2577)) & 6L);
        (*l_6) = func_12(l_2598[4], (*g_930), &l_2[1][1][1], (((&l_6 != ((*l_2600) = &l_2598[4])) < (safe_add_func_uint32_t_u_u((safe_mod_func_int64_t_s_s((((**l_6) & (safe_mul_func_int8_t_s_s(0L, (*g_607)))) == (((0x4DL | 0L) <= 0x07D1L) ^ 255UL)), g_2607)), (*g_5)))) , (*g_5)), l_2608);
    }
    return (**l_6);
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_40 g_4 g_10 g_83 g_5 g_91 g_34 g_491 g_436 g_718 g_607 g_112 g_238 g_140 g_101 g_705 g_648 g_69 g_606 g_185 g_450 g_785 g_492 g_795 g_583 g_819 g_11 g_237 g_816 g_236 g_911 g_404 g_929 g_437 g_939 g_940 g_882 g_302.f0 g_1534 g_2426 g_2427 g_2194
 * writes: g_40 g_69 g_34 g_83 g_437 g_404 g_112 g_185 g_785 g_816 g_140 g_882 g_891 g_5 g_492 g_705
 */
static int32_t  func_7(const int32_t ** p_8, const uint64_t  p_9)
{ /* block id: 2 */
    int32_t **l_23[3];
    int32_t *l_2485 = &g_492[2][1];
    uint32_t l_2497[1][8][9] = {{{7UL,0xA7634B1FL,1UL,7UL,1UL,0xA7634B1FL,7UL,18446744073709551613UL,18446744073709551613UL},{7UL,0xA7634B1FL,1UL,7UL,1UL,0xA7634B1FL,7UL,18446744073709551613UL,18446744073709551613UL},{7UL,0xA7634B1FL,1UL,7UL,1UL,0xA7634B1FL,7UL,18446744073709551613UL,18446744073709551613UL},{7UL,0xA7634B1FL,1UL,7UL,1UL,0xA7634B1FL,7UL,18446744073709551613UL,18446744073709551613UL},{7UL,0xA7634B1FL,1UL,7UL,1UL,0xA7634B1FL,7UL,18446744073709551613UL,18446744073709551613UL},{7UL,0xA7634B1FL,1UL,7UL,1UL,0xA7634B1FL,7UL,18446744073709551613UL,18446744073709551613UL},{7UL,0xA7634B1FL,1UL,7UL,1UL,0xA7634B1FL,7UL,18446744073709551613UL,18446744073709551613UL},{7UL,0xA7634B1FL,1UL,7UL,1UL,0xA7634B1FL,7UL,18446744073709551613UL,18446744073709551613UL}}};
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_23[i] = &g_5;
    l_2485 = func_12(&g_5, g_3[2], func_18((func_20(l_23[2], func_24(func_28(func_31((g_3[2] , g_3[0])), &g_3[5]), g_940, p_9)) , l_23[2])), (*g_11), p_9);
    for (g_140 = 0; (g_140 <= 6); g_140 += 1)
    { /* block id: 1117 */
        int32_t l_2498 = 0x44568A6EL;
        int i;
        (*g_5) = (**p_8);
        if ((**p_8))
            break;
        l_2498 ^= ((*l_2485) = (((*g_940) = (safe_unary_minus_func_uint8_t_u((safe_mod_func_int16_t_s_s(((((safe_rshift_func_uint16_t_u_s((*l_2485), (p_9 & 8UL))) , (!(~g_816))) , (g_1534 && ((safe_mul_func_uint64_t_u_u(p_9, (0x276CL & (safe_add_func_uint8_t_u_u(p_9, (0L <= 8L)))))) >= (*g_607)))) ^ p_9), (**g_2426)))))) > l_2497[0][3][1]));
        if ((*l_2485))
            continue;
    }
    for (g_69 = 0; (g_69 != 33); g_69++)
    { /* block id: 1127 */
        return (**p_8);
    }
    return (*l_2485);
}


/* ------------------------------------------ */
/* 
 * reads : g_705 g_5
 * writes: g_705
 */
static int32_t * func_12(int32_t ** p_13, uint32_t  p_14, int32_t ** p_15, int32_t  p_16, uint32_t  p_17)
{ /* block id: 716 */
    int8_t l_1735 = 1L;
    int32_t l_1768 = 0x4FBEAF77L;
    int32_t l_1790 = 0x62FE7EF9L;
    int32_t l_1804[3][10] = {{(-8L),(-1L),0x4FAA2C9DL,0x4FAA2C9DL,(-1L),(-8L),8L,5L,0x79D3C4F8L,5L},{0L,0x4FAA2C9DL,0x79D3C4F8L,(-1L),0x79D3C4F8L,0x4FAA2C9DL,0L,8L,1L,1L},{0L,1L,(-8L),6L,6L,(-8L),1L,0L,(-1L),8L}};
    uint16_t l_1811 = 0xDF90L;
    uint16_t **l_1837 = (void*)0;
    int16_t l_1874 = 0x200DL;
    uint64_t **** const l_1962 = (void*)0;
    uint64_t **** const * const l_1961 = &l_1962;
    const int32_t *l_1980 = &g_3[0];
    int64_t l_1984[10] = {0x11B31F6674A1469DLL,0L,0L,0x11B31F6674A1469DLL,0xC1F17114B472437ALL,0x11B31F6674A1469DLL,0L,0L,0x11B31F6674A1469DLL,0xC1F17114B472437ALL};
    int16_t *l_1986 = (void*)0;
    int16_t **l_1985 = &l_1986;
    int16_t **l_1988 = &l_1986;
    uint64_t *l_2007 = &g_101;
    uint64_t **l_2006 = &l_2007;
    uint64_t ***l_2005 = &l_2006;
    uint64_t **** const l_2004 = &l_2005;
    uint64_t **** const *l_2003 = &l_2004;
    uint64_t **** const l_2009 = (void*)0;
    uint64_t **** const *l_2008 = &l_2009;
    const union U0 *l_2010 = &g_718[6][1][4];
    int16_t l_2039 = (-1L);
    int16_t l_2040 = 0x81F6L;
    int16_t l_2062 = (-1L);
    uint32_t l_2063 = 7UL;
    uint8_t *l_2077 = &g_882;
    uint8_t **l_2076 = &l_2077;
    int32_t **l_2136 = &g_940;
    union U0 l_2262 = {0x40B899C5L};
    int32_t l_2278 = 0L;
    int64_t l_2325[8] = {0xC119A67AE0733788LL,0x80ADA88F1EC0D51DLL,0xC119A67AE0733788LL,0xC119A67AE0733788LL,0x80ADA88F1EC0D51DLL,0xC119A67AE0733788LL,0xC119A67AE0733788LL,0x80ADA88F1EC0D51DLL};
    uint64_t l_2335[1];
    int32_t l_2353[9][1];
    int32_t ****l_2381 = &g_439;
    int32_t *****l_2380[8];
    union U1 *l_2396 = (void*)0;
    uint32_t l_2446 = 0UL;
    int32_t * const *l_2449 = &g_1834;
    uint32_t l_2455 = 0xCEDD035EL;
    int8_t *l_2471 = &g_816;
    int i, j;
    for (i = 0; i < 1; i++)
        l_2335[i] = 7UL;
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 1; j++)
            l_2353[i][j] = 0x8C9D27C6L;
    }
    for (i = 0; i < 8; i++)
        l_2380[i] = &l_2381;
    for (g_705 = 23; (g_705 == 29); g_705 = safe_add_func_int32_t_s_s(g_705, 2))
    { /* block id: 719 */
        int64_t l_1722 = 0x83C2C11C5ADA691BLL;
        int32_t l_1731 = 0x59857A31L;
        uint16_t l_1734[5];
        int32_t *l_1739 = &g_492[2][0];
        int32_t l_1802 = 0x7AAACFA8L;
        int32_t l_1803 = 9L;
        int32_t l_1808[9];
        union U1 *l_1896 = (void*)0;
        int32_t l_1947[10][3][4] = {{{0xCD66C83AL,0x23594B47L,0xFD5276CDL,0xCD66C83AL},{0xCD6CC5BBL,0x1BA859F7L,0xFD5276CDL,0xB12CD3B3L},{0xCD66C83AL,0xF7683D6FL,0x6D68D6A4L,(-4L)}},{{(-4L),0xFD5276CDL,0x65B79B3AL,0xD741FA5EL},{0x65B79B3AL,0xD741FA5EL,0xB12CD3B3L,0xB12CD3B3L},{0x31A933E5L,0x31A933E5L,0x75B07EAFL,(-6L)}},{{0x1BA859F7L,0x23594B47L,1L,0x08EB6A2FL},{0x65B79B3AL,(-6L),1L,0L},{0L,0x23594B47L,0x08EB6A2FL,0x65B79B3AL}},{{0x23594B47L,0xA1CD19DEL,0x75B07EAFL,0x23594B47L},{0x52EF3D62L,0xF7C5EA15L,0xA1CD19DEL,0xF82B5C41L},{0x8BE49E0CL,0L,0x08EB6A2FL,0L}},{{0xB12CD3B3L,0x6D68D6A4L,0x52EF3D62L,1L},{(-4L),0xB12CD3B3L,(-3L),0xF82B5C41L},{0x65B79B3AL,0xCD6CC5BBL,0x1BA859F7L,0xFD5276CDL}},{{0x65B79B3AL,0xA1CD19DEL,(-3L),0xF7C5EA15L},{(-4L),0xFD5276CDL,0x52EF3D62L,0L},{0xB12CD3B3L,0x8BE49E0CL,0x08EB6A2FL,0xCD6CC5BBL}},{{0x8BE49E0CL,0xA1CD19DEL,0xA1CD19DEL,0x8BE49E0CL},{0x52EF3D62L,0x65B79B3AL,0x75B07EAFL,0xF82B5C41L},{0x23594B47L,1L,0x08EB6A2FL,0xB12CD3B3L}},{{0L,0x6D68D6A4L,1L,0xB12CD3B3L},{(-4L),1L,0L,0xF82B5C41L},{0xCD6CC5BBL,0x65B79B3AL,0x1BA859F7L,0x8BE49E0CL}},{{0xF7C5EA15L,0xA1CD19DEL,0xF82B5C41L,0xCD6CC5BBL},{(-4L),0x8BE49E0CL,(-4L),0L},{1L,0xFD5276CDL,0x08EB6A2FL,0xF7C5EA15L}},{{0xFD5276CDL,0xA1CD19DEL,0x6D68D6A4L,0xFD5276CDL},{0x52EF3D62L,0xCD6CC5BBL,0x6D68D6A4L,0xF82B5C41L},{0xFD5276CDL,0xB12CD3B3L,0x08EB6A2FL,1L}}};
        int64_t l_2011 = 0x2BC59056893F3080LL;
        uint8_t l_2041 = 0x2FL;
        int32_t *l_2058 = (void*)0;
        int64_t l_2096[4];
        uint16_t l_2200 = 2UL;
        union U0 l_2231 = {0x0BA9FB4FL};
        int16_t ***l_2292 = &l_1988;
        int64_t *l_2299[10][9][2] = {{{(void*)0,&l_1984[4]},{(void*)0,&g_140},{(void*)0,(void*)0},{&g_140,&l_1984[0]},{(void*)0,&l_2011},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&l_2011},{(void*)0,&l_1984[0]}},{{&g_140,(void*)0},{(void*)0,&g_140},{(void*)0,&l_1984[4]},{(void*)0,&g_140},{(void*)0,(void*)0},{&g_140,&l_1984[0]},{(void*)0,&l_2011},{(void*)0,(void*)0},{(void*)0,(void*)0}},{{(void*)0,&l_2011},{(void*)0,&l_1984[0]},{&g_140,(void*)0},{(void*)0,&g_140},{(void*)0,&l_1984[4]},{(void*)0,&g_140},{(void*)0,(void*)0},{&g_140,&l_1984[0]},{(void*)0,&l_2011}},{{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&l_2011},{(void*)0,&l_1984[0]},{&g_140,(void*)0},{(void*)0,&g_140},{(void*)0,&l_1984[4]},{(void*)0,&g_140},{(void*)0,(void*)0}},{{&g_140,&l_1984[0]},{(void*)0,&l_2011},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&l_2011},{(void*)0,&l_1984[0]},{&g_140,(void*)0},{(void*)0,&g_140},{(void*)0,&l_1984[4]}},{{(void*)0,&g_140},{(void*)0,(void*)0},{&g_140,&l_1984[0]},{(void*)0,&l_2011},{(void*)0,(void*)0},{(void*)0,&l_2096[2]},{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_1984[4],(void*)0}},{{(void*)0,&l_1984[4]},{&l_2011,&l_1984[5]},{&l_2011,&l_1984[4]},{(void*)0,(void*)0},{&l_1984[4],(void*)0},{(void*)0,(void*)0},{(void*)0,&l_2096[2]},{&l_2096[2],&l_2096[2]},{(void*)0,(void*)0}},{{(void*)0,(void*)0},{&l_1984[4],(void*)0},{(void*)0,&l_1984[4]},{&l_2011,&l_1984[5]},{&l_2011,&l_1984[4]},{(void*)0,(void*)0},{&l_1984[4],(void*)0},{(void*)0,(void*)0},{(void*)0,&l_2096[2]}},{{&l_2096[2],&l_2096[2]},{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_1984[4],(void*)0},{(void*)0,&l_1984[4]},{&l_2011,&l_1984[5]},{&l_2011,&l_1984[4]},{(void*)0,(void*)0},{&l_1984[4],(void*)0}},{{(void*)0,(void*)0},{(void*)0,&l_2096[2]},{&l_2096[2],&l_2096[2]},{(void*)0,(void*)0},{(void*)0,(void*)0},{&l_1984[4],(void*)0},{(void*)0,&l_1984[4]},{&l_2011,&l_1984[5]},{&l_2011,&l_1984[4]}}};
        uint64_t l_2372[8][5][6] = {{{0x8B8B67D0525CC00DLL,0x52279D9084F4B31ALL,18446744073709551612UL,18446744073709551612UL,0x52279D9084F4B31ALL,0x8B8B67D0525CC00DLL},{0UL,0x2EB6CDE9FF7C5D67LL,0xE65246F871A29F79LL,0x9ACDD26DCECD7185LL,18446744073709551606UL,18446744073709551615UL},{5UL,0x8B8B67D0525CC00DLL,18446744073709551608UL,0x0E4DF707AB5164C3LL,8UL,0x6E482D268FF08695LL},{5UL,0UL,0x0E4DF707AB5164C3LL,0x9ACDD26DCECD7185LL,18446744073709551608UL,0UL},{0UL,18446744073709551606UL,3UL,18446744073709551612UL,3UL,18446744073709551606UL}},{{0x8B8B67D0525CC00DLL,18446744073709551615UL,7UL,0xE65246F871A29F79LL,0xADCF840EB2EE2920LL,0x8B8B67D0525CC00DLL},{18446744073709551615UL,0x9ACDD26DCECD7185LL,18446744073709551615UL,18446744073709551608UL,18446744073709551606UL,0x35C2EA19619F6CAFLL},{0x6E482D268FF08695LL,0x9ACDD26DCECD7185LL,0x2EB6CDE9FF7C5D67LL,0x0E4DF707AB5164C3LL,0xADCF840EB2EE2920LL,0xBC05ED16C95CC9CFLL},{0UL,18446744073709551615UL,0x0E4DF707AB5164C3LL,3UL,3UL,0x0E4DF707AB5164C3LL},{18446744073709551606UL,18446744073709551606UL,0x8B8B67D0525CC00DLL,7UL,18446744073709551608UL,0x41EF07C688D78523LL}},{{0x8B8B67D0525CC00DLL,0UL,0xE32CE68000352176LL,18446744073709551615UL,8UL,0x8B8B67D0525CC00DLL},{0x35C2EA19619F6CAFLL,0x8B8B67D0525CC00DLL,0xE32CE68000352176LL,0x2EB6CDE9FF7C5D67LL,18446744073709551606UL,0x41EF07C688D78523LL},{0xBC05ED16C95CC9CFLL,0x2EB6CDE9FF7C5D67LL,0x8B8B67D0525CC00DLL,0x0E4DF707AB5164C3LL,0x52279D9084F4B31ALL,0x0E4DF707AB5164C3LL},{0x0E4DF707AB5164C3LL,0x52279D9084F4B31ALL,0x0E4DF707AB5164C3LL,0x8B8B67D0525CC00DLL,0x2EB6CDE9FF7C5D67LL,0xBC05ED16C95CC9CFLL},{0x41EF07C688D78523LL,18446744073709551606UL,0x2EB6CDE9FF7C5D67LL,0xE32CE68000352176LL,0x8B8B67D0525CC00DLL,0x35C2EA19619F6CAFLL}},{{0x8B8B67D0525CC00DLL,8UL,18446744073709551615UL,0xE32CE68000352176LL,0UL,0x8B8B67D0525CC00DLL},{0x41EF07C688D78523LL,18446744073709551608UL,7UL,0x8B8B67D0525CC00DLL,18446744073709551606UL,18446744073709551606UL},{0x0E4DF707AB5164C3LL,3UL,3UL,0x0E4DF707AB5164C3LL,18446744073709551615UL,0UL},{0xBC05ED16C95CC9CFLL,0xADCF840EB2EE2920LL,0x0E4DF707AB5164C3LL,0x2EB6CDE9FF7C5D67LL,5UL,7UL},{0x9ACDD26DCECD7185LL,0x8B8B67D0525CC00DLL,0xBC05ED16C95CC9CFLL,18446744073709551615UL,5UL,18446744073709551608UL}},{{0x6E482D268FF08695LL,0x41EF07C688D78523LL,8UL,0UL,0UL,0x6E482D268FF08695LL},{0x8B8B67D0525CC00DLL,0x0E4DF707AB5164C3LL,0x52279D9084F4B31ALL,0x0E4DF707AB5164C3LL,0x8B8B67D0525CC00DLL,0x2EB6CDE9FF7C5D67LL},{0xE65246F871A29F79LL,0xBC05ED16C95CC9CFLL,5UL,18446744073709551615UL,18446744073709551615UL,18446744073709551612UL},{7UL,0x35C2EA19619F6CAFLL,18446744073709551615UL,0xBC05ED16C95CC9CFLL,0x6E482D268FF08695LL,18446744073709551612UL},{18446744073709551608UL,0x8B8B67D0525CC00DLL,5UL,8UL,0UL,0x2EB6CDE9FF7C5D67LL}},{{0x6E482D268FF08695LL,18446744073709551606UL,0x52279D9084F4B31ALL,0x52279D9084F4B31ALL,18446744073709551606UL,0x6E482D268FF08695LL},{0x2EB6CDE9FF7C5D67LL,0UL,8UL,5UL,0x8B8B67D0525CC00DLL,18446744073709551608UL},{18446744073709551612UL,0x6E482D268FF08695LL,0xBC05ED16C95CC9CFLL,18446744073709551615UL,0x35C2EA19619F6CAFLL,7UL},{18446744073709551612UL,18446744073709551615UL,18446744073709551615UL,5UL,0xBC05ED16C95CC9CFLL,0xE65246F871A29F79LL},{0x2EB6CDE9FF7C5D67LL,0x8B8B67D0525CC00DLL,0x0E4DF707AB5164C3LL,0x52279D9084F4B31ALL,0x0E4DF707AB5164C3LL,0x8B8B67D0525CC00DLL}},{{0x6E482D268FF08695LL,0UL,0UL,8UL,0x41EF07C688D78523LL,0x6E482D268FF08695LL},{18446744073709551608UL,5UL,18446744073709551615UL,0xBC05ED16C95CC9CFLL,0x8B8B67D0525CC00DLL,0x9ACDD26DCECD7185LL},{7UL,5UL,0UL,18446744073709551615UL,0x41EF07C688D78523LL,0xE32CE68000352176LL},{0xE65246F871A29F79LL,0UL,18446744073709551615UL,0x0E4DF707AB5164C3LL,0x0E4DF707AB5164C3LL,18446744073709551615UL},{0x8B8B67D0525CC00DLL,0x8B8B67D0525CC00DLL,0x6E482D268FF08695LL,0UL,0xBC05ED16C95CC9CFLL,3UL}},{{0x6E482D268FF08695LL,18446744073709551615UL,0xADCF840EB2EE2920LL,18446744073709551615UL,0x35C2EA19619F6CAFLL,0x6E482D268FF08695LL},{0x9ACDD26DCECD7185LL,0x6E482D268FF08695LL,0xADCF840EB2EE2920LL,0UL,0x8B8B67D0525CC00DLL,3UL},{0xE32CE68000352176LL,0UL,0x6E482D268FF08695LL,18446744073709551615UL,18446744073709551606UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551606UL,18446744073709551615UL,0x6E482D268FF08695LL,0UL,0xE32CE68000352176LL},{3UL,0x8B8B67D0525CC00DLL,0UL,0xADCF840EB2EE2920LL,0x6E482D268FF08695LL,0x9ACDD26DCECD7185LL}}};
        int16_t l_2377 = 1L;
        int8_t l_2394 = 0x96L;
        union U1 *l_2398 = (void*)0;
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_1734[i] = 0UL;
        for (i = 0; i < 9; i++)
            l_1808[i] = 0x6A627A5FL;
        for (i = 0; i < 4; i++)
            l_2096[i] = 0x4F414216A80D1701LL;
    }
    return (*p_15);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t ** func_18(int32_t ** p_19)
{ /* block id: 432 */
    uint32_t l_982 = 1UL;
    int32_t **l_983 = &g_5;
    int32_t l_1008 = 0x6F96F471L;
    uint8_t l_1020 = 0x03L;
    uint16_t l_1065 = 65535UL;
    uint32_t l_1066 = 0x6FF050D3L;
    uint64_t *l_1073[10][7] = {{&g_450[0][6],(void*)0,&g_450[0][6],&g_450[0][6],(void*)0,&g_101,&g_450[0][6]},{&g_450[1][2],&g_450[2][4],(void*)0,&g_450[0][6],&g_450[2][4],&g_450[0][6],&g_450[0][6]},{&g_450[0][6],&g_450[0][6],&g_450[0][6],&g_450[3][8],&g_450[3][8],&g_450[0][6],&g_450[0][6]},{&g_450[0][6],&g_450[0][6],&g_450[0][6],&g_450[2][4],&g_450[0][6],(void*)0,&g_450[2][4]},{&g_450[1][2],&g_450[0][6],&g_101,(void*)0,&g_450[0][6],&g_450[0][6],(void*)0},{&g_450[0][6],&g_450[0][6],&g_450[0][6],&g_450[2][4],&g_450[0][6],&g_450[0][2],&g_101},{&g_101,(void*)0,&g_450[0][6],&g_450[3][8],&g_450[0][6],(void*)0,&g_101},{&g_450[0][6],&g_450[4][0],&g_101,&g_450[0][6],&g_101,(void*)0,(void*)0},{&g_450[4][0],&g_450[3][8],&g_450[0][2],&g_450[0][6],&g_450[0][6],&g_450[0][6],(void*)0},{(void*)0,&g_450[0][6],&g_450[0][2],(void*)0,&g_450[1][0],&g_450[3][1],&g_101}};
    uint64_t **l_1072[4][5] = {{&l_1073[1][1],&l_1073[1][1],&l_1073[2][3],&l_1073[2][3],&l_1073[1][1]},{&l_1073[0][6],&l_1073[7][6],&l_1073[1][1],&l_1073[1][1],&l_1073[7][6]},{&l_1073[1][1],&l_1073[1][1],&l_1073[2][3],&l_1073[2][3],&l_1073[1][1]},{&l_1073[0][6],&l_1073[7][6],&l_1073[1][1],&l_1073[1][1],&l_1073[7][6]}};
    uint64_t ***l_1071 = &l_1072[1][2];
    uint64_t ****l_1070 = &l_1071;
    uint64_t *****l_1069 = &l_1070;
    union U0 l_1084 = {0xA123962FL};
    int32_t ** const **l_1106 = &g_1104;
    int32_t l_1161 = (-9L);
    int32_t l_1176 = 0L;
    int32_t l_1184 = 0x54A23C50L;
    int32_t l_1185[6] = {(-1L),1L,1L,(-1L),1L,1L};
    union U0 *****l_1214[3];
    union U1 * const *l_1219 = &g_301;
    uint32_t *l_1257 = &g_891;
    uint32_t * const *l_1256[5][2] = {{&l_1257,&l_1257},{&l_1257,&l_1257},{&l_1257,&l_1257},{&l_1257,&l_1257},{&l_1257,&l_1257}};
    uint32_t l_1269 = 2UL;
    uint32_t l_1345 = 18446744073709551615UL;
    uint8_t l_1372[3][8] = {{255UL,0x6FL,0xD0L,0x6FL,255UL,255UL,0x6FL,0xD0L},{255UL,255UL,0x6FL,0xD0L,0x6FL,255UL,255UL,0x6FL},{1UL,0x6FL,0x6FL,1UL,0UL,1UL,0x6FL,0x6FL}};
    uint32_t l_1440 = 0x4FCBD925L;
    union U0 **l_1458 = &g_1017;
    int64_t l_1523 = 9L;
    int32_t *l_1536 = &g_3[2];
    int16_t l_1604 = 2L;
    int64_t l_1615 = 0xED92F61BFD5156D3LL;
    int16_t l_1661 = 1L;
    int32_t **l_1704[3];
    int i, j;
    for (i = 0; i < 3; i++)
        l_1214[i] = (void*)0;
    for (i = 0; i < 3; i++)
        l_1704[i] = &l_1536;
    return p_19;
}


/* ------------------------------------------ */
/* 
 * reads : g_236 g_237 g_238 g_882 g_5 g_34 g_11 g_3 g_705 g_302.f0
 * writes: g_882 g_140
 */
static const int64_t  func_20(int32_t ** p_21, const int32_t ** p_22)
{ /* block id: 426 */
    const int8_t l_961 = 0xE4L;
    uint16_t l_962 = 0xC548L;
    uint8_t *l_971 = &g_882;
    int64_t *l_972 = &g_140;
    int32_t l_973 = 0x2141825EL;
    const union U0 ****l_974 = (void*)0;
    l_973 &= (safe_sub_func_uint16_t_u_u(((safe_mod_func_int16_t_s_s(0x3475L, (safe_lshift_func_uint8_t_u_u(((((18446744073709551612UL || ((*l_972) = (l_961 >= ((*l_971) |= ((l_961 != l_962) == (((safe_sub_func_uint8_t_u_u((l_962 , (safe_mul_func_uint64_t_u_u(l_961, (safe_mul_func_uint64_t_u_u((**g_236), (safe_sub_func_uint8_t_u_u((0x29861A6AC4B43A52LL != l_961), 0x48L))))))), l_962)) && l_962) == 1L)))))) & l_961) , (**p_21)) == (**p_22)), 0)))) && 0x09DCL), g_705));
    l_974 = l_974;
    return g_302.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_492 g_940
 * writes: g_492
 */
static const int32_t ** func_24(int32_t * p_25, int32_t * p_26, uint8_t  p_27)
{ /* block id: 421 */
    int16_t l_941 = 9L;
    int32_t *l_942 = &g_34;
    int32_t *l_943[4][7] = {{&g_492[2][1],&g_34,&g_785,(void*)0,(void*)0,&g_785,&g_34},{&g_34,&g_34,&g_34,&g_785,&g_785,&g_34,&g_34},{&g_492[2][1],&g_34,&g_785,(void*)0,(void*)0,&g_785,&g_34},{&g_34,&g_34,&g_34,&g_785,&g_785,&g_34,&g_34}};
    uint8_t l_944 = 0x31L;
    union U0 * const l_953 = &g_718[6][1][4];
    union U0 * const *l_952[9] = {&l_953,&l_953,&l_953,&l_953,&l_953,&l_953,&l_953,&l_953,&l_953};
    union U0 * const **l_951[1];
    const int32_t **l_954 = &g_11;
    int i, j;
    for (i = 0; i < 1; i++)
        l_951[i] = &l_952[2];
    l_944--;
    (*p_26) &= (safe_mul_func_int32_t_s_s((*l_942), ((*p_25) != (*p_25))));
    (*g_940) = (safe_lshift_func_int64_t_s_s((l_951[0] == (void*)0), 57));
    return l_954;
}


/* ------------------------------------------ */
/* 
 * reads : g_939
 * writes: g_5
 */
static int32_t * func_28(int32_t ** p_29, int32_t * p_30)
{ /* block id: 418 */
    int32_t *l_938 = &g_34;
    (*g_939) = l_938;
    return l_938;
}


/* ------------------------------------------ */
/* 
 * reads : g_40 g_3 g_4 g_10 g_83 g_5 g_91 g_34 g_491 g_436 g_718 g_607 g_112 g_238 g_140 g_101 g_705 g_648 g_69 g_606 g_185 g_450 g_785 g_492 g_795 g_583 g_819 g_11 g_237 g_816 g_236 g_911 g_404 g_929 g_437
 * writes: g_40 g_69 g_34 g_83 g_437 g_404 g_112 g_185 g_785 g_816 g_140 g_882 g_891
 */
static int32_t ** func_31(int32_t  p_32)
{ /* block id: 3 */
    int32_t *l_33 = &g_34;
    int32_t *l_35 = &g_34;
    int32_t *l_36 = &g_34;
    int32_t *l_37[3];
    int16_t l_38 = (-7L);
    int64_t l_39[9][6] = {{1L,(-6L),1L,0x202D95C78859B346LL,0xCE3FF50EDC67586ELL,(-6L)},{0xC758019D44E4153CLL,1L,0x16066802143632CBLL,1L,0xC758019D44E4153CLL,0x202D95C78859B346LL},{1L,0xAE11E546375426BELL,0x79388B32A1BF3346LL,0L,0x16066802143632CBLL,1L},{0x79388B32A1BF3346LL,(-4L),0xC758019D44E4153CLL,0xAE11E546375426BELL,(-1L),1L},{0x202D95C78859B346LL,(-6L),0x79388B32A1BF3346LL,0x79388B32A1BF3346LL,(-6L),0x202D95C78859B346LL},{(-1L),(-1L),0x16066802143632CBLL,0xCE3FF50EDC67586ELL,1L,(-6L)},{(-1L),0xC758019D44E4153CLL,1L,0L,(-6L),7L},{(-1L),0L,0L,0xCE3FF50EDC67586ELL,0L,0L},{(-1L),1L,0xAE11E546375426BELL,0x79388B32A1BF3346LL,0L,0x16066802143632CBLL}};
    int16_t l_85 = (-1L);
    uint32_t l_86 = 18446744073709551613UL;
    uint16_t *l_742 = &g_185;
    uint16_t **l_741 = &l_742;
    int32_t ****l_758 = &g_439;
    uint64_t *l_827 = &g_101;
    uint64_t **l_826 = &l_827;
    uint64_t ***l_825 = &l_826;
    uint64_t ****l_824[10] = {&l_825,&l_825,&l_825,&l_825,&l_825,&l_825,&l_825,&l_825,&l_825,&l_825};
    int32_t l_842 = 0x61F46A37L;
    union U1 **l_843 = &g_301;
    const uint32_t l_883[2] = {0x214A6E32L,0x214A6E32L};
    int32_t l_910 = 0xD8400FA2L;
    const uint64_t **l_924 = (void*)0;
    uint16_t l_937[6] = {0xA943L,0xA943L,0xA943L,0xA943L,0xA943L,0xA943L};
    int i, j;
    for (i = 0; i < 3; i++)
        l_37[i] = &g_34;
lbl_725:
    ++g_40;
    for (p_32 = 0; (p_32 <= 5); p_32 += 1)
    { /* block id: 7 */
        uint8_t *l_68 = &g_69;
        int32_t l_84 = 0L;
        int32_t l_717 = (-2L);
        int32_t **l_726 = (void*)0;
        union U0 l_761 = {0x75BAA8BAL};
        uint64_t l_783[1][4] = {{0xAFD90FC0F5995CAELL,0xAFD90FC0F5995CAELL,0xAFD90FC0F5995CAELL,0xAFD90FC0F5995CAELL}};
        int32_t l_794[3][3] = {{0xFD5B6D13L,(-10L),(-10L)},{0xFD5B6D13L,(-10L),(-10L)},{0xFD5B6D13L,(-10L),(-10L)}};
        int16_t l_818 = 1L;
        union U1 **l_848 = (void*)0;
        int64_t *l_865 = (void*)0;
        uint32_t *l_914 = (void*)0;
        uint32_t *l_917 = &l_86;
        uint32_t **l_916 = &l_917;
        const uint64_t ***l_925 = &l_924;
        uint32_t l_928 = 4UL;
        uint64_t * const *l_934 = &l_827;
        int16_t *l_935 = (void*)0;
        int16_t *l_936 = &l_85;
        int i, j;
        if (func_43(p_32, ((*g_436) = ((l_717 ^= (((0xEAL < (((func_50((safe_mod_func_uint32_t_u_u((((((65529UL >= ((safe_add_func_int16_t_s_s((safe_rshift_func_int16_t_s_u(((safe_mod_func_uint32_t_u_u(((safe_add_func_int32_t_s_s((safe_mul_func_uint16_t_u_u(((safe_mod_func_uint8_t_u_u((((*l_68) = 0x55L) >= ((safe_div_func_int16_t_s_s((safe_div_func_int64_t_s_s(g_3[6], (safe_mul_func_int32_t_s_s((safe_rshift_func_int64_t_s_s((!(safe_sub_func_uint16_t_u_u(((((l_84 = (safe_sub_func_int32_t_s_s((g_83 ^= (((*l_33) = (((g_4[p_32] == g_10[(p_32 + 2)]) != (g_3[2] == p_32)) <= 0xE9L)) >= p_32)), p_32))) & p_32) || p_32) >= 6L), (-6L)))), 61)), p_32)))), p_32)) , p_32)), p_32)) | 0UL), p_32)), (*g_5))) >= p_32), (-1L))) >= p_32), 11)), l_85)) == 5L)) , 1UL) & 0L) == l_86) , 0xAB43C673L), 4294967295UL))) | 4294967291UL) < g_491[2]) > p_32)) != p_32) < p_32)) , (void*)0)), p_32, g_718[6][1][4]))
        { /* block id: 328 */
            uint16_t l_723[7][5][7] = {{{3UL,0UL,1UL,0x5FADL,6UL,0x82A8L,0x290FL},{0x82A8L,65535UL,0UL,0UL,65535UL,0x82A8L,0x0094L},{0x4AD4L,0xE9BFL,65535UL,0x2F8FL,1UL,65535UL,0x5FADL},{65535UL,0x0094L,0UL,8UL,0UL,1UL,8UL},{0x82A8L,0xE9BFL,0UL,6UL,0x290FL,0UL,0UL}},{{0x290FL,65535UL,65535UL,65535UL,0x290FL,0xBD49L,1UL},{0x8758L,0UL,6UL,1UL,0UL,0x0094L,0x8758L},{0UL,0x8758L,0x0094L,0UL,1UL,6UL,0UL},{0x8758L,1UL,0xBD49L,0x290FL,65535UL,65535UL,65535UL},{0x290FL,0UL,0UL,0x290FL,6UL,0UL,0xE9BFL}},{{0x82A8L,8UL,1UL,0UL,8UL,0UL,0x0094L},{65535UL,0x5FADL,65535UL,1UL,0x2F8FL,65535UL,0xE9BFL},{0x4AD4L,0x0094L,0x82A8L,65535UL,0UL,0UL,65535UL},{0x82A8L,0x290FL,0x82A8L,6UL,0x5FADL,1UL,0UL},{0x5FADL,0x4AD4L,65535UL,8UL,0xE9BFL,0xBD49L,0x8758L}},{{1UL,0UL,1UL,0x2F8FL,0UL,1UL,1UL},{0UL,0x2F8FL,0UL,0UL,0x8758L,0UL,0UL},{0x2F8FL,0x2F8FL,0xBD49L,0x5FADL,0x4AD4L,65535UL,8UL},{0xE9BFL,0UL,0x0094L,0xE9BFL,6UL,0UL,0x5FADL},{0x82A8L,0x4AD4L,6UL,0UL,0x4AD4L,0UL,0x0094L}},{{8UL,0x290FL,65535UL,0x8758L,0x8758L,65535UL,0x290FL},{8UL,0x0094L,0UL,0x4AD4L,0UL,6UL,0x4AD4L},{0x82A8L,0x5FADL,0UL,6UL,0xE9BFL,0x0094L,0UL},{0xE9BFL,8UL,65535UL,0x4AD4L,0x5FADL,0xBD49L,0x2F8FL},{0x2F8FL,0UL,0UL,0x8758L,0UL,0UL,0x2F8FL}},{{0UL,1UL,1UL,0UL,0x2F8FL,1UL,0UL},{1UL,0x8758L,0xBD49L,0xE9BFL,8UL,65535UL,0x4AD4L},{0x5FADL,0UL,1UL,0UL,3UL,0x3A91L,1UL},{0x3A91L,1UL,0x3000L,0x3000L,1UL,0x3A91L,65535UL},{6UL,0x0094L,1UL,0UL,0x82A8L,1UL,0UL}},{{1UL,65535UL,65535UL,0UL,0x3000L,0xDCAFL,0UL},{0x3A91L,0x0094L,0xD9ADL,3UL,1UL,0UL,0UL},{1UL,1UL,1UL,1UL,1UL,0x8758L,0x82A8L},{0UL,0UL,3UL,0x82A8L,0x3000L,65535UL,0UL},{0xD9ADL,0UL,65535UL,0x3000L,0x82A8L,3UL,0UL}}};
            uint16_t **l_782 = &l_742;
            int16_t *l_784[6];
            int32_t l_786 = 0xBB7DB1E4L;
            int32_t l_787 = 0x38A51D38L;
            int32_t l_817 = 0xF33E8845L;
            int8_t l_880 = 1L;
            uint32_t **l_918 = &l_917;
            int i, j, k;
            for (i = 0; i < 6; i++)
                l_784[i] = &l_38;
            for (g_112 = 0; (g_112 <= 5); g_112 += 1)
            { /* block id: 331 */
                int32_t l_724[4][4] = {{(-9L),0xD9A5D945L,(-9L),0xD9A5D945L},{(-9L),0xD9A5D945L,(-9L),0xD9A5D945L},{(-9L),0xD9A5D945L,(-9L),0xD9A5D945L},{(-9L),0xD9A5D945L,(-9L),0xD9A5D945L}};
                int i, j;
                l_724[1][2] = ((*g_5) | l_723[5][0][3]);
                for (l_85 = 1; (l_85 <= 5); l_85 += 1)
                { /* block id: 335 */
                    int8_t l_747 = 0x83L;
                    int32_t l_748 = 0L;
                    int32_t l_749 = 0x3DCDCDE7L;
                    int8_t *l_757 = &l_747;
                    const union U0 *l_760 = (void*)0;
                    const union U0 **l_759 = &l_760;
                    for (l_717 = 0; (l_717 <= 3); l_717 += 1)
                    { /* block id: 338 */
                        if (p_32)
                            goto lbl_725;
                        return l_726;
                    }
                    for (g_185 = 0; (g_185 <= 2); g_185 += 1)
                    { /* block id: 344 */
                        int64_t *l_731 = (void*)0;
                        int64_t *l_752 = &l_39[7][1];
                        l_749 = ((((*l_68) ^= (((l_748 = (safe_mod_func_int8_t_s_s(((*l_36) = (safe_sub_func_int16_t_s_s(((l_731 != (void*)0) && ((((safe_rshift_func_uint32_t_u_u((((safe_add_func_uint8_t_u_u((p_32 > (safe_unary_minus_func_int64_t_s((((((((safe_sub_func_int8_t_s_s((*g_607), (safe_add_func_int8_t_s_s(((void*)0 == l_741), ((safe_sub_func_int16_t_s_s(g_34, ((((safe_lshift_func_uint16_t_u_s((g_238 >= g_3[4]), g_3[5])) & g_140) , l_747) <= p_32))) != p_32))))) > g_112) || 0x74C4105D1744C6F1LL) <= l_724[1][1]) == (*g_607)) | 0L) , 0x320EE57095BA9EBFLL)))), 0UL)) , &g_645[1][0][2]) == (void*)0), p_32)) , (-5L)) | g_101) , 4UL)), g_83))), p_32))) & g_705) && g_648[1])) < 1UL) , l_724[1][2]);
                        (*l_35) ^= ((safe_mul_func_int8_t_s_s(0x11L, l_723[2][0][6])) < ((*l_752) = 0x07DD2AB7D21C2D1ALL));
                    }
                    (*g_91) = ((((safe_add_func_int8_t_s_s(((l_749 & (((*l_757) ^= (**g_606)) >= p_32)) > ((l_758 == (void*)0) && g_185)), (*g_607))) , (l_759 != ((p_32 , l_761) , (void*)0))) != 0xC9L) , l_723[2][3][1]);
                }
                if (l_724[1][2])
                    break;
            }
            if ((l_787 &= ((safe_rshift_func_uint64_t_u_u(((*l_36) <= (*g_91)), 44)) && (l_786 = ((safe_div_func_uint16_t_u_u((safe_add_func_uint16_t_u_u((safe_rshift_func_uint64_t_u_u((((((((g_785 ^= ((((safe_div_func_uint8_t_u_u((p_32 >= ((((((*l_68) = (safe_lshift_func_uint64_t_u_s((p_32 , (safe_lshift_func_uint8_t_u_u(((((safe_lshift_func_uint32_t_u_s((((safe_rshift_func_int64_t_s_u(g_450[0][6], g_185)) < ((void*)0 != l_782)) > (g_705 , p_32)), l_723[5][0][3])) >= 0x36L) || l_783[0][1]) > 4L), 0))), 21))) < p_32) ^ (-10L)) , l_723[2][3][1]) < 65535UL)), p_32)) < 0x40CCL) , 0xA5L) > 1L)) == g_492[2][0]) == l_723[5][0][3]) , l_723[5][0][3]) != 0UL) || p_32) , 18446744073709551615UL), p_32)), g_112)), g_492[2][1])) > p_32)))))
            { /* block id: 361 */
                int32_t l_813 = (-1L);
                int8_t *l_814 = (void*)0;
                int8_t *l_815 = &g_816;
                int32_t l_831[4][3][6] = {{{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL},{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL},{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL}},{{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL},{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL},{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL}},{{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL},{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL},{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL}},{{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL},{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL},{0x2828CC1DL,0x43C4DB3DL,0x0B131C47L,0L,0x0B131C47L,0x43C4DB3DL}}};
                int i, j, k;
                l_818 = ((safe_rshift_func_int64_t_s_s((safe_sub_func_int32_t_s_s(((safe_sub_func_int32_t_s_s(l_794[0][2], 5UL)) | (g_795 , ((safe_mod_func_int8_t_s_s((**g_606), (safe_rshift_func_int16_t_s_s(((!(safe_rshift_func_uint8_t_u_u((safe_sub_func_int32_t_s_s(((g_69--) >= (((p_32 < (*l_33)) | 0x7AACL) >= ((*l_815) = (safe_lshift_func_int8_t_s_u((g_583 < ((safe_mul_func_int32_t_s_s((((**l_782) = (safe_mul_func_int16_t_s_s((l_813 = (1UL && p_32)), 0xE7CDL))) == p_32), 8UL)) != 0x430AL)), 1))))), p_32)), p_32))) < p_32), g_3[4])))) <= l_817))), p_32)), 35)) != 9UL);
                for (l_761.f1 = 0; (l_761.f1 <= 2); l_761.f1 += 1)
                { /* block id: 369 */
                    uint64_t *l_823 = (void*)0;
                    uint64_t **l_822 = &l_823;
                    uint64_t ***l_821 = &l_822;
                    uint64_t ****l_820 = &l_821;
                    uint64_t *****l_828 = &l_824[3];
                    int32_t l_830 = 0x372D476BL;
                    int16_t l_832[2];
                    int32_t l_833[6][8] = {{0x8D955545L,0L,0L,0xFA1ECC05L,0L,0L,(-3L),0xBCE0CBACL},{(-3L),0x4D4CB7F1L,0L,0x6BF0DDA9L,0x8D955545L,0xDD69F7A8L,(-3L),(-3L)},{0xE856541CL,0x6BF0DDA9L,0L,0L,0x6BF0DDA9L,0xE856541CL,0L,0x4D4CB7F1L},{0x6BF0DDA9L,0xE856541CL,0L,0x4D4CB7F1L,1L,0L,(-6L),1L},{0x4D4CB7F1L,(-3L),(-4L),0x4D4CB7F1L,0x8D955545L,0x32329CE2L,0x8D955545L,0x4D4CB7F1L},{0L,0x8D955545L,0L,0L,0xFA1ECC05L,0L,0L,(-3L)}};
                    uint32_t l_835 = 6UL;
                    int i, j;
                    for (i = 0; i < 2; i++)
                        l_832[i] = 3L;
                    (*l_33) ^= (g_819 , ((l_820 != ((*l_828) = l_824[3])) , (g_112 , p_32)));
                    for (l_813 = 0; (l_813 <= 8); l_813 += 1)
                    { /* block id: 374 */
                        int32_t l_829 = (-1L);
                        int32_t l_834 = 0xEB7BD005L;
                        int i;
                        if ((*g_11))
                            break;
                        ++l_835;
                    }
                }
            }
            else
            { /* block id: 379 */
                uint32_t l_849 = 1UL;
                int64_t *l_857[10][6] = {{(void*)0,&l_39[7][1],&l_39[8][2],(void*)0,&l_39[7][1],&l_39[8][2]},{&g_140,&l_39[0][4],&l_39[7][1],&l_39[7][1],&l_39[7][1],&l_39[0][4]},{(void*)0,&l_39[7][1],&l_39[8][0],&l_39[7][1],&l_39[7][1],&l_39[7][1]},{&g_140,&l_39[7][1],&l_39[8][0],(void*)0,&l_39[0][4],&l_39[0][4]},{&l_39[3][4],&l_39[7][1],&l_39[7][1],&l_39[3][4],&l_39[7][1],&l_39[8][2]},{&l_39[3][4],&l_39[7][1],&l_39[8][2],(void*)0,&l_39[7][1],&l_39[8][2]},{&g_140,&l_39[0][4],&l_39[7][1],&l_39[7][1],&l_39[7][1],&l_39[0][4]},{(void*)0,&l_39[7][1],&l_39[8][0],&l_39[7][1],&l_39[7][1],&l_39[7][1]},{&g_140,&l_39[7][1],&l_39[8][0],(void*)0,&l_39[0][4],&l_39[0][4]},{&l_39[3][4],&l_39[7][1],&l_39[7][1],&l_39[3][4],&l_39[7][1],&l_39[8][2]}};
                int32_t l_881 = 0xCE10137DL;
                int32_t l_884 = 0x93A09B3EL;
                int32_t *****l_896 = &l_758;
                int i, j;
                (*l_33) ^= ((safe_mul_func_int8_t_s_s(((safe_rshift_func_int64_t_s_s(g_648[4], 48)) , l_842), (((void*)0 == l_843) && (safe_mul_func_int8_t_s_s(p_32, ((safe_sub_func_int16_t_s_s(((g_718[6][1][4] , (((l_848 == (void*)0) < (&g_437[6] != (void*)0)) <= 246UL)) == p_32), p_32)) < l_849)))))) > (*g_607));
                l_884 |= ((l_849 != (safe_div_func_uint32_t_u_u(((~((1UL || ((safe_add_func_uint16_t_u_u(((**l_741)--), ((0x96E32777201B274FLL <= (l_787 |= 1L)) | p_32))) , (safe_unary_minus_func_uint64_t_u(((((((((((safe_rshift_func_int32_t_s_s((safe_div_func_uint8_t_u_u((safe_add_func_uint64_t_u_u(((void*)0 == l_865), (l_761 , (safe_rshift_func_uint64_t_u_s((safe_rshift_func_int16_t_s_u((safe_sub_func_int32_t_s_s(((g_882 = (g_140 = ((safe_sub_func_int16_t_s_s((safe_rshift_func_int64_t_s_u((l_881 &= (safe_rshift_func_int64_t_s_s(((((safe_rshift_func_uint32_t_u_u(((**g_606) == l_880), 31)) < g_492[6][2]) | l_723[5][0][3]) , p_32), 5))), 5)), 0x6529L)) <= (*g_91)))) & 6L), (-9L))), p_32)), l_883[0]))))), g_705)), p_32)) , (*g_237)) , g_492[1][0]) , p_32) > 18446744073709551615UL) == 0L) > g_816) && 4294967295UL) , p_32) ^ 2L))))) , 0x1FL)) <= 1L), g_83))) , p_32);
                for (g_34 = 8; (g_34 >= 2); g_34 -= 1)
                { /* block id: 389 */
                    int32_t *****l_895 = &l_758;
                    int32_t l_915 = 0xEA6C87DEL;
                    for (l_38 = 1; (l_38 <= 8); l_38 += 1)
                    { /* block id: 392 */
                        int32_t l_889[7];
                        int32_t * const l_890 = &l_717;
                        int i;
                        for (i = 0; i < 7; i++)
                            l_889[i] = 0x9CE4567EL;
                        (*l_890) &= (safe_lshift_func_int32_t_s_u(((((((l_889[4] = (l_786 ^= p_32)) ^ (l_890 != ((g_891 = p_32) , &l_787))) < (safe_mod_func_uint8_t_u_u(l_787, 1UL))) ^ 0x244EB791L) , ((safe_unary_minus_func_int32_t_s(p_32)) || (((l_895 = (void*)0) == l_896) , p_32))) ^ (**g_236)), g_450[0][6]));
                        l_915 ^= (safe_rshift_func_int32_t_s_s((*g_91), (((**l_741) = (safe_div_func_int32_t_s_s((((*l_68) ^= ((safe_sub_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((safe_add_func_uint64_t_u_u(0xD4676C880161BAECLL, (*l_890))), (safe_unary_minus_func_uint8_t_u(((((safe_div_func_uint32_t_u_u(l_910, g_911[0])) > (l_787 = (((safe_lshift_func_int16_t_s_s(g_404, ((((g_911[1] , g_101) , &g_10[5]) != &g_10[7]) < p_32))) , (void*)0) == l_914))) , (*g_607)) <= p_32))))), 0x96L)) >= (*g_5))) | 0x2CL), g_705))) <= 2UL)));
                        if (l_881)
                            goto lbl_725;
                    }
                }
            }
            l_918 = l_916;
        }
        else
        { /* block id: 407 */
            int32_t **l_919 = &l_37[1];
            int i;
            (*l_919) = (void*)0;
            if ((*g_5))
                break;
        }
        l_937[1] = ((safe_div_func_int64_t_s_s(((safe_mod_func_uint16_t_u_u(((&g_237 == ((*l_925) = l_924)) ^ g_911[0]), (((*l_936) ^= (safe_sub_func_int64_t_s_s(((*l_36) = g_3[2]), (((l_928 , g_929[1]) == &g_930) > ((safe_lshift_func_uint8_t_u_s(((*l_68) &= ((&g_237 == l_934) == p_32)), p_32)) && g_238))))) && 0xB92CL))) ^ 0x49L), (-6L))) , 0x98E749A7L);
    }
    return (*g_436);
}


/* ------------------------------------------ */
/* 
 * reads : g_404 g_5 g_3 g_34
 * writes: g_404 g_34
 */
static int32_t  func_43(uint32_t  p_44, int32_t ** p_45, uint32_t  p_46, union U0  p_47)
{ /* block id: 320 */
    int32_t l_722 = 2L;
    for (g_404 = (-26); (g_404 == 17); g_404++)
    { /* block id: 323 */
        int32_t *l_721 = &g_34;
        l_722 = ((*l_721) |= (*g_5));
    }
    return l_722;
}


/* ------------------------------------------ */
/* 
 * reads : g_91 g_34
 * writes: g_34
 */
static uint32_t  func_50(uint64_t  p_51)
{ /* block id: 12 */
    uint64_t l_89 = 0x68C1B86B2CC90326LL;
    uint64_t *l_96 = &l_89;
    int32_t l_99 = 0L;
    uint64_t *l_100 = &g_101;
    int32_t l_108 = (-3L);
    uint32_t *l_109 = &g_83;
    uint8_t *l_110 = &g_69;
    int8_t *l_111 = &g_112;
    uint32_t l_141 = 0x73E69D14L;
    union U1 *l_151 = &g_152;
    int32_t **l_166[4] = {&g_5,&g_5,&g_5,&g_5};
    const int32_t **l_172 = &g_11;
    int64_t l_203 = (-6L);
    int32_t l_273 = 0xEB052647L;
    int16_t l_327[9][7] = {{0L,0xB459L,0L,0xB459L,0L,0xB459L,0L},{0L,1L,1L,0L,0L,1L,1L},{0xC2A2L,0xB459L,0xC2A2L,0xB459L,0xC2A2L,0xB459L,0xC2A2L},{0L,0L,1L,1L,0L,0L,1L},{0L,0xB459L,0L,0xB459L,0L,0xB459L,0L},{0L,1L,1L,0L,0L,1L,1L},{0xC2A2L,0xB459L,0xC2A2L,0xB459L,0xC2A2L,0xB459L,0xC2A2L},{0L,0L,1L,1L,0L,0L,1L},{0L,0xB459L,0L,0xB459L,0L,0xB459L,0L}};
    int64_t l_347 = 0L;
    int16_t l_349 = 0xC102L;
    union U0 l_402 = {0x70D8B566L};
    union U0 l_503 = {1UL};
    int32_t l_546 = 0x754459D4L;
    uint16_t **l_574 = (void*)0;
    uint16_t *l_702[7];
    uint16_t **l_701[9][9][3] = {{{&l_702[2],(void*)0,&l_702[1]},{&l_702[2],&l_702[2],&l_702[0]},{(void*)0,&l_702[2],(void*)0},{&l_702[2],&l_702[0],&l_702[4]},{&l_702[2],&l_702[6],&l_702[2]},{&l_702[2],(void*)0,&l_702[6]},{(void*)0,(void*)0,&l_702[2]},{&l_702[2],&l_702[2],&l_702[2]},{&l_702[2],&l_702[3],&l_702[2]}},{{&l_702[2],&l_702[2],&l_702[2]},{&l_702[6],&l_702[2],(void*)0},{&l_702[2],(void*)0,&l_702[2]},{&l_702[2],&l_702[2],&l_702[1]},{&l_702[1],&l_702[6],&l_702[0]},{&l_702[0],&l_702[2],(void*)0},{&l_702[4],&l_702[1],&l_702[2]},{&l_702[0],&l_702[2],&l_702[6]},{&l_702[1],&l_702[3],&l_702[2]}},{{&l_702[2],&l_702[2],&l_702[2]},{&l_702[2],&l_702[2],&l_702[1]},{&l_702[6],&l_702[2],(void*)0},{&l_702[2],(void*)0,(void*)0},{&l_702[3],(void*)0,&l_702[3]},{&l_702[6],&l_702[2],&l_702[2]},{&l_702[4],&l_702[0],&l_702[0]},{&l_702[3],&l_702[2],&l_702[2]},{(void*)0,&l_702[2],(void*)0}},{{&l_702[1],&l_702[6],(void*)0},{&l_702[2],&l_702[2],&l_702[2]},{&l_702[3],(void*)0,(void*)0},{&l_702[2],&l_702[2],(void*)0},{(void*)0,(void*)0,&l_702[2]},{&l_702[2],&l_702[2],&l_702[5]},{&l_702[6],&l_702[2],&l_702[5]},{&l_702[1],&l_702[1],&l_702[2]},{&l_702[2],&l_702[3],(void*)0}},{{&l_702[3],&l_702[0],(void*)0},{&l_702[2],(void*)0,&l_702[2]},{&l_702[2],(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{&l_702[2],&l_702[3],&l_702[2]},{&l_702[4],&l_702[2],&l_702[0]},{(void*)0,(void*)0,&l_702[2]},{&l_702[2],&l_702[2],&l_702[3]},{&l_702[2],&l_702[0],(void*)0}},{{&l_702[2],(void*)0,&l_702[1]},{&l_702[2],&l_702[3],&l_702[2]},{&l_702[3],&l_702[2],&l_702[2]},{&l_702[2],(void*)0,(void*)0},{&l_702[2],&l_702[2],(void*)0},{(void*)0,&l_702[6],&l_702[2]},{&l_702[2],(void*)0,&l_702[3]},{(void*)0,&l_702[6],&l_702[3]},{&l_702[2],&l_702[2],&l_702[2]}},{{&l_702[2],(void*)0,&l_702[6]},{&l_702[6],&l_702[2],&l_702[2]},{&l_702[2],&l_702[3],&l_702[6]},{(void*)0,(void*)0,&l_702[3]},{(void*)0,&l_702[0],&l_702[0]},{&l_702[2],&l_702[2],(void*)0},{&l_702[2],(void*)0,(void*)0},{&l_702[3],&l_702[2],(void*)0},{&l_702[2],&l_702[3],&l_702[2]}},{{&l_702[0],(void*)0,&l_702[2]},{&l_702[6],(void*)0,(void*)0},{&l_702[2],(void*)0,(void*)0},{&l_702[4],&l_702[0],&l_702[4]},{&l_702[2],&l_702[3],&l_702[2]},{(void*)0,&l_702[1],&l_702[2]},{&l_702[0],&l_702[2],(void*)0},{&l_702[0],&l_702[2],&l_702[2]},{(void*)0,(void*)0,&l_702[1]}},{{&l_702[2],&l_702[2],&l_702[2]},{&l_702[4],(void*)0,&l_702[2]},{&l_702[2],&l_702[2],&l_702[2]},{&l_702[6],&l_702[6],&l_702[2]},{&l_702[0],&l_702[2],&l_702[2]},{&l_702[2],&l_702[2],&l_702[2]},{&l_702[3],&l_702[0],(void*)0},{&l_702[2],&l_702[2],&l_702[4]},{&l_702[2],(void*)0,&l_702[2]}}};
    uint8_t l_715 = 0UL;
    int16_t l_716 = 0x354EL;
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_702[i] = (void*)0;
    (*g_91) ^= (p_51 & (l_89 = (safe_lshift_func_uint8_t_u_u(0xCCL, 7))));
    return p_51;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_3[i], "g_3[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_83, "g_83", print_hash_value);
    transparent_crc(g_101, "g_101", print_hash_value);
    transparent_crc(g_112, "g_112", print_hash_value);
    transparent_crc(g_118, "g_118", print_hash_value);
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_146.f0, "g_146.f0", print_hash_value);
    transparent_crc(g_152.f0, "g_152.f0", print_hash_value);
    transparent_crc(g_153.f0, "g_153.f0", print_hash_value);
    transparent_crc(g_185, "g_185", print_hash_value);
    transparent_crc(g_220.f0, "g_220.f0", print_hash_value);
    transparent_crc(g_238, "g_238", print_hash_value);
    transparent_crc(g_302.f0, "g_302.f0", print_hash_value);
    transparent_crc(g_404, "g_404", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_450[i][j], "g_450[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_491[i], "g_491[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_492[i][j], "g_492[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_583, "g_583", print_hash_value);
    transparent_crc(g_646, "g_646", print_hash_value);
    transparent_crc(g_647, "g_647", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_648[i], "g_648[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_649[i], "g_649[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_705, "g_705", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_718[i][j][k].f0, "g_718[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_785, "g_785", print_hash_value);
    transparent_crc(g_795.f0, "g_795.f0", print_hash_value);
    transparent_crc(g_816, "g_816", print_hash_value);
    transparent_crc(g_819.f0, "g_819.f0", print_hash_value);
    transparent_crc(g_882, "g_882", print_hash_value);
    transparent_crc(g_891, "g_891", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_911[i], "g_911[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_931, "g_931", print_hash_value);
    transparent_crc(g_1326, "g_1326", print_hash_value);
    transparent_crc(g_1330, "g_1330", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_1348[i][j][k], "g_1348[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1381.f0, "g_1381.f0", print_hash_value);
    transparent_crc(g_1456, "g_1456", print_hash_value);
    transparent_crc(g_1534, "g_1534", print_hash_value);
    transparent_crc(g_1577.f0, "g_1577.f0", print_hash_value);
    transparent_crc(g_1645.f0, "g_1645.f0", print_hash_value);
    transparent_crc(g_1695, "g_1695", print_hash_value);
    transparent_crc(g_1700.f0, "g_1700.f0", print_hash_value);
    transparent_crc(g_1737, "g_1737", print_hash_value);
    transparent_crc(g_1828, "g_1828", print_hash_value);
    transparent_crc(g_1836.f0, "g_1836.f0", print_hash_value);
    transparent_crc(g_1870.f0, "g_1870.f0", print_hash_value);
    transparent_crc(g_1897.f0, "g_1897.f0", print_hash_value);
    transparent_crc(g_1954.f0, "g_1954.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2038[i], "g_2038[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2046.f0, "g_2046.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2097[i], "g_2097[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2194, "g_2194", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_2271[i].f0, "g_2271[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2308.f0, "g_2308.f0", print_hash_value);
    transparent_crc(g_2607, "g_2607", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 686
XXX total union variables: 34

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 48
breakdown:
   indirect level: 0, occurrence: 14
   indirect level: 1, occurrence: 14
   indirect level: 2, occurrence: 7
   indirect level: 3, occurrence: 5
   indirect level: 4, occurrence: 5
   indirect level: 5, occurrence: 3
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 11
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 15
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 27

XXX max expression depth: 51
breakdown:
   depth: 1, occurrence: 68
   depth: 2, occurrence: 17
   depth: 3, occurrence: 4
   depth: 4, occurrence: 2
   depth: 6, occurrence: 1
   depth: 8, occurrence: 1
   depth: 14, occurrence: 1
   depth: 16, occurrence: 2
   depth: 17, occurrence: 2
   depth: 18, occurrence: 2
   depth: 20, occurrence: 1
   depth: 21, occurrence: 1
   depth: 22, occurrence: 1
   depth: 23, occurrence: 1
   depth: 28, occurrence: 1
   depth: 36, occurrence: 1
   depth: 39, occurrence: 1
   depth: 43, occurrence: 1
   depth: 51, occurrence: 1

XXX total number of pointers: 557

XXX times a variable address is taken: 1020
XXX times a pointer is dereferenced on RHS: 468
breakdown:
   depth: 1, occurrence: 267
   depth: 2, occurrence: 183
   depth: 3, occurrence: 18
XXX times a pointer is dereferenced on LHS: 332
breakdown:
   depth: 1, occurrence: 279
   depth: 2, occurrence: 51
   depth: 3, occurrence: 1
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 52
XXX times a pointer is compared with address of another variable: 9
XXX times a pointer is compared with another pointer: 22
XXX times a pointer is qualified to be dereferenced: 12000

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1165
   level: 2, occurrence: 479
   level: 3, occurrence: 263
   level: 4, occurrence: 144
   level: 5, occurrence: 17
XXX number of pointers point to pointers: 265
XXX number of pointers point to scalars: 265
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 29.1
XXX average alias set size: 1.36

XXX times a non-volatile is read: 2451
XXX times a non-volatile is write: 1058
XXX times a volatile is read: 144
XXX    times read thru a pointer: 44
XXX times a volatile is write: 11
XXX    times written thru a pointer: 2
XXX times a volatile is available for access: 8.49e+03
XXX percentage of non-volatile access: 95.8

XXX forward jumps: 0
XXX backward jumps: 5

XXX stmts: 74
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 27
   depth: 1, occurrence: 16
   depth: 2, occurrence: 8
   depth: 3, occurrence: 8
   depth: 4, occurrence: 6
   depth: 5, occurrence: 9

XXX percentage a fresh-made variable is used: 14.7
XXX percentage an existing variable is used: 85.3
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

