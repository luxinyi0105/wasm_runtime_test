/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      1325244326
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0x7E2799ACL;/* VOLATILE GLOBAL g_2 */
static int32_t g_3[4][5] = {{2L,(-6L),0x12B57E8BL,0x12B57E8BL,(-6L)},{0xCEFA9D19L,0x2FD4914DL,0x6A162C9CL,0x6A162C9CL,0x2FD4914DL},{2L,(-6L),0x12B57E8BL,0x12B57E8BL,(-6L)},{0xCEFA9D19L,0x2FD4914DL,0x6A162C9CL,0x6A162C9CL,0x2FD4914DL}};
static int32_t g_57 = 0x7F6F8F64L;
static int16_t g_73[3][3][8] = {{{0x7B04L,0L,0L,0x7B04L,0xEF05L,0L,(-8L),0xEF05L},{0x7B04L,(-8L),0x285EL,0x7B04L,0x7B04L,0x285EL,(-8L),0x7B04L},{0xEF05L,(-8L),0L,0xEF05L,0x7B04L,0L,0L,0x7B04L}},{{0x7B04L,0L,0x285EL,0xEF05L,0x34E2L,0x285EL,0L,0x34E2L},{0xEF05L,0L,(-8L),0xEF05L,0xEF05L,(-8L),0L,0xEF05L},{0x34E2L,0L,0x285EL,0x34E2L,0xEF05L,0x285EL,0x285EL,0xEF05L}},{{0xEF05L,0x285EL,0x285EL,0xEF05L,0x34E2L,0x285EL,0L,0x34E2L},{0xEF05L,0L,(-8L),0xEF05L,0xEF05L,(-8L),0L,0xEF05L},{0x34E2L,0L,0x285EL,0x34E2L,0xEF05L,0x285EL,0x285EL,0xEF05L}}};
static int8_t g_74 = 0xC6L;
static uint64_t g_77[5][7][5] = {{{0x18E11B1975C8F0ABLL,1UL,1UL,0x18E11B1975C8F0ABLL,1UL},{0x2693068B84F8C038LL,18446744073709551615UL,0x2693068B84F8C038LL,1UL,0x2693068B84F8C038LL},{0x18E11B1975C8F0ABLL,0x18E11B1975C8F0ABLL,0UL,1UL,1UL},{0x2345427DA897626FLL,1UL,0x7E171BA0D895055DLL,1UL,0x2345427DA897626FLL},{1UL,1UL,0UL,0x18E11B1975C8F0ABLL,0x18E11B1975C8F0ABLL},{0x2693068B84F8C038LL,1UL,0x2693068B84F8C038LL,18446744073709551615UL,0x2693068B84F8C038LL},{1UL,0x18E11B1975C8F0ABLL,1UL,1UL,0x18E11B1975C8F0ABLL}},{{0x2345427DA897626FLL,18446744073709551615UL,0x7E171BA0D895055DLL,18446744073709551615UL,0x2345427DA897626FLL},{0x18E11B1975C8F0ABLL,1UL,1UL,0x18E11B1975C8F0ABLL,1UL},{0x2693068B84F8C038LL,18446744073709551615UL,0x2693068B84F8C038LL,1UL,0x2693068B84F8C038LL},{0x18E11B1975C8F0ABLL,0x18E11B1975C8F0ABLL,0UL,1UL,1UL},{0x2345427DA897626FLL,1UL,0x7E171BA0D895055DLL,1UL,0x2345427DA897626FLL},{1UL,1UL,0UL,0x18E11B1975C8F0ABLL,0x18E11B1975C8F0ABLL},{0x2693068B84F8C038LL,1UL,0x2693068B84F8C038LL,18446744073709551615UL,0x2693068B84F8C038LL}},{{1UL,0x18E11B1975C8F0ABLL,1UL,1UL,0x18E11B1975C8F0ABLL},{0x2345427DA897626FLL,18446744073709551615UL,0x7E171BA0D895055DLL,18446744073709551615UL,0x2345427DA897626FLL},{0x18E11B1975C8F0ABLL,1UL,1UL,0x18E11B1975C8F0ABLL,1UL},{0x2693068B84F8C038LL,18446744073709551615UL,0x2693068B84F8C038LL,1UL,0x2693068B84F8C038LL},{0x18E11B1975C8F0ABLL,0x18E11B1975C8F0ABLL,0UL,1UL,1UL},{0x2345427DA897626FLL,1UL,0x7E171BA0D895055DLL,1UL,0x2345427DA897626FLL},{1UL,1UL,0UL,0x18E11B1975C8F0ABLL,0x18E11B1975C8F0ABLL}},{{0x2693068B84F8C038LL,1UL,0x2693068B84F8C038LL,18446744073709551615UL,0x2693068B84F8C038LL},{1UL,0x18E11B1975C8F0ABLL,1UL,1UL,0x18E11B1975C8F0ABLL},{0x2345427DA897626FLL,18446744073709551615UL,0x7E171BA0D895055DLL,18446744073709551615UL,0x2345427DA897626FLL},{0x18E11B1975C8F0ABLL,1UL,1UL,0x18E11B1975C8F0ABLL,1UL},{0x2693068B84F8C038LL,18446744073709551615UL,0x2693068B84F8C038LL,1UL,0x2693068B84F8C038LL},{0x18E11B1975C8F0ABLL,0x18E11B1975C8F0ABLL,0UL,1UL,1UL},{0x2345427DA897626FLL,1UL,0x7E171BA0D895055DLL,1UL,0x2345427DA897626FLL}},{{1UL,1UL,0UL,0x18E11B1975C8F0ABLL,0x18E11B1975C8F0ABLL},{0x2693068B84F8C038LL,1UL,0x2693068B84F8C038LL,18446744073709551615UL,0x2693068B84F8C038LL},{1UL,0x18E11B1975C8F0ABLL,1UL,1UL,0x18E11B1975C8F0ABLL},{0x2345427DA897626FLL,18446744073709551615UL,0x7E171BA0D895055DLL,18446744073709551615UL,0x2345427DA897626FLL},{0x18E11B1975C8F0ABLL,1UL,1UL,0x18E11B1975C8F0ABLL,1UL},{0x2693068B84F8C038LL,18446744073709551615UL,0x2693068B84F8C038LL,1UL,0x2693068B84F8C038LL},{0x18E11B1975C8F0ABLL,0x18E11B1975C8F0ABLL,0UL,1UL,1UL}}};
static const int32_t *g_89 = &g_3[3][0];
static const int32_t **g_88 = &g_89;
static int32_t *g_100[3][9] = {{&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1]},{&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1]},{&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1],&g_3[0][1]}};
static int32_t **g_99 = &g_100[2][6];
static int32_t ***g_98 = &g_99;
static uint32_t g_125 = 7UL;
static uint64_t g_127[7][1] = {{5UL},{0xEB154EA432D78657LL},{5UL},{0xEB154EA432D78657LL},{5UL},{0xEB154EA432D78657LL},{5UL}};
static uint32_t g_134 = 1UL;
static uint16_t g_138 = 2UL;
static uint8_t g_215 = 0x88L;
static int8_t g_218 = 0x1DL;
static int64_t g_265 = 0x520F47FAEE1063A2LL;
static uint16_t *g_294 = &g_138;
static volatile int32_t ** const  volatile **g_301[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static volatile int32_t ** const  volatile ***g_300[9][6] = {{&g_301[1],&g_301[3],&g_301[0],&g_301[2],&g_301[0],&g_301[1]},{&g_301[1],&g_301[0],&g_301[2],&g_301[3],&g_301[2],&g_301[0]},{&g_301[4],&g_301[0],(void*)0,&g_301[5],&g_301[0],&g_301[0]},{&g_301[2],&g_301[4],&g_301[3],(void*)0,&g_301[0],&g_301[2]},{&g_301[5],&g_301[4],(void*)0,&g_301[0],&g_301[0],(void*)0},{&g_301[0],&g_301[0],&g_301[4],&g_301[0],&g_301[2],&g_301[1]},{&g_301[3],&g_301[0],&g_301[1],&g_301[2],&g_301[0],&g_301[4]},{&g_301[0],&g_301[3],&g_301[1],&g_301[1],&g_301[0],&g_301[1]},{&g_301[4],&g_301[1],&g_301[4],&g_301[0],&g_301[1],(void*)0}};
static volatile int8_t g_304 = 0x07L;/* VOLATILE GLOBAL g_304 */
static const volatile int8_t * volatile g_303[4] = {&g_304,&g_304,&g_304,&g_304};
static const volatile int8_t * volatile *g_302 = &g_303[0];
static int64_t g_337 = 0x98669F6CD55B524CLL;
static int8_t g_378 = (-1L);
static int64_t *g_387[9][9][3] = {{{&g_337,&g_265,&g_265},{(void*)0,&g_337,(void*)0},{&g_337,&g_265,(void*)0},{&g_337,&g_265,&g_265},{&g_265,&g_265,&g_265},{&g_265,&g_265,&g_265},{&g_337,(void*)0,&g_265},{&g_337,(void*)0,&g_337},{(void*)0,&g_265,&g_265}},{{&g_337,(void*)0,&g_337},{&g_337,(void*)0,&g_337},{&g_265,&g_265,(void*)0},{(void*)0,&g_265,(void*)0},{&g_337,&g_265,&g_337},{&g_265,&g_265,&g_337},{&g_265,&g_337,&g_265},{&g_265,&g_265,&g_337},{&g_265,&g_337,&g_265}},{{&g_265,&g_337,&g_265},{&g_337,(void*)0,&g_265},{(void*)0,(void*)0,&g_337},{(void*)0,&g_337,&g_265},{&g_265,&g_265,(void*)0},{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,&g_265},{&g_337,&g_265,&g_337}},{{&g_265,&g_265,&g_265},{&g_265,&g_337,&g_265},{&g_337,&g_265,(void*)0},{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,&g_265},{&g_265,&g_265,&g_337},{(void*)0,&g_337,&g_337},{&g_265,&g_265,&g_337}},{{&g_265,&g_265,&g_337},{&g_337,(void*)0,&g_265},{&g_265,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0},{&g_265,&g_265,(void*)0},{&g_337,&g_337,&g_265},{&g_265,&g_337,&g_265},{&g_265,&g_337,&g_337},{(void*)0,&g_337,&g_265}},{{&g_265,&g_265,(void*)0},{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,&g_265},{&g_337,&g_265,&g_337},{&g_265,&g_265,&g_265},{&g_265,&g_337,&g_265},{&g_337,&g_265,(void*)0},{&g_265,(void*)0,(void*)0}},{{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,&g_265},{&g_265,&g_265,&g_337},{(void*)0,&g_337,&g_337},{&g_265,&g_265,&g_337},{&g_265,&g_265,&g_337},{&g_337,(void*)0,&g_265},{&g_265,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0}},{{&g_265,&g_265,(void*)0},{&g_337,&g_337,&g_265},{&g_265,&g_337,&g_265},{&g_265,&g_337,&g_337},{(void*)0,&g_337,&g_265},{&g_265,&g_265,(void*)0},{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,&g_265}},{{&g_337,&g_265,&g_337},{&g_265,&g_265,&g_265},{&g_265,&g_337,&g_265},{&g_337,&g_265,(void*)0},{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,(void*)0},{&g_265,(void*)0,&g_265},{&g_265,&g_265,&g_337},{(void*)0,&g_337,&g_337}}};
static uint8_t g_392 = 0UL;
static uint32_t *g_468[3][6] = {{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125},{&g_125,&g_125,&g_125,&g_125,&g_125,&g_125}};
static uint32_t **g_467 = &g_468[0][2];
static uint64_t g_478[10] = {0xF80A275DAFDDA69ALL,18446744073709551609UL,18446744073709551609UL,0xF80A275DAFDDA69ALL,18446744073709551609UL,18446744073709551609UL,0xF80A275DAFDDA69ALL,18446744073709551609UL,18446744073709551609UL,0xF80A275DAFDDA69ALL};
static int32_t g_543 = 0xF2905774L;
static const int32_t ***g_551 = &g_88;
static const int32_t ****g_550 = &g_551;
static uint64_t g_605 = 0UL;
static uint16_t g_629 = 65530UL;
static int16_t g_657 = 0x2AF2L;
static volatile uint64_t g_717 = 0x87D59BA9CAA82B8FLL;/* VOLATILE GLOBAL g_717 */
static volatile uint64_t *g_716 = &g_717;
static volatile uint64_t ** const g_715 = &g_716;
static int32_t g_751 = 4L;
static int64_t g_777 = 0xF72752CC2196CD90LL;
static volatile int32_t g_892[10] = {1L,1L,1L,1L,1L,1L,1L,1L,1L,1L};
static volatile int32_t *g_891 = &g_892[1];
static volatile int32_t ** volatile g_890 = &g_891;/* VOLATILE GLOBAL g_890 */
static volatile int32_t ** volatile * volatile g_889[2] = {&g_890,&g_890};
static volatile int32_t ** volatile * volatile *g_888 = &g_889[0];
static int32_t ****g_896 = (void*)0;
static int32_t *****g_895 = &g_896;
static int32_t g_901[1] = {1L};
static uint32_t ***g_914 = &g_467;
static uint32_t ****g_913 = &g_914;
static uint8_t * volatile g_935 = &g_215;/* VOLATILE GLOBAL g_935 */
static uint8_t * volatile *g_934 = &g_935;
static const int16_t * volatile g_987 = &g_657;/* VOLATILE GLOBAL g_987 */
static const int16_t * volatile *g_986 = &g_987;
static int8_t g_1005 = 6L;
static uint64_t *g_1026 = &g_127[4][0];
static uint64_t **g_1025 = &g_1026;
static uint8_t *g_1081[3] = {&g_392,&g_392,&g_392};
static int64_t g_1122 = 0x4B6C3FFF9B534E68LL;
static int32_t g_1123 = 0xEFB684C8L;
static volatile int32_t g_1164[9] = {(-1L),(-1L),0x8EC0ADFFL,(-1L),(-1L),0x8EC0ADFFL,(-1L),(-1L),0x8EC0ADFFL};
static volatile int32_t *g_1163 = &g_1164[6];
static uint16_t g_1230 = 65529UL;
static uint64_t ***g_1278 = (void*)0;
static const int32_t *g_1340 = &g_901[0];
static const int32_t **g_1339 = &g_1340;
static const int32_t ** volatile * const g_1338 = &g_1339;
static uint8_t g_1407 = 0x46L;
static int16_t *g_1448 = &g_73[1][1][7];
static int16_t **g_1447[7] = {&g_1448,&g_1448,&g_1448,&g_1448,&g_1448,&g_1448,&g_1448};
static uint32_t g_1476 = 1UL;
static int8_t *g_1494 = &g_218;
static int8_t * volatile *g_1493[7][5] = {{&g_1494,&g_1494,&g_1494,&g_1494,&g_1494},{&g_1494,&g_1494,&g_1494,&g_1494,&g_1494},{&g_1494,&g_1494,&g_1494,&g_1494,&g_1494},{&g_1494,&g_1494,&g_1494,&g_1494,&g_1494},{&g_1494,&g_1494,&g_1494,&g_1494,&g_1494},{&g_1494,&g_1494,&g_1494,&g_1494,&g_1494},{&g_1494,&g_1494,&g_1494,&g_1494,&g_1494}};
static int8_t * volatile * volatile *g_1492[7] = {&g_1493[1][3],&g_1493[1][3],&g_1493[5][0],&g_1493[1][3],&g_1493[1][3],&g_1493[5][0],&g_1493[1][3]};
static int8_t * volatile * volatile **g_1491 = &g_1492[3];
static int8_t * volatile * volatile ***g_1490 = &g_1491;
static int8_t *g_1501 = &g_378;
static int8_t **g_1500[3][10] = {{&g_1494,&g_1501,&g_1501,&g_1494,&g_1501,&g_1501,&g_1494,&g_1501,&g_1501,&g_1494},{&g_1501,&g_1494,&g_1501,&g_1501,&g_1494,&g_1501,&g_1501,&g_1494,&g_1501,&g_1501},{&g_1494,&g_1494,&g_1501,&g_1494,&g_1494,&g_1501,&g_1494,&g_1494,&g_1501,&g_1494}};
static volatile uint16_t g_1507 = 5UL;/* VOLATILE GLOBAL g_1507 */
static volatile uint16_t *g_1506 = &g_1507;
static volatile uint16_t **g_1505 = &g_1506;
static volatile uint16_t ***g_1504 = &g_1505;
static int32_t **g_1649 = (void*)0;
static int32_t g_1690 = (-7L);
static uint16_t g_1743 = 0x8BCFL;
static int32_t g_1862 = (-6L);
static int16_t ***g_1935 = &g_1447[5];
static int16_t ****g_1934 = &g_1935;
static int16_t *****g_1933[1] = {&g_1934};
static int16_t *****g_1937[1][1][10] = {{{(void*)0,&g_1934,&g_1934,&g_1934,(void*)0,(void*)0,&g_1934,&g_1934,&g_1934,(void*)0}}};
static int8_t g_2016[8][6] = {{1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L}};
static uint8_t ***g_2110 = (void*)0;
static uint8_t ****g_2109 = &g_2110;
static uint8_t *****g_2108 = &g_2109;
static int8_t *****g_2124 = (void*)0;
static int8_t g_2263 = 0x21L;
static int8_t g_2312 = 0L;
static uint32_t g_2329 = 0x0F50A32FL;
static int8_t g_2374 = 0L;
static int32_t ** const *g_2421[10][5][3] = {{{&g_99,&g_1649,&g_99},{(void*)0,&g_99,(void*)0},{&g_99,&g_99,&g_1649},{(void*)0,&g_99,&g_1649},{&g_1649,(void*)0,&g_99}},{{&g_1649,&g_1649,&g_1649},{&g_1649,&g_99,&g_99},{&g_1649,&g_99,&g_99},{&g_1649,&g_99,&g_99},{(void*)0,&g_1649,&g_99}},{{&g_1649,(void*)0,&g_99},{(void*)0,&g_99,&g_1649},{&g_1649,(void*)0,&g_99},{&g_1649,&g_1649,&g_1649},{&g_1649,&g_99,&g_99}},{{&g_1649,&g_99,&g_99},{&g_1649,&g_99,&g_99},{(void*)0,&g_1649,&g_99},{&g_1649,(void*)0,&g_99},{(void*)0,&g_99,&g_1649}},{{&g_1649,(void*)0,&g_99},{&g_1649,&g_1649,&g_1649},{&g_1649,&g_99,&g_99},{&g_1649,&g_99,&g_99},{&g_1649,&g_99,&g_99}},{{(void*)0,&g_1649,&g_99},{&g_1649,(void*)0,&g_99},{(void*)0,&g_99,&g_1649},{&g_1649,(void*)0,&g_99},{&g_1649,&g_1649,&g_1649}},{{&g_1649,&g_99,&g_99},{&g_1649,&g_99,&g_99},{&g_1649,&g_99,&g_99},{(void*)0,&g_1649,&g_99},{&g_1649,(void*)0,&g_99}},{{(void*)0,&g_99,&g_1649},{&g_1649,(void*)0,&g_99},{&g_1649,&g_1649,&g_1649},{&g_1649,&g_99,&g_99},{&g_1649,&g_99,&g_99}},{{&g_1649,&g_99,&g_99},{(void*)0,&g_1649,&g_99},{&g_1649,(void*)0,&g_99},{(void*)0,&g_99,&g_1649},{&g_1649,(void*)0,&g_99}},{{&g_1649,&g_1649,&g_1649},{&g_1649,&g_99,&g_99},{&g_1649,&g_99,&g_99},{&g_1649,&g_99,&g_99},{(void*)0,&g_1649,&g_99}}};
static int32_t ** const **g_2420 = &g_2421[0][4][2];
static uint32_t g_2545[6][5][2] = {{{0UL,0UL},{0UL,0x6566D166L},{0xCA70D27AL,0UL},{0x6566D166L,0UL},{0xCA70D27AL,0x6566D166L}},{{0UL,0UL},{0UL,0x6566D166L},{0xCA70D27AL,0UL},{0x6566D166L,0UL},{0xCA70D27AL,0x6566D166L}},{{0UL,0UL},{0UL,0x6566D166L},{0xCA70D27AL,0UL},{0x6566D166L,0UL},{0xCA70D27AL,0x6566D166L}},{{0UL,0UL},{0UL,0x6566D166L},{0xCA70D27AL,0UL},{0x6566D166L,0UL},{0xCA70D27AL,0x6566D166L}},{{0UL,0UL},{0UL,0x6566D166L},{0xCA70D27AL,0UL},{0x6566D166L,0UL},{0xCA70D27AL,0x6566D166L}},{{0UL,0x6566D166L},{0x6566D166L,0xCA70D27AL},{8UL,0UL},{0xCA70D27AL,0UL},{8UL,0xCA70D27AL}}};
static uint32_t g_2591 = 0xCD0A83E6L;
static int8_t g_2605 = 0x86L;
static int32_t ** const *g_2727 = (void*)0;
static uint16_t g_2828[5] = {0xFBEDL,0xFBEDL,0xFBEDL,0xFBEDL,0xFBEDL};
static int8_t g_2963[8][7] = {{0L,0x78L,0xFCL,0x78L,0L,0x0DL,0x0DL},{8L,(-5L),0xE3L,(-5L),8L,0x35L,0x35L},{0L,0x78L,0xFCL,0x78L,0L,0x0DL,0x0DL},{8L,(-5L),0xE3L,(-5L),8L,0x35L,0x35L},{0L,0x78L,0xFCL,0x78L,0L,0x0DL,0x0DL},{8L,(-5L),0xE3L,(-5L),8L,0x35L,0x35L},{0L,0x78L,0xFCL,0x78L,0L,0x0DL,0x0DL},{8L,(-5L),0xE3L,(-5L),8L,0x35L,0x35L}};
static int8_t * const g_2962 = &g_2963[1][6];
static int8_t * const *g_2961 = &g_2962;
static int8_t * const **g_2960 = &g_2961;
static int8_t * const ***g_2959 = &g_2960;
static uint16_t * const *g_3038 = (void*)0;
static uint16_t g_3042 = 0UL;
static int8_t ***g_3045 = &g_1500[2][7];
static int8_t ****g_3044 = &g_3045;
static const int64_t g_3072 = (-1L);
static const int64_t *g_3071[2] = {&g_3072,&g_3072};
static const int64_t g_3074[2] = {(-1L),(-1L)};
static int64_t g_3092 = 1L;


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static uint64_t  func_9(int64_t  p_10);
static int64_t  func_14(int8_t  p_15, int32_t  p_16, uint32_t  p_17);
static int16_t  func_33(const uint16_t  p_34, const uint64_t  p_35);
static uint32_t  func_36(const uint16_t  p_37, int8_t  p_38, int16_t  p_39);
static int16_t  func_46(int8_t  p_47, uint8_t  p_48);
static int8_t  func_49(int8_t  p_50);
static int32_t  func_52(int64_t  p_53);
static int64_t  func_80(const int32_t ** p_81, int32_t  p_82);
static const int32_t ** func_83(int32_t ** p_84);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2263 g_934 g_935 g_215
 * writes: g_3 g_2263
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_6 = 0x8819570AL;
    uint16_t l_51 = 2UL;
    uint32_t l_2473 = 0xC052D250L;
    const uint64_t l_2595 = 18446744073709551607UL;
    int32_t *l_2897 = &g_3[1][3];
    int32_t l_2923 = 9L;
    int8_t * const *l_2957[8] = {&g_1501,&g_1501,&g_1501,&g_1501,&g_1501,&g_1501,&g_1501,&g_1501};
    int8_t * const **l_2956 = &l_2957[5];
    int8_t * const ***l_2955 = &l_2956;
    int32_t l_2964 = 0L;
    uint64_t *l_3011[5];
    int8_t l_3018 = 0L;
    const int64_t *l_3073[5][10] = {{&g_3072,(void*)0,&g_3074[0],&g_3074[0],&g_3072,&g_3072,(void*)0,&g_3074[1],(void*)0,&g_3074[1]},{&g_3074[0],&g_3074[1],&g_3074[0],&g_3072,&g_3074[0],&g_3074[1],&g_3074[0],&g_3074[1],&g_3074[0],&g_3072},{(void*)0,(void*)0,&g_3074[0],(void*)0,(void*)0,&g_3074[0],&g_3074[1],(void*)0,(void*)0,&g_3074[1]},{(void*)0,(void*)0,&g_3074[1],&g_3074[1],(void*)0,(void*)0,&g_3074[0],&g_3072,&g_3072,&g_3074[0]},{&g_3072,&g_3074[1],&g_3072,(void*)0,(void*)0,&g_3072,(void*)0,&g_3074[0],(void*)0,&g_3072}};
    int32_t ***l_3091[8] = {&g_99,&g_99,&g_99,&g_99,&g_99,&g_99,&g_99,&g_99};
    uint8_t *l_3154 = &g_392;
    uint8_t ***** const l_3161 = &g_2109;
    int i, j;
    for (i = 0; i < 5; i++)
        l_3011[i] = (void*)0;
    for (g_3[0][1] = 0; (g_3[0][1] <= 16); g_3[0][1]++)
    { /* block id: 3 */
        uint32_t l_11[3][2][7] = {{{0xA592C6EEL,0xECF04B06L,3UL,3UL,0xECF04B06L,0xA592C6EEL,0xECF04B06L},{0x1E12AA53L,0xA592C6EEL,0xA592C6EEL,0x1E12AA53L,0xECF04B06L,0x1E12AA53L,0xA592C6EEL}},{{0xF9C71042L,0xF9C71042L,0xA592C6EEL,3UL,0xA592C6EEL,0xF9C71042L,0xF9C71042L},{0xF9C71042L,0xA592C6EEL,3UL,0xA592C6EEL,0xF9C71042L,0xF9C71042L,0xA592C6EEL}},{{0x1E12AA53L,0xECF04B06L,0x1E12AA53L,0xA592C6EEL,0xA592C6EEL,0x1E12AA53L,0xECF04B06L},{0xA592C6EEL,0xECF04B06L,3UL,3UL,0xECF04B06L,0xA592C6EEL,0xECF04B06L}}};
        int16_t *l_1235 = (void*)0;
        int16_t *l_1236[9];
        uint16_t l_2474 = 6UL;
        int32_t l_2596 = (-10L);
        int32_t *l_2892 = (void*)0;
        int32_t *l_2893 = (void*)0;
        int32_t *l_2894 = (void*)0;
        int32_t *l_2895 = &g_751;
        int32_t *****l_2912[5] = {&g_896,&g_896,&g_896,&g_896,&g_896};
        uint32_t *** const *l_2916[9];
        int8_t l_2929[9] = {(-4L),(-8L),(-8L),(-8L),0x06L,0x06L,(-8L),0x06L,0x06L};
        int i, j, k;
        for (i = 0; i < 9; i++)
            l_1236[i] = (void*)0;
        for (i = 0; i < 9; i++)
            l_2916[i] = (void*)0;
        if (l_6)
            break;
    }
    for (g_2263 = 0; (g_2263 > (-7)); g_2263--)
    { /* block id: 1403 */
        int32_t ***l_2954 = (void*)0;
        int32_t ****l_2953 = &l_2954;
        int8_t * const ****l_2958[5][7][2] = {{{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955}},{{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955}},{{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955}},{{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955}},{{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955},{&l_2955,&l_2955}}};
        int32_t l_2988 = 1L;
        int32_t *****l_2997 = &g_896;
        uint64_t l_3007 = 0x60E95EF701450209LL;
        uint32_t l_3019 = 0x0801DDBBL;
        int16_t **** const l_3020[8][1][10] = {{{&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935}},{{&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0}},{{&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935}},{{&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0}},{{&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935}},{{&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0}},{{&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935}},{{&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0,(void*)0,&g_1935,&g_1935,(void*)0}}};
        uint32_t *****l_3062 = &g_913;
        uint64_t l_3096 = 0xFBCB40F6784E6C4ALL;
        int8_t l_3145[6];
        int32_t l_3149 = 5L;
        uint8_t *l_3153 = &g_1407;
        int64_t **l_3165 = (void*)0;
        int64_t *** const l_3164 = &l_3165;
        uint8_t l_3167 = 0x28L;
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_3145[i] = (-1L);
    }
    return (**g_934);
}


/* ------------------------------------------ */
/* 
 * reads : g_550 g_551 g_88 g_3
 * writes: g_89
 */
static uint64_t  func_9(int64_t  p_10)
{ /* block id: 1354 */
    int32_t *l_2896 = &g_3[3][1];
    (***g_550) = l_2896;
    return (*l_2896);
}


/* ------------------------------------------ */
/* 
 * reads : g_1025 g_1026 g_127 g_890 g_891 g_1490 g_1491 g_294 g_138 g_1935 g_1447 g_1448 g_73 g_543 g_3 g_888 g_889 g_892 g_1492 g_1493 g_1494 g_1504 g_1505 g_1506 g_1507 g_934 g_935 g_215 g_467 g_134 g_77 g_1934 g_57 g_2727 g_914 g_468 g_716 g_717 g_1338 g_1339 g_1340 g_550 g_551 g_88 g_751 g_2828 g_1163 g_1164
 * writes: g_543 g_777 g_138 g_215 g_218 g_892 g_468 g_73 g_134 g_1407 g_127 g_57 g_2727 g_125 g_657 g_89 g_751 g_1476
 */
static int64_t  func_14(int8_t  p_15, int32_t  p_16, uint32_t  p_17)
{ /* block id: 1227 */
    int8_t l_2597 = 0L;
    int32_t l_2598 = 0x4560FC33L;
    int32_t l_2599[3][1];
    int32_t *l_2600 = &g_543;
    int32_t *l_2601 = &l_2599[2][0];
    int32_t *l_2602[1][8][9] = {{{(void*)0,(void*)0,&l_2599[2][0],(void*)0,&l_2599[2][0],(void*)0,(void*)0,&l_2599[2][0],&l_2599[2][0]},{&g_57,&g_3[0][1],(void*)0,&g_57,(void*)0,&g_3[0][1],&g_57,&g_751,&g_751},{(void*)0,(void*)0,&l_2599[2][0],(void*)0,&l_2599[2][0],(void*)0,(void*)0,&l_2599[2][0],&l_2599[2][0]},{&g_57,&g_3[0][1],(void*)0,&g_57,(void*)0,&g_3[0][1],&g_57,&g_751,&g_543},{&l_2599[2][0],&g_3[3][3],&g_543,&l_2599[2][0],&g_543,&g_3[3][3],&l_2599[2][0],&l_2599[2][0],&l_2599[2][0]},{&g_751,(void*)0,(void*)0,&g_751,(void*)0,(void*)0,&g_751,&g_543,&g_543},{&l_2599[2][0],&g_3[3][3],&g_543,&l_2599[2][0],&g_543,&g_3[3][3],&l_2599[2][0],&l_2599[2][0],&l_2599[2][0]},{&g_751,(void*)0,(void*)0,&g_751,(void*)0,(void*)0,&g_751,&g_543,&g_543}}};
    int32_t l_2603[2];
    int8_t l_2604 = 0xBFL;
    uint16_t l_2606 = 1UL;
    int32_t *l_2613 = &g_543;
    int64_t *l_2620 = &g_777;
    int64_t *l_2627[1][9][3] = {{{&g_1122,&g_265,&g_265},{(void*)0,(void*)0,(void*)0},{&g_1122,&g_265,&g_265},{(void*)0,(void*)0,(void*)0},{&g_1122,&g_265,&g_265},{(void*)0,(void*)0,(void*)0},{&g_1122,&g_265,&g_265},{(void*)0,(void*)0,(void*)0},{&g_1122,&g_265,&g_265}}};
    int32_t *** const *l_2628 = &g_98;
    uint16_t l_2629 = 9UL;
    uint16_t l_2630[5][7] = {{3UL,65528UL,0x3ED6L,65528UL,3UL,0UL,65532UL},{0x29F9L,65534UL,0x954CL,0UL,3UL,65532UL,3UL},{0UL,0UL,0UL,0UL,65528UL,0UL,0x29F9L},{0x29F9L,0UL,65528UL,0UL,0UL,0UL,0UL},{3UL,65532UL,3UL,0UL,0x954CL,65534UL,0x29F9L}};
    int8_t l_2631 = (-7L);
    int8_t ***l_2633[2][7] = {{&g_1500[2][7],&g_1500[2][7],&g_1500[2][7],&g_1500[2][7],&g_1500[2][7],&g_1500[2][7],&g_1500[2][7]},{(void*)0,&g_1500[0][5],&g_1500[0][5],(void*)0,&g_1500[0][5],&g_1500[0][5],(void*)0}};
    int8_t ****l_2632[7][4] = {{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}};
    uint32_t ** const *l_2699[6] = {&g_467,&g_467,&g_467,&g_467,&g_467,&g_467};
    uint32_t ** const **l_2698 = &l_2699[1];
    uint64_t l_2738 = 0xD9F5C3346F4E4A23LL;
    int16_t **l_2760 = &g_1448;
    int i, j, k;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 1; j++)
            l_2599[i][j] = 0L;
    }
    for (i = 0; i < 2; i++)
        l_2603[i] = 4L;
lbl_2661:
    l_2606--;
    if ((safe_div_func_int32_t_s_s((((**g_1025) ^ (l_2630[4][4] = (safe_mod_func_int8_t_s_s((((0x15BA16DA22C4FDA0LL | ((l_2602[0][4][2] = l_2613) == (*g_890))) > (((safe_rshift_func_uint64_t_u_s((((safe_mul_func_uint8_t_u_u((((*l_2620) = (0xADL & (safe_div_func_uint32_t_u_u(5UL, ((*l_2613) = p_16))))) < (((*g_1490) != ((((safe_rshift_func_uint16_t_u_u(((*g_294)--), (((l_2603[1] = (l_2598 = ((*l_2601) = (((safe_mul_func_uint16_t_u_u(p_17, p_16)) & 0x4CL) || (*l_2601))))) , (***g_1935)) & p_16))) != 8UL) , 0xCA6B8A68L) , (*g_1490))) || 0xB189F8C6L)), 0xC9L)) , (*l_2600)) || (*l_2613)), p_15)) , l_2628) != (void*)0)) , l_2629), 0xDCL)))) >= g_3[0][3]), l_2631)))
    { /* block id: 1237 */
        int16_t *l_2634 = &g_657;
        const int32_t l_2647 = (-1L);
        int16_t l_2660[5][8] = {{0x2044L,(-1L),(-1L),0x2044L,0x2044L,(-1L),(-1L),0x2044L},{0x2044L,(-1L),(-1L),0x2044L,0x2044L,(-1L),(-1L),0x2044L},{0x2044L,(-1L),(-1L),0x2044L,0x2044L,(-1L),(-1L),0x2044L},{0x2044L,(-1L),(-1L),0x2044L,0x2044L,(-1L),(-1L),0x2044L},{0x2044L,(-1L),(-1L),0x2044L,0x2044L,(-1L),(-1L),0x2044L}};
        int32_t l_2708[6][8][2] = {{{(-3L),0x8E4051A3L},{3L,0xA686E6B8L},{0x2EFC250FL,1L},{1L,3L},{1L,1L},{0x2EFC250FL,(-1L)},{1L,0L},{7L,1L}},{{0xCD2F55FBL,3L},{3L,0x37A211ACL},{(-1L),0x8F847834L},{1L,0xE77037B6L},{0L,(-3L)},{(-2L),3L},{0x70B80986L,(-5L)},{0xB131D1A9L,0xFEBA35CFL}},{{1L,0xFEBA35CFL},{0xB131D1A9L,(-5L)},{0x70B80986L,3L},{(-2L),(-3L)},{0L,0xE77037B6L},{1L,0x8F847834L},{(-1L),0x37A211ACL},{3L,3L}},{{0xCD2F55FBL,1L},{7L,0L},{1L,(-1L)},{0x2EFC250FL,1L},{1L,3L},{1L,1L},{0x2EFC250FL,(-1L)},{1L,0L}},{{7L,1L},{0xCD2F55FBL,3L},{3L,0x37A211ACL},{(-1L),0x8F847834L},{1L,0xE77037B6L},{0L,(-3L)},{(-2L),3L},{0x70B80986L,(-5L)}},{{0xB131D1A9L,0xFEBA35CFL},{1L,0xFEBA35CFL},{0xB131D1A9L,(-5L)},{0x70B80986L,3L},{(-2L),(-3L)},{0L,0xE77037B6L},{1L,0x8F847834L},{(-1L),0x37A211ACL}}};
        int32_t ***l_2757 = (void*)0;
        int32_t *** const * const l_2756 = &l_2757;
        int32_t l_2827[3];
        int32_t *l_2850 = &g_57;
        int32_t l_2854 = 7L;
        int8_t l_2877 = 0x5AL;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2827[i] = 0L;
        (*l_2601) = ((*g_1490) == l_2632[1][1]);
        if ((l_2634 == (void*)0))
        { /* block id: 1239 */
            uint32_t l_2656 = 0x1C151413L;
            int32_t l_2659 = (-1L);
            uint8_t l_2690 = 0x3BL;
            int32_t *l_2726 = &g_901[0];
            int32_t **l_2725 = &l_2726;
            int32_t ***l_2724 = &l_2725;
            uint8_t *****l_2770 = &g_2109;
            uint8_t *****l_2771[8][3] = {{&g_2109,&g_2109,&g_2109},{(void*)0,&g_2109,&g_2109},{&g_2109,&g_2109,(void*)0},{&g_2109,&g_2109,&g_2109},{(void*)0,&g_2109,&g_2109},{&g_2109,&g_2109,(void*)0},{&g_2109,&g_2109,&g_2109},{(void*)0,&g_2109,&g_2109}};
            int32_t l_2831 = 1L;
            int64_t l_2834 = 0x9984D44AB3AB454CLL;
            int32_t l_2835 = 0x5C66F1C3L;
            int32_t l_2836 = (-1L);
            int32_t l_2844 = 0x5D7D3046L;
            int i, j;
            p_16 = (****g_888);
            if ((((safe_mod_func_uint32_t_u_u(((safe_lshift_func_uint32_t_u_s(1UL, ((safe_mul_func_int8_t_s_s(p_16, ((p_16 , ((*****g_1490) = (safe_add_func_uint32_t_u_u((((safe_lshift_func_uint64_t_u_u((safe_add_func_int32_t_s_s(((l_2647 != ((((safe_mul_func_uint8_t_u_u(((**g_934) = ((safe_mod_func_int64_t_s_s((safe_mod_func_uint32_t_u_u(3UL, (((safe_div_func_int32_t_s_s((l_2656 & ((((l_2659 &= (safe_lshift_func_uint32_t_u_u((*l_2600), 23))) , (((void*)0 == (****g_1490)) < l_2656)) , 1L) >= 9UL)), p_15)) <= (***g_1504)) , (-7L)))), l_2647)) == l_2647)), 255UL)) , 0xBE027BEB73F7D229LL) , l_2647) , 0x1EL)) , l_2659), (-10L))), l_2656)) != 5UL) , l_2660[0][7]), 1L)))) , p_15))) != 0xEA2B8882L))) & l_2656), 0x9CE05A53L)) != 0L) <= 5L))
            { /* block id: 1244 */
                int16_t l_2681 = 0xAF82L;
                int32_t l_2684 = 0xE37C8A5DL;
                uint32_t *l_2688 = &g_134;
                uint8_t *l_2689 = &g_1407;
                int32_t l_2707[6][9][4] = {{{(-1L),0L,7L,0x2A6A1EB3L},{0x32615EDBL,0x46213E94L,0x46213E94L,0x32615EDBL},{0x33F61931L,0x46213E94L,0x437C1A2DL,0x2A6A1EB3L},{0x2A6A1EB3L,0L,0x40A08BC3L,1L},{0x33F61931L,(-6L),0L,1L},{0x32615EDBL,0L,1L,0x2A6A1EB3L},{(-1L),0x46213E94L,0L,0x32615EDBL},{0L,0x46213E94L,0x40A08BC3L,0x2A6A1EB3L},{0x049300A5L,0L,0x437C1A2DL,1L}},{{0L,(-6L),0x46213E94L,1L},{(-1L),0L,7L,0x2A6A1EB3L},{0x32615EDBL,0x46213E94L,0x46213E94L,0x32615EDBL},{0x33F61931L,0x46213E94L,0x437C1A2DL,0x2A6A1EB3L},{0x2A6A1EB3L,0L,0x40A08BC3L,1L},{0x33F61931L,(-6L),0L,1L},{0x32615EDBL,0L,1L,0x2A6A1EB3L},{(-1L),0x46213E94L,0L,0x32615EDBL},{0L,0x46213E94L,0x40A08BC3L,0x2A6A1EB3L}},{{0x049300A5L,0L,0xB6F61B5EL,(-4L)},{0x2A6A1EB3L,0x46213E94L,1L,(-4L)},{0x8D996420L,(-6L),0x437C1A2DL,0x32615EDBL},{1L,1L,1L,1L},{0x049300A5L,1L,0xB6F61B5EL,0x32615EDBL},{0x32615EDBL,(-6L),0L,(-4L)},{0x049300A5L,0x46213E94L,7L,(-4L)},{1L,(-6L),0x40A08BC3L,0x32615EDBL},{0x8D996420L,1L,7L,1L}},{{0x2A6A1EB3L,1L,0L,0x32615EDBL},{(-1L),(-6L),0xB6F61B5EL,(-4L)},{0x2A6A1EB3L,0x46213E94L,1L,(-4L)},{0x8D996420L,(-6L),0x437C1A2DL,0x32615EDBL},{1L,1L,1L,1L},{0x049300A5L,1L,0xB6F61B5EL,0x32615EDBL},{0x32615EDBL,(-6L),0L,(-4L)},{0x049300A5L,0x46213E94L,7L,(-4L)},{1L,(-6L),0x40A08BC3L,0x32615EDBL}},{{0x8D996420L,1L,7L,1L},{0x2A6A1EB3L,1L,0L,0x32615EDBL},{(-1L),(-6L),0xB6F61B5EL,(-4L)},{0x2A6A1EB3L,0x46213E94L,1L,(-4L)},{0x8D996420L,(-6L),0x437C1A2DL,0x32615EDBL},{1L,1L,1L,1L},{0x049300A5L,1L,0xB6F61B5EL,0x32615EDBL},{0x32615EDBL,(-6L),0L,(-4L)},{0x049300A5L,0x46213E94L,7L,(-4L)}},{{1L,(-6L),0x40A08BC3L,0x32615EDBL},{0x8D996420L,1L,7L,1L},{0x2A6A1EB3L,1L,0L,0x32615EDBL},{(-1L),(-6L),0xB6F61B5EL,(-4L)},{0x2A6A1EB3L,0x46213E94L,1L,(-4L)},{0x8D996420L,(-6L),0x437C1A2DL,0x32615EDBL},{1L,1L,1L,1L},{0x049300A5L,1L,0xB6F61B5EL,0x32615EDBL},{0x32615EDBL,(-6L),0L,(-4L)}}};
                int i, j, k;
                (*l_2600) |= l_2656;
                (*g_891) = 0xF2232EB7L;
                if (l_2659)
                    goto lbl_2661;
                if ((safe_div_func_int32_t_s_s(((safe_rshift_func_uint64_t_u_s((safe_add_func_uint16_t_u_u((safe_add_func_int8_t_s_s((safe_mul_func_uint64_t_u_u(p_15, (p_17 <= (safe_rshift_func_int32_t_s_u((safe_div_func_uint8_t_u_u(((*l_2689) = ((safe_mul_func_uint32_t_u_u(((*l_2688) ^= ((((((~0xA41BL) | l_2660[0][0]) || ((*g_294) = (safe_div_func_int16_t_s_s((((l_2684 &= ((**g_934) &= (l_2681 != ((*l_2600) , (safe_rshift_func_uint32_t_u_u(l_2681, 22)))))) , (!l_2659)) , ((*g_1448) = (safe_rshift_func_uint16_t_u_s(((((*g_467) = (void*)0) != (void*)0) != 0L), l_2681)))), p_16)))) , (-2L)) || l_2684) , 0x729399B1L)), 1L)) <= g_77[3][0][2])), (*l_2600))), l_2690))))), p_16)), 1UL)), l_2681)) <= l_2681), 0x9167439EL)))
                { /* block id: 1255 */
                    int16_t l_2700 = 1L;
                    int16_t l_2705 = 0x059FL;
                    int32_t l_2706[7];
                    int i;
                    for (i = 0; i < 7; i++)
                        l_2706[i] = 0x4CD5ED59L;
                    (*l_2600) |= ((((((safe_div_func_int8_t_s_s(((safe_mod_func_int64_t_s_s((-1L), 0xEAB58B0F76C24F0ELL)) && 0x84DCL), 0x79L)) | (safe_rshift_func_uint8_t_u_u(((!(((*g_1026) = (((****g_1934) = 0xE705L) >= ((void*)0 != l_2698))) && l_2700)) == (safe_mod_func_uint32_t_u_u((((*l_2620) = (safe_sub_func_uint16_t_u_u(((*g_294) &= (p_17 || l_2647)), 0xA6D8L))) <= l_2690), 4294967286UL))), 7))) , l_2700) ^ 5L) == l_2659) ^ l_2705);
                    for (g_57 = 0; (g_57 <= 2); g_57 += 1)
                    { /* block id: 1263 */
                        uint16_t l_2709 = 65535UL;
                        l_2709--;
                    }
                }
                else
                { /* block id: 1266 */
                    uint32_t l_2712 = 0xA28C9023L;
                    p_16 ^= l_2707[5][4][2];
                    --l_2712;
                }
            }
            else
            { /* block id: 1270 */
                int32_t *l_2735 = &l_2603[0];
                int16_t ****l_2767 = &g_1935;
                uint16_t **l_2800 = (void*)0;
                uint16_t ***l_2799 = &l_2800;
                uint64_t l_2801 = 0UL;
                const int32_t ****l_2825 = &g_551;
                int32_t l_2830 = 0x64C3442DL;
                int32_t l_2832 = (-9L);
                int32_t l_2837 = 1L;
                int32_t l_2838 = 5L;
                int32_t l_2839 = (-7L);
                int32_t l_2840 = 0x4E0A6121L;
                int32_t l_2841 = 1L;
                int32_t l_2842 = 0xD8C450FEL;
                uint64_t l_2847 = 0UL;
                for (p_16 = (-4); (p_16 != 26); ++p_16)
                { /* block id: 1273 */
                    uint32_t l_2719 = 0x0B92B2D8L;
                    int32_t ** const **l_2728 = (void*)0;
                    int32_t ** const **l_2729 = (void*)0;
                    int32_t ** const **l_2730[5][6][5] = {{{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727}},{{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727}},{{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727}},{{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727}},{{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727},{&g_2727,&g_2727,&g_2727,&g_2727,&g_2727}}};
                    int32_t *l_2734 = &g_3[1][0];
                    uint8_t *****l_2772[3];
                    uint8_t *****l_2775 = &g_2109;
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                        l_2772[i] = &g_2109;
                    if ((safe_mod_func_uint32_t_u_u(l_2719, ((safe_lshift_func_uint8_t_u_u(((safe_mod_func_uint16_t_u_u((l_2724 != (g_2727 = g_2727)), (7UL && p_17))) > ((**g_934)++)), 6)) , (~l_2719)))))
                    { /* block id: 1276 */
                        uint16_t l_2746 = 0x249EL;
                        l_2735 = l_2734;
                        (*l_2601) ^= (safe_mul_func_uint64_t_u_u((((*l_2620) = 1L) <= l_2738), ((safe_mod_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u((~(safe_mul_func_uint64_t_u_u(((l_2746 <= ((((**g_934) = (**g_934)) || ((0xC8L && (((safe_add_func_uint16_t_u_u(((safe_div_func_uint32_t_u_u(((***g_914) = ((safe_mul_func_uint32_t_u_u((((*g_294) = ((safe_mul_func_uint64_t_u_u((safe_unary_minus_func_uint64_t_u(0x57E0129FAC1527BDLL)), l_2746)) || 0xBC0E9208L)) ^ 1L), p_16)) && 0xC7L)), (*l_2734))) == (*l_2735)), l_2660[0][7])) , l_2756) == &g_1338)) & (**g_1505))) , l_2690)) | p_17), p_17))), p_16)), l_2656)) >= (*l_2735))));
                    }
                    else
                    { /* block id: 1283 */
                        (*g_891) = (safe_add_func_int32_t_s_s((&g_914 != &g_914), ((p_16 , l_2760) != (void*)0)));
                    }
                    l_2708[4][2][1] |= (l_2659 = ((safe_lshift_func_int32_t_s_s(((safe_lshift_func_int8_t_s_u((1UL >= (safe_sub_func_int32_t_s_s((*l_2735), ((p_16 , l_2767) != (void*)0)))), p_17)) , (safe_rshift_func_uint64_t_u_s((l_2656 , ((l_2772[0] = (l_2771[0][0] = (l_2770 = l_2770))) == (l_2775 = (((safe_add_func_int32_t_s_s(0x4837A212L, (*l_2734))) & 0x90C82E0EL) , &g_2109)))), 3))), p_17)) >= p_17));
                    if (((*l_2613) = (safe_rshift_func_uint8_t_u_s(p_15, 0))))
                    { /* block id: 1293 */
                        return p_16;
                    }
                    else
                    { /* block id: 1295 */
                        uint64_t l_2802[9][10][2] = {{{0UL,0x0249EFF8BC5D48C6LL},{18446744073709551606UL,0xE554F488E4A7360ALL},{18446744073709551606UL,0x0249EFF8BC5D48C6LL},{0UL,0UL},{0x0249EFF8BC5D48C6LL,18446744073709551608UL},{0xF0C5D7E1B0FAD48BLL,0xF2667572CF4CD6FFLL},{0x256AAB21EB2C78D0LL,18446744073709551613UL},{18446744073709551613UL,0UL},{1UL,0UL},{18446744073709551613UL,18446744073709551613UL}},{{0x256AAB21EB2C78D0LL,0xF2667572CF4CD6FFLL},{0xF0C5D7E1B0FAD48BLL,18446744073709551608UL},{0x0249EFF8BC5D48C6LL,0UL},{0UL,0x0249EFF8BC5D48C6LL},{18446744073709551606UL,0xE554F488E4A7360ALL},{18446744073709551606UL,0x0249EFF8BC5D48C6LL},{0UL,0UL},{0x0249EFF8BC5D48C6LL,18446744073709551608UL},{0xF0C5D7E1B0FAD48BLL,0xF2667572CF4CD6FFLL},{0x256AAB21EB2C78D0LL,18446744073709551613UL}},{{18446744073709551613UL,0UL},{1UL,0UL},{18446744073709551613UL,18446744073709551613UL},{0x256AAB21EB2C78D0LL,0xF2667572CF4CD6FFLL},{0xF0C5D7E1B0FAD48BLL,18446744073709551608UL},{0x0249EFF8BC5D48C6LL,0UL},{0UL,0x0249EFF8BC5D48C6LL},{18446744073709551606UL,0xE554F488E4A7360ALL},{18446744073709551606UL,0x0249EFF8BC5D48C6LL},{0UL,0UL}},{{0x0249EFF8BC5D48C6LL,18446744073709551608UL},{0xF0C5D7E1B0FAD48BLL,0xF2667572CF4CD6FFLL},{0x256AAB21EB2C78D0LL,18446744073709551613UL},{18446744073709551613UL,0UL},{1UL,0UL},{18446744073709551613UL,18446744073709551613UL},{0x256AAB21EB2C78D0LL,0xF2667572CF4CD6FFLL},{0xF0C5D7E1B0FAD48BLL,18446744073709551608UL},{0x0249EFF8BC5D48C6LL,0UL},{0UL,0x0249EFF8BC5D48C6LL}},{{18446744073709551606UL,0xE554F488E4A7360ALL},{18446744073709551606UL,0x0249EFF8BC5D48C6LL},{0UL,0UL},{0x0249EFF8BC5D48C6LL,18446744073709551608UL},{0xF0C5D7E1B0FAD48BLL,0xF2667572CF4CD6FFLL},{0xF2667572CF4CD6FFLL,0xE554F488E4A7360ALL},{0xE554F488E4A7360ALL,1UL},{18446744073709551613UL,1UL},{0xE554F488E4A7360ALL,0xE554F488E4A7360ALL},{0xF2667572CF4CD6FFLL,0UL}},{{18446744073709551606UL,0UL},{0x256AAB21EB2C78D0LL,0xF11E2605D23C4C3BLL},{1UL,0x256AAB21EB2C78D0LL},{18446744073709551608UL,0x0249EFF8BC5D48C6LL},{18446744073709551608UL,0x256AAB21EB2C78D0LL},{1UL,0xF11E2605D23C4C3BLL},{0x256AAB21EB2C78D0LL,0UL},{18446744073709551606UL,0UL},{0xF2667572CF4CD6FFLL,0xE554F488E4A7360ALL},{0xE554F488E4A7360ALL,1UL}},{{18446744073709551613UL,1UL},{0xE554F488E4A7360ALL,0xE554F488E4A7360ALL},{0xF2667572CF4CD6FFLL,0UL},{18446744073709551606UL,0UL},{0x256AAB21EB2C78D0LL,0xF11E2605D23C4C3BLL},{1UL,0x256AAB21EB2C78D0LL},{18446744073709551608UL,0x0249EFF8BC5D48C6LL},{18446744073709551608UL,0x256AAB21EB2C78D0LL},{1UL,0xF11E2605D23C4C3BLL},{0x256AAB21EB2C78D0LL,0UL}},{{18446744073709551606UL,0UL},{0xF2667572CF4CD6FFLL,0xE554F488E4A7360ALL},{0xE554F488E4A7360ALL,1UL},{18446744073709551613UL,1UL},{0xE554F488E4A7360ALL,0xE554F488E4A7360ALL},{0xF2667572CF4CD6FFLL,0UL},{18446744073709551606UL,0UL},{0x256AAB21EB2C78D0LL,0xF11E2605D23C4C3BLL},{1UL,0x256AAB21EB2C78D0LL},{18446744073709551608UL,0x0249EFF8BC5D48C6LL}},{{18446744073709551608UL,0x256AAB21EB2C78D0LL},{1UL,0xF11E2605D23C4C3BLL},{0x256AAB21EB2C78D0LL,0UL},{18446744073709551606UL,0UL},{0xF2667572CF4CD6FFLL,0xE554F488E4A7360ALL},{0xE554F488E4A7360ALL,1UL},{18446744073709551613UL,1UL},{0xE554F488E4A7360ALL,0xE554F488E4A7360ALL},{0xF2667572CF4CD6FFLL,0UL},{18446744073709551606UL,0UL}}};
                        int32_t *l_2803[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                        int i, j, k;
                        (*l_2601) = ((+(***g_1504)) && (safe_mod_func_uint8_t_u_u(((*g_716) > ((safe_mod_func_uint8_t_u_u((((*l_2620) = 0x51DC6313948F2127LL) != 1UL), ((*g_294) | ((((((safe_sub_func_uint32_t_u_u((safe_add_func_int64_t_s_s(p_15, (((safe_lshift_func_int32_t_s_s(((safe_rshift_func_uint64_t_u_s((p_15 != ((safe_lshift_func_uint8_t_u_u(((((*l_2634) = (&g_1505 == ((safe_rshift_func_int32_t_s_s((safe_div_func_int16_t_s_s(((*g_1448) = p_17), p_17)), 22)) , l_2799))) | p_15) | (*l_2601)), p_16)) <= 0UL)), 12)) > p_17), 31)) <= 0UL) ^ l_2656))), l_2801)) && 2L) , 0L) , (**g_1025)) , (**l_2724)) == (**g_1338))))) >= p_17)), p_15)));
                        if (l_2802[5][3][1])
                            break;
                        (*l_2600) |= 0x03D1FA47L;
                        (***g_550) = l_2803[7];
                    }
                }
                for (g_215 = 0; (g_215 <= 3); g_215 += 1)
                { /* block id: 1307 */
                    uint8_t **l_2804[6] = {&g_1081[2],&g_1081[2],&g_1081[2],&g_1081[2],&g_1081[2],&g_1081[2]};
                    uint16_t l_2805[3];
                    int32_t ****l_2824 = &g_98;
                    uint32_t l_2829 = 0x42EE5F08L;
                    int32_t l_2833 = 0xE517F9ECL;
                    int32_t l_2843 = 7L;
                    int32_t l_2845 = (-1L);
                    int32_t l_2846[5];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_2805[i] = 0x8237L;
                    for (i = 0; i < 5; i++)
                        l_2846[i] = 0x679033E5L;
                    (*g_891) ^= (&g_1081[2] == l_2804[2]);
                    for (g_751 = 0; (g_751 >= 0); g_751 -= 1)
                    { /* block id: 1311 */
                        const int32_t *****l_2826 = &l_2825;
                        int i, j;
                        --l_2805[2];
                        (*l_2600) = (safe_mod_func_int8_t_s_s(((safe_sub_func_uint16_t_u_u(((***g_1504) != l_2660[1][7]), (safe_mod_func_int64_t_s_s((l_2827[1] = (l_2708[5][6][1] = ((safe_lshift_func_int32_t_s_s((((safe_sub_func_uint64_t_u_u((((safe_add_func_uint16_t_u_u(((-1L) >= (((g_127[g_215][g_751] = ((safe_lshift_func_uint16_t_u_s((0L & l_2805[2]), ((***g_1935) = (p_15 , (safe_lshift_func_uint64_t_u_s(((l_2690 == ((*l_2620) = ((l_2824 == ((*l_2826) = l_2825)) <= (***g_1935)))) >= (-3L)), p_15)))))) > p_16)) >= (*l_2735)) & p_17)), (-6L))) >= p_16) != (-2L)), p_15)) , p_17) < (*l_2735)), p_17)) & 0x43L))), g_2828[4])))) ^ (*l_2613)), l_2829));
                    }
                    l_2847--;
                    for (g_1476 = 0; (g_1476 <= 3); g_1476 += 1)
                    { /* block id: 1324 */
                        l_2850 = &p_16;
                    }
                    for (g_57 = 0; (g_57 <= 2); g_57 += 1)
                    { /* block id: 1329 */
                        if ((*l_2850))
                            break;
                    }
                }
            }
        }
        else
        { /* block id: 1334 */
            int16_t ** const *l_2860 = (void*)0;
            int16_t ** const **l_2859 = &l_2860;
            int32_t l_2875 = 0L;
            const uint16_t l_2876 = 0UL;
            int8_t **l_2878 = &g_1494;
            int8_t **l_2879 = &g_1501;
            (*l_2613) &= ((p_15 != (!(safe_mul_func_uint32_t_u_u((l_2854 > ((safe_div_func_int32_t_s_s((safe_lshift_func_int64_t_s_s((l_2859 == (void*)0), ((((*l_2850) = (((((safe_sub_func_uint16_t_u_u((*g_294), (safe_rshift_func_uint64_t_u_u(((*g_1026) = (safe_add_func_int64_t_s_s((((safe_add_func_uint64_t_u_u(((((*l_2620) = ((*g_294) && ((((safe_rshift_func_int32_t_s_s((safe_sub_func_int64_t_s_s(0L, (safe_sub_func_int8_t_s_s((*l_2850), ((((*g_1506) != p_15) & 0xA5EAD862L) ^ p_17))))), p_16)) <= p_16) && (-4L)) , (*g_1506)))) == 0x957DB704748F11BFLL) != 0xD4L), (*g_1026))) & 0x426AL) ^ l_2875), p_15))), 52)))) , p_15) == p_15) & p_17) < p_15)) , &p_16) != &p_16))), l_2876)) != l_2877)), l_2875)))) || p_16);
            p_16 = (((((l_2878 = l_2878) != l_2879) ^ ((*l_2613) = (*g_1163))) == ((((safe_sub_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u((((*l_2601) = ((safe_mul_func_int8_t_s_s(1L, p_16)) != (((((**g_1934) == (((l_2850 = &p_16) != &p_16) , l_2760)) != (-1L)) , l_2875) , l_2876))) > 3L), p_15)), 0x8196L)) != 0x96D8L) > l_2875) != (*g_294))) , 8L);
        }
    }
    else
    { /* block id: 1345 */
        uint32_t l_2889 = 4294967288UL;
        for (l_2738 = (-24); (l_2738 > 55); l_2738 = safe_add_func_int16_t_s_s(l_2738, 9))
        { /* block id: 1348 */
            int64_t l_2888 = 0L;
            ++l_2889;
        }
    }
    return p_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_294 g_138 g_1501 g_378 g_1494 g_218 g_913 g_914 g_467 g_468 g_134 g_125 g_1934 g_1935 g_1447 g_1448 g_73 g_716 g_717 g_550 g_551 g_88 g_1504 g_1505 g_1506 g_1507 g_1026 g_89 g_1163 g_1164 g_888 g_889 g_890 g_891 g_629 g_892 g_2108 g_2109 g_2110 g_901 g_2545 g_1025 g_2591 g_751 g_986 g_987 g_657 g_895 g_896
 * writes: g_73 g_89 g_127 g_892 g_629 g_138 g_2110 g_1476 g_2329 g_2545 g_543 g_751 g_218 g_896
 */
static int16_t  func_33(const uint16_t  p_34, const uint64_t  p_35)
{ /* block id: 1168 */
    uint8_t *****l_2482 = &g_2109;
    int32_t l_2483 = 0x42728992L;
    int32_t l_2528[1];
    int16_t l_2582 = 0x8D3FL;
    int i;
    for (i = 0; i < 1; i++)
        l_2528[i] = 3L;
    if ((l_2483 = ((0x2E3899AA1F23DB31LL <= (p_35 & ((((p_35 , (*g_294)) && (safe_rshift_func_uint16_t_u_s((((-10L) == (*g_1501)) , (safe_mod_func_uint64_t_u_u((((****g_1934) ^= (((~(((((safe_mod_func_uint32_t_u_u(((&g_2109 == l_2482) <= ((l_2483 , p_34) != (*g_1494))), p_35)) , 0UL) < 18446744073709551608UL) == 0x9D3EE54566DB8714LL) > 0x37072AB6398BD21CLL)) && l_2483) <= (****g_913))) , l_2483), (*g_716)))), l_2483))) == l_2483) <= l_2483))) <= l_2483)))
    { /* block id: 1171 */
        uint32_t l_2484 = 0UL;
        int32_t l_2508 = 0x021F281AL;
        int16_t l_2509 = 1L;
        int8_t **l_2535 = &g_1501;
        int32_t l_2581 = (-9L);
        uint32_t l_2592 = 4294967295UL;
        (***g_550) = &l_2483;
        if ((l_2484 , (safe_add_func_uint32_t_u_u((safe_mul_func_uint64_t_u_u((((*g_1026) = (p_34 > (safe_rshift_func_uint16_t_u_s((l_2484 ^ ((safe_lshift_func_uint16_t_u_u((((safe_mod_func_int64_t_s_s(((+(safe_mul_func_int8_t_s_s(l_2484, (safe_add_func_uint8_t_u_u(((p_35 , (safe_sub_func_int16_t_s_s(((***g_1935) = ((l_2483 >= (l_2508 = (((***g_1504) || (safe_mod_func_uint64_t_u_u((p_35 <= (safe_add_func_uint8_t_u_u(((0x487AL == p_34) ^ l_2483), 0x5DL))), p_35))) < 5UL))) <= p_35)), l_2483))) , p_34), p_35))))) ^ p_34), 1L)) == 18446744073709551615UL) != p_35), 12)) >= l_2509)), p_35)))) >= 0x6EA05791AEED6AFELL), (-1L))), p_34))))
        { /* block id: 1176 */
            (***g_550) = (***g_550);
            (****g_888) = (*g_1163);
        }
        else
        { /* block id: 1179 */
            uint64_t l_2519 = 0xA64B0260B8DABEB6LL;
            int32_t l_2546 = 0x73D314B9L;
            int32_t l_2547 = (-3L);
            int32_t *** const *l_2553 = &g_98;
            for (g_629 = (-2); (g_629 < 8); g_629 = safe_add_func_uint64_t_u_u(g_629, 2))
            { /* block id: 1182 */
                int32_t *l_2512 = &g_543;
                int32_t *l_2513 = &g_751;
                int32_t *l_2514 = &l_2483;
                int32_t *l_2515 = &l_2508;
                int32_t *l_2516 = &g_1123;
                int32_t *l_2517 = &l_2483;
                int32_t *l_2518[1][1][3];
                uint8_t **l_2540 = (void*)0;
                uint8_t ***l_2539 = &l_2540;
                uint8_t ****l_2541 = &l_2539;
                uint32_t *l_2542 = &g_1476;
                uint32_t *l_2543 = &g_2329;
                uint32_t *l_2544 = &g_2545[1][1][0];
                int64_t l_2590 = 8L;
                int i, j, k;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 1; j++)
                    {
                        for (k = 0; k < 3; k++)
                            l_2518[i][j][k] = &l_2508;
                    }
                }
                l_2519--;
                if ((safe_sub_func_uint16_t_u_u(((safe_rshift_func_uint16_t_u_u(((safe_mul_func_uint32_t_u_u(l_2528[0], ((***g_914) < (**g_890)))) ^ (p_34 ^ (--(*g_294)))), 10)) >= (safe_div_func_uint32_t_u_u(((*l_2544) |= (safe_sub_func_uint32_t_u_u((((void*)0 != l_2535) , ((*l_2543) = (~(0xF9L == (((*l_2542) = (((safe_rshift_func_int64_t_s_s((((((**l_2482) = (**g_2108)) != ((*l_2541) = l_2539)) <= 0x622E2CEFB494BE3BLL) & g_901[0]), 33)) == l_2484) & (*l_2515))) >= (****g_913)))))), (-1L)))), 0x803F58CAL))), 0x4A62L)))
                { /* block id: 1190 */
                    uint8_t l_2548[6] = {0UL,0UL,0UL,0UL,0UL,0UL};
                    int i;
                    l_2548[1]++;
                }
                else
                { /* block id: 1192 */
                    uint64_t ***l_2554[4][9] = {{&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,(void*)0,&g_1025},{&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025},{(void*)0,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025},{&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025,&g_1025}};
                    int32_t l_2560 = 1L;
                    int64_t *l_2561[5];
                    int32_t l_2562 = (-7L);
                    uint32_t l_2563[5][8][6] = {{{0xBC67CD2BL,5UL,0x4EA52584L,0xFE8BF5FCL,0x1AF428DBL,18446744073709551615UL},{18446744073709551615UL,0x9E88346EL,0x3232E0F2L,0x36E2BD59L,1UL,0xE54564C8L},{9UL,0xF4E5736DL,0x6074A6DEL,0xF2D42228L,18446744073709551615UL,0xBB193249L},{0x5472D686L,0xE54564C8L,6UL,18446744073709551615UL,0x1546F4BFL,0x1AF428DBL},{18446744073709551609UL,0x6074A6DEL,0xE54564C8L,1UL,0xF2D42228L,0xDE1AFDF7L},{0UL,2UL,9UL,9UL,2UL,0UL},{0xFE8BF5FCL,6UL,0xF2D42228L,0x88921B8DL,1UL,0x4EA52584L},{0x8D37EA2FL,0x1AF428DBL,0x1478362BL,7UL,0UL,18446744073709551610UL}},{{1UL,0x9E88346EL,7UL,1UL,0xE54564C8L,0x705B59D9L},{0xACFCF9C8L,0xDE1AFDF7L,1UL,0UL,0xAB620A52L,9UL},{0UL,0x3232E0F2L,0x8D37EA2FL,0x9213A91CL,1UL,4UL},{0xA6A25668L,0UL,0xDFCB7290L,0xF477CF4BL,0x88921B8DL,0UL},{0xE54564C8L,0xCCE36329L,1UL,18446744073709551615UL,18446744073709551609UL,0xE579EF00L},{0UL,1UL,0x9213A91CL,0x3EFF9CFBL,18446744073709551615UL,18446744073709551615UL},{0xF477CF4BL,0x6074A6DEL,0xAB620A52L,0xACFCF9C8L,0x0F58F51AL,1UL},{0xE579EF00L,18446744073709551615UL,0x2C275E69L,0x9E88346EL,0x6074A6DEL,0xB5D985B8L}},{{0xAB620A52L,0UL,0UL,0xBB193249L,0xF4E5736DL,1UL},{0x9E88346EL,0x4EA52584L,18446744073709551607UL,1UL,18446744073709551607UL,0x4EA52584L},{0x4EA52584L,9UL,18446744073709551609UL,0x1478362BL,0UL,0x4CDD7FA4L},{1UL,2UL,0xDE1AFDF7L,0xB5D985B8L,3UL,0x37443088L},{0x4CDD7FA4L,2UL,1UL,18446744073709551607UL,0UL,0x9213A91CL},{0x88921B8DL,9UL,0UL,6UL,18446744073709551607UL,0xCCE36329L},{0x0B14C414L,0x4EA52584L,0xACFCF9C8L,1UL,0xF4E5736DL,0xDE1AFDF7L},{18446744073709551609UL,0UL,1UL,4UL,0x6074A6DEL,18446744073709551615UL}},{{1UL,18446744073709551615UL,1UL,0x02F1F32AL,0x0F58F51AL,0x88921B8DL},{0xCCE36329L,0x6074A6DEL,1UL,0x37443088L,18446744073709551615UL,0x02F1F32AL},{0x1AF428DBL,1UL,0UL,0UL,18446744073709551609UL,0xA6A25668L},{0UL,0xCCE36329L,0x705B59D9L,0x6074A6DEL,0x88921B8DL,6UL},{5UL,0UL,0x0F58F51AL,0x5472D686L,1UL,0x1F1FE3BBL},{0xB5D985B8L,0x3232E0F2L,0x0B14C414L,0xAB620A52L,0xAB620A52L,0x0B14C414L},{0xDE1AFDF7L,0xDE1AFDF7L,0xF2D42228L,1UL,0xE54564C8L,0x6074A6DEL},{1UL,0x9E88346EL,0x37443088L,0x1546F4BFL,0UL,0xF2D42228L}},{{0UL,1UL,0x37443088L,0x40355C7FL,0xDE1AFDF7L,0x6074A6DEL},{1UL,0x40355C7FL,0xF2D42228L,3UL,0UL,0x0B14C414L},{3UL,0UL,0x0B14C414L,0x659BB849L,18446744073709551615UL,0x1F1FE3BBL},{7UL,18446744073709551610UL,0x0F58F51AL,0xFE832651L,0x8D37EA2FL,6UL},{0x8D37EA2FL,0xFE8BF5FCL,0x705B59D9L,0x0B14C414L,0xF477CF4BL,0xA6A25668L},{0x40355C7FL,3UL,0UL,0x1AF428DBL,1UL,0x02F1F32AL},{0xF4E5736DL,18446744073709551615UL,1UL,0x2C275E69L,1UL,0x88921B8DL},{0UL,0x4EA52584L,1UL,18446744073709551615UL,0x36E2BD59L,0xF477CF4BL}}};
                    int i, j, k;
                    for (i = 0; i < 5; i++)
                        l_2561[i] = (void*)0;
                    l_2528[0] = ((safe_mul_func_uint16_t_u_u((l_2553 == (void*)0), 1L)) < 0L);
                    (*l_2515) &= ((void*)0 == l_2554[1][1]);
                    if ((safe_rshift_func_int64_t_s_u((l_2528[0] = (safe_sub_func_uint8_t_u_u(((((p_34 || (l_2560 = ((**g_467) ^ ((!p_34) != p_34)))) > p_35) < 9UL) , 0x45L), 8UL))), ((*g_1026) = (((((l_2562 && 65531UL) <= (-10L)) || p_35) <= l_2563[2][3][0]) & 18446744073709551615UL)))))
                    { /* block id: 1198 */
                        if (l_2563[4][6][1])
                            break;
                        return p_34;
                    }
                    else
                    { /* block id: 1201 */
                        uint32_t l_2564 = 0x08440F75L;
                        --l_2564;
                        (*l_2512) = 0x6E868D28L;
                    }
                }
                (*l_2515) ^= (safe_add_func_uint8_t_u_u((safe_rshift_func_uint64_t_u_u((safe_lshift_func_uint32_t_u_s(0x2B447685L, 1)), 50)), ((*l_2513) &= ((safe_div_func_uint32_t_u_u(0x05273452L, (safe_sub_func_int16_t_s_s((safe_add_func_uint64_t_u_u(((**g_1025) = (safe_mul_func_uint32_t_u_u(p_34, (l_2581 > p_35)))), (l_2582 & (0xBF8A9417BEF2C6DELL >= (((safe_rshift_func_uint64_t_u_s((*g_716), 39)) >= (!((*l_2517) &= (safe_rshift_func_int32_t_s_u(((safe_mod_func_uint32_t_u_u(l_2590, p_35)) && l_2582), 10))))) != l_2581))))), g_2591)))) ^ l_2528[0]))));
                (*l_2513) ^= (((l_2592 = 0xE5ECL) ^ l_2508) > p_35);
            }
            for (g_218 = 0; (g_218 <= 10); ++g_218)
            { /* block id: 1215 */
                return p_35;
            }
            return l_2592;
        }
        return (**g_986);
    }
    else
    { /* block id: 1221 */
        (*g_891) = (((*g_895) = (*g_895)) == (void*)0);
    }
    return l_2483;
}


/* ------------------------------------------ */
/* 
 * reads : g_337 g_1339 g_1340 g_901 g_215 g_1025 g_1026 g_127 g_913 g_914 g_88 g_550 g_551 g_100 g_3 g_294 g_138 g_99 g_467 g_468 g_134 g_125 g_629 g_57 g_1407 g_751 g_1447 g_1448 g_378 g_1476 g_89 g_1490 g_1491 g_1492 g_1493 g_1494 g_218 g_1504 g_98 g_605 g_73 g_392 g_1743 g_1005 g_777 g_1501 g_1862 g_2124 g_1935 g_2108 g_2109 g_2110
 * writes: g_337 g_88 g_138 g_100 g_127 g_1081 g_1278 g_751 g_89 g_392 g_57 g_1447 g_73 g_378 g_543 g_1490 g_1500 g_74 g_134 g_125 g_629 g_1230 g_99 g_1649 g_1025 g_605 g_1743 g_657 g_777 g_218 g_1862 g_1933 g_1937
 */
static uint32_t  func_36(const uint16_t  p_37, int8_t  p_38, int16_t  p_39)
{ /* block id: 546 */
    int16_t l_1239[6] = {0xF01BL,0xF01BL,0xF01BL,0xF01BL,0xF01BL,0xF01BL};
    int32_t l_1244 = 0L;
    uint32_t l_1264 = 0x2B7B6C84L;
    int32_t *l_1285 = &l_1244;
    uint32_t *****l_1292[9][10] = {{&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913},{&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913},{&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913},{&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913},{&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913},{&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913},{&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913},{&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913},{&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913,&g_913}};
    const int32_t ***l_1341 = &g_1339;
    const uint32_t ***l_1354[6][6] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
    const uint32_t **l_1356 = (void*)0;
    const uint32_t ***l_1355 = &l_1356;
    const uint32_t ****l_1357 = &l_1354[5][0];
    int32_t **l_1358 = &g_100[1][1];
    uint8_t *l_1361 = &g_392;
    int64_t *l_1374 = (void*)0;
    int16_t *l_1378[9][2] = {{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}};
    int32_t **l_1381 = (void*)0;
    int32_t *l_1383 = &g_901[0];
    int32_t **l_1382 = &l_1383;
    int16_t l_1384[4];
    uint8_t **l_1385[9] = {&g_1081[1],&g_1081[1],&g_1081[1],&g_1081[1],&g_1081[1],&g_1081[1],&g_1081[1],&g_1081[1],&g_1081[1]};
    uint32_t l_1388 = 0x9B76F72EL;
    uint32_t l_1403 = 18446744073709551611UL;
    int32_t l_1433 = 0x7B66F1F9L;
    int64_t l_1514 = 1L;
    int32_t l_1515 = 0xC78B1F5EL;
    int32_t l_1517 = 0x000E02C8L;
    int32_t l_1521[9] = {(-1L),(-1L),0x681CD4A9L,(-1L),(-1L),0x681CD4A9L,(-1L),(-1L),0x681CD4A9L};
    uint64_t l_1633 = 0x00563F1AB93E2ECELL;
    int32_t * const *l_1788 = &l_1285;
    int32_t * const **l_1787 = &l_1788;
    int32_t * const ***l_1786 = &l_1787;
    uint64_t l_1820 = 18446744073709551615UL;
    uint32_t l_1864[5][1] = {{18446744073709551615UL},{9UL},{18446744073709551615UL},{9UL},{18446744073709551615UL}};
    uint32_t l_1869 = 1UL;
    int32_t *l_1874 = &l_1433;
    int32_t *l_1875 = &g_57;
    uint64_t **l_1879 = &g_1026;
    uint64_t **l_1880 = (void*)0;
    int8_t l_1886 = (-1L);
    int16_t *****l_1936[5][1] = {{&g_1934},{&g_1934},{&g_1934},{&g_1934},{&g_1934}};
    uint32_t l_2000 = 0xD931822BL;
    int8_t l_2130 = 0xDDL;
    int8_t l_2161 = 0L;
    int32_t ****l_2172 = &g_98;
    const uint16_t l_2179 = 3UL;
    int16_t l_2264 = 0xDD76L;
    const int32_t l_2392 = 0L;
    int32_t *l_2471 = (void*)0;
    int i, j;
    for (i = 0; i < 4; i++)
        l_1384[i] = 0L;
    for (g_337 = 0; (g_337 == 13); g_337 = safe_add_func_uint8_t_u_u(g_337, 7))
    { /* block id: 549 */
        int32_t l_1245 = 0xF1969D9CL;
    }
    (*g_99) = (((*g_294) ^= ((!(((((safe_add_func_uint64_t_u_u((((((safe_rshift_func_int8_t_s_s(((**g_1339) , g_215), 7)) | (**g_1025)) < ((*g_913) != ((*l_1357) = (l_1355 = l_1354[1][5])))) , (((**g_550) = func_83((((*l_1285) && (*l_1285)) , &l_1285))) == l_1358)) , 0xA10599D5151666FCLL), (**l_1358))) && 0x73L) != (**l_1358)) || p_37) >= p_39)) || (**g_1025))) , (void*)0);
    if ((((*g_294) = (p_38 < (safe_lshift_func_uint64_t_u_u(((l_1361 = &g_392) == (g_1081[2] = ((safe_mod_func_int32_t_s_s(((safe_rshift_func_int16_t_s_s((safe_rshift_func_uint16_t_u_u((safe_mul_func_uint8_t_u_u(6UL, (safe_mul_func_uint32_t_u_u((((((((--(*g_1026)) , l_1374) == l_1374) <= p_39) & ((safe_sub_func_int16_t_s_s((l_1244 = (~l_1244)), ((safe_sub_func_int8_t_s_s(p_38, (((*l_1382) = l_1285) == (**l_1341)))) >= 0xDE0CL))) != (**g_467))) ^ g_629) , p_38), l_1384[3])))), 14)), g_57)) != (*g_294)), 1UL)) , &g_392))), 50)))) , p_38))
    { /* block id: 644 */
        return (**g_467);
    }
    else
    { /* block id: 646 */
        const int32_t l_1393[3][3] = {{0xC810999BL,0L,0L},{0xC810999BL,0L,0L},{0xC810999BL,0L,0x3057BF69L}};
        uint64_t l_1402 = 5UL;
        uint64_t ***l_1408 = (void*)0;
        int32_t *l_1412 = &g_57;
        int32_t l_1417 = 0x2771213FL;
        uint64_t l_1434 = 0xBE02FDC1BCF9C342LL;
        int64_t l_1457[1];
        int32_t l_1482 = 0xAD7803A1L;
        uint32_t l_1496 = 0UL;
        int8_t **l_1499[6][1][5] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_1494,&g_1494,(void*)0,&g_1494,&g_1494}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_1494,&g_1494,&g_1494,&g_1494,&g_1494}},{{(void*)0,(void*)0,&g_1494,(void*)0,(void*)0}},{{&g_1494,&g_1494,&g_1494,&g_1494,&g_1494}}};
        int32_t l_1518 = 9L;
        int32_t l_1519 = (-1L);
        int32_t l_1520 = 0x5D4C5495L;
        int32_t l_1522 = 0x16869DF4L;
        int32_t l_1523[9] = {0x3511A7AEL,0x3511A7AEL,0x3511A7AEL,0x3511A7AEL,0x3511A7AEL,0x3511A7AEL,0x3511A7AEL,0x3511A7AEL,0x3511A7AEL};
        uint16_t l_1641 = 65535UL;
        int32_t l_1715[4];
        uint16_t l_1792 = 1UL;
        int8_t l_1860[2][2];
        int16_t l_1861 = 0xBFB0L;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_1457[i] = 0xD9BBBBABDECA0AE1LL;
        for (i = 0; i < 4; i++)
            l_1715[i] = 0xDA2F94DDL;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 2; j++)
                l_1860[i][j] = 0xD7L;
        }
        if (((p_39 , (safe_mul_func_int32_t_s_s(((((l_1388 ^ (safe_rshift_func_int16_t_s_u((safe_sub_func_uint64_t_u_u(p_39, (l_1393[2][1] != ((g_1081[2] = &g_392) != (void*)0)))), p_37))) != 1UL) <= ((((safe_rshift_func_int32_t_s_s((((safe_rshift_func_uint32_t_u_u((((safe_mul_func_int32_t_s_s(((((safe_lshift_func_int8_t_s_u(((p_39 ^ l_1393[2][1]) ^ p_39), 7)) <= l_1402) < p_38) , l_1403), 0xBCEF2836L)) | l_1393[0][1]) != l_1393[1][2]), 5)) & (***g_914)) , (-1L)), p_39)) <= l_1402) , (void*)0) == (void*)0)) != 2UL), l_1393[2][1]))) , p_38))
        { /* block id: 648 */
            uint8_t l_1404 = 1UL;
            uint64_t ****l_1409 = &g_1278;
            uint64_t ***l_1410 = &g_1025;
            int32_t *l_1411 = &g_751;
            int8_t *l_1416 = &g_74;
            int8_t **l_1415 = &l_1416;
            int32_t l_1430 = 0xC03031BDL;
            int32_t l_1431 = 0x4B16A169L;
            int32_t l_1432 = 1L;
            --l_1404;
            (*l_1411) &= (((g_1407 && (*g_294)) & l_1404) < (l_1244 = (((*l_1409) = l_1408) != l_1410)));
            (*g_88) = l_1412;
            if ((safe_mul_func_uint8_t_u_u((((*l_1415) = &g_218) == &p_38), ((*l_1361) = l_1417))))
            { /* block id: 656 */
                return p_38;
            }
            else
            { /* block id: 658 */
                int32_t *l_1424 = (void*)0;
                int32_t *l_1427 = &g_751;
                int32_t *l_1428 = &l_1244;
                int32_t *l_1429[1][1];
                int16_t ***l_1449 = &g_1447[5];
                uint8_t ***l_1452 = &l_1385[5];
                uint8_t ****l_1453 = &l_1452;
                uint8_t l_1458 = 0x83L;
                int i, j;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_1429[i][j] = (void*)0;
                }
                for (l_1404 = 0; (l_1404 == 34); l_1404 = safe_add_func_uint32_t_u_u(l_1404, 4))
                { /* block id: 661 */
                    uint16_t **l_1425 = &g_294;
                    uint16_t ***l_1426 = &l_1425;
                    for (l_1388 = 0; (l_1388 <= 46); l_1388 = safe_add_func_int16_t_s_s(l_1388, 2))
                    { /* block id: 664 */
                        return p_39;
                    }
                    for (g_57 = 0; (g_57 < 15); g_57++)
                    { /* block id: 669 */
                        (**g_551) = &l_1393[2][1];
                        (***g_550) = l_1424;
                        if (p_37)
                            continue;
                        return (*l_1411);
                    }
                    (*l_1426) = l_1425;
                }
                l_1434--;
                l_1417 |= ((*l_1428) = (safe_sub_func_int16_t_s_s(((*l_1412) = ((((*l_1411) = p_38) == (~((safe_mul_func_int64_t_s_s((~(safe_sub_func_int16_t_s_s((((safe_rshift_func_int8_t_s_u(p_38, ((*l_1361) = (*l_1412)))) != (((*l_1449) = g_1447[5]) != (void*)0)) , ((safe_mod_func_int16_t_s_s(((((*l_1453) = l_1452) != (void*)0) , ((*g_1448) = (safe_lshift_func_int8_t_s_s(p_39, (((!l_1457[0]) | 0UL) < 0xE984L))))), 65535UL)) > l_1458)), (*g_294)))), 7L)) ^ p_38))) < (*l_1412))), p_37)));
            }
        }
        else
        { /* block id: 687 */
            uint16_t l_1477 = 0xDD3EL;
            int32_t l_1479 = (-1L);
            int32_t *l_1508 = &g_57;
            int32_t l_1524[4][9] = {{0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L},{0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L},{0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L,0x237558E2L},{0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L,0x17EEECB6L}};
            int32_t *****l_1543 = &g_896;
            uint64_t * const *l_1650 = &g_1026;
            const int32_t l_1662 = 0x611FABB1L;
            int16_t ***l_1679 = &g_1447[5];
            uint32_t l_1720 = 0xD5CECE05L;
            int32_t l_1752 = (-4L);
            uint64_t l_1760 = 0xB554EDF78782F0CELL;
            const uint16_t l_1819[7] = {0xE7D6L,0xE7D6L,0xE7D6L,0xE7D6L,0xE7D6L,0xE7D6L,0xE7D6L};
            int32_t *l_1858 = &l_1523[6];
            int32_t *l_1859[4][10][6] = {{{&g_751,(void*)0,(void*)0,&l_1522,&l_1417,&l_1482},{&l_1715[3],&l_1244,&l_1523[7],&l_1433,&l_1433,(void*)0},{&l_1515,&l_1522,&l_1515,&l_1523[6],&g_3[1][1],&l_1417},{&l_1523[6],&g_751,&l_1524[1][5],&l_1524[1][5],&g_751,&l_1523[6]},{&l_1515,&l_1524[1][5],&g_543,&g_1123,&l_1482,&l_1519},{&l_1515,&l_1518,&l_1244,&l_1517,&l_1522,(void*)0},{&l_1515,&l_1482,&l_1517,&g_1123,&l_1524[1][1],&l_1433},{&l_1515,&l_1482,&l_1479,&l_1524[1][5],&l_1521[2],&l_1515},{&l_1523[6],&g_751,&l_1521[8],&l_1523[6],&l_1479,&l_1715[1]},{&l_1515,&l_1517,&l_1479,&l_1433,&l_1479,&l_1521[6]}},{{&l_1715[3],&l_1524[3][1],&l_1521[2],&l_1522,(void*)0,&g_751},{&g_751,&l_1522,&l_1515,&g_751,&l_1433,&l_1244},{&l_1524[1][5],&g_543,&g_57,&l_1715[1],&g_1123,&l_1520},{&l_1522,&l_1523[6],&l_1433,(void*)0,&l_1520,&l_1515},{&l_1522,(void*)0,&l_1519,&l_1524[3][1],&l_1517,&l_1433},{(void*)0,&l_1521[8],&l_1482,(void*)0,&l_1519,&l_1244},{&l_1244,(void*)0,&l_1482,&l_1417,&l_1523[6],&l_1515},{&l_1715[3],&l_1517,&l_1433,&l_1479,(void*)0,&l_1524[3][1]},{&l_1433,&l_1417,&l_1482,&l_1515,&l_1479,&l_1519},{&l_1479,&l_1479,&l_1433,&l_1715[3],&l_1521[2],&l_1523[0]}},{{&l_1715[3],&l_1244,&l_1524[3][1],&l_1479,&l_1482,&l_1482},{(void*)0,&l_1515,&l_1479,&l_1417,&l_1479,&l_1515},{&l_1518,(void*)0,&g_57,&l_1244,&g_751,&l_1715[3]},{&l_1433,(void*)0,&l_1715[3],&l_1524[1][5],&l_1479,&g_57},{&l_1521[6],(void*)0,&l_1522,&l_1519,&g_751,&l_1520},{&l_1482,(void*)0,&l_1517,&l_1521[8],&l_1479,&l_1517},{&l_1482,&l_1515,&l_1523[6],&l_1417,&l_1482,(void*)0},{(void*)0,&l_1244,&l_1522,&l_1522,&l_1521[2],&l_1479},{&l_1479,&l_1479,&l_1520,(void*)0,&l_1479,&l_1524[1][5]},{&l_1417,&l_1417,&l_1521[6],(void*)0,&l_1515,&l_1519}},{{&l_1482,&l_1433,&l_1244,(void*)0,&g_57,&l_1433},{&l_1524[0][0],&l_1515,&l_1433,&l_1523[8],&l_1524[1][1],&l_1518},{(void*)0,(void*)0,&g_751,&l_1515,&l_1515,&l_1523[8]},{&l_1515,&l_1523[0],&l_1522,&l_1523[6],(void*)0,&l_1417},{&l_1522,&l_1433,&l_1519,&l_1417,&l_1522,&l_1515},{&l_1433,(void*)0,&l_1433,&l_1479,&l_1715[3],&l_1521[6]},{&l_1244,&l_1482,&l_1417,&l_1482,&l_1517,&l_1515},{&l_1482,(void*)0,&g_57,&l_1517,(void*)0,&l_1515},{&l_1482,&l_1515,&l_1515,&l_1479,&l_1479,&l_1521[2]},{&g_1123,&g_543,&l_1524[1][5],&l_1515,&l_1515,&l_1524[1][5]}}};
            int32_t l_1863[7];
            int i, j, k;
            for (i = 0; i < 7; i++)
                l_1863[i] = 0xFB95FDF6L;
            for (g_378 = 0; (g_378 <= 5); g_378 += 1)
            { /* block id: 690 */
                uint32_t **l_1467 = &g_468[0][2];
                int8_t *l_1474 = &g_74;
                int8_t **l_1473 = &l_1474;
                int8_t *** const l_1472[4][6] = {{&l_1473,(void*)0,(void*)0,&l_1473,&l_1473,(void*)0},{(void*)0,(void*)0,&l_1473,&l_1473,&l_1473,&l_1473},{&l_1473,&l_1473,&l_1473,&l_1473,&l_1473,&l_1473},{&l_1473,(void*)0,(void*)0,&l_1473,&l_1473,(void*)0}};
                int8_t *** const *l_1471 = &l_1472[3][0];
                uint32_t l_1475 = 0x35A6DAC3L;
                int32_t l_1513 = 9L;
                int32_t l_1516[5][5][7] = {{{0xCE21466EL,0L,0xCE21466EL,0xCE21466EL,0L,0xCE21466EL,0xCE21466EL},{0x56D4CFB3L,0x56D4CFB3L,1L,0x56D4CFB3L,0x56D4CFB3L,1L,0x56D4CFB3L},{0L,0xCE21466EL,0xCE21466EL,0L,0xCE21466EL,0xCE21466EL,0L},{(-1L),0x56D4CFB3L,(-1L),(-1L),0x56D4CFB3L,(-1L),(-1L)},{0L,0L,0xF9CBF0AAL,0L,0L,0xF9CBF0AAL,0xCE21466EL}},{{(-1L),1L,1L,(-1L),1L,1L,(-1L)},{0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL},{(-1L),(-1L),0x56D4CFB3L,(-1L),(-1L),0x56D4CFB3L,(-1L)},{0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL,0xCE21466EL},{1L,(-1L),1L,1L,(-1L),1L,1L}},{{0xCE21466EL,0xCE21466EL,0L,0xCE21466EL,0xCE21466EL,0L,0xCE21466EL},{(-1L),1L,1L,(-1L),1L,1L,(-1L)},{0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL},{(-1L),(-1L),0x56D4CFB3L,(-1L),(-1L),0x56D4CFB3L,(-1L)},{0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL,0xCE21466EL}},{{1L,(-1L),1L,1L,(-1L),1L,1L},{0xCE21466EL,0xCE21466EL,0L,0xCE21466EL,0xCE21466EL,0L,0xCE21466EL},{(-1L),1L,1L,(-1L),1L,1L,(-1L)},{0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL},{(-1L),(-1L),0x56D4CFB3L,(-1L),(-1L),0x56D4CFB3L,(-1L)}},{{0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL,0xCE21466EL},{1L,(-1L),1L,1L,(-1L),1L,1L},{0xCE21466EL,0xCE21466EL,0L,0xCE21466EL,0xCE21466EL,0L,0xCE21466EL},{(-1L),1L,1L,(-1L),1L,1L,(-1L)},{0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL,0xCE21466EL,0xF9CBF0AAL,0xF9CBF0AAL}}};
                int32_t l_1525 = 0x59D749AAL;
                int64_t l_1563 = (-10L);
                int i, j, k;
                (*l_1412) = l_1239[g_378];
                for (g_543 = 0; (g_543 <= 6); g_543 += 1)
                { /* block id: 694 */
                    uint64_t l_1461 = 7UL;
                    int8_t **l_1470 = (void*)0;
                    int8_t ***l_1469 = &l_1470;
                    int8_t ****l_1468 = &l_1469;
                    int32_t l_1478[9] = {(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L),(-5L)};
                    uint32_t l_1487[9][9][3] = {{{0xEA4E9F33L,0x54A74BC3L,18446744073709551609UL},{0x70ABF68AL,0x67F3DA5BL,18446744073709551615UL},{0xF3BE098FL,0xB61228A2L,0xF3BE098FL},{9UL,18446744073709551615UL,0x5D219E22L},{0xEA4E9F33L,0xB61228A2L,0x03F2135DL},{0UL,0x67F3DA5BL,8UL},{0x14796DC8L,0x54A74BC3L,0xF3BE098FL},{0UL,0xE2E4D00FL,0xE2E4D00FL},{0xEA4E9F33L,0UL,18446744073709551609UL}},{{9UL,0x67F3DA5BL,0xE2E4D00FL},{0xF3BE098FL,0xC785B4F8L,0xF3BE098FL},{0x70ABF68AL,18446744073709551615UL,8UL},{0xEA4E9F33L,0xC785B4F8L,0x03F2135DL},{0x67F3DA5BL,0x67F3DA5BL,0x5D219E22L},{0x14796DC8L,0UL,0xF3BE098FL},{0x67F3DA5BL,0xE2E4D00FL,18446744073709551615UL},{0xEA4E9F33L,0x54A74BC3L,18446744073709551609UL},{0x70ABF68AL,0x67F3DA5BL,18446744073709551615UL}},{{0xF3BE098FL,0xB61228A2L,0xF3BE098FL},{9UL,18446744073709551615UL,0x5D219E22L},{0xEA4E9F33L,0xB61228A2L,0x03F2135DL},{0UL,0x67F3DA5BL,8UL},{0x14796DC8L,0x54A74BC3L,0xF3BE098FL},{0UL,0xE2E4D00FL,0xE2E4D00FL},{0xEA4E9F33L,0UL,18446744073709551609UL},{9UL,0x67F3DA5BL,0xE2E4D00FL},{0xF3BE098FL,0xC785B4F8L,0xF3BE098FL}},{{0x70ABF68AL,18446744073709551615UL,8UL},{0xEA4E9F33L,0xC785B4F8L,0x03F2135DL},{0x67F3DA5BL,0x67F3DA5BL,0x5D219E22L},{0x14796DC8L,0UL,0xF3BE098FL},{0x67F3DA5BL,0xE2E4D00FL,18446744073709551615UL},{0xEA4E9F33L,0x54A74BC3L,18446744073709551609UL},{0x70ABF68AL,0x67F3DA5BL,18446744073709551615UL},{0xF3BE098FL,0xB61228A2L,0xF3BE098FL},{9UL,18446744073709551615UL,0x5D219E22L}},{{0xEA4E9F33L,0xB61228A2L,0x03F2135DL},{0UL,0x67F3DA5BL,8UL},{0x14796DC8L,0x54A74BC3L,0xF3BE098FL},{0UL,0xE2E4D00FL,0xE2E4D00FL},{0xEA4E9F33L,0UL,18446744073709551609UL},{9UL,0x67F3DA5BL,0xE2E4D00FL},{0xF3BE098FL,0xC785B4F8L,0xF3BE098FL},{0x70ABF68AL,18446744073709551615UL,8UL},{0xEA4E9F33L,0xC785B4F8L,0x03F2135DL}},{{0x67F3DA5BL,0x67F3DA5BL,0x5D219E22L},{0x14796DC8L,0UL,0xF3BE098FL},{0x67F3DA5BL,0xE2E4D00FL,18446744073709551615UL},{0xEA4E9F33L,0x54A74BC3L,18446744073709551609UL},{0x70ABF68AL,0x67F3DA5BL,18446744073709551615UL},{0xF3BE098FL,0xB61228A2L,0xF3BE098FL},{9UL,18446744073709551615UL,0x5D219E22L},{0xEA4E9F33L,0xB61228A2L,0x03F2135DL},{0UL,0x67F3DA5BL,8UL}},{{0x14796DC8L,0x54A74BC3L,0xF3BE098FL},{0UL,0xE2E4D00FL,0xE2E4D00FL},{0xEA4E9F33L,0UL,18446744073709551609UL},{9UL,0x67F3DA5BL,0xE2E4D00FL},{0xF3BE098FL,0xC785B4F8L,0xF3BE098FL},{0x70ABF68AL,18446744073709551615UL,8UL},{0xEA4E9F33L,0xC785B4F8L,0x03F2135DL},{0x67F3DA5BL,0x67F3DA5BL,0x5D219E22L},{0x14796DC8L,0UL,0xF3BE098FL}},{{0x67F3DA5BL,0xE2E4D00FL,18446744073709551615UL},{0xEA4E9F33L,0x54A74BC3L,18446744073709551609UL},{0x70ABF68AL,0x67F3DA5BL,18446744073709551615UL},{0xF3BE098FL,0xB61228A2L,0xF3BE098FL},{9UL,18446744073709551615UL,0x5D219E22L},{0xEA4E9F33L,0xB61228A2L,0x03F2135DL},{0UL,0x67F3DA5BL,8UL},{0x14796DC8L,0x54A74BC3L,0xF3BE098FL},{0UL,0xE2E4D00FL,0xE2E4D00FL}},{{0xEA4E9F33L,0UL,18446744073709551609UL},{9UL,0x67F3DA5BL,0xE2E4D00FL},{0xF3BE098FL,0xC785B4F8L,0xF3BE098FL},{0x70ABF68AL,18446744073709551615UL,8UL},{0xEA4E9F33L,0xC785B4F8L,0x03F2135DL},{0x67F3DA5BL,0x67F3DA5BL,0x5D219E22L},{0x14796DC8L,0UL,0xF3BE098FL},{0x67F3DA5BL,0xE2E4D00FL,18446744073709551615UL},{0xEA4E9F33L,0x54A74BC3L,18446744073709551609UL}}};
                    const uint8_t *l_1531 = &g_1407;
                    const uint8_t **l_1530 = &l_1531;
                    const uint8_t *** const l_1529 = &l_1530;
                    int32_t *l_1552 = &g_1123;
                    int32_t *l_1553 = &l_1524[1][5];
                    int32_t *l_1554 = &l_1523[0];
                    int32_t *l_1555 = &l_1515;
                    int32_t *l_1556 = (void*)0;
                    int32_t *l_1557 = (void*)0;
                    int32_t *l_1558 = &l_1513;
                    int32_t *l_1559 = &l_1521[0];
                    int32_t *l_1560 = &l_1244;
                    int32_t *l_1561 = (void*)0;
                    int32_t *l_1562[2][2][3] = {{{&l_1521[6],&l_1521[6],&l_1521[6]},{&g_1123,&g_1123,&g_1123}},{{&l_1521[6],&l_1521[6],&l_1521[6]},{&g_1123,&g_1123,&g_1123}}};
                    uint32_t l_1564[10][6][4] = {{{4294967293UL,0xE11881FDL,7UL,4294967288UL},{0UL,0xE11881FDL,0x37A5F999L,0UL},{0xE11881FDL,0xF2FA53D7L,0x38BE3207L,0x37A5F999L},{0UL,1UL,0UL,0x37A5F999L},{4294967293UL,0xF2FA53D7L,4294967295UL,0UL},{4294967294UL,0xE11881FDL,0UL,4294967288UL}},{{1UL,0xE11881FDL,0x38BE3207L,0UL},{0xE7135E1DL,0xF2FA53D7L,0x37A5F999L,0x37A5F999L},{1UL,1UL,7UL,0x37A5F999L},{4294967294UL,0xF2FA53D7L,4294967288UL,0UL},{4294967293UL,0xE11881FDL,7UL,4294967288UL},{0UL,0xE11881FDL,0x37A5F999L,0UL}},{{0xE11881FDL,0xF2FA53D7L,0x38BE3207L,0x37A5F999L},{0UL,1UL,0UL,0x37A5F999L},{4294967293UL,0xF2FA53D7L,4294967295UL,0UL},{4294967294UL,0xE11881FDL,0UL,4294967288UL},{1UL,0xE11881FDL,0x38BE3207L,0UL},{0xE7135E1DL,0xF2FA53D7L,0x37A5F999L,0x37A5F999L}},{{1UL,1UL,7UL,0x37A5F999L},{4294967294UL,0xF2FA53D7L,4294967288UL,0UL},{4294967293UL,0xE11881FDL,7UL,4294967288UL},{0UL,0xE11881FDL,0x37A5F999L,0UL},{0xE11881FDL,0xF2FA53D7L,0x38BE3207L,0x37A5F999L},{0UL,1UL,0UL,0x37A5F999L}},{{4294967293UL,0xF2FA53D7L,4294967295UL,0UL},{4294967294UL,0xE11881FDL,0UL,4294967288UL},{1UL,0xE11881FDL,0x38BE3207L,0UL},{0xE7135E1DL,0xF2FA53D7L,0x37A5F999L,0x37A5F999L},{1UL,1UL,7UL,0x37A5F999L},{4294967294UL,0xF2FA53D7L,4294967288UL,0UL}},{{4294967293UL,0xE11881FDL,7UL,4294967288UL},{0UL,0xE11881FDL,0x37A5F999L,0UL},{0xE11881FDL,0xF2FA53D7L,0x38BE3207L,0x37A5F999L},{0UL,1UL,0UL,0x37A5F999L},{4294967293UL,0xF2FA53D7L,4294967295UL,0UL},{4294967294UL,0xE11881FDL,0UL,4294967288UL}},{{1UL,0xE11881FDL,0x38BE3207L,0UL},{0xE7135E1DL,0xF2FA53D7L,0x37A5F999L,0x37A5F999L},{1UL,1UL,7UL,0x37A5F999L},{4294967294UL,0xF2FA53D7L,4294967288UL,0UL},{4294967293UL,0xE11881FDL,7UL,4294967288UL},{0UL,0xE11881FDL,0x37A5F999L,4294967288UL}},{{4294967293UL,1UL,4294967295UL,0UL},{0xE7135E1DL,0xE11881FDL,4294967288UL,0UL},{0UL,1UL,0x38BE3207L,4294967288UL},{0xFA865B94L,4294967293UL,4294967288UL,0x37A5F999L},{0xE11881FDL,4294967293UL,4294967295UL,4294967288UL},{4294967294UL,1UL,0UL,0UL}},{{0xE11881FDL,0xE11881FDL,4294967295UL,0UL},{0xFA865B94L,1UL,0x37A5F999L,4294967288UL},{0UL,4294967293UL,4294967295UL,0x37A5F999L},{0xE7135E1DL,4294967293UL,0UL,4294967288UL},{4294967293UL,1UL,4294967295UL,0UL},{0xE7135E1DL,0xE11881FDL,4294967288UL,0UL}},{{0UL,1UL,0x38BE3207L,4294967288UL},{0xFA865B94L,4294967293UL,4294967288UL,0x37A5F999L},{0xE11881FDL,4294967293UL,4294967295UL,4294967288UL},{4294967294UL,1UL,0UL,0UL},{0xE11881FDL,0xE11881FDL,4294967295UL,0UL},{0xFA865B94L,1UL,0x37A5F999L,4294967288UL}}};
                    int i, j, k;
                    if ((((safe_lshift_func_uint16_t_u_u((l_1461 , ((safe_add_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u(((((((~p_39) , l_1467) == (**g_913)) , l_1468) != (l_1461 , l_1471)) , ((*g_294) || ((*g_294) || l_1475))), (*l_1412))), p_37)) == g_1476)), (*g_294))) < l_1477) , 0x189AB898L))
                    { /* block id: 695 */
                        (***g_550) = (**g_551);
                    }
                    else
                    { /* block id: 697 */
                        int32_t *l_1480 = &l_1478[2];
                        int32_t *l_1481 = &g_1123;
                        int32_t *l_1483 = &l_1478[6];
                        int32_t *l_1484 = &g_751;
                        int32_t *l_1485 = &g_751;
                        int32_t *l_1486 = &g_1123;
                        --l_1487[1][4][0];
                    }
                    for (l_1479 = 0; (l_1479 <= 2); l_1479 += 1)
                    { /* block id: 702 */
                        int32_t *l_1495 = &l_1417;
                        g_1490 = g_1490;
                        l_1495 = &l_1478[2];
                        ++l_1496;
                    }
                    for (l_1461 = 1; (l_1461 <= 6); l_1461 += 1)
                    { /* block id: 709 */
                        int32_t *l_1509 = &l_1417;
                        int32_t *l_1510 = (void*)0;
                        int32_t *l_1511 = &g_57;
                        int32_t *l_1512[5][8] = {{&l_1482,&l_1244,&g_57,&g_3[1][2],&g_57,&l_1244,&l_1482,&l_1482},{&l_1244,&g_3[1][2],&g_3[0][1],&g_3[0][1],&g_3[1][2],&l_1244,&l_1244,&l_1244},{&g_3[1][2],&l_1244,&l_1244,&l_1244,&g_3[1][2],&g_3[0][1],&g_3[0][1],&g_3[1][2]},{&l_1244,&l_1482,&l_1482,&l_1244,&g_57,&g_3[1][2],&g_57,&l_1244},{&l_1482,&g_57,&l_1482,&g_3[0][1],&l_1244,&l_1244,&g_3[0][1],&l_1482}};
                        uint16_t l_1526 = 65535UL;
                        const uint8_t ***l_1533[4] = {&l_1530,&l_1530,&l_1530,&l_1530};
                        const uint8_t ****l_1532[2][8][9] = {{{&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1]},{&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2]},{&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1]},{&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2]},{&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1]},{&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2]},{&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1]},{&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2]}},{{&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1]},{&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2]},{&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1]},{&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2]},{&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1]},{&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2]},{&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1],&l_1533[1]},{&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2],&l_1533[3],&l_1533[2]}}};
                        const uint8_t ****l_1534 = &l_1533[2];
                        uint16_t **l_1550 = &g_294;
                        uint16_t *** const l_1549 = &l_1550;
                        uint16_t *l_1551 = &l_1477;
                        int i, j, k;
                        l_1412 = ((*l_1358) = (((**l_1467) = (((*****g_1490) ^ (*l_1412)) < (((*l_1474) = ((((*g_294) = (((g_1500[2][7] = l_1499[4][0][1]) == &g_1494) < ((safe_lshift_func_uint64_t_u_u((((0x542773C8L || ((void*)0 == g_1504)) > (p_37 <= ((-1L) > 252UL))) | l_1477), 6)) | p_37))) | p_37) & l_1239[g_378])) == (*l_1412)))) , l_1508));
                        ++l_1526;
                        (*l_1534) = l_1529;
                        l_1525 ^= (safe_sub_func_uint64_t_u_u(((safe_rshift_func_uint16_t_u_u((safe_add_func_int8_t_s_s((safe_div_func_uint8_t_u_u(((l_1543 != (((safe_add_func_int64_t_s_s(((+(*l_1412)) , (*l_1412)), (((safe_lshift_func_int16_t_s_u((((***g_914) , l_1549) == (void*)0), 1)) | ((*l_1509) >= 255UL)) && (((*l_1551) ^= ((**l_1550) = 0x9CEAL)) & l_1478[2])))) , l_1475) , &g_550)) && 8L), p_37)), p_37)), 8)) & (-1L)), p_38));
                    }
                    l_1564[7][3][1]++;
                }
            }
lbl_1721:
            for (l_1519 = 10; (l_1519 <= (-22)); l_1519--)
            { /* block id: 727 */
                uint32_t l_1574 = 0xC2C6FC55L;
                int64_t l_1577 = 0xBCE3F80525143389LL;
                uint16_t *l_1631 = (void*)0;
                uint16_t *l_1632 = &l_1477;
                uint32_t l_1634 = 18446744073709551613UL;
                uint32_t l_1635[1][10] = {{1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL,1UL}};
                uint16_t l_1636 = 0x6C91L;
                uint16_t *l_1637[1];
                int32_t l_1638[10] = {1L,0L,(-4L),(-4L),0L,1L,0L,(-4L),(-4L),0L};
                int32_t l_1639 = 1L;
                int32_t l_1640 = 0xED3CBBF3L;
                int32_t *l_1642 = &l_1515;
                uint64_t * const **l_1651 = &l_1650;
                uint64_t ***l_1652 = &g_1025;
                uint16_t l_1653 = 65535UL;
                int16_t **l_1654 = &l_1378[0][0];
                int i, j;
                for (i = 0; i < 1; i++)
                    l_1637[i] = &g_1230;
                l_1518 ^= (((p_39 > (safe_mul_func_int32_t_s_s((((safe_sub_func_uint16_t_u_u(((**g_467) , 9UL), ((0x6B9E570BL | p_38) <= (+1L)))) | (*l_1412)) >= l_1574), ((safe_mul_func_int16_t_s_s(p_39, p_39)) , 0x1E1714C9L)))) && l_1577) , (-1L));
                (*l_1642) = ((*l_1508) = ((safe_rshift_func_int32_t_s_s((((*l_1412) < ((safe_sub_func_uint8_t_u_u(l_1574, 0UL)) ^ (safe_sub_func_int64_t_s_s((((safe_div_func_uint32_t_u_u((safe_mul_func_int32_t_s_s(((safe_mod_func_int32_t_s_s(((l_1640 = (safe_sub_func_int32_t_s_s((safe_add_func_int16_t_s_s((p_39 = (safe_mod_func_uint32_t_u_u(((safe_lshift_func_uint8_t_u_s((((safe_lshift_func_uint8_t_u_s((l_1639 |= ((safe_mul_func_uint64_t_u_u(((safe_add_func_int16_t_s_s((l_1638[3] &= (safe_mul_func_uint64_t_u_u((safe_sub_func_uint16_t_u_u((g_1230 = (g_629 ^= (((*l_1412) && (*l_1508)) , (+((*l_1361) = (safe_mul_func_int64_t_s_s((safe_div_func_uint8_t_u_u((safe_div_func_uint32_t_u_u((safe_sub_func_int64_t_s_s((((safe_sub_func_uint64_t_u_u((((*g_1448) = (((safe_lshift_func_uint8_t_u_s((safe_sub_func_uint32_t_u_u((safe_rshift_func_int64_t_s_s(((*g_89) , (p_39 , (((((safe_sub_func_uint16_t_u_u((safe_mul_func_int64_t_s_s((((1L != ((*l_1632) &= ((*g_294)--))) == (l_1577 != 0UL)) > (*l_1412)), 0xC25CB7062F5B88FELL)), l_1633)) && p_39) < l_1634) < 65535UL) , 1L))), 44)), p_38)), 6)) & l_1635[0][6]) , l_1636)) , p_37), 0L)) & p_38) == 7L), 0x161D4088330B3320LL)), (**g_467))), (*l_1508))), l_1577))))))), l_1635[0][1])), p_37))), p_37)) >= (**g_1025)), 1UL)) , (*l_1508))), 0)) < 7L) & 0UL), (*l_1412))) <= p_38), p_38))), g_751)), p_38))) != p_37), p_38)) ^ 0xE8FAB23AL), 0x57D53142L)), 0xDE3224E4L)) , p_39) <= p_38), 0x8E0DBD4AC8F6C0C9LL)))) ^ p_38), l_1641)) <= p_37));
                (*l_1412) = ((((safe_add_func_int16_t_s_s((safe_lshift_func_uint64_t_u_u((safe_lshift_func_uint32_t_u_u(((void*)0 == &g_715), (p_39 < ((g_1649 = ((*g_98) = (void*)0)) == (void*)0)))), (((*l_1651) = l_1650) != ((*l_1652) = &g_1026)))), (l_1653 != (((*l_1654) = (((*l_1508) & p_38) , (void*)0)) == &p_39)))) && (-5L)) , p_38) , (*l_1642));
            }
            if ((!((void*)0 != &p_38)))
            { /* block id: 748 */
                uint32_t l_1660 = 4294967287UL;
                int16_t ****l_1680 = &l_1679;
                int32_t l_1683[3][10] = {{0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L},{0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L},{0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L,0x0066AE91L}};
                uint64_t l_1722 = 18446744073709551608UL;
                int32_t **l_1726 = &l_1383;
                int i, j;
                if ((((safe_rshift_func_uint64_t_u_s((safe_div_func_int16_t_s_s(l_1660, (+0x50F0L))), l_1662)) , ((*l_1361) = (safe_add_func_int32_t_s_s(((*l_1508) = ((safe_div_func_uint32_t_u_u((safe_lshift_func_int64_t_s_u((safe_mod_func_int16_t_s_s((safe_div_func_int32_t_s_s(((*l_1412) && (safe_mul_func_uint16_t_u_u(0x5D6AL, (*l_1508)))), (safe_mod_func_int64_t_s_s(((p_37 , (safe_sub_func_int64_t_s_s((((*l_1680) = l_1679) == &g_986), 0UL))) , p_38), (*l_1412))))), (*l_1412))), 54)), (***g_914))) , p_39)), l_1660)))) & p_39))
                { /* block id: 752 */
                    int32_t l_1687 = 0x7ABE260CL;
                    int32_t l_1688[2][10][2] = {{{0x6A81F977L,(-1L)},{0x6A81F977L,7L},{2L,0x6A81F977L},{7L,(-1L)},{0xDE21253AL,0xDE21253AL},{2L,0xDE21253AL},{0xDE21253AL,(-1L)},{7L,0x6A81F977L},{2L,7L},{0x6A81F977L,(-1L)}},{{0x6A81F977L,7L},{2L,0x6A81F977L},{7L,(-1L)},{0xDE21253AL,0xDE21253AL},{2L,0xDE21253AL},{0xDE21253AL,(-1L)},{7L,0x6A81F977L},{2L,7L},{0x6A81F977L,(-1L)},{0x6A81F977L,7L}}};
                    int8_t l_1689 = 3L;
                    uint32_t l_1691 = 8UL;
                    int i, j, k;
                    for (g_605 = 0; (g_605 != 40); g_605 = safe_add_func_int32_t_s_s(g_605, 8))
                    { /* block id: 755 */
                        int32_t l_1684 = 1L;
                        int32_t *l_1685 = &l_1520;
                        int32_t *l_1686[10][6] = {{&l_1518,&l_1479,&l_1417,&l_1519,&l_1523[6],&g_543},{&l_1417,&g_1123,&l_1479,&l_1524[3][2],&l_1417,&l_1517},{&l_1523[6],&g_751,&l_1683[0][9],&l_1517,&l_1524[3][2],&l_1524[3][2]},{&g_3[1][0],(void*)0,(void*)0,&g_3[1][0],&l_1517,&l_1417},{(void*)0,&l_1523[6],&l_1683[0][9],&g_57,&g_543,&l_1523[6]},{&l_1524[1][5],(void*)0,(void*)0,&l_1523[6],&l_1524[3][2],(void*)0},{(void*)0,&l_1519,&l_1524[1][5],&l_1524[1][5],&l_1417,&l_1517},{&g_543,&l_1518,(void*)0,&g_1123,&l_1417,&g_1123},{&l_1519,&l_1683[0][9],&l_1519,&g_543,&l_1523[6],&l_1523[6]},{(void*)0,&l_1524[1][5],&l_1417,&l_1518,&g_751,(void*)0}};
                        int i, j;
                        l_1691--;
                        if (p_37)
                            break;
                    }
                    l_1688[1][2][0] |= (safe_lshift_func_int64_t_s_u((safe_lshift_func_int32_t_s_u((safe_div_func_int32_t_s_s(0x2F140791L, (((***l_1679) ^= (((safe_lshift_func_int64_t_s_s((safe_lshift_func_uint64_t_u_u(18446744073709551608UL, 18)), (safe_rshift_func_int16_t_s_s((safe_mul_func_uint64_t_u_u((((*g_294) || (((**g_1025) |= ((safe_div_func_uint16_t_u_u(((p_39 , ((safe_div_func_int32_t_s_s(0xD3F12EFBL, 0x808BA51BL)) , (safe_unary_minus_func_uint64_t_u((((((void*)0 == &l_1687) != ((safe_sub_func_uint64_t_u_u((0x8FL > (*l_1412)), p_38)) && 0x1EL)) <= 0xDAL) , l_1691))))) > 0x42F0L), p_38)) | 0xA842L)) > p_39)) | p_38), 18446744073709551615UL)), 11)))) & 0xEDD982BDE006E8CDLL) & 0UL)) || l_1715[3]))), 8)), 58));
                    if ((***g_551))
                    { /* block id: 762 */
                        int32_t *l_1717[4][4][4] = {{{&l_1517,&l_1417,&l_1688[1][3][1],&l_1417},{&l_1521[6],&g_3[0][1],&l_1688[0][1][1],&l_1482},{&l_1520,&l_1482,&l_1517,&l_1521[4]},{(void*)0,(void*)0,&l_1521[4],&l_1520}},{{(void*)0,&l_1688[1][4][1],&l_1517,&l_1517},{&l_1520,&l_1520,&l_1688[0][1][1],&l_1522},{&l_1521[6],&l_1688[0][1][1],&l_1688[1][3][1],&g_3[0][1]},{&l_1517,(void*)0,&l_1520,&l_1688[1][3][1]}},{{&l_1688[1][3][1],(void*)0,&l_1520,&g_3[0][1]},{(void*)0,&l_1688[0][1][1],(void*)0,&l_1522},{&l_1688[1][4][1],&l_1520,&l_1482,&l_1517},{&l_1482,&l_1688[1][4][1],&l_1522,&l_1520}},{{&g_3[0][1],(void*)0,&l_1522,&l_1521[4]},{&l_1482,&l_1482,&l_1482,&l_1482},{&l_1688[1][4][1],&g_3[0][1],(void*)0,&l_1417},{(void*)0,&l_1417,&l_1520,(void*)0}}};
                        int i, j, k;
                        l_1523[6] = ((*l_1412) = (safe_unary_minus_func_uint8_t_u((*l_1412))));
                        l_1479 = (((*l_1412) = (((((void*)0 != &l_1361) != (*l_1508)) || ((****g_913) = (p_37 & (*l_1412)))) != (l_1688[1][2][0] = l_1660))) > (l_1683[0][9] , ((safe_lshift_func_uint16_t_u_u((((((((*g_294) = 0xCB15L) & (l_1683[1][7] ^ p_38)) | 0x83917571693FCA1BLL) > 0xDAA2L) < l_1720) & p_37), 8)) != (*g_1026))));
                    }
                    else
                    { /* block id: 770 */
                        if (l_1515)
                            goto lbl_1721;
                        l_1722--;
                    }
                    (*g_88) = (*l_1358);
                }
                else
                { /* block id: 775 */
                    const int16_t *l_1730 = (void*)0;
                    const int16_t **l_1729 = &l_1730;
                    int32_t l_1741 = 0x5243F612L;
                    int32_t l_1742[4];
                    int i;
                    for (i = 0; i < 4; i++)
                        l_1742[i] = 1L;
                    if ((((+p_37) , 9L) , (((void*)0 != l_1726) >= (safe_add_func_uint8_t_u_u(((**g_88) > (l_1729 != (((p_38 & 65531UL) < (safe_sub_func_uint64_t_u_u(((((((**g_1025) > 0xA60CCBCC6562D54CLL) | p_39) | 0xD116FDBEL) == p_39) < 0x3604146E2096B4D5LL), p_37))) , (void*)0))), p_37)))))
                    { /* block id: 776 */
                        return p_38;
                    }
                    else
                    { /* block id: 778 */
                        uint16_t l_1737 = 0UL;
                        int32_t *l_1740[4][2][4] = {{{(void*)0,(void*)0,&l_1524[1][4],&l_1417},{&l_1244,&l_1482,(void*)0,(void*)0}},{{&g_1123,&g_1123,(void*)0,&l_1715[3]},{&l_1244,(void*)0,&l_1524[1][4],&l_1482}},{{(void*)0,&l_1524[1][4],&l_1715[3],&l_1524[1][4]},{&l_1715[3],&l_1524[1][4],(void*)0,&l_1482}},{{&l_1524[1][4],(void*)0,&l_1244,&l_1715[3]},{(void*)0,&g_1123,&g_1123,(void*)0}}};
                        int i, j, k;
                        (*l_1508) ^= ((*g_1026) ^ (((((safe_lshift_func_uint16_t_u_s((*g_294), ((*g_89) & p_37))) ^ p_37) ^ p_38) ^ ((((*g_1491) == ((safe_add_func_uint8_t_u_u(l_1737, ((*l_1361)++))) , (**g_1490))) & p_39) ^ 0x83L)) & p_37));
                        g_1743++;
                    }
                    (*g_88) = (*l_1358);
                    return p_39;
                }
            }
            else
            { /* block id: 786 */
                uint16_t l_1748 = 65528UL;
                int8_t l_1751 = 0xCCL;
                int32_t l_1753 = (-5L);
                int32_t l_1758 = (-5L);
                int32_t l_1759[2][3][7] = {{{0x46EAF830L,6L,6L,0x46EAF830L,0xC10044F1L,0x22B67A1EL,(-10L)},{(-10L),0x22B67A1EL,0xC10044F1L,0x46EAF830L,6L,6L,0x46EAF830L},{(-3L),0x733F8928L,(-3L),0x22B67A1EL,(-7L),(-1L),(-10L)}},{{0x733F8928L,0L,(-3L),0xC10044F1L,0x85711EF0L,0xC10044F1L,(-3L)},{(-7L),(-7L),0xC10044F1L,0xB1478842L,0x4757C095L,(-1L),0x733F8928L},{0xB1478842L,(-7L),6L,(-1L),(-1L),6L,(-7L)}}};
                int8_t *l_1763 = &g_218;
                const int16_t *l_1768 = &g_73[1][1][7];
                const int16_t **l_1767 = &l_1768;
                const int16_t ***l_1766 = &l_1767;
                uint64_t l_1797 = 0xE4D953C55B231B9DLL;
                int8_t l_1817 = 0x07L;
                int16_t ****l_1842 = (void*)0;
                int16_t *****l_1841 = &l_1842;
                int16_t l_1856 = 0x129FL;
                uint32_t **l_1857 = &g_468[0][2];
                int i, j, k;
                for (p_39 = 0; (p_39 >= 0); p_39 -= 1)
                { /* block id: 789 */
                    int32_t **l_1746 = &l_1383;
                    int32_t l_1754 = 0xBC35D0FCL;
                    int32_t **l_1783[10][4] = {{&g_100[2][6],&l_1412,&g_100[2][6],&g_100[2][6]},{&l_1412,&l_1412,&l_1412,&l_1412},{&l_1412,&g_100[2][6],&g_100[2][6],&l_1412},{&g_100[2][6],&l_1412,&g_100[2][6],&g_100[2][6]},{&l_1412,&l_1412,&l_1412,&l_1412},{&l_1412,&g_100[2][6],&g_100[2][6],&g_100[2][6]},{&l_1412,&g_100[2][6],&l_1412,&l_1412},{&g_100[2][6],&g_100[2][6],&l_1412,&g_100[2][6]},{&g_100[2][6],&l_1412,&l_1412,&g_100[2][6]},{&l_1412,&g_100[2][6],&l_1412,&l_1412}};
                    int32_t l_1818 = (-8L);
                    int i, j;
                    for (g_657 = 0; (g_657 >= 0); g_657 -= 1)
                    { /* block id: 792 */
                        int32_t ***l_1747 = &l_1746;
                        int i;
                        (*l_1747) = l_1746;
                        l_1748--;
                    }
                    if (l_1751)
                        break;
                }
                (*l_1841) = &l_1679;
                l_1758 ^= (p_39 , (((****l_1842) = (*g_1448)) | (((g_1005 , (l_1797 & ((((safe_add_func_uint8_t_u_u((((+(safe_sub_func_uint64_t_u_u((*l_1412), ((((safe_div_func_uint32_t_u_u((safe_sub_func_int8_t_s_s(p_39, (safe_rshift_func_uint64_t_u_u(l_1753, ((((*g_1026)--) != ((-4L) ^ l_1856)) | 5L))))), l_1748)) , 1UL) ^ (**g_467)) , 0L)))) & 0xCAL) | 0xA2A8DA833AA16B30LL), l_1797)) , 0x1ED9016BL) , (**g_913)) != l_1857))) , l_1759[0][0][1]) <= (*g_294))));
            }
            l_1864[2][0]++;
        }
    }
    if (((safe_div_func_uint32_t_u_u(l_1869, (((safe_mul_func_uint64_t_u_u((((*l_1875) = ((*l_1874) = (18446744073709551615UL == 0x5A4E85D0648E975FLL))) != ((p_38 , &l_1514) != ((!0x1DL) , &g_337))), (safe_mod_func_uint64_t_u_u(((**g_1025) = (l_1879 != (l_1880 = l_1879))), 1UL)))) != 0x16L) & p_38))) && p_38))
    { /* block id: 847 */
        uint64_t l_1881 = 0x4F20BEAC91A12184LL;
        uint8_t ** const *l_1893[1][6] = {{&l_1385[4],&l_1385[4],&l_1385[4],&l_1385[4],&l_1385[4],&l_1385[4]}};
        int32_t l_1899 = 0xEC364F94L;
        uint16_t **l_1908 = &g_294;
        uint16_t ***l_1907[6];
        int16_t l_1919 = (-1L);
        int16_t ***l_1932 = &g_1447[2];
        int16_t ****l_1931 = &l_1932;
        int16_t *****l_1930 = &l_1931;
        uint32_t *l_1942[9];
        int8_t ***l_1950 = &g_1500[2][3];
        int8_t ****l_1949[6][10][4] = {{{&l_1950,(void*)0,(void*)0,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,&l_1950,(void*)0},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,(void*)0,(void*)0,&l_1950},{(void*)0,&l_1950,&l_1950,&l_1950},{(void*)0,(void*)0,&l_1950,(void*)0},{&l_1950,&l_1950,(void*)0,(void*)0},{(void*)0,(void*)0,&l_1950,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950}},{{&l_1950,(void*)0,(void*)0,&l_1950},{&l_1950,&l_1950,&l_1950,(void*)0},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,(void*)0,&l_1950},{&l_1950,(void*)0,&l_1950,&l_1950},{(void*)0,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,(void*)0,&l_1950},{&l_1950,&l_1950,(void*)0,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950},{(void*)0,&l_1950,&l_1950,(void*)0}},{{&l_1950,(void*)0,(void*)0,&l_1950},{&l_1950,(void*)0,&l_1950,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,(void*)0,(void*)0},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,(void*)0,&l_1950,&l_1950},{(void*)0,(void*)0,(void*)0,&l_1950},{&l_1950,(void*)0,&l_1950,&l_1950},{(void*)0,(void*)0,&l_1950,&l_1950},{(void*)0,&l_1950,(void*)0,(void*)0}},{{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,(void*)0,&l_1950,&l_1950},{&l_1950,(void*)0,(void*)0,(void*)0},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,(void*)0,(void*)0,&l_1950}},{{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,&l_1950,(void*)0},{&l_1950,&l_1950,&l_1950,(void*)0},{&l_1950,(void*)0,(void*)0,&l_1950},{&l_1950,&l_1950,(void*)0,&l_1950},{(void*)0,&l_1950,&l_1950,&l_1950},{(void*)0,&l_1950,&l_1950,&l_1950},{(void*)0,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,(void*)0,&l_1950},{&l_1950,(void*)0,&l_1950,(void*)0}},{{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,(void*)0,(void*)0,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950},{&l_1950,(void*)0,&l_1950,&l_1950},{(void*)0,(void*)0,&l_1950,&l_1950},{&l_1950,&l_1950,(void*)0,(void*)0},{&l_1950,&l_1950,(void*)0,&l_1950},{&l_1950,&l_1950,&l_1950,(void*)0},{(void*)0,&l_1950,&l_1950,&l_1950},{&l_1950,&l_1950,&l_1950,&l_1950}}};
        int8_t *****l_1948 = &l_1949[5][6][1];
        int32_t **l_1981 = &g_100[2][6];
        int32_t l_2008 = 0x9807BFFBL;
        int32_t l_2015 = 7L;
        int32_t l_2017 = 0xBB4AFCFEL;
        int32_t l_2019 = 0x977FD1FBL;
        int8_t *l_2048 = &l_1886;
        uint32_t *l_2062 = &g_125;
        int32_t l_2079 = 1L;
        uint64_t l_2119 = 0x02CFC97FDA55CE7ALL;
        int32_t l_2132 = 0x1792F417L;
        int32_t l_2133 = 0L;
        int32_t l_2134 = 0x60972ECEL;
        int32_t l_2136 = (-10L);
        int32_t l_2137[9][1][6] = {{{0x69D47E15L,0x69D47E15L,(-1L),1L,1L,0L}},{{1L,0x8708858DL,0xC9C6E5BAL,1L,0x8708858DL,(-1L)}},{{0x69D47E15L,1L,0xC9C6E5BAL,1L,0x69D47E15L,0L}},{{0xAA369B16L,1L,(-1L),0xAA369B16L,0x8708858DL,0xCDCE5CD6L}},{{0xAA369B16L,0x8708858DL,0xCDCE5CD6L,1L,1L,0xCDCE5CD6L}},{{0x69D47E15L,0x69D47E15L,(-1L),1L,1L,0L}},{{1L,0x8708858DL,0xC9C6E5BAL,1L,0x8708858DL,(-1L)}},{{0x69D47E15L,1L,0xC9C6E5BAL,1L,0x69D47E15L,0L}},{{0xAA369B16L,1L,(-1L),0xAA369B16L,0x8708858DL,0xCDCE5CD6L}}};
        uint8_t *****l_2181 = &g_2109;
        int i, j, k;
        for (i = 0; i < 6; i++)
            l_1907[i] = &l_1908;
        for (i = 0; i < 9; i++)
            l_1942[i] = &g_1476;
lbl_1884:
        for (g_777 = 2; (g_777 >= 0); g_777 -= 1)
        { /* block id: 850 */
            int i;
            return l_1521[(g_777 + 3)];
        }
        --l_1881;
        for (g_218 = 0; (g_218 <= 2); g_218 += 1)
        { /* block id: 856 */
            uint32_t l_1898 = 0x230B01F8L;
            int32_t ***l_1913 = &l_1382;
            int32_t l_1915 = (-1L);
            int8_t l_1916 = 0x19L;
            int16_t ***l_1929 = &g_1447[6];
            int16_t ****l_1928[2];
            int16_t *****l_1927 = &l_1928[1];
            int64_t *l_1952[9];
            int32_t l_1955 = 0x5828949FL;
            int16_t l_1998[7];
            int8_t l_1999 = 0xCFL;
            uint64_t l_2020[9] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
            int16_t l_2057 = 0xFEEEL;
            uint8_t ** const *l_2086 = &l_1385[5];
            int32_t *l_2088 = &g_751;
            int32_t l_2117 = (-3L);
            int64_t l_2118 = 0L;
            int32_t l_2126 = 0L;
            int32_t l_2129[9][8];
            uint32_t l_2139 = 18446744073709551615UL;
            int32_t l_2142 = 0x79ABDAC2L;
            int32_t ****l_2171[8][3] = {{&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98}};
            uint8_t *****l_2182 = &g_2109;
            int i, j;
            for (i = 0; i < 2; i++)
                l_1928[i] = &l_1929;
            for (i = 0; i < 9; i++)
                l_1952[i] = &g_1122;
            for (i = 0; i < 7; i++)
                l_1998[i] = (-1L);
            for (i = 0; i < 9; i++)
            {
                for (j = 0; j < 8; j++)
                    l_2129[i][j] = 0xB50A315FL;
            }
            for (g_1862 = 2; (g_1862 >= 0); g_1862 -= 1)
            { /* block id: 859 */
                int32_t l_1885[8] = {0x62DF6D0AL,0x62DF6D0AL,1L,0x62DF6D0AL,0x62DF6D0AL,1L,0x62DF6D0AL,0x62DF6D0AL};
                int16_t **l_1889 = &l_1378[7][1];
                int32_t l_1890 = (-1L);
                uint16_t l_1894[7];
                uint8_t * const *l_1904[2][5][1] = {{{&l_1361},{&g_1081[1]},{&l_1361},{&g_1081[1]},{&l_1361}},{{&g_1081[1]},{&l_1361},{&g_1081[1]},{&l_1361},{&g_1081[1]}}};
                int8_t l_1917[5][8] = {{1L,0x76L,0xC0L,0x76L,1L,1L,1L,0x76L},{0xDFL,0x76L,0xDFL,1L,1L,1L,0xC0L,1L},{0xDFL,1L,0xC0L,1L,0xC0L,1L,0xDFL,1L},{0xDFL,1L,1L,1L,0xDFL,0x76L,0xDFL,1L},{0xC0L,1L,0xC0L,1L,0xDFL,1L,0xC0L,1L}};
                int i, j, k;
                for (i = 0; i < 7; i++)
                    l_1894[i] = 65529UL;
                for (l_1881 = 0; (l_1881 <= 2); l_1881 += 1)
                { /* block id: 862 */
                    int i;
                    if (l_1384[(g_218 + 1)])
                    { /* block id: 863 */
                        int i, j;
                        (**g_551) = g_468[g_218][(g_218 + 2)];
                        if (g_337)
                            goto lbl_1884;
                        l_1521[l_1881] ^= 0x2B1E62BBL;
                    }
                    else
                    { /* block id: 867 */
                        if (l_1885[3])
                            break;
                    }
                    for (g_1743 = 0; (g_1743 <= 3); g_1743 += 1)
                    { /* block id: 872 */
                        (*l_1874) = l_1886;
                    }
                    if (p_39)
                        break;
                }
                for (g_57 = 0; (g_57 <= 2); g_57 += 1)
                { /* block id: 879 */
                    int32_t l_1900 = 0xA4896213L;
                    uint64_t l_1901[7][1];
                    int i, j;
                    for (i = 0; i < 7; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_1901[i][j] = 8UL;
                    }
                    if ((((((*g_1026) = 0xAAB11996C2CA4159LL) > 1UL) , ((((**g_1025)--) <= (g_468[g_218][(g_218 + 3)] != (void*)0)) & ((*g_1501) |= (l_1890 ^= ((void*)0 != l_1889))))) , p_37))
                    { /* block id: 884 */
                        uint32_t l_1897 = 0xF407652EL;
                        l_1899 &= ((p_38 & ((safe_rshift_func_uint64_t_u_u((l_1894[4] ^= ((p_37 , (p_39 >= p_37)) == ((l_1893[0][4] != (void*)0) , 0UL))), 27)) , (((**l_1880) &= ((((l_1898 = ((*l_1361) = ((*g_294) || ((safe_sub_func_uint32_t_u_u(l_1894[4], l_1897)) | (*l_1875))))) < (*l_1874)) | 3L) <= (*g_294))) != 0xEBE998D795D1D31FLL))) > 255UL);
                        return (**g_467);
                    }
                    else
                    { /* block id: 891 */
                        (*l_1874) &= 2L;
                        l_1901[6][0]++;
                    }
                    for (l_1517 = 0; (l_1517 <= 5); l_1517 += 1)
                    { /* block id: 897 */
                        uint64_t l_1914 = 0x0AFBD13D8C537847LL;
                        l_1915 = ((l_1904[0][0][0] == &l_1361) == (l_1901[6][0] <= ((((((safe_div_func_int64_t_s_s((((&g_1505 == l_1907[2]) <= (((**l_1880) = p_39) >= 0xA98815CBCEF054A2LL)) && (safe_sub_func_int32_t_s_s((safe_mul_func_int8_t_s_s(((p_38 = p_37) == ((p_37 , l_1913) == (void*)0)), l_1901[6][0])), p_37))), l_1914)) | (*g_294)) >= l_1894[3]) , p_39) , (-6L)) ^ 0xC0233FD52A42BBD4LL)));
                    }
                    if ((l_1916 == 1UL))
                    { /* block id: 902 */
                        (*l_1874) = p_37;
                        return l_1917[2][6];
                    }
                    else
                    { /* block id: 905 */
                        int64_t l_1918 = 0L;
                        l_1918 = l_1890;
                        return l_1919;
                    }
                }
                (*l_1875) = 0xAFB1CAD2L;
                if (l_1915)
                { /* block id: 911 */
                    (*l_1875) = (p_37 >= p_38);
                    (*g_88) = (void*)0;
                    (*l_1874) = p_39;
                    if (g_215)
                        goto lbl_1884;
                }
                else
                { /* block id: 916 */
                    uint32_t l_1920 = 0x97D6A583L;
                    int8_t *****l_1947 = (void*)0;
                    int32_t l_1951 = (-3L);
                    int i, j;
                    ++l_1920;
                    (*l_1875) = (safe_sub_func_int32_t_s_s(((safe_mul_func_uint64_t_u_u((p_38 > (l_1951 = ((p_39 >= (((((g_1933[0] = (l_1930 = l_1927)) != (g_1937[0][0][5] = l_1936[2][0])) , (safe_rshift_func_int16_t_s_u(0x6322L, 5))) > (safe_mod_func_uint64_t_u_u(((((g_468[g_218][(g_1862 + 1)] != (((*****l_1927) ^= (l_1915 ^= (-1L))) , l_1942[5])) >= (safe_mul_func_uint16_t_u_u(((safe_mul_func_int64_t_s_s((l_1947 == l_1948), l_1920)) > 0xCDL), 65532UL))) < (****g_913)) & (***g_914)), p_39))) == 1UL)) ^ p_38))), p_37)) , 0xAAA0C7D0L), p_37));
                    if ((((*l_1874) , l_1952[5]) == (void*)0))
                    { /* block id: 925 */
                        int8_t l_1953 = 0x4DL;
                        return l_1953;
                    }
                    else
                    { /* block id: 927 */
                        return (***g_914);
                    }
                }
                for (p_39 = 2; (p_39 >= 0); p_39 -= 1)
                { /* block id: 933 */
                    return (***g_914);
                }
            }
            for (l_1916 = 5; (l_1916 >= 0); l_1916 -= 1)
            { /* block id: 939 */
                uint64_t l_1957 = 0x1121825F2AAF3324LL;
                int32_t l_1967 = 1L;
                int32_t l_2018[1];
                int16_t ** const *l_2055 = &g_1447[5];
                int16_t l_2056 = 0L;
                uint32_t *l_2063 = &g_1476;
                int i, j;
                for (i = 0; i < 1; i++)
                    l_2018[i] = 0xBAF640DEL;
                (***g_550) = (*l_1358);
            }
            for (g_543 = 0; (g_543 <= 2); g_543 += 1)
            { /* block id: 1003 */
                int16_t l_2111 = (-2L);
                int32_t *l_2112 = &l_1244;
                int32_t l_2113 = 0xFB577810L;
                int32_t *l_2114 = (void*)0;
                int32_t *l_2115 = &l_1899;
                int32_t *l_2116[2];
                int8_t *****l_2123 = &l_1949[5][6][1];
                int8_t l_2128 = 1L;
                int64_t l_2131 = 0L;
                int32_t l_2135 = 0L;
                int16_t l_2138 = 0xE489L;
                int i;
                for (i = 0; i < 2; i++)
                    l_2116[i] = &l_1521[6];
                --l_2119;
                if (p_39)
                    break;
                if ((*l_1874))
                { /* block id: 1006 */
                    int64_t l_2122 = 0xEE8C25C54F0108C1LL;
                    return l_2122;
                }
                else
                { /* block id: 1008 */
                    int16_t ** const l_2125 = &l_1378[7][0];
                    int32_t l_2127[6][9] = {{0x493B9578L,0x24AA6DDCL,0xD35FC89FL,0x493B9578L,0xD35FC89FL,0x24AA6DDCL,0x493B9578L,0x614EA6A5L,0x614EA6A5L},{0x493B9578L,0x24AA6DDCL,0xD35FC89FL,0x493B9578L,0xD35FC89FL,0x24AA6DDCL,0x493B9578L,0x614EA6A5L,0x614EA6A5L},{0x493B9578L,0x24AA6DDCL,0xD35FC89FL,0x493B9578L,0xD35FC89FL,0x24AA6DDCL,0x493B9578L,0x614EA6A5L,0x614EA6A5L},{0x493B9578L,0x24AA6DDCL,0xD35FC89FL,0x493B9578L,0xD35FC89FL,0x24AA6DDCL,0x493B9578L,0x614EA6A5L,0x614EA6A5L},{0x493B9578L,0x24AA6DDCL,0xD35FC89FL,0x493B9578L,0xD35FC89FL,0x24AA6DDCL,0x493B9578L,0x614EA6A5L,0x614EA6A5L},{0x493B9578L,0x24AA6DDCL,0xD35FC89FL,0x493B9578L,0xD35FC89FL,0x24AA6DDCL,0x493B9578L,0x614EA6A5L,0x614EA6A5L}};
                    int i, j;
                    (*l_1875) &= ((p_37 & (l_2123 != (l_1948 = g_2124))) , (((***l_1930) = (*g_1935)) != l_2125));
                    l_2139++;
                    (*l_1874) |= l_2142;
                    (*l_2088) = ((*l_2112) = ((((**g_1025) = p_39) != (safe_add_func_int16_t_s_s((safe_lshift_func_int32_t_s_u(p_37, 22)), (safe_rshift_func_uint64_t_u_s(((safe_div_func_int32_t_s_s(p_38, (safe_add_func_uint32_t_u_u(l_2127[3][4], (*l_2088))))) == ((*g_294) = ((+p_39) == (safe_mod_func_uint16_t_u_u(p_38, (safe_div_func_uint32_t_u_u((p_37 , ((safe_mod_func_uint32_t_u_u((~p_38), 5L)) <= l_2161)), 4294967295UL))))))), 61))))) < (*l_1875)));
                }
            }
            for (l_1433 = 0; (l_1433 <= 2); l_1433 += 1)
            { /* block id: 1022 */
                int64_t l_2178 = 1L;
                uint8_t *****l_2180 = &g_2109;
                for (g_337 = 2; (g_337 >= 0); g_337 -= 1)
                { /* block id: 1025 */
                    uint64_t ****l_2168 = &g_1278;
                    int32_t l_2175 = 0L;
                    (*l_1875) = ((l_2181 = (((((safe_div_func_int8_t_s_s(0x74L, (((safe_mul_func_int32_t_s_s((((*g_1501) = (safe_mul_func_int64_t_s_s((((*l_2168) = &g_1025) != ((((safe_rshift_func_uint64_t_u_s((&l_1787 != (l_2172 = l_2171[4][2])), 47)) >= ((safe_mul_func_int16_t_s_s((l_2175 >= ((safe_mul_func_uint64_t_u_u((p_39 , (*g_1026)), (((p_37 & l_2178) & 0x04CEFAFDL) >= p_38))) <= l_2179)), p_37)) , 18446744073709551614UL)) , p_39) , (void*)0)), p_37))) < 7L), 0xEEDE6C9AL)) && 255UL) , l_2175))) == (***g_914)) , p_38) || 0x0BCE9728L) , l_2180)) == l_2182);
                }
                if (p_38)
                    break;
            }
        }
    }
    else
    { /* block id: 1035 */
        int32_t *l_2183[1][3][10] = {{{&g_1123,&l_1244,&l_1433,&l_1515,&l_1433,&l_1244,&g_1123,&l_1244,&l_1433,&l_1515},{&l_1433,&l_1515,&l_1433,&l_1244,&g_1123,&l_1244,&l_1433,&l_1515,&l_1433,&l_1244},{&g_1123,&l_1515,&l_1521[4],&l_1515,&g_1123,&g_3[2][0],&g_1123,&l_1515,&l_1521[4],&l_1515}}};
        uint64_t *l_2191[1];
        int16_t ****l_2196 = (void*)0;
        int16_t *** const *l_2197[8][8] = {{(void*)0,&g_1935,&g_1935,&g_1935,&g_1935,&g_1935,(void*)0,&g_1935},{(void*)0,&g_1935,&g_1935,&g_1935,(void*)0,&g_1935,(void*)0,&g_1935},{&g_1935,&g_1935,&g_1935,&g_1935,(void*)0,&g_1935,&g_1935,&g_1935},{(void*)0,&g_1935,&g_1935,&g_1935,&g_1935,&g_1935,(void*)0,&g_1935},{(void*)0,&g_1935,&g_1935,&g_1935,(void*)0,&g_1935,(void*)0,&g_1935},{&g_1935,&g_1935,&g_1935,&g_1935,(void*)0,&g_1935,&g_1935,&g_1935},{(void*)0,&g_1935,&g_1935,&g_1935,&g_1935,&g_1935,(void*)0,&g_1935},{(void*)0,&g_1935,&g_1935,&g_1935,(void*)0,&g_1935,(void*)0,&g_1935}};
        uint32_t l_2207 = 0x85C249B5L;
        int32_t l_2241 = 0L;
        uint64_t l_2258 = 0xEB02BB90EBDDD4BDLL;
        int32_t l_2259 = 0xE4473544L;
        int8_t ** const ** const l_2267 = (void*)0;
        int8_t **l_2272[5] = {&g_1501,&g_1501,&g_1501,&g_1501,&g_1501};
        int8_t *** const l_2271 = &l_2272[1];
        int8_t *** const *l_2270 = &l_2271;
        int64_t l_2328 = 0L;
        const uint8_t *l_2371[4] = {&g_1407,&g_1407,&g_1407,&g_1407};
        const uint8_t **l_2370 = &l_2371[2];
        const uint8_t ***l_2369 = &l_2370;
        const uint8_t ****l_2368 = &l_2369;
        const uint8_t *****l_2367 = &l_2368;
        uint64_t **l_2383 = &l_2191[0];
        uint32_t l_2387 = 0x62B4DB67L;
        int64_t **l_2393[5][6][1] = {{{&g_387[1][4][0]},{&l_1374},{&l_1374},{&g_387[1][4][0]},{&l_1374},{&l_1374}},{{&g_387[1][4][0]},{&g_387[1][4][0]},{&g_387[1][4][0]},{&l_1374},{&g_387[1][4][0]},{&g_387[1][4][0]}},{{&l_1374},{&g_387[1][4][0]},{&g_387[1][4][0]},{&l_1374},{&g_387[1][4][0]},{&g_387[1][4][0]}},{{&l_1374},{&g_387[1][4][0]},{&g_387[1][4][0]},{&l_1374},{&g_387[1][4][0]},{&g_387[1][4][0]}},{{&l_1374},{&g_387[1][4][0]},{&g_387[1][4][0]},{&l_1374},{&g_387[1][4][0]},{&g_387[1][4][0]}}};
        uint32_t l_2427[4];
        const uint32_t *l_2470 = &l_2427[2];
        const uint32_t **l_2469 = &l_2470;
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_2191[i] = &l_1633;
        for (i = 0; i < 4; i++)
            l_2427[i] = 0xD952D85DL;
        (**g_551) = l_2183[0][0][8];
        (*l_1874) |= (safe_sub_func_int16_t_s_s((*l_1875), ((void*)0 == (**g_2108))));
        for (g_138 = 14; (g_138 != 1); --g_138)
        { /* block id: 1040 */
            int64_t *l_2192 = &g_337;
            int32_t l_2193 = 0xB6448E56L;
            int32_t *l_2195 = &l_2193;
            uint8_t l_2211 = 0x12L;
            int32_t l_2242 = 0x92DCAAEBL;
            int32_t l_2243 = 0x919B5D5DL;
            const int16_t *l_2297 = &l_1384[2];
            const int16_t **l_2296 = &l_2297;
            uint8_t l_2314 = 252UL;
            int8_t l_2317 = (-6L);
            int32_t l_2319 = 0L;
            int32_t l_2322[1][7] = {{(-4L),(-1L),(-4L),(-4L),(-1L),(-4L),(-4L)}};
            uint64_t **l_2381 = &g_1026;
            int64_t **l_2394[4];
            uint64_t ***l_2441 = &l_2383;
            uint8_t *****l_2465[8][1][10] = {{{&g_2109,(void*)0,&g_2109,&g_2109,&g_2109,&g_2109,(void*)0,&g_2109,&g_2109,&g_2109}},{{&g_2109,(void*)0,&g_2109,&g_2109,&g_2109,&g_2109,(void*)0,&g_2109,&g_2109,&g_2109}},{{&g_2109,(void*)0,&g_2109,&g_2109,&g_2109,&g_2109,(void*)0,&g_2109,&g_2109,&g_2109}},{{&g_2109,(void*)0,&g_2109,&g_2109,&g_2109,&g_2109,(void*)0,&g_2109,&g_2109,&g_2109}},{{&g_2109,(void*)0,&g_2109,&g_2109,&g_2109,&g_2109,(void*)0,&g_2109,&g_2109,&g_2109}},{{&g_2109,(void*)0,&g_2109,&g_2109,&g_2109,&g_2109,(void*)0,&g_2109,&g_2109,&g_2109}},{{&g_2109,(void*)0,&g_2109,&g_2109,&g_2109,&g_2109,(void*)0,&g_2109,&g_2109,&g_2109}},{{&g_2109,(void*)0,&g_2109,&g_2109,&g_2109,&g_2109,(void*)0,&g_2109,&g_2109,&g_2109}}};
            int64_t l_2467 = 1L;
            int i, j, k;
            for (i = 0; i < 4; i++)
                l_2394[i] = (void*)0;
        }
    }
    return (***g_914);
}


/* ------------------------------------------ */
/* 
 * reads : g_265 g_3
 * writes: g_265
 */
static int16_t  func_46(int8_t  p_47, uint8_t  p_48)
{ /* block id: 227 */
    uint16_t l_561[1];
    int32_t l_574[3][1][9] = {{{0x706E02A5L,0x2FA86B30L,0x706E02A5L,0x2FA86B30L,0x706E02A5L,0x2FA86B30L,0x706E02A5L,0x2FA86B30L,0x706E02A5L}},{{0x5CF535A0L,0x5CF535A0L,0x5CF535A0L,0x5CF535A0L,0x5CF535A0L,0x5CF535A0L,0x5CF535A0L,0x5CF535A0L,0x5CF535A0L}},{{0x706E02A5L,0x2FA86B30L,0x706E02A5L,0x2FA86B30L,0x706E02A5L,0x2FA86B30L,0x706E02A5L,0x2FA86B30L,0x706E02A5L}}};
    int32_t l_596 = 0xA6F6CE57L;
    uint8_t *l_637[1][2][1];
    uint8_t * const *l_636[4];
    uint64_t l_656[3];
    uint64_t l_702 = 0xBAFC2234E18AE90CLL;
    int8_t l_727 = 0xEBL;
    int32_t l_753 = 0L;
    uint64_t l_843 = 0x67B2BC81A9500DCFLL;
    int32_t *l_900[5][6][6] = {{{&g_901[0],&g_901[0],(void*)0,&g_901[0],&g_901[0],&g_901[0]},{&g_901[0],&g_901[0],&g_901[0],&g_901[0],(void*)0,&g_901[0]},{&g_901[0],&g_901[0],(void*)0,&g_901[0],(void*)0,&g_901[0]},{(void*)0,(void*)0,&g_901[0],(void*)0,(void*)0,(void*)0},{&g_901[0],&g_901[0],&g_901[0],(void*)0,(void*)0,(void*)0},{(void*)0,&g_901[0],&g_901[0],&g_901[0],&g_901[0],(void*)0}},{{(void*)0,&g_901[0],&g_901[0],(void*)0,(void*)0,(void*)0},{&g_901[0],&g_901[0],&g_901[0],(void*)0,&g_901[0],&g_901[0]},{&g_901[0],(void*)0,(void*)0,(void*)0,&g_901[0],&g_901[0]},{&g_901[0],(void*)0,&g_901[0],&g_901[0],&g_901[0],&g_901[0]},{(void*)0,(void*)0,&g_901[0],&g_901[0],&g_901[0],&g_901[0]},{(void*)0,&g_901[0],&g_901[0],&g_901[0],&g_901[0],&g_901[0]}},{{&g_901[0],(void*)0,&g_901[0],(void*)0,(void*)0,&g_901[0]},{(void*)0,(void*)0,&g_901[0],(void*)0,&g_901[0],&g_901[0]},{(void*)0,&g_901[0],&g_901[0],(void*)0,&g_901[0],(void*)0},{(void*)0,&g_901[0],(void*)0,(void*)0,&g_901[0],(void*)0},{&g_901[0],&g_901[0],&g_901[0],&g_901[0],&g_901[0],&g_901[0]},{(void*)0,&g_901[0],&g_901[0],&g_901[0],&g_901[0],(void*)0}},{{(void*)0,&g_901[0],&g_901[0],&g_901[0],&g_901[0],(void*)0},{&g_901[0],(void*)0,&g_901[0],&g_901[0],(void*)0,&g_901[0]},{&g_901[0],(void*)0,&g_901[0],(void*)0,&g_901[0],(void*)0},{&g_901[0],&g_901[0],(void*)0,&g_901[0],&g_901[0],(void*)0},{&g_901[0],(void*)0,&g_901[0],&g_901[0],&g_901[0],&g_901[0]},{(void*)0,(void*)0,&g_901[0],&g_901[0],&g_901[0],&g_901[0]}},{{(void*)0,&g_901[0],&g_901[0],&g_901[0],&g_901[0],&g_901[0]},{&g_901[0],(void*)0,&g_901[0],(void*)0,(void*)0,&g_901[0]},{(void*)0,(void*)0,&g_901[0],(void*)0,&g_901[0],&g_901[0]},{(void*)0,&g_901[0],&g_901[0],(void*)0,&g_901[0],(void*)0},{(void*)0,&g_901[0],(void*)0,(void*)0,&g_901[0],(void*)0},{&g_901[0],&g_901[0],&g_901[0],&g_901[0],&g_901[0],&g_901[0]}}};
    int32_t **l_899 = &l_900[1][0][0];
    const int8_t ***l_910 = (void*)0;
    const int8_t ****l_909 = &l_910;
    int32_t *l_991 = &g_57;
    uint16_t l_1079 = 0xB40FL;
    int8_t ****l_1083 = (void*)0;
    int8_t *****l_1082[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
    const int32_t **l_1118 = &g_89;
    int32_t *l_1136 = (void*)0;
    uint16_t l_1142 = 0x80A3L;
    int32_t *l_1154 = (void*)0;
    int32_t l_1201 = 0x3BFD7E9FL;
    int16_t l_1232 = 0x7E96L;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_561[i] = 0xE4C0L;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 1; k++)
                l_637[i][j][k] = &g_392;
        }
    }
    for (i = 0; i < 4; i++)
        l_636[i] = &l_637[0][0][0];
    for (i = 0; i < 3; i++)
        l_656[i] = 0x739EA18F2FE4C62DLL;
    for (g_265 = 0; (g_265 <= 2); g_265 += 1)
    { /* block id: 230 */
        uint32_t **l_557 = &g_468[1][0];
        int32_t l_572 = 1L;
        int32_t l_575 = 0xFC7FB595L;
        int8_t *l_588 = (void*)0;
        int8_t **l_587[7] = {&l_588,&l_588,&l_588,&l_588,&l_588,&l_588,&l_588};
        int32_t l_725 = 0x67AC3D21L;
        int32_t l_728 = 0xDE59F237L;
        int32_t l_729 = 9L;
        int32_t l_730 = 0L;
        int32_t l_731 = 1L;
        int32_t l_732 = 0x2A769D9BL;
        int32_t l_733 = 0x3C3DE3E9L;
        int32_t l_734 = 1L;
        int32_t l_735 = 0xF7ED9E49L;
        int8_t l_736 = 0x7EL;
        int32_t l_737 = (-8L);
        int32_t l_738 = 0xE57A9939L;
        int32_t l_739 = 1L;
        int32_t l_740[7];
        uint32_t l_754 = 0UL;
        int32_t *l_761 = &l_730;
        int64_t **l_795[7][2] = {{&g_387[8][1][2],&g_387[8][2][2]},{&g_387[7][3][0],(void*)0},{&g_387[7][3][0],&g_387[8][2][2]},{&g_387[8][1][2],&g_387[8][1][2]},{&g_387[8][2][2],&g_387[7][3][0]},{(void*)0,&g_387[7][3][0]},{&g_387[8][2][2],&g_387[8][1][2]}};
        uint8_t **l_936 = &l_637[0][1][0];
        int32_t l_1004[10] = {0x9306E6FEL,6L,0L,0L,6L,0x9306E6FEL,6L,0L,0L,6L};
        int32_t ** const * const l_1050 = (void*)0;
        int32_t ** const * const *l_1049[6] = {(void*)0,&l_1050,&l_1050,(void*)0,&l_1050,&l_1050};
        int8_t l_1051[7][9] = {{0x0CL,0L,0xDCL,(-1L),0xDCL,0L,0x0CL,0x1FL,0xC8L},{(-1L),0L,(-1L),(-1L),0xDCL,0x55L,(-1L),0x1FL,(-6L)},{(-1L),0L,1L,0x0CL,0xDCL,0x2AL,(-6L),0xCCL,0xCCL},{0xC8L,0x01L,6L,0x1FL,6L,0x01L,0xC8L,0xCCL,8L},{0x1FL,0x01L,0x44L,(-6L),6L,1L,0x1FL,0xCCL,(-1L)},{(-6L),0x01L,0xF0L,0xC8L,6L,0x2AL,(-6L),0xCCL,0xCCL},{0xC8L,0x01L,6L,0x1FL,6L,0x01L,0xC8L,0xCCL,8L}};
        int32_t *l_1090 = &g_543;
        int64_t l_1091 = 0L;
        const int32_t **l_1120 = &g_89;
        int16_t l_1187[7][3][3] = {{{(-1L),(-1L),(-1L)},{(-1L),6L,6L},{(-1L),0x69E8L,0xD7B4L}},{{(-1L),0x3BBCL,(-1L)},{(-1L),(-1L),0xD7B4L},{(-2L),(-2L),6L}},{{0L,(-1L),(-1L)},{6L,0x3BBCL,0x4BBAL},{0L,0x69E8L,0L}},{{(-2L),6L,0x4BBAL},{(-1L),(-1L),(-1L)},{(-1L),6L,6L}},{{(-1L),0x69E8L,0xD7B4L},{(-1L),0x3BBCL,(-1L)},{(-1L),(-1L),0xD7B4L}},{{(-2L),(-2L),6L},{0L,(-1L),(-1L)},{6L,0x3BBCL,0x4BBAL}},{{0L,0x69E8L,0L},{(-2L),6L,0x4BBAL},{(-1L),(-1L),(-1L)}}};
        uint32_t l_1190 = 0xB1D02044L;
        int8_t l_1231 = 0xDDL;
        int i, j, k;
        for (i = 0; i < 7; i++)
            l_740[i] = 6L;
    }
    for (l_843 = 18; (l_843 > 33); l_843 = safe_add_func_int8_t_s_s(l_843, 2))
    { /* block id: 541 */
        return g_3[1][0];
    }
    return p_47;
}


/* ------------------------------------------ */
/* 
 * reads : g_57 g_73 g_478 g_3 g_294 g_138 g_392 g_89 g_543 g_550
 * writes: g_57 g_543 g_550
 */
static int8_t  func_49(int8_t  p_50)
{ /* block id: 5 */
    int32_t l_54 = 0xF8000858L;
    int32_t *l_542 = &g_543;
    int32_t *l_544 = (void*)0;
    int32_t *l_545 = &g_543;
    int32_t *l_546[10][4][2] = {{{(void*)0,&g_3[3][2]},{&l_54,&g_3[3][1]},{&l_54,&l_54},{&g_3[3][1],&g_3[3][2]}},{{&g_3[3][1],&l_54},{&l_54,&g_3[3][1]},{&l_54,&g_3[3][2]},{(void*)0,(void*)0}},{{&l_54,(void*)0},{(void*)0,&g_3[3][2]},{&l_54,&g_3[3][1]},{&l_54,&l_54}},{{&g_3[3][1],&g_3[3][2]},{&g_3[3][1],&l_54},{&l_54,&g_3[3][1]},{&l_54,&g_3[3][2]}},{{(void*)0,(void*)0},{&l_54,(void*)0},{(void*)0,&g_3[3][2]},{&l_54,&g_3[3][1]}},{{&l_54,&l_54},{&g_3[3][1],&g_3[3][2]},{&g_3[3][1],&l_54},{&l_54,&g_3[3][1]}},{{&l_54,&g_3[3][2]},{(void*)0,(void*)0},{&l_54,(void*)0},{(void*)0,&g_3[3][2]}},{{&l_54,&g_3[3][1]},{&l_54,&l_54},{&g_3[3][1],&g_3[3][2]},{&g_3[3][1],&l_54}},{{&l_54,&g_3[3][1]},{&l_54,&g_3[3][2]},{(void*)0,(void*)0},{&l_54,(void*)0}},{{(void*)0,&g_3[3][2]},{&l_54,&g_3[3][1]},{&l_54,&l_54},{&g_3[3][1],&g_3[3][2]}}};
    uint32_t l_547 = 0x119C95BBL;
    const int32_t *****l_552 = &g_550;
    int32_t ****l_553 = &g_98;
    int i, j, k;
    (*l_542) ^= func_52(l_54);
    l_547--;
    (*l_545) &= (((*l_552) = g_550) != l_553);
    return g_392;
}


/* ------------------------------------------ */
/* 
 * reads : g_57 g_73 g_478 g_3 g_294 g_138 g_392 g_89
 * writes: g_57
 */
static int32_t  func_52(int64_t  p_53)
{ /* block id: 6 */
    uint32_t l_55[6][7][6] = {{{18446744073709551615UL,1UL,0x1C5AB2A4L,0UL,18446744073709551615UL,0UL},{0x9ABC19ACL,18446744073709551615UL,18446744073709551606UL,0x84ADDBFDL,0xD537E8F8L,0UL},{18446744073709551611UL,0x84ADDBFDL,1UL,0x84ADDBFDL,18446744073709551611UL,18446744073709551615UL},{0x84ADDBFDL,18446744073709551611UL,18446744073709551615UL,0x20F84B0FL,18446744073709551611UL,18446744073709551615UL},{0xD45EB447L,0x84ADDBFDL,0xE16D714EL,18446744073709551611UL,0xD537E8F8L,18446744073709551615UL},{0xD537E8F8L,0xD45EB447L,18446744073709551615UL,0x7F77771FL,0x7F77771FL,18446744073709551615UL},{0xD537E8F8L,0xD537E8F8L,1UL,18446744073709551611UL,18446744073709551615UL,0UL}},{{0xD45EB447L,0xD537E8F8L,18446744073709551606UL,0x20F84B0FL,0x7F77771FL,1UL},{0x84ADDBFDL,0xD45EB447L,18446744073709551606UL,0x84ADDBFDL,0xD537E8F8L,0UL},{18446744073709551611UL,0x84ADDBFDL,1UL,0x84ADDBFDL,18446744073709551611UL,18446744073709551615UL},{0x84ADDBFDL,18446744073709551611UL,18446744073709551615UL,0x20F84B0FL,18446744073709551611UL,18446744073709551615UL},{0xD45EB447L,0x84ADDBFDL,0xE16D714EL,18446744073709551611UL,0xD537E8F8L,18446744073709551615UL},{0xD537E8F8L,0xD45EB447L,18446744073709551615UL,0x7F77771FL,0x7F77771FL,18446744073709551615UL},{0xD537E8F8L,0xD537E8F8L,1UL,18446744073709551611UL,18446744073709551615UL,0UL}},{{0xD45EB447L,0xD537E8F8L,18446744073709551606UL,0x20F84B0FL,0x7F77771FL,1UL},{0x84ADDBFDL,0xD45EB447L,18446744073709551606UL,0x84ADDBFDL,0xD537E8F8L,0UL},{18446744073709551611UL,0x84ADDBFDL,1UL,0x84ADDBFDL,18446744073709551611UL,18446744073709551615UL},{0x84ADDBFDL,18446744073709551611UL,18446744073709551615UL,0x20F84B0FL,18446744073709551611UL,18446744073709551615UL},{0xD45EB447L,0x84ADDBFDL,0xE16D714EL,18446744073709551611UL,0xD537E8F8L,18446744073709551615UL},{0xD537E8F8L,0xD45EB447L,18446744073709551615UL,0x7F77771FL,0x7F77771FL,18446744073709551615UL},{0xD537E8F8L,0xD537E8F8L,1UL,18446744073709551611UL,18446744073709551615UL,0UL}},{{0xD45EB447L,0xD537E8F8L,18446744073709551606UL,0x20F84B0FL,0x7F77771FL,1UL},{0x84ADDBFDL,0xD45EB447L,18446744073709551606UL,0x84ADDBFDL,0xD537E8F8L,0UL},{18446744073709551611UL,0x84ADDBFDL,1UL,0x84ADDBFDL,18446744073709551611UL,18446744073709551615UL},{0x84ADDBFDL,18446744073709551611UL,18446744073709551615UL,0x20F84B0FL,18446744073709551611UL,18446744073709551615UL},{0xD45EB447L,0x84ADDBFDL,0xE16D714EL,18446744073709551611UL,0xD537E8F8L,18446744073709551615UL},{0xD537E8F8L,0xD45EB447L,18446744073709551615UL,0x7F77771FL,0x7F77771FL,18446744073709551615UL},{0xD537E8F8L,0xD537E8F8L,1UL,18446744073709551611UL,18446744073709551615UL,0UL}},{{0xD45EB447L,0xD537E8F8L,18446744073709551606UL,0x20F84B0FL,0x7F77771FL,1UL},{0x84ADDBFDL,0xD45EB447L,18446744073709551606UL,0x84ADDBFDL,0xD537E8F8L,0UL},{18446744073709551611UL,0x84ADDBFDL,1UL,0x84ADDBFDL,18446744073709551611UL,18446744073709551615UL},{0x84ADDBFDL,18446744073709551611UL,18446744073709551615UL,0x20F84B0FL,18446744073709551611UL,18446744073709551615UL},{0xD45EB447L,0x84ADDBFDL,0xE16D714EL,18446744073709551611UL,0xD537E8F8L,18446744073709551615UL},{0xD537E8F8L,0x742D63D2L,0x7F77771FL,7UL,7UL,0x7F77771FL},{0x6D35DF96L,0x6D35DF96L,0xD537E8F8L,0UL,0x1C5AB2A4L,0x20F84B0FL}},{{0x742D63D2L,0x6D35DF96L,18446744073709551611UL,0xC4B0538FL,7UL,0xD537E8F8L},{18446744073709551615UL,0x742D63D2L,18446744073709551611UL,18446744073709551615UL,0x6D35DF96L,0x20F84B0FL},{0UL,18446744073709551615UL,0xD537E8F8L,18446744073709551615UL,0UL,0x7F77771FL},{18446744073709551615UL,0UL,0x7F77771FL,0xC4B0538FL,0UL,0xD45EB447L},{0x742D63D2L,18446744073709551615UL,18446744073709551615UL,0UL,0x6D35DF96L,0xD45EB447L},{0x6D35DF96L,0x742D63D2L,0x7F77771FL,7UL,7UL,0x7F77771FL},{0x6D35DF96L,0x6D35DF96L,0xD537E8F8L,0UL,0x1C5AB2A4L,0x20F84B0FL}}};
    int32_t l_61 = 3L;
    int8_t l_63[2];
    int32_t l_64 = (-1L);
    int32_t l_65 = 1L;
    int32_t *l_71 = &g_57;
    int32_t **l_97 = &l_71;
    int32_t ***l_96 = &l_97;
    uint64_t *l_135 = &g_77[4][4][0];
    int32_t l_161 = 0x5F86D9A3L;
    int32_t l_163 = (-1L);
    int32_t l_228 = 0xB74285D3L;
    int32_t l_229 = 0L;
    uint32_t l_264[3][7] = {{0x934C4DA2L,0x934C4DA2L,0xDFDF90A1L,0x934C4DA2L,0x934C4DA2L,0xDFDF90A1L,0x934C4DA2L},{0x934C4DA2L,18446744073709551615UL,18446744073709551615UL,0x934C4DA2L,18446744073709551615UL,18446744073709551615UL,0x934C4DA2L},{18446744073709551615UL,0x934C4DA2L,18446744073709551615UL,18446744073709551615UL,0x934C4DA2L,18446744073709551615UL,18446744073709551615UL}};
    int8_t l_292 = 0x1AL;
    uint8_t *l_322 = &g_215;
    uint8_t l_323 = 0xEFL;
    int16_t l_426 = 6L;
    int32_t *****l_452 = (void*)0;
    int32_t l_490 = 0x99A1CBDCL;
    int32_t l_492 = 0x5C908C8EL;
    int32_t l_494 = 0xA2508394L;
    int32_t l_495 = 0L;
    int32_t l_496[1][1][1];
    int32_t l_515 = 0xAB841462L;
    int8_t * const l_526 = &g_218;
    int8_t * const *l_525 = &l_526;
    uint8_t **l_531 = &l_322;
    uint8_t *l_532 = &l_323;
    uint64_t l_538[7] = {0x4F67B80D12432A7DLL,0x4F67B80D12432A7DLL,0x4F67B80D12432A7DLL,0x4F67B80D12432A7DLL,0x4F67B80D12432A7DLL,0x4F67B80D12432A7DLL,0x4F67B80D12432A7DLL};
    int32_t l_539 = 0x4EE51AC9L;
    int16_t *l_540 = &l_426;
    int16_t l_541 = 0x0B69L;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_63[i] = 1L;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 1; k++)
                l_496[i][j][k] = 0x397ABB54L;
        }
    }
    for (p_53 = 0; (p_53 <= 5); p_53 += 1)
    { /* block id: 9 */
        int32_t *l_56 = &g_57;
        int32_t *l_58 = &g_57;
        int32_t *l_59 = &g_57;
        int32_t *l_60[5][7][7] = {{{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57}},{{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57}},{{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57}},{{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57}},{{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57},{&g_57,&g_57,&g_57,&g_57,&g_57,&g_57,&g_57}}};
        int8_t l_62[9][9][3] = {{{(-1L),0xE3L,0x93L},{0x19L,6L,(-1L)},{0xE3L,(-1L),0x93L},{0xB5L,0x1AL,(-1L)},{1L,1L,0x93L},{0x82L,(-1L),(-1L)},{(-1L),0xE3L,0x93L},{0x19L,6L,(-1L)},{0xE3L,(-1L),0x93L}},{{0xB5L,0x1AL,(-1L)},{1L,1L,0x93L},{0x82L,(-1L),(-1L)},{(-1L),0xE3L,0x93L},{0x19L,6L,(-1L)},{0xE3L,(-1L),0x93L},{0xB5L,0x1AL,(-1L)},{1L,1L,0x93L},{0x82L,(-1L),(-1L)}},{{(-1L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L},{0L,0x08L,0x19L},{0x40L,0x40L,1L},{1L,(-7L),0x19L},{(-4L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L}},{{0L,0x08L,0x19L},{0x40L,0x40L,1L},{1L,(-7L),0x19L},{(-4L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L},{0L,0x08L,0x19L},{0x40L,0x40L,1L},{1L,(-7L),0x19L}},{{(-4L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L},{0L,0x08L,0x19L},{0x40L,0x40L,1L},{1L,(-7L),0x19L},{(-4L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L}},{{0L,0x08L,0x19L},{0x40L,0x40L,1L},{1L,(-7L),0x19L},{(-4L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L},{0L,0x08L,0x19L},{0x40L,0x40L,1L},{1L,(-7L),0x19L}},{{(-4L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L},{0L,0x08L,0x19L},{0x40L,0x40L,1L},{1L,(-7L),0x19L},{(-4L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L}},{{0L,0x08L,0x19L},{0x40L,0x40L,1L},{1L,(-7L),0x19L},{(-4L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L},{0L,0x08L,0x19L},{0x40L,0x40L,1L},{1L,(-7L),0x19L}},{{(-4L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L},{0L,0x08L,0x19L},{0x40L,0x40L,1L},{1L,(-7L),0x19L},{(-4L),1L,1L},{0x6CL,0x50L,0x19L},{1L,(-4L),1L}}};
        uint64_t l_66 = 0xD8479822E7BB9215LL;
        uint32_t l_165 = 18446744073709551615UL;
        int32_t l_226 = 0L;
        int32_t l_258[7] = {0xFE854735L,0xFE854735L,0xFE854735L,0xFE854735L,0xFE854735L,0xFE854735L,0xFE854735L};
        int32_t ****l_261 = (void*)0;
        uint32_t l_267 = 0x64FD8085L;
        const uint32_t l_299[3] = {0x409956FBL,0x409956FBL,0x409956FBL};
        const int16_t l_308 = (-1L);
        uint8_t *l_321[4][6][6] = {{{(void*)0,&g_215,&g_215,&g_215,&g_215,(void*)0},{&g_215,(void*)0,&g_215,(void*)0,&g_215,(void*)0},{(void*)0,(void*)0,(void*)0,&g_215,&g_215,&g_215},{&g_215,&g_215,&g_215,(void*)0,&g_215,&g_215},{&g_215,(void*)0,(void*)0,&g_215,(void*)0,(void*)0},{&g_215,&g_215,&g_215,&g_215,&g_215,(void*)0}},{{&g_215,(void*)0,&g_215,(void*)0,&g_215,(void*)0},{&g_215,(void*)0,&g_215,&g_215,&g_215,&g_215},{(void*)0,&g_215,(void*)0,(void*)0,(void*)0,&g_215},{&g_215,(void*)0,&g_215,&g_215,&g_215,(void*)0},{(void*)0,&g_215,&g_215,&g_215,&g_215,(void*)0},{&g_215,(void*)0,&g_215,(void*)0,&g_215,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_215,&g_215,&g_215},{&g_215,&g_215,&g_215,(void*)0,&g_215,&g_215},{&g_215,(void*)0,(void*)0,&g_215,(void*)0,(void*)0},{&g_215,&g_215,&g_215,&g_215,&g_215,(void*)0},{&g_215,(void*)0,&g_215,(void*)0,&g_215,(void*)0},{&g_215,(void*)0,&g_215,&g_215,&g_215,&g_215}},{{(void*)0,&g_215,(void*)0,(void*)0,(void*)0,&g_215},{&g_215,(void*)0,&g_215,&g_215,&g_215,(void*)0},{(void*)0,&g_215,&g_215,&g_215,&g_215,(void*)0},{&g_215,(void*)0,&g_215,(void*)0,&g_215,(void*)0},{(void*)0,(void*)0,(void*)0,&g_215,&g_215,&g_215},{&g_215,&g_215,&g_215,(void*)0,&g_215,&g_215}}};
        int64_t l_341 = 1L;
        uint32_t l_405[3];
        int8_t *l_433 = &l_63[1];
        int8_t **l_432[1];
        int8_t ***l_431 = &l_432[0];
        int32_t l_443 = 0xD41C0020L;
        uint8_t l_471 = 1UL;
        int32_t l_516 = 1L;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_405[i] = 4294967295UL;
        for (i = 0; i < 1; i++)
            l_432[i] = &l_433;
        l_66--;
    }
    l_541 &= (((safe_lshift_func_int16_t_s_u(((*l_540) = (safe_div_func_int32_t_s_s((p_53 | (safe_div_func_int32_t_s_s((safe_div_func_uint8_t_u_u(((**l_97) != (((void*)0 != l_525) & (((safe_rshift_func_int16_t_s_s((((safe_mul_func_int8_t_s_s((&l_323 == ((*l_531) = &g_392)), (--(*l_532)))) , &l_96) != ((safe_unary_minus_func_int16_t_s((safe_mod_func_int32_t_s_s((*l_71), l_538[6])))) , &l_96)), g_73[1][1][0])) , g_478[7]) >= (*l_71)))), g_3[2][0])), l_539))), p_53))), (*g_294))) ^ (**l_97)) <= g_392);
    (*l_71) = 0x0533EDA1L;
    return (*g_89);
}


/* ------------------------------------------ */
/* 
 * reads : g_89 g_73
 * writes: g_89
 */
static int64_t  func_80(const int32_t ** p_81, int32_t  p_82)
{ /* block id: 28 */
    (*p_81) = (*p_81);
    return g_73[1][1][7];
}


/* ------------------------------------------ */
/* 
 * reads : g_88
 * writes: g_100
 */
static const int32_t ** func_83(int32_t ** p_84)
{ /* block id: 21 */
    int32_t *l_87[10][5][5] = {{{&g_3[0][1],(void*)0,&g_3[0][1],(void*)0,&g_3[0][1]},{&g_57,&g_3[0][2],&g_3[0][1],&g_3[2][3],&g_3[0][1]},{(void*)0,(void*)0,&g_3[0][1],&g_3[0][1],(void*)0},{&g_3[0][2],&g_57,&g_57,&g_3[0][2],&g_3[0][1]},{(void*)0,&g_3[0][1],(void*)0,(void*)0,&g_3[0][1]}},{{&g_3[0][1],&g_57,&g_57,&g_3[2][0],&g_3[2][0]},{(void*)0,(void*)0,(void*)0,(void*)0,&g_3[0][1]},{&g_3[2][3],&g_3[0][2],&g_3[2][0],&g_3[0][2],&g_57},{&g_3[0][1],(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_3[0][1],&g_57,&g_3[0][2]}},{{(void*)0,&g_3[0][1],&g_3[0][1],(void*)0,(void*)0},{&g_57,&g_57,&g_3[2][0],&g_3[2][0],&g_57},{(void*)0,&g_3[0][1],&g_3[0][1],(void*)0,(void*)0},{&g_3[2][3],(void*)0,&g_3[2][3],&g_3[2][0],&g_3[0][1]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_3[2][3],&g_57,(void*)0,&g_57,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_57,&g_3[2][3],&g_3[2][3],&g_57,(void*)0},{(void*)0,(void*)0,&g_3[0][1],&g_3[0][1],(void*)0},{(void*)0,&g_3[2][3],&g_3[2][0],&g_3[0][1],&g_3[0][1]}},{{&g_3[0][1],(void*)0,&g_3[0][1],&g_3[0][1],(void*)0},{&g_57,&g_57,&g_3[0][1],&g_57,&g_57},{&g_3[0][1],(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_3[0][1],&g_57,&g_3[0][2]},{(void*)0,&g_3[0][1],&g_3[0][1],(void*)0,(void*)0}},{{&g_57,&g_57,&g_3[2][0],&g_3[2][0],&g_57},{(void*)0,&g_3[0][1],&g_3[0][1],(void*)0,(void*)0},{&g_3[2][3],(void*)0,&g_3[2][3],&g_3[2][0],&g_3[0][1]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_3[2][3],&g_57,(void*)0,&g_57,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_57,&g_3[2][3],&g_3[2][3],&g_57,(void*)0},{(void*)0,(void*)0,&g_3[0][1],&g_3[0][1],(void*)0},{(void*)0,&g_3[2][3],&g_3[2][0],&g_3[0][1],&g_3[0][1]},{&g_3[0][1],(void*)0,&g_3[0][1],&g_3[0][1],(void*)0}},{{&g_57,&g_57,&g_3[0][1],&g_57,&g_57},{&g_3[0][1],(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_3[0][1],&g_57,&g_3[0][2]},{(void*)0,&g_3[0][1],&g_3[0][1],(void*)0,(void*)0},{&g_57,&g_57,&g_3[2][0],&g_3[2][0],&g_57}},{{(void*)0,&g_3[0][1],&g_3[0][1],(void*)0,(void*)0},{&g_3[2][3],(void*)0,&g_3[2][3],&g_3[2][0],&g_3[0][1]},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_3[2][3],&g_57,(void*)0,&g_57,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_57,&g_3[2][3],&g_3[2][3],&g_57,(void*)0},{&g_3[0][1],&g_3[0][1],(void*)0,(void*)0,&g_3[0][1]},{&g_3[0][2],&g_57,&g_3[0][1],(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&g_3[2][0],&g_3[2][3],(void*)0,&g_3[2][3],&g_3[2][0]}}};
    int i, j, k;
    (*p_84) = l_87[3][0][3];
    return g_88;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_3[i][j], "g_3[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_57, "g_57", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_73[i][j][k], "g_73[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_74, "g_74", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_77[i][j][k], "g_77[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_125, "g_125", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_127[i][j], "g_127[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_134, "g_134", print_hash_value);
    transparent_crc(g_138, "g_138", print_hash_value);
    transparent_crc(g_215, "g_215", print_hash_value);
    transparent_crc(g_218, "g_218", print_hash_value);
    transparent_crc(g_265, "g_265", print_hash_value);
    transparent_crc(g_304, "g_304", print_hash_value);
    transparent_crc(g_337, "g_337", print_hash_value);
    transparent_crc(g_378, "g_378", print_hash_value);
    transparent_crc(g_392, "g_392", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_478[i], "g_478[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_543, "g_543", print_hash_value);
    transparent_crc(g_605, "g_605", print_hash_value);
    transparent_crc(g_629, "g_629", print_hash_value);
    transparent_crc(g_657, "g_657", print_hash_value);
    transparent_crc(g_717, "g_717", print_hash_value);
    transparent_crc(g_751, "g_751", print_hash_value);
    transparent_crc(g_777, "g_777", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_892[i], "g_892[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_901[i], "g_901[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1005, "g_1005", print_hash_value);
    transparent_crc(g_1122, "g_1122", print_hash_value);
    transparent_crc(g_1123, "g_1123", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1164[i], "g_1164[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1230, "g_1230", print_hash_value);
    transparent_crc(g_1407, "g_1407", print_hash_value);
    transparent_crc(g_1476, "g_1476", print_hash_value);
    transparent_crc(g_1507, "g_1507", print_hash_value);
    transparent_crc(g_1690, "g_1690", print_hash_value);
    transparent_crc(g_1743, "g_1743", print_hash_value);
    transparent_crc(g_1862, "g_1862", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_2016[i][j], "g_2016[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2263, "g_2263", print_hash_value);
    transparent_crc(g_2312, "g_2312", print_hash_value);
    transparent_crc(g_2329, "g_2329", print_hash_value);
    transparent_crc(g_2374, "g_2374", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 2; k++)
            {
                transparent_crc(g_2545[i][j][k], "g_2545[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2591, "g_2591", print_hash_value);
    transparent_crc(g_2605, "g_2605", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_2828[i], "g_2828[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_2963[i][j], "g_2963[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_3042, "g_3042", print_hash_value);
    transparent_crc(g_3072, "g_3072", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_3074[i], "g_3074[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3092, "g_3092", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 857
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 67
breakdown:
   depth: 1, occurrence: 224
   depth: 2, occurrence: 48
   depth: 3, occurrence: 5
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 7, occurrence: 2
   depth: 10, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 3
   depth: 18, occurrence: 1
   depth: 20, occurrence: 3
   depth: 21, occurrence: 5
   depth: 22, occurrence: 2
   depth: 23, occurrence: 3
   depth: 25, occurrence: 2
   depth: 26, occurrence: 2
   depth: 27, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 3
   depth: 31, occurrence: 2
   depth: 32, occurrence: 2
   depth: 33, occurrence: 1
   depth: 36, occurrence: 1
   depth: 37, occurrence: 2
   depth: 67, occurrence: 1

XXX total number of pointers: 613

XXX times a variable address is taken: 1541
XXX times a pointer is dereferenced on RHS: 509
breakdown:
   depth: 1, occurrence: 304
   depth: 2, occurrence: 99
   depth: 3, occurrence: 63
   depth: 4, occurrence: 38
   depth: 5, occurrence: 5
XXX times a pointer is dereferenced on LHS: 475
breakdown:
   depth: 1, occurrence: 370
   depth: 2, occurrence: 56
   depth: 3, occurrence: 30
   depth: 4, occurrence: 15
   depth: 5, occurrence: 4
XXX times a pointer is compared with null: 63
XXX times a pointer is compared with address of another variable: 16
XXX times a pointer is compared with another pointer: 17
XXX times a pointer is qualified to be dereferenced: 12830

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1279
   level: 2, occurrence: 542
   level: 3, occurrence: 335
   level: 4, occurrence: 222
   level: 5, occurrence: 164
XXX number of pointers point to pointers: 328
XXX number of pointers point to scalars: 285
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 27.9
XXX average alias set size: 1.51

XXX times a non-volatile is read: 3024
XXX times a non-volatile is write: 1516
XXX times a volatile is read: 68
XXX    times read thru a pointer: 63
XXX times a volatile is write: 25
XXX    times written thru a pointer: 24
XXX times a volatile is available for access: 236
XXX percentage of non-volatile access: 98

XXX forward jumps: 0
XXX backward jumps: 5

XXX stmts: 216
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 30
   depth: 1, occurrence: 18
   depth: 2, occurrence: 23
   depth: 3, occurrence: 35
   depth: 4, occurrence: 52
   depth: 5, occurrence: 58

XXX percentage a fresh-made variable is used: 16
XXX percentage an existing variable is used: 84
XXX total OOB instances added: 0
********************* end of statistics **********************/

