/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      1926580076
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static uint32_t g_12 = 0x81C1D99EL;
static uint8_t g_14 = 0x9BL;
static int32_t g_19[6] = {0xCC0C7FD5L,0xCC0C7FD5L,0xCC0C7FD5L,0xCC0C7FD5L,0xCC0C7FD5L,0xCC0C7FD5L};
static const int32_t *g_28 = &g_19[0];
static const int32_t ** volatile g_27 = &g_28;/* VOLATILE GLOBAL g_27 */
static int32_t g_55 = 1L;
static int32_t g_59 = 0x7FB601BAL;
static volatile int8_t g_60 = 0xF2L;/* VOLATILE GLOBAL g_60 */
static uint32_t g_76 = 0xC6F6B910L;
static int32_t *g_107 = &g_19[4];
static int32_t **g_106 = &g_107;
static uint8_t g_124 = 0x34L;
static volatile int8_t g_139 = 0x42L;/* VOLATILE GLOBAL g_139 */
static volatile uint32_t g_140 = 4294967294UL;/* VOLATILE GLOBAL g_140 */
static int16_t g_155 = 0xB7C9L;
static uint32_t g_163 = 4294967289UL;
static volatile uint64_t g_168 = 0UL;/* VOLATILE GLOBAL g_168 */
static uint32_t g_200 = 5UL;
static int8_t g_213 = 0x5FL;
static int8_t g_215 = 0xBDL;
static uint32_t g_217 = 0UL;
static const int64_t * volatile g_240 = (void*)0;/* VOLATILE GLOBAL g_240 */
static int64_t g_242 = 0x07749A3EB63C3F2BLL;
static uint32_t g_244 = 0x90DA673FL;
static volatile uint32_t g_270 = 0xEB18E8DEL;/* VOLATILE GLOBAL g_270 */
static int8_t g_278 = 0x46L;
static volatile uint64_t g_279 = 0x01241E3A8740F6EFLL;/* VOLATILE GLOBAL g_279 */
static volatile int32_t g_311 = 0L;/* VOLATILE GLOBAL g_311 */
static volatile int32_t g_314[7] = {0x9DBCD600L,0xA202F784L,0x9DBCD600L,0x9DBCD600L,0xA202F784L,0x9DBCD600L,0x9DBCD600L};
static uint8_t g_315 = 3UL;
static volatile uint16_t g_318 = 0x9782L;/* VOLATILE GLOBAL g_318 */
static uint8_t *g_336 = &g_124;
static volatile int64_t g_342[4][7][9] = {{{(-9L),0x5E9CE2A3B59A8C30LL,(-9L),0L,(-9L),(-3L),0x5E9CE2A3B59A8C30LL,0x41679F912CC45B12LL,0x12D92A50D181D2BCLL},{0L,0L,0xF7DCAAD0FF3DFD6FLL,(-9L),0L,0x387CC21128C3E584LL,0x12D92A50D181D2BCLL,0xDE5C421F52606973LL,(-3L)},{0xCD63C0136F6219D4LL,0xF7DCAAD0FF3DFD6FLL,0xBD4E487063272226LL,0L,0L,0L,0L,0xBD4E487063272226LL,0xF7DCAAD0FF3DFD6FLL},{0L,0x0BE5CBDDB987CA8CLL,0xBD4E487063272226LL,0xDF0E0FF55728C40FLL,(-1L),0L,0L,0x0BE5CBDDB987CA8CLL,(-1L)},{0xDE5C421F52606973LL,0L,(-3L),0x0BE5CBDDB987CA8CLL,0L,0xF7DCAAD0FF3DFD6FLL,(-9L),0x387CC21128C3E584LL,0x0BE5CBDDB987CA8CLL},{0xDF0E0FF55728C40FLL,(-1L),7L,(-9L),(-9L),7L,(-1L),0xDF0E0FF55728C40FLL,0L},{0xDF0E0FF55728C40FLL,(-3L),0L,7L,0xCC790F11AC0BC284LL,0x93E918DBAE1EF9B9LL,0x41679F912CC45B12LL,(-9L),0x78D6E3BB352B3691LL}},{{0xDE5C421F52606973LL,0x387CC21128C3E584LL,(-1L),0x41679F912CC45B12LL,0L,0x12D92A50D181D2BCLL,0L,(-1L),0L},{0x387CC21128C3E584LL,0L,0x5E9CE2A3B59A8C30LL,0x5E9CE2A3B59A8C30LL,0L,0x387CC21128C3E584LL,0xCC790F11AC0BC284LL,(-1L),0x0BE5CBDDB987CA8CLL},{0x12D92A50D181D2BCLL,0L,0x41679F912CC45B12LL,(-1L),0x387CC21128C3E584LL,0xDE5C421F52606973LL,(-9L),(-9L),(-1L)},{0x93E918DBAE1EF9B9LL,0xCC790F11AC0BC284LL,7L,0L,(-3L),0xDF0E0FF55728C40FLL,0xCC790F11AC0BC284LL,0xDF0E0FF55728C40FLL,(-3L)},{7L,(-9L),(-9L),7L,(-1L),0xDF0E0FF55728C40FLL,0L,0x387CC21128C3E584LL,0x78D6E3BB352B3691LL},{0xF7DCAAD0FF3DFD6FLL,0L,0x0BE5CBDDB987CA8CLL,(-3L),0L,0xDE5C421F52606973LL,0x41679F912CC45B12LL,0x0BE5CBDDB987CA8CLL,(-9L)},{0x387CC21128C3E584LL,0xCD63C0136F6219D4LL,0L,7L,(-1L),0x387CC21128C3E584LL,(-1L),7L,0L}},{{0L,0L,0x387CC21128C3E584LL,7L,(-3L),0x12D92A50D181D2BCLL,(-9L),0L,7L},{0xBD4E487063272226LL,0L,7L,(-3L),0x387CC21128C3E584LL,0x93E918DBAE1EF9B9LL,0L,0xDF0E0FF55728C40FLL,0x41679F912CC45B12LL},{0x78D6E3BB352B3691LL,0x41679F912CC45B12LL,0x387CC21128C3E584LL,7L,0L,7L,0x387CC21128C3E584LL,0x41679F912CC45B12LL,0x78D6E3BB352B3691LL},{(-9L),0x41679F912CC45B12LL,0L,0L,0L,0xF7DCAAD0FF3DFD6FLL,(-9L),0L,0x387CC21128C3E584LL},{0x387CC21128C3E584LL,0L,0x0BE5CBDDB987CA8CLL,(-1L),0xCC790F11AC0BC284LL,0x387CC21128C3E584LL,0L,0x5E9CE2A3B59A8C30LL,0x5E9CE2A3B59A8C30LL},{(-9L),0L,(-9L),0x5E9CE2A3B59A8C30LL,(-9L),0L,(-9L),(-3L),0x5E9CE2A3B59A8C30LL},{0x78D6E3BB352B3691LL,0xCD63C0136F6219D4LL,7L,0x41679F912CC45B12LL,0L,0xBD4E487063272226LL,0xCD63C0136F6219D4LL,0xDF0E0FF55728C40FLL,0x387CC21128C3E584LL}},{{0xBD4E487063272226LL,0L,0x41679F912CC45B12LL,7L,0xCD63C0136F6219D4LL,0x78D6E3BB352B3691LL,(-3L),(-3L),0x78D6E3BB352B3691LL},{0L,(-9L),0x5E9CE2A3B59A8C30LL,(-9L),0L,(-9L),(-3L),0x5E9CE2A3B59A8C30LL,0x41679F912CC45B12LL},{0x387CC21128C3E584LL,0xCC790F11AC0BC284LL,(-1L),0x0BE5CBDDB987CA8CLL,0L,0x387CC21128C3E584LL,0xCD63C0136F6219D4LL,0L,7L},{0xF7DCAAD0FF3DFD6FLL,0L,0L,0L,0x41679F912CC45B12LL,(-9L),(-9L),0x41679F912CC45B12LL,0L},{0x0BE5CBDDB987CA8CLL,0L,0x0BE5CBDDB987CA8CLL,0xBD4E487063272226LL,0xDF0E0FF55728C40FLL,(-1L),0L,0L,7L},{0x5E9CE2A3B59A8C30LL,0xBD4E487063272226LL,0x78D6E3BB352B3691LL,0x0BE5CBDDB987CA8CLL,0xDE5C421F52606973LL,7L,7L,0x93E918DBAE1EF9B9LL,(-1L)},{(-9L),0x78D6E3BB352B3691LL,0xCC790F11AC0BC284LL,0xBD4E487063272226LL,0x387CC21128C3E584LL,0x387CC21128C3E584LL,0xBD4E487063272226LL,0xCC790F11AC0BC284LL,0x78D6E3BB352B3691LL}}};
static int32_t g_346 = 0x5F862F7FL;
static uint16_t g_347 = 0x2CE8L;
static uint32_t g_353 = 0x0B109EEFL;
static int8_t *g_372 = &g_278;
static int8_t **g_371 = &g_372;
static volatile uint64_t g_373 = 18446744073709551607UL;/* VOLATILE GLOBAL g_373 */
static uint64_t g_404 = 0x69356C6CD4D1F397LL;
static volatile int32_t g_418 = (-8L);/* VOLATILE GLOBAL g_418 */
static int32_t g_419 = (-1L);
static uint16_t g_422[3] = {65535UL,65535UL,65535UL};
static int32_t g_446 = 1L;
static volatile int32_t g_498 = 0x3C893D89L;/* VOLATILE GLOBAL g_498 */
static int8_t g_500 = 0xE3L;
static volatile uint32_t g_501 = 0UL;/* VOLATILE GLOBAL g_501 */
static int16_t g_505[4] = {(-7L),(-7L),(-7L),(-7L)};
static volatile uint64_t g_506[4] = {18446744073709551614UL,18446744073709551614UL,18446744073709551614UL,18446744073709551614UL};
static const uint8_t g_547 = 1UL;
static volatile int32_t g_565 = (-1L);/* VOLATILE GLOBAL g_565 */
static volatile uint64_t g_566 = 18446744073709551614UL;/* VOLATILE GLOBAL g_566 */
static uint8_t **g_606 = &g_336;
static volatile int16_t g_621[10][9] = {{1L,0L,0x5DAEL,(-5L),0x73FFL,0x3AA0L,0L,0x8C94L,0L},{0x1C7AL,2L,0x5DAEL,0x5DAEL,2L,0x1C7AL,8L,0x0304L,0x9BAFL},{(-6L),0L,0L,0x0304L,8L,(-1L),1L,0x1C7AL,0x281FL},{1L,0x11DBL,0xEE6BL,0xE965L,(-4L),0x53E7L,8L,1L,8L},{0xDBD5L,0x1C7AL,8L,0x53E7L,0x11DBL,0xE64FL,0L,0L,0xE64FL},{(-1L),0x1C7AL,0x5BF9L,0x1C7AL,(-1L),0x3AA0L,0xCDD4L,0x9BAFL,0x1C7AL},{0L,0x11DBL,0x281FL,0x5DAEL,8L,(-5L),(-7L),0x281FL,0x8C94L},{1L,0L,0xCDD4L,0x5BF9L,(-5L),0x3AA0L,0L,8L,0x281FL},{0xE64FL,2L,0xAAF1L,0xCDD4L,0xE965L,0xE64FL,8L,0xE64FL,0xE965L},{0xE64FL,0L,0L,0xE64FL,0x11DBL,0x53E7L,8L,0x1C7AL,0xDBD5L}};
static volatile int16_t * volatile g_620[2] = {&g_621[8][1],&g_621[8][1]};
static volatile int16_t * volatile *g_619 = &g_620[0];
static volatile int16_t * volatile ** volatile g_618[2][4] = {{&g_619,&g_619,&g_619,&g_619},{&g_619,&g_619,&g_619,&g_619}};
static uint32_t g_650 = 0x1245EFC2L;
static uint32_t *g_676 = &g_200;
static int32_t * volatile g_680 = &g_59;/* VOLATILE GLOBAL g_680 */
static int32_t * volatile g_684 = &g_55;/* VOLATILE GLOBAL g_684 */
static int32_t * volatile g_685 = &g_55;/* VOLATILE GLOBAL g_685 */
static int32_t *g_688[8][10] = {{&g_346,&g_346,&g_346,&g_346,&g_346,&g_346,(void*)0,&g_346,&g_346,&g_346},{&g_346,(void*)0,&g_346,&g_346,(void*)0,(void*)0,&g_346,&g_346,(void*)0,&g_346},{&g_346,&g_346,(void*)0,&g_346,(void*)0,&g_346,&g_346,&g_346,&g_346,(void*)0},{&g_346,&g_346,&g_346,&g_346,(void*)0,&g_346,(void*)0,&g_346,&g_346,&g_346},{(void*)0,&g_346,&g_346,(void*)0,(void*)0,&g_346,&g_346,(void*)0,&g_346,&g_346},{&g_346,&g_346,(void*)0,&g_346,&g_346,(void*)0,(void*)0,&g_346,&g_346,(void*)0},{(void*)0,(void*)0,(void*)0,&g_346,&g_346,&g_346,(void*)0,(void*)0,(void*)0,(void*)0},{&g_346,&g_346,(void*)0,(void*)0,&g_346,&g_346,(void*)0,&g_346,&g_346,(void*)0}};
static int32_t g_699 = 0x3BAF9AB5L;
static int16_t g_781 = (-1L);
static uint64_t g_783 = 0x02CA7B9F1C2D842CLL;
static int64_t g_877 = 0x2DF0F04015CEC921LL;
static uint64_t g_1117 = 0x65DD8A20FF6DC0ADLL;
static uint32_t **g_1185 = (void*)0;
static uint32_t ***g_1184[5][10] = {{&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185},{&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185},{&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185},{&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185},{&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185,&g_1185}};
static uint32_t **** volatile g_1183 = &g_1184[0][2];/* VOLATILE GLOBAL g_1183 */
static uint32_t g_1197[1][2] = {{3UL,3UL}};
static uint32_t g_1200 = 0xF50CF6DFL;
static uint64_t *g_1300 = &g_783;
static uint64_t **g_1299 = &g_1300;
static volatile int32_t g_1359[2][1][4] = {{{0x5B6F8622L,0x5B6F8622L,0x5B6F8622L,0x5B6F8622L}},{{0x5B6F8622L,0x5B6F8622L,0x5B6F8622L,0x5B6F8622L}}};
static int8_t *** volatile g_1367 = &g_371;/* VOLATILE GLOBAL g_1367 */
static volatile uint32_t g_1403[7][8][4] = {{{1UL,18446744073709551609UL,0x48E5BD4BL,18446744073709551615UL},{2UL,0x5D7A4D9BL,0xB8DD9225L,0xFF8CEBCBL},{0x1BBCC035L,0UL,18446744073709551609UL,2UL},{0xC67B8251L,1UL,1UL,0x2FD58B9BL},{0x5D7A4D9BL,0xFE096EC2L,3UL,18446744073709551614UL},{1UL,18446744073709551615UL,0x4B8780C5L,0x7F521425L},{0xF21CC9CAL,0xF0D450FAL,18446744073709551606UL,1UL},{0xF0D450FAL,0xFE096EC2L,0x0BD55E5FL,0x061DD0D6L}},{{18446744073709551615UL,0xC67B8251L,0x5AAF153EL,2UL},{0x7249F5C1L,0x7F521425L,0xC67B8251L,0x6F00904EL},{18446744073709551610UL,0x5D7A4D9BL,18446744073709551606UL,0xF0D450FAL},{0UL,0xBE5AFCD5L,0xE43E6CDFL,0xB915F9BFL},{18446744073709551615UL,0x9CDC2726L,18446744073709551615UL,1UL},{0x1CA54E77L,0xE95FC98AL,1UL,0xFE096EC2L},{0xB915F9BFL,4UL,1UL,0xE95FC98AL},{7UL,0x061DD0D6L,1UL,0x48E5BD4BL}},{{0xB915F9BFL,1UL,1UL,18446744073709551615UL},{0x1CA54E77L,18446744073709551609UL,18446744073709551615UL,8UL},{18446744073709551615UL,8UL,0xE43E6CDFL,0UL},{0UL,1UL,18446744073709551606UL,0xE8BC89EEL},{18446744073709551610UL,0xE43E6CDFL,0xC67B8251L,0xED91D136L},{0x7249F5C1L,0UL,0x5AAF153EL,0x7249F5C1L},{18446744073709551615UL,18446744073709551614UL,0x0BD55E5FL,0x9CDC2726L},{0xF0D450FAL,7UL,18446744073709551606UL,0x19047E1AL}},{{0xF21CC9CAL,0x34E11D5AL,0x4B8780C5L,0x5174AC37L},{1UL,18446744073709551609UL,0xF0D450FAL,0xBE5AFCD5L},{18446744073709551615UL,7UL,1UL,1UL},{18446744073709551613UL,0xC67B8251L,0xBF917363L,0xB9CECBCBL},{18446744073709551615UL,1UL,18446744073709551610UL,18446744073709551606UL},{0x7249F5C1L,1UL,0xC2DDFF3CL,18446744073709551609UL},{7UL,0UL,0x996C16E2L,18446744073709551606UL},{0x16FD4120L,0x7249F5C1L,0x1CA54E77L,7UL}},{{0x6F00904EL,0x69E5C1CEL,18446744073709551606UL,0xCB3B2912L},{0xC2DDFF3CL,0UL,0xB8DD9225L,0x57A2CFCAL},{0xCB3B2912L,18446744073709551612UL,0xB915F9BFL,0x4266B84CL},{0x6F00904EL,0x57A2CFCAL,0UL,0UL},{0x0BD55E5FL,0xBE5AFCD5L,0x996C16E2L,8UL},{0x48E5BD4BL,0x5AAF153EL,0UL,0xE43E6CDFL},{0x7249F5C1L,1UL,0xE319F582L,0x2FD58B9BL},{0x996C16E2L,18446744073709551615UL,0xBF917363L,0xBF917363L}},{{0x539BF2E9L,0x539BF2E9L,18446744073709551615UL,0UL},{18446744073709551615UL,0xCBE0F7D4L,0UL,0x48E5BD4BL},{0x69E5C1CEL,0xE43E6CDFL,0UL,0UL},{0x64640AD8L,0xE43E6CDFL,1UL,0x48E5BD4BL},{0xE43E6CDFL,0xCBE0F7D4L,0x8E8E0043L,0UL},{0xB8DD9225L,0x539BF2E9L,0x4434C59DL,0xBF917363L},{1UL,18446744073709551615UL,0x1BBCC035L,0x2FD58B9BL},{18446744073709551612UL,1UL,0x192E31DCL,0xE43E6CDFL}},{{0UL,0x5AAF153EL,18446744073709551613UL,8UL},{1UL,0xBE5AFCD5L,0x8DA23DBAL,0UL},{3UL,0x57A2CFCAL,0xB9CECBCBL,0x4266B84CL},{8UL,18446744073709551612UL,7UL,0x57A2CFCAL},{4UL,0UL,0x9A1DEFE6L,0xCB3B2912L},{0UL,0x69E5C1CEL,0xB9CECBCBL,7UL},{18446744073709551615UL,0x7249F5C1L,0x57A2CFCAL,18446744073709551606UL},{1UL,0UL,18446744073709551614UL,18446744073709551609UL}}};
static volatile uint16_t **g_1411 = (void*)0;


/* --- FORWARD DECLARATIONS --- */
static const int64_t  func_1(void);
static uint64_t  func_4(int8_t  p_5);
static int64_t  func_8(const int32_t  p_9, uint8_t  p_10, int8_t  p_11);
static int32_t ** func_29(int16_t  p_30, int32_t ** p_31, uint8_t * p_32, int32_t * p_33);
static int32_t * const * func_36(int32_t * p_37, int64_t  p_38, int32_t  p_39);
static int32_t * func_40(int32_t * p_41);
static int32_t * func_42(int64_t  p_43, const uint64_t  p_44, int8_t  p_45, uint8_t * p_46);
static uint64_t  func_51(int32_t ** p_52);
static uint32_t  func_68(int32_t  p_69);
static int32_t ** func_81(const int32_t  p_82, uint16_t  p_83, uint32_t  p_84, int16_t  p_85);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_12 g_14 g_19 g_27 g_28 g_59 g_55 g_76 g_336 g_124 g_107 g_371 g_106 g_372 g_373 g_217 g_318 g_163 g_346 g_446 g_244 g_278 g_213 g_342 g_505 g_155 g_315 g_242 g_606 g_404 g_270 g_680 g_684 g_419 g_685 g_314 g_215
 * writes: g_14 g_19 g_28 g_59 g_55 g_76 g_106 g_353 g_347 g_278 g_217 g_346 g_446 g_244 g_676 g_107 g_419 g_242 g_688 g_213 g_404
 */
static const int64_t  func_1(void)
{ /* block id: 0 */
    uint16_t l_7[4][5][10] = {{{0x8084L,4UL,0x213EL,0x10FEL,1UL,0x6F9BL,65532UL,65535UL,0xEF6EL,0xF67DL},{0x0CF5L,0UL,0xDEDBL,0x6F9BL,4UL,0x4822L,65533UL,0xECF7L,0xDCA8L,4UL},{0xF7D9L,0UL,0x6A92L,65535UL,0xD762L,0xD762L,65535UL,0x6A92L,0UL,0xF7D9L},{7UL,0x0672L,0xF7D9L,0UL,65531UL,65535UL,0x4822L,65534UL,7UL,0x938DL},{0UL,0x10FEL,0xD762L,0x0672L,65531UL,65535UL,0x7B4BL,65535UL,0x0CF5L,0xF7D9L}},{{65531UL,0x4822L,0x662AL,0x5786L,0xD762L,0xEF6EL,0x9051L,65528UL,0xD193L,4UL},{65532UL,0xDEDBL,0x0CF5L,1UL,4UL,0x5786L,7UL,0xD9D0L,0x938DL,0xE1FCL},{65535UL,65535UL,65535UL,0xD762L,65533UL,1UL,0x0672L,65534UL,0x0CF5L,3UL},{0x6F93L,0UL,4UL,0xE3D3L,0x21E1L,0x5786L,65531UL,1UL,0xEF6EL,1UL},{0xF67DL,0x662AL,0x213EL,0x7B4BL,0x213EL,0x662AL,0xF67DL,0xDEDBL,65531UL,1UL}},{{0xECF7L,65535UL,65535UL,65534UL,0x57E3L,0xF7D9L,0xE1FCL,1UL,65535UL,0xDEDBL},{0x4EDCL,65535UL,0x8084L,0x0672L,0x938DL,65532UL,0xF67DL,1UL,0x57E3L,0xDCA8L},{0xE3D3L,0x662AL,65535UL,65535UL,65535UL,4UL,65531UL,65535UL,0x718BL,1UL},{65535UL,0UL,0x4006L,65535UL,0x9051L,0xDCA8L,0x0672L,65534UL,1UL,65528UL},{4UL,65535UL,0x711DL,0x6A92L,0UL,0x718BL,1UL,65535UL,0x662AL,0x57E3L}},{{65535UL,0xECF7L,0x4EDCL,0x711DL,0xF67DL,7UL,0UL,0UL,7UL,0xF67DL},{0xAD53L,0x6A92L,0x6A92L,0xAD53L,0UL,0xF67DL,0UL,4UL,65533UL,0x9051L},{0x9051L,65534UL,0x662AL,0xDEDBL,0x5786L,0xE3D3L,0x6A92L,0UL,65533UL,0x811FL},{0x917AL,65535UL,0x10FEL,0xAD53L,0x4EDCL,0xD9D0L,7UL,0x4006L,7UL,65533UL},{0xF845L,65528UL,0x0CF5L,0x711DL,0xD9D0L,0x6F93L,0xD193L,0xDCA8L,0x662AL,0UL}}};
    uint8_t *l_13[2][10] = {{&g_14,&g_14,&g_14,&g_14,&g_14,&g_14,&g_14,&g_14,&g_14,&g_14},{&g_14,&g_14,&g_14,&g_14,&g_14,&g_14,&g_14,&g_14,&g_14,&g_14}};
    int32_t l_15[10] = {0xABDF11CAL,0xABDF11CAL,0xABDF11CAL,0xABDF11CAL,0xABDF11CAL,0xABDF11CAL,0xABDF11CAL,0xABDF11CAL,0xABDF11CAL,0xABDF11CAL};
    int32_t *l_1507 = (void*)0;
    int32_t *l_1508[2];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1508[i] = &g_19[0];
    (*g_680) = ((safe_div_func_uint64_t_u_u(func_4(((!l_7[2][2][4]) , (func_8((g_12 , (((l_7[2][2][4] , 255UL) != 5UL) || g_12)), (l_15[3] ^= 0xB6L), g_14) || l_15[8]))), (-4L))) , 0x8F14D308L);
    return g_244;
}


/* ------------------------------------------ */
/* 
 * reads : g_314 g_446 g_215 g_107 g_19 g_106 g_372 g_278 g_59
 * writes: g_404 g_19
 */
static uint64_t  func_4(int8_t  p_5)
{ /* block id: 372 */
    const int32_t l_720 = (-1L);
    const int32_t **l_737[5][6] = {{&g_28,&g_28,&g_28,&g_28,&g_28,&g_28},{&g_28,&g_28,&g_28,&g_28,&g_28,&g_28},{&g_28,&g_28,&g_28,&g_28,&g_28,&g_28},{&g_28,&g_28,&g_28,&g_28,&g_28,&g_28},{&g_28,&g_28,&g_28,&g_28,&g_28,&g_28}};
    const int32_t ***l_736 = &l_737[1][0];
    uint64_t *l_738 = &g_404;
    uint32_t l_761[1][4][7] = {{{18446744073709551606UL,0xDD26C430L,0UL,0UL,0xDD26C430L,18446744073709551606UL,0xDD26C430L},{3UL,18446744073709551615UL,18446744073709551615UL,3UL,0x578060D8L,3UL,18446744073709551615UL},{1UL,1UL,18446744073709551606UL,0UL,18446744073709551606UL,1UL,1UL},{18446744073709551615UL,18446744073709551615UL,0xFA75744DL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL}}};
    uint8_t *l_784 = &g_14;
    uint16_t l_809 = 0xEE61L;
    int32_t *l_820 = (void*)0;
    uint32_t **l_822 = &g_676;
    const uint16_t l_881 = 0x7020L;
    int32_t **l_899 = &g_688[6][3];
    int32_t l_907 = 0x664ACB4EL;
    int32_t ***l_916 = &g_106;
    uint8_t l_917[9] = {252UL,252UL,252UL,252UL,252UL,252UL,252UL,252UL,252UL};
    int64_t l_922 = 0x201A880AA18723D5LL;
    int32_t l_955 = 0xFC51EACBL;
    int32_t l_956 = 0x1B16E9C1L;
    int32_t l_957 = 0x92E1D63FL;
    int32_t l_958 = 1L;
    int32_t l_959 = 0L;
    int32_t l_962 = 0xC0C67401L;
    int32_t l_966[7];
    int32_t l_967 = 0xF08258C8L;
    uint64_t l_970[8] = {0x37D7CD85CB9A83A1LL,0x37D7CD85CB9A83A1LL,0x37D7CD85CB9A83A1LL,0x37D7CD85CB9A83A1LL,0x37D7CD85CB9A83A1LL,0x37D7CD85CB9A83A1LL,0x37D7CD85CB9A83A1LL,0x37D7CD85CB9A83A1LL};
    int8_t l_1049 = 0L;
    int32_t l_1060 = 0x40E250A3L;
    int16_t l_1063 = (-9L);
    uint8_t ***l_1190 = (void*)0;
    uint8_t *l_1236 = &g_14;
    uint16_t *l_1290 = &g_422[0];
    int8_t **l_1293 = &g_372;
    int8_t l_1295 = 0L;
    int64_t l_1455 = 0x1A71A2FE730D40E7LL;
    uint16_t l_1482 = 0x0851L;
    uint32_t l_1490 = 1UL;
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_966[i] = 0x7D2A3F18L;
    if (((l_720 <= (safe_sub_func_uint16_t_u_u((l_720 == l_720), 1L))) ^ ((*l_738) = (((safe_sub_func_uint16_t_u_u((l_720 < ((((((safe_add_func_uint32_t_u_u(g_314[1], (safe_lshift_func_uint32_t_u_s((safe_lshift_func_int16_t_s_s(((((safe_div_func_uint32_t_u_u(g_446, (safe_mod_func_uint16_t_u_u((+((((void*)0 == l_736) | 0x702D878EL) , g_215)), p_5)))) == (*g_107)) <= (-8L)) > p_5), 5)), (**g_106))))) ^ (*g_372)) ^ 0xC2B10CB1L) ^ g_59) | p_5) , (**g_106))), p_5)) | 0x68L) == p_5))))
    { /* block id: 374 */
        int32_t l_743 = 0xCB3C12ACL;
        uint32_t *l_762 = &g_353;
        const int32_t **l_769 = (void*)0;
        int8_t **l_778[2];
        uint8_t **l_815 = &g_336;
        int8_t l_896 = (-1L);
        int64_t l_918 = 0x4942881E69E894E8LL;
        int32_t l_953 = 0x04BC8769L;
        int32_t l_954 = 1L;
        int32_t l_960 = (-4L);
        int32_t l_961 = 5L;
        int32_t l_963 = 0xBD35A9EBL;
        int32_t l_964 = 3L;
        int32_t l_965 = 0x5803C37EL;
        int32_t l_968[6] = {0L,0L,(-10L),0L,0L,(-10L)};
        uint32_t l_989 = 0xDF95D93BL;
        int16_t l_1062 = 0xB500L;
        int16_t l_1154 = 0x0DA8L;
        int8_t * const l_1202[6] = {&g_213,&g_213,&g_213,&g_213,&g_213,&g_213};
        int8_t l_1260 = 0x56L;
        uint64_t **l_1297 = &l_738;
        int32_t *l_1371 = &l_955;
        const uint32_t *l_1394 = &l_761[0][3][5];
        const uint32_t **l_1393 = &l_1394;
        const uint16_t *l_1396 = &g_422[0];
        const uint16_t **l_1395[7] = {&l_1396,&l_1396,(void*)0,&l_1396,&l_1396,(void*)0,&l_1396};
        const int16_t *l_1400 = &l_1062;
        const int16_t **l_1399 = &l_1400;
        const int16_t ***l_1398 = &l_1399;
        uint8_t *l_1402 = (void*)0;
        int32_t ***l_1404 = &l_899;
        int32_t ***l_1454[2];
        uint16_t l_1456 = 0x5536L;
        int i;
        for (i = 0; i < 2; i++)
            l_778[i] = &g_372;
        for (i = 0; i < 2; i++)
            l_1454[i] = &g_106;
    }
    else
    { /* block id: 670 */
        int32_t *l_1494 = &l_958;
        int32_t *l_1495 = &l_966[0];
        int32_t l_1496 = 2L;
        int32_t *l_1497 = (void*)0;
        int32_t *l_1498 = &l_966[3];
        int32_t *l_1499 = &l_958;
        int32_t *l_1500 = (void*)0;
        int32_t l_1501 = 0x39146402L;
        int32_t *l_1502 = &g_59;
        int32_t *l_1503[10][4][6] = {{{(void*)0,&g_699,&l_966[3],&l_1496,&g_699,&l_907},{&l_1496,&g_699,&l_907,&l_966[1],&l_959,&l_955},{&l_1501,&l_966[3],&l_962,&l_966[1],&l_962,&l_966[1]},{&l_962,&l_956,&l_962,&g_59,(void*)0,&g_55}},{{&l_956,&l_966[3],(void*)0,&l_962,&g_55,&l_959},{&l_907,&l_955,&g_699,&l_962,&l_955,&g_59},{&l_956,&l_962,&g_55,&g_59,&g_699,&l_959},{&l_962,&l_955,&g_446,&l_966[1],&l_1060,&g_55}},{{&l_1501,(void*)0,&l_907,&l_966[1],&l_962,&l_962},{&l_1496,&l_966[3],&l_966[3],&l_1496,&l_966[1],&l_962},{(void*)0,&l_956,&g_699,&g_699,&l_956,&g_446},{&l_955,&l_1496,&l_962,&l_956,&l_956,&g_699}},{{&l_962,&l_956,&l_1060,&l_955,&l_966[1],(void*)0},{&l_907,&l_966[3],&l_1501,&l_966[3],&l_962,&g_699},{&g_699,(void*)0,&l_966[1],&l_962,&l_1060,&l_966[3]},{&g_699,&l_955,(void*)0,&l_955,&g_699,&l_1496}},{{&l_955,&l_962,&l_966[3],&l_956,&l_955,(void*)0},{&l_962,&l_955,&g_55,&l_962,&g_55,(void*)0},{&g_59,&l_966[3],&l_966[3],&g_55,(void*)0,&l_1496},{&g_55,&l_956,(void*)0,&g_59,&l_962,&l_966[3]}},{{&g_55,&l_966[3],&l_966[1],(void*)0,&l_959,&g_699},{&l_962,&l_962,&l_1496,&l_1496,&l_962,&l_962},{&l_907,&l_962,(void*)0,&l_959,(void*)0,(void*)0},{&g_59,&g_446,&l_955,&l_962,&g_59,&g_699}},{{&g_59,&g_699,&l_962,&l_959,&l_955,&g_55},{&l_907,(void*)0,&l_907,&l_1496,&l_956,&g_446},{&l_962,&g_699,&g_699,&g_59,&l_966[3],&l_907},{&l_955,&l_966[3],&g_699,&l_966[3],&g_699,&l_966[3]}},{{&l_1060,&l_1496,&l_955,&l_907,&l_966[3],&g_699},{&l_966[3],(void*)0,&l_962,&g_55,&l_959,&l_962},{&g_55,(void*)0,&g_59,&l_1060,&l_966[3],&l_1060},{&l_956,&l_1496,&g_55,&l_966[1],&g_699,&l_1501}},{{&l_962,&l_966[3],&g_55,&g_446,&l_966[3],&l_966[1]},{(void*)0,&g_699,(void*)0,&l_956,&l_956,(void*)0},{(void*)0,(void*)0,&g_55,&l_959,&l_955,&l_966[3]},{&g_446,&g_699,&l_966[3],&l_966[1],&g_59,&g_55}},{{&l_956,&g_446,&l_966[3],&l_962,(void*)0,&l_966[3]},{&l_955,&l_962,&g_55,&l_966[3],&l_962,(void*)0},{&l_966[3],&l_962,(void*)0,&l_955,&l_962,&l_966[1]},{&l_1496,&g_55,&g_55,&l_1501,&g_55,&l_1501}}};
        uint32_t l_1504[9] = {0x40FC0116L,0x40FC0116L,0x40FC0116L,0x40FC0116L,0x40FC0116L,0x40FC0116L,0x40FC0116L,0x40FC0116L,0x40FC0116L};
        int i, j, k;
        l_1504[2]--;
    }
    (***l_916) = (*g_107);
    return (***l_916);
}


/* ------------------------------------------ */
/* 
 * reads : g_14 g_19 g_27 g_12 g_28 g_59 g_55 g_76 g_336 g_124 g_107 g_371 g_106 g_372 g_373 g_217 g_318 g_163 g_346 g_446 g_244 g_278 g_213 g_342 g_505 g_155 g_315 g_242 g_606 g_404 g_270 g_680 g_684 g_419 g_685
 * writes: g_14 g_19 g_28 g_59 g_55 g_76 g_106 g_353 g_347 g_278 g_217 g_346 g_446 g_244 g_676 g_107 g_419 g_242 g_688 g_213
 */
static int64_t  func_8(const int32_t  p_9, uint8_t  p_10, int8_t  p_11)
{ /* block id: 2 */
    int64_t l_23 = (-9L);
    const uint64_t l_24 = 18446744073709551615UL;
    int32_t *l_26[6] = {&g_19[3],&g_19[5],&g_19[5],&g_19[3],&g_19[5],&g_19[5]};
    int32_t **l_53 = &l_26[1];
    int64_t *l_673 = &l_23;
    uint32_t *l_678 = &g_200;
    uint32_t **l_677 = &l_678;
    uint32_t l_679 = 0x620FE6A1L;
    int32_t * const l_698 = &g_699;
    int32_t * const *l_697 = &l_698;
    int32_t * const **l_696 = &l_697;
    int i;
lbl_25:
    for (g_14 = (-1); (g_14 > 14); g_14++)
    { /* block id: 5 */
        int32_t *l_18 = &g_19[4];
        int32_t **l_20 = &l_18;
        int32_t *l_22 = (void*)0;
        int32_t **l_21 = &l_22;
        (*l_21) = ((*l_20) = l_18);
        l_23 |= g_19[1];
        if ((**l_21))
            break;
        if (g_14)
            goto lbl_25;
        if (l_24)
            continue;
    }
    g_19[4] = g_14;
    (*g_27) = &p_9;
    (*l_696) = func_29((safe_add_func_uint16_t_u_u(((g_19[4] <= 0x1EA52FA5L) , g_12), (((*l_696) = func_36(func_40(func_42(p_10, (((safe_mul_func_int8_t_s_s((((*l_673) &= (safe_add_func_uint64_t_u_u(func_51(l_53), p_11))) <= (safe_div_func_int64_t_s_s(((((((((*l_677) = (g_676 = &g_650)) != l_26[0]) | l_679) ^ (**l_53)) ^ (**l_53)) , (**l_53)) || p_10), p_9))), 0x36L)) >= g_12) >= p_10), (**l_53), (*g_606))), g_19[0], p_10)) == &g_28))), &l_26[4], (*g_606), (*l_53));
    return p_10;
}


/* ------------------------------------------ */
/* 
 * reads : g_213
 * writes: g_213
 */
static int32_t ** func_29(int16_t  p_30, int32_t ** p_31, uint8_t * p_32, int32_t * p_33)
{ /* block id: 363 */
    int32_t l_702 = 1L;
    int32_t l_707 = 0xC6AE3A0EL;
    int32_t l_708 = 0x3E7E33F7L;
    int32_t l_709 = 0x470E3CFAL;
    int32_t l_710 = 0xFCC03608L;
    int32_t l_711 = 0x48C2E7B2L;
    int32_t l_712 = 0x0D6C513AL;
    int32_t l_713 = 0x97A743C4L;
    int32_t l_714 = 1L;
    int32_t l_715 = 0x68784030L;
    uint32_t l_716 = 0x79361D68L;
    int32_t **l_719[8][9][3] = {{{(void*)0,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{(void*)0,&g_107,&g_107},{&g_107,&g_107,&g_107}},{{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{(void*)0,&g_107,&g_107},{&g_107,(void*)0,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107}},{{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,(void*)0},{(void*)0,&g_107,&g_107},{&g_107,&g_107,(void*)0},{&g_107,&g_107,&g_107}},{{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,(void*)0,&g_107},{&g_107,&g_107,(void*)0},{&g_107,&g_107,&g_107},{(void*)0,&g_107,(void*)0}},{{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,(void*)0,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107}},{{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{(void*)0,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107}},{{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,(void*)0},{(void*)0,&g_107,&g_107},{&g_107,&g_107,(void*)0},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107}},{{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107},{&g_107,(void*)0,&g_107},{&g_107,&g_107,(void*)0},{&g_107,&g_107,&g_107},{(void*)0,&g_107,(void*)0},{&g_107,&g_107,&g_107},{&g_107,&g_107,&g_107}}};
    int i, j, k;
    for (g_213 = 0; (g_213 >= 1); g_213 = safe_add_func_int16_t_s_s(g_213, 1))
    { /* block id: 366 */
        int32_t *l_703 = (void*)0;
        int32_t *l_704 = &g_19[0];
        int32_t *l_705 = &g_59;
        int32_t *l_706[9][1] = {{&g_699},{(void*)0},{&g_699},{(void*)0},{&g_699},{(void*)0},{&g_699},{(void*)0},{&g_699}};
        int i, j;
        --l_716;
    }
    return l_719[5][5][2];
}


/* ------------------------------------------ */
/* 
 * reads : g_446 g_213 g_684
 * writes: g_688 g_446 g_55
 */
static int32_t * const * func_36(int32_t * p_37, int64_t  p_38, int32_t  p_39)
{ /* block id: 355 */
    int32_t *l_687 = (void*)0;
    int32_t **l_686[3];
    int32_t *l_689 = &g_346;
    int32_t *l_690 = &g_446;
    uint64_t *l_691[5];
    int64_t l_692[3];
    uint32_t l_695 = 4294967287UL;
    int i;
    for (i = 0; i < 3; i++)
        l_686[i] = &l_687;
    for (i = 0; i < 5; i++)
        l_691[i] = &g_404;
    for (i = 0; i < 3; i++)
        l_692[i] = 0x64BCC106953BD27CLL;
    (*l_690) &= ((g_688[6][3] = &p_39) == l_689);
    (*g_684) = (((((*l_690) = 0xDD58FF2DBA44E566LL) , ((*l_690) = (l_692[2] , ((void*)0 == &g_163)))) == ((((safe_sub_func_uint16_t_u_u(0x8B6CL, 2UL)) , (l_695 >= 0x7B196A92L)) , &l_692[1]) == (void*)0)) <= g_213);
    return &g_107;
}


/* ------------------------------------------ */
/* 
 * reads : g_419 g_244 g_680 g_59 g_685 g_242 g_106 g_107
 * writes: g_419 g_244 g_55 g_242
 */
static int32_t * func_40(int32_t * p_41)
{ /* block id: 339 */
    for (g_419 = 3; (g_419 >= 0); g_419 -= 1)
    { /* block id: 342 */
        for (g_244 = 0; (g_244 <= 3); g_244 += 1)
        { /* block id: 345 */
            (*g_685) = (*g_680);
        }
        for (g_242 = 3; (g_242 >= 0); g_242 -= 1)
        { /* block id: 350 */
            return p_41;
        }
    }
    return (*g_106);
}


/* ------------------------------------------ */
/* 
 * reads : g_270 g_680 g_106 g_107 g_244 g_19 g_684
 * writes: g_59 g_107 g_244 g_55
 */
static int32_t * func_42(int64_t  p_43, const uint64_t  p_44, int8_t  p_45, uint8_t * p_46)
{ /* block id: 329 */
    (*g_680) = ((0x34L ^ (-1L)) >= g_270);
    (*g_106) = (*g_106);
    for (g_244 = 0; (g_244 <= 46); g_244++)
    { /* block id: 334 */
        int32_t *l_683[7];
        int i;
        for (i = 0; i < 7; i++)
            l_683[i] = (void*)0;
        return l_683[2];
    }
    (*g_684) = (**g_106);
    return (*g_106);
}


/* ------------------------------------------ */
/* 
 * reads : g_27 g_28 g_59 g_55 g_76 g_14 g_19 g_336 g_124 g_107 g_371 g_106 g_372 g_373 g_217 g_318 g_163 g_346 g_446 g_244 g_278 g_213 g_342 g_505 g_155 g_315 g_242 g_606 g_404
 * writes: g_59 g_55 g_76 g_14 g_106 g_353 g_347 g_278 g_217 g_346 g_446 g_244
 */
static uint64_t  func_51(int32_t ** p_52)
{ /* block id: 15 */
    int32_t *l_54 = &g_55;
    int32_t *l_56 = &g_55;
    int32_t *l_57 = (void*)0;
    int32_t *l_58[5];
    uint32_t l_61 = 4294967295UL;
    uint32_t *l_661 = &l_61;
    int16_t ***l_672 = (void*)0;
    int i;
    for (i = 0; i < 5; i++)
        l_58[i] = (void*)0;
    --l_61;
    (*l_54) = (0xA8BFL && (safe_sub_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u((((*l_661) = func_68((**g_27))) , (safe_mul_func_uint64_t_u_u((1L == (*g_372)), (safe_add_func_int16_t_s_s((safe_mod_func_uint32_t_u_u(g_213, (safe_div_func_uint32_t_u_u((((*l_56) , (((safe_add_func_int64_t_s_s((g_342[3][5][7] == (l_672 == &g_619)), g_505[0])) , g_155) & 0L)) != g_315), (**p_52))))), (-5L)))))), g_242)), (**g_606))));
    return g_404;
}


/* ------------------------------------------ */
/* 
 * reads : g_59 g_55 g_76 g_14 g_19 g_28 g_27 g_336 g_124 g_107 g_371 g_106 g_372 g_373 g_217 g_318 g_163 g_346 g_446 g_244 p_9
 * writes: g_59 g_55 g_76 g_14 g_106 g_353 g_347 g_278 g_217 g_346 g_446 g_244
 */
static uint32_t  func_68(int32_t  p_69)
{ /* block id: 17 */
    int32_t l_89 = 0x14B153CBL;
    int32_t l_383[1];
    int8_t l_434 = 3L;
    int32_t *** const l_442[7] = {&g_106,&g_106,&g_106,&g_106,&g_106,&g_106,&g_106};
    int16_t l_472 = 0xECD1L;
    const int32_t **l_597 = (void*)0;
    int32_t *l_612 = &l_89;
    int32_t **l_611 = &l_612;
    int i;
    for (i = 0; i < 1; i++)
        l_383[i] = 0x28358FC4L;
    for (p_69 = 12; (p_69 < 24); p_69++)
    { /* block id: 20 */
        uint64_t l_364 = 0x072602DF7147C9C7LL;
        const int8_t *l_370 = &g_215;
        const int8_t ** const l_369 = &l_370;
        for (g_59 = 3; (g_59 != (-28)); g_59 = safe_sub_func_int16_t_s_s(g_59, 1))
        { /* block id: 23 */
            int32_t *l_74 = (void*)0;
            int32_t *l_75 = &g_55;
            int16_t l_77[9] = {0x92FDL,0x92FDL,0x92FDL,0x92FDL,0x92FDL,0x92FDL,0x92FDL,0x92FDL,0x92FDL};
            int i;
            g_76 ^= ((*l_75) |= 0x0E761D3FL);
            for (g_14 = 0; (g_14 <= 8); g_14 += 1)
            { /* block id: 28 */
                int32_t ***l_352 = &g_106;
                uint16_t *l_357 = &g_347;
                uint32_t *l_376 = &g_217;
                int i;
                if (l_77[g_14])
                    break;
                g_353 = (g_19[4] , ((*l_75) = (((safe_div_func_int8_t_s_s((~(((*l_352) = func_81(l_77[g_14], g_76, p_69, (safe_lshift_func_uint16_t_u_s((l_77[g_14] > (((((((safe_unary_minus_func_uint16_t_u((((l_89 < (p_69 != g_55)) && (safe_add_func_int32_t_s_s((*g_28), (**g_27)))) >= 7L))) , &p_69) != (void*)0) , (void*)0) == l_74) && p_69) & 0xB5L)), 5)))) == (void*)0)), (*g_336))) & (*g_107)) , 0xE3D5871BL)));
                (*l_75) = (p_69 >= (safe_mul_func_int64_t_s_s(((((void*)0 == &g_336) | (((((+((((((*l_357) = g_76) , (safe_mul_func_int16_t_s_s((((void*)0 != &g_107) && (0xAB817C311D1F85CFLL != (safe_div_func_uint8_t_u_u((((((**g_371) = (safe_mod_func_int32_t_s_s(((l_364 <= (safe_add_func_int64_t_s_s((safe_div_func_uint8_t_u_u((l_369 != g_371), l_364)), p_69))) & (***l_352)), (**g_106)))) < p_69) , l_364) == (***l_352)), 1L)))), 65535UL))) == 0L) != g_373) == (*l_75))) | 0x6154L) >= g_55) , p_69) | 65527UL)) || p_69), l_89)));
                (*l_75) = (4294967295UL <= (0L <= (((safe_lshift_func_int32_t_s_u(0x6DCEA92AL, (--(*l_376)))) || 0x97B9BFE1L) | (safe_mul_func_uint8_t_u_u((*g_336), (safe_sub_func_int32_t_s_s((l_383[0] = ((g_318 , (*l_75)) < (((*g_28) , (*g_106)) == (void*)0))), g_163)))))));
            }
        }
    }
    for (g_14 = 0; (g_14 > 26); ++g_14)
    { /* block id: 168 */
        uint8_t l_405 = 250UL;
        int32_t l_416 = 1L;
        int32_t ***l_443 = &g_106;
        uint64_t l_447 = 18446744073709551610UL;
        uint16_t l_471 = 65526UL;
        for (g_346 = 0; (g_346 > 12); g_346 = safe_add_func_int32_t_s_s(g_346, 4))
        { /* block id: 171 */
            int32_t l_388[4] = {2L,2L,2L,2L};
            uint16_t l_412 = 0xDFEBL;
            uint16_t l_441 = 0x57BFL;
            int32_t *l_517 = &l_388[2];
            int i;
            if (l_388[1])
                break;
            for (g_59 = 0; (g_59 <= 4); g_59++)
            { /* block id: 175 */
                uint64_t *l_403[9][8] = {{&g_404,(void*)0,(void*)0,&g_404,&g_404,(void*)0,(void*)0,&g_404},{&g_404,(void*)0,(void*)0,(void*)0,&g_404,&g_404,&g_404,&g_404},{(void*)0,(void*)0,&g_404,&g_404,(void*)0,&g_404,&g_404,&g_404},{&g_404,(void*)0,&g_404,(void*)0,&g_404,&g_404,&g_404,&g_404},{&g_404,&g_404,&g_404,&g_404,&g_404,(void*)0,(void*)0,(void*)0},{&g_404,(void*)0,&g_404,&g_404,&g_404,&g_404,&g_404,&g_404},{&g_404,&g_404,&g_404,&g_404,&g_404,(void*)0,&g_404,&g_404},{(void*)0,&g_404,&g_404,&g_404,&g_404,&g_404,&g_404,&g_404},{&g_404,&g_404,(void*)0,&g_404,(void*)0,&g_404,&g_404,&g_404}};
                int32_t l_406 = 0xD938A761L;
                int64_t *l_407 = (void*)0;
                int64_t *l_408 = &g_242;
                int32_t *l_413 = &l_89;
                int16_t *l_414 = &g_155;
                uint32_t *l_415 = &g_217;
                int8_t l_420 = 0x23L;
                int64_t l_421 = (-1L);
                int32_t *l_473 = &l_388[1];
                const int32_t **l_495 = &g_28;
                int32_t l_497 = 2L;
                int32_t l_504[6] = {(-2L),(-2L),0x72CF6539L,(-2L),(-2L),0x72CF6539L};
                int i, j;
                if (l_89)
                    break;
            }
            (*l_517) = (safe_lshift_func_uint8_t_u_u((*g_336), 2));
            if ((**g_106))
                break;
        }
    }
    for (g_446 = 0; (g_446 != 26); g_446 = safe_add_func_uint32_t_u_u(g_446, 1))
    { /* block id: 248 */
        const int32_t *l_533[4][5][3] = {{{&g_19[4],&g_59,&g_59},{(void*)0,&l_383[0],(void*)0},{&g_446,&g_446,&g_19[4]},{&g_19[4],&g_59,&l_383[0]},{&g_55,&l_383[0],&g_55}},{{&l_383[0],&g_59,&g_19[4]},{&g_19[4],&g_446,&g_446},{(void*)0,&l_383[0],(void*)0},{&g_59,&g_59,&g_19[4]},{(void*)0,&l_383[0],&l_383[0]}},{{&g_19[4],&g_19[4],&l_383[0]},{&l_383[0],&l_383[0],&l_383[0]},{&g_55,&g_19[4],&l_383[0]},{&g_19[4],&g_59,&l_383[0]},{&g_446,&g_19[5],&g_19[4]}},{{(void*)0,&g_59,(void*)0},{&g_19[4],&g_19[5],&g_446},{&l_383[0],&g_59,&g_19[4]},{&l_383[0],&g_19[4],&g_55},{&l_383[0],&l_383[0],&l_383[0]}}};
        int32_t l_535 = 0x7D1D343AL;
        const uint8_t *l_548 = (void*)0;
        int64_t l_549[8][6][1] = {{{(-1L)},{0xC12BECA3DA5228B5LL},{3L},{0xC12BECA3DA5228B5LL},{(-1L)},{0xF425CAEBDBC00466LL}},{{(-1L)},{0xC12BECA3DA5228B5LL},{3L},{0xC12BECA3DA5228B5LL},{(-1L)},{0xF425CAEBDBC00466LL}},{{(-1L)},{0xC12BECA3DA5228B5LL},{3L},{0xC12BECA3DA5228B5LL},{(-1L)},{0xF425CAEBDBC00466LL}},{{(-1L)},{0xC12BECA3DA5228B5LL},{3L},{0xC12BECA3DA5228B5LL},{(-1L)},{0xF425CAEBDBC00466LL}},{{(-1L)},{0xC12BECA3DA5228B5LL},{3L},{0xC12BECA3DA5228B5LL},{(-1L)},{0xF425CAEBDBC00466LL}},{{(-1L)},{0xC12BECA3DA5228B5LL},{3L},{0xC12BECA3DA5228B5LL},{(-1L)},{0xF425CAEBDBC00466LL}},{{(-1L)},{0xC12BECA3DA5228B5LL},{3L},{0xC12BECA3DA5228B5LL},{(-1L)},{0xF425CAEBDBC00466LL}},{{(-1L)},{0xC12BECA3DA5228B5LL},{3L},{0xC12BECA3DA5228B5LL},{(-1L)},{0xF425CAEBDBC00466LL}}};
        uint32_t l_585 = 0x5482B49EL;
        int i, j, k;
        if ((*g_107))
            break;
        for (g_244 = (-20); (g_244 >= 42); g_244++)
        { /* block id: 252 */
            const int32_t **l_532[3][2][8] = {{{&g_28,&g_28,&g_28,&g_28,(void*)0,&g_28,&g_28,(void*)0},{&g_28,&g_28,&g_28,&g_28,&g_28,&g_28,&g_28,(void*)0}},{{&g_28,&g_28,&g_28,&g_28,(void*)0,&g_28,&g_28,&g_28},{&g_28,&g_28,(void*)0,&g_28,&g_28,&g_28,&g_28,&g_28}},{{(void*)0,&g_28,&g_28,&g_28,&g_28,(void*)0,&g_28,(void*)0},{&g_28,&g_28,(void*)0,&g_28,&g_28,&g_28,&g_28,&g_28}}};
            uint8_t l_534[7][6][6] = {{{0x3AL,0UL,0xA7L,0x47L,0xA1L,0x47L},{246UL,255UL,246UL,0x11L,0UL,0x88L},{0x88L,0xECL,1UL,0xEAL,8UL,0UL},{0xECL,0UL,0x3AL,0xEAL,0xC4L,0x11L},{0x88L,0xA7L,0xA1L,0x11L,0x11L,0xA1L},{246UL,246UL,0xBEL,0x47L,252UL,0xECL}},{{0x3AL,1UL,252UL,255UL,0x6AL,0xBEL},{0xA7L,0x3AL,252UL,0xA1L,246UL,0xECL},{254UL,0xA1L,0xBEL,8UL,0xBEL,0xA1L},{8UL,0xBEL,0xA1L,254UL,0xF4L,0x11L},{0xA1L,252UL,0x3AL,0xA7L,255UL,0UL},{255UL,252UL,1UL,0x3AL,0xF4L,0x88L}},{{0x47L,0xBEL,246UL,246UL,0xBEL,0x47L},{0x11L,0xA1L,0xA7L,0x88L,246UL,254UL},{0xEAL,0x3AL,0UL,0xECL,0x6AL,1UL},{0xEAL,1UL,0xECL,0x88L,252UL,0x6AL},{0x11L,246UL,255UL,246UL,0x11L,0UL},{0x47L,0xA7L,0UL,0x3AL,0xC4L,0xD7L}},{{255UL,0UL,0x50L,0xA7L,8UL,0xD7L},{0xA1L,0xECL,0UL,254UL,0UL,0UL},{8UL,255UL,255UL,8UL,0xA1L,0x6AL},{254UL,0UL,0xECL,0xA1L,0x88L,1UL},{0xA7L,0x50L,0UL,255UL,0x88L,254UL},{0x3AL,0UL,0xA7L,0x47L,0xA1L,0x47L}},{{246UL,255UL,246UL,0x11L,0UL,0x88L},{0x88L,0xECL,1UL,0xEAL,8UL,0UL},{0UL,0xBEL,0x88L,0xC4L,8UL,0xECL},{0xA7L,0x11L,255UL,0xECL,0xECL,255UL},{0xF4L,0xF4L,0x50L,246UL,0x47L,0UL},{0x88L,0x3AL,0x47L,0x8EL,0xA1L,0x50L}},{{0x11L,0x88L,0x47L,255UL,0xF4L,0UL},{1UL,255UL,0x50L,0xD7L,0x50L,255UL},{0xD7L,0x50L,255UL,1UL,0x6AL,0xECL},{255UL,0x47L,0x88L,0x11L,0x8EL,0UL},{0x8EL,0x47L,0x3AL,0x88L,0x6AL,0xA7L},{246UL,0x50L,0xF4L,0xF4L,0x50L,246UL}},{{0xECL,255UL,0x11L,0xA7L,0xF4L,1UL},{0xC4L,0x88L,0xBEL,0UL,0xA1L,0x3AL},{0xC4L,0x3AL,0UL,0xA7L,0x47L,0xA1L},{0xECL,0xF4L,0x8EL,0xF4L,0xECL,0xBEL},{246UL,0x11L,0UL,0x88L,8UL,252UL},{0x8EL,0xBEL,0xEAL,0x11L,0xD7L,252UL}}};
            int32_t *l_562 = &g_346;
            int32_t l_623 = (-4L);
            int8_t *l_637 = &g_278;
            int32_t l_657[3];
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_657[i] = 0x42F2E42BL;
        }
    }
    return p_69;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t ** func_81(const int32_t  p_82, uint16_t  p_83, uint32_t  p_84, int16_t  p_85)
{ /* block id: 30 */
    uint64_t l_94 = 0xEB3B2B9CE0359602LL;
    uint8_t *l_95 = &g_14;
    int32_t *l_98 = &g_55;
    int32_t **l_97 = &l_98;
    int32_t l_137 = 3L;
    int32_t l_268 = (-6L);
    int8_t l_269 = 0x2FL;
    uint32_t l_284[6][5][8] = {{{1UL,0x5617BBF6L,0x598B75F5L,0x65F59FADL,0x62DFEED0L,7UL,0x149BCCB0L,0xD19256E6L},{18446744073709551615UL,0x5617BBF6L,0x6006E27DL,18446744073709551614UL,0x5617BBF6L,18446744073709551615UL,0x1E7CC754L,0x65F59FADL},{0UL,18446744073709551615UL,18446744073709551614UL,0x149BCCB0L,18446744073709551614UL,18446744073709551615UL,0UL,18446744073709551615UL},{0x5617BBF6L,0x62DFEED0L,0x598B75F5L,0UL,0xD19256E6L,0x598B75F5L,1UL,0UL},{18446744073709551615UL,0x149BCCB0L,0x1E7CC754L,18446744073709551614UL,0xD19256E6L,0x6006E27DL,18446744073709551615UL,0x149BCCB0L}},{{0x5617BBF6L,0x1E7CC754L,18446744073709551615UL,0UL,18446744073709551614UL,18446744073709551614UL,0UL,18446744073709551615UL},{0UL,0UL,7UL,1UL,0x5617BBF6L,0x598B75F5L,0x65F59FADL,0x62DFEED0L},{18446744073709551615UL,1UL,0xF1773046L,0x6006E27DL,0x62DFEED0L,0x1E7CC754L,18446744073709551615UL,0x62DFEED0L},{1UL,18446744073709551615UL,18446744073709551614UL,1UL,0x6006E27DL,18446744073709551615UL,18446744073709551614UL,18446744073709551615UL},{18446744073709551614UL,0UL,0x598B75F5L,0UL,18446744073709551614UL,7UL,0xD19256E6L,0x149BCCB0L}},{{18446744073709551615UL,0x65F59FADL,0UL,18446744073709551614UL,0x65F59FADL,0xF1773046L,0x1E7CC754L,0UL},{0xD19256E6L,18446744073709551615UL,0UL,0UL,18446744073709551614UL,18446744073709551614UL,18446744073709551615UL,0xE1F7ADB6L},{18446744073709551614UL,18446744073709551614UL,0xD19256E6L,18446744073709551615UL,18446744073709551615UL,0xD19256E6L,18446744073709551614UL,18446744073709551614UL},{0xE1F7ADB6L,18446744073709551615UL,7UL,3UL,0xF1773046L,1UL,18446744073709551615UL,18446744073709551615UL},{0UL,0x598B75F5L,0UL,18446744073709551614UL,3UL,1UL,18446744073709551614UL,0x9497A160L}},{{18446744073709551615UL,18446744073709551615UL,0x149BCCB0L,18446744073709551614UL,0UL,0xD19256E6L,0UL,18446744073709551614UL},{0x9497A160L,18446744073709551614UL,0x9497A160L,0xD741B982L,18446744073709551615UL,7UL,18446744073709551615UL,18446744073709551615UL},{0x1E7CC754L,18446744073709551615UL,0x598B75F5L,0x1E7CC754L,0xD741B982L,0UL,18446744073709551615UL,0x9497A160L},{0x1E7CC754L,18446744073709551614UL,0xD19256E6L,0x6006E27DL,18446744073709551615UL,0x149BCCB0L,0xF1773046L,0xF1773046L},{0x9497A160L,0UL,3UL,3UL,0UL,0x9497A160L,0x598B75F5L,0x6006E27DL}},{{18446744073709551615UL,18446744073709551615UL,0xD741B982L,18446744073709551615UL,3UL,0x598B75F5L,18446744073709551615UL,0xE1F7ADB6L},{0UL,18446744073709551615UL,0xD19256E6L,18446744073709551615UL,0xF1773046L,0xD19256E6L,0x1E7CC754L,0x6006E27DL},{0xE1F7ADB6L,0xF1773046L,18446744073709551615UL,3UL,18446744073709551615UL,3UL,18446744073709551615UL,0xF1773046L},{18446744073709551614UL,0x598B75F5L,0xE1F7ADB6L,0x6006E27DL,3UL,0xD741B982L,0x6006E27DL,0x9497A160L},{18446744073709551615UL,18446744073709551615UL,0x149BCCB0L,0x1E7CC754L,18446744073709551614UL,0xD19256E6L,0x6006E27DL,18446744073709551615UL}},{{0x9497A160L,0x1E7CC754L,0xE1F7ADB6L,0xD741B982L,18446744073709551614UL,18446744073709551615UL,18446744073709551615UL,18446744073709551614UL},{18446744073709551614UL,18446744073709551615UL,18446744073709551615UL,18446744073709551614UL,0xD741B982L,0xE1F7ADB6L,0x1E7CC754L,0x9497A160L},{18446744073709551615UL,0x6006E27DL,0xD19256E6L,18446744073709551614UL,0x1E7CC754L,0x149BCCB0L,18446744073709551615UL,18446744073709551615UL},{0x9497A160L,0x6006E27DL,0xD741B982L,3UL,0x6006E27DL,0xE1F7ADB6L,0x598B75F5L,18446744073709551614UL},{0xF1773046L,18446744073709551615UL,3UL,18446744073709551615UL,3UL,18446744073709551615UL,0xF1773046L,0xE1F7ADB6L}}};
    int32_t **l_351 = &g_107;
    int i, j, k;
    for (p_85 = 0; (p_85 >= 22); ++p_85)
    { /* block id: 33 */
        int32_t **l_99[1][6];
        int32_t *l_105 = &g_19[2];
        uint8_t *l_135 = &g_14;
        int64_t l_263[4] = {0xFD9DDA32BF4E470BLL,0xFD9DDA32BF4E470BLL,0xFD9DDA32BF4E470BLL,0xFD9DDA32BF4E470BLL};
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 6; j++)
                l_99[i][j] = (void*)0;
        }
    }
    return l_351;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_14, "g_14", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_19[i], "g_19[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_59, "g_59", print_hash_value);
    transparent_crc(g_60, "g_60", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_124, "g_124", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_155, "g_155", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_168, "g_168", print_hash_value);
    transparent_crc(g_200, "g_200", print_hash_value);
    transparent_crc(g_213, "g_213", print_hash_value);
    transparent_crc(g_215, "g_215", print_hash_value);
    transparent_crc(g_217, "g_217", print_hash_value);
    transparent_crc(g_242, "g_242", print_hash_value);
    transparent_crc(g_244, "g_244", print_hash_value);
    transparent_crc(g_270, "g_270", print_hash_value);
    transparent_crc(g_278, "g_278", print_hash_value);
    transparent_crc(g_279, "g_279", print_hash_value);
    transparent_crc(g_311, "g_311", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_314[i], "g_314[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_315, "g_315", print_hash_value);
    transparent_crc(g_318, "g_318", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_342[i][j][k], "g_342[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_346, "g_346", print_hash_value);
    transparent_crc(g_347, "g_347", print_hash_value);
    transparent_crc(g_353, "g_353", print_hash_value);
    transparent_crc(g_373, "g_373", print_hash_value);
    transparent_crc(g_404, "g_404", print_hash_value);
    transparent_crc(g_418, "g_418", print_hash_value);
    transparent_crc(g_419, "g_419", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_422[i], "g_422[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_446, "g_446", print_hash_value);
    transparent_crc(g_498, "g_498", print_hash_value);
    transparent_crc(g_500, "g_500", print_hash_value);
    transparent_crc(g_501, "g_501", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_505[i], "g_505[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_506[i], "g_506[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_547, "g_547", print_hash_value);
    transparent_crc(g_565, "g_565", print_hash_value);
    transparent_crc(g_566, "g_566", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_621[i][j], "g_621[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_650, "g_650", print_hash_value);
    transparent_crc(g_699, "g_699", print_hash_value);
    transparent_crc(g_781, "g_781", print_hash_value);
    transparent_crc(g_783, "g_783", print_hash_value);
    transparent_crc(g_877, "g_877", print_hash_value);
    transparent_crc(g_1117, "g_1117", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_1197[i][j], "g_1197[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1200, "g_1200", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1359[i][j][k], "g_1359[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1403[i][j][k], "g_1403[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 346
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 34
breakdown:
   depth: 1, occurrence: 52
   depth: 2, occurrence: 18
   depth: 3, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 2
   depth: 19, occurrence: 1
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 30, occurrence: 1
   depth: 34, occurrence: 1

XXX total number of pointers: 323

XXX times a variable address is taken: 827
XXX times a pointer is dereferenced on RHS: 183
breakdown:
   depth: 1, occurrence: 113
   depth: 2, occurrence: 62
   depth: 3, occurrence: 8
XXX times a pointer is dereferenced on LHS: 187
breakdown:
   depth: 1, occurrence: 170
   depth: 2, occurrence: 16
   depth: 3, occurrence: 1
XXX times a pointer is compared with null: 33
XXX times a pointer is compared with address of another variable: 4
XXX times a pointer is compared with another pointer: 6
XXX times a pointer is qualified to be dereferenced: 4464

XXX max dereference level: 3
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 617
   level: 2, occurrence: 242
   level: 3, occurrence: 29
XXX number of pointers point to pointers: 121
XXX number of pointers point to scalars: 202
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 34.7
XXX average alias set size: 1.6

XXX times a non-volatile is read: 1201
XXX times a non-volatile is write: 563
XXX times a volatile is read: 68
XXX    times read thru a pointer: 9
XXX times a volatile is write: 30
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 587
XXX percentage of non-volatile access: 94.7

XXX forward jumps: 1
XXX backward jumps: 5

XXX stmts: 58
XXX max block depth: 3
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 14
   depth: 2, occurrence: 8
   depth: 3, occurrence: 5

XXX percentage a fresh-made variable is used: 17.6
XXX percentage an existing variable is used: 82.4
XXX total OOB instances added: 0
********************* end of statistics **********************/

