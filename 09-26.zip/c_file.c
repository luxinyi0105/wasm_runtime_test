/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      258852231
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   int32_t  f0;
   volatile uint32_t  f1;
   uint16_t  f2;
   volatile int32_t  f3;
   volatile int16_t  f4;
};

#pragma pack(push)
#pragma pack(1)
struct S1 {
   int8_t  f0;
   uint64_t  f1;
   int32_t  f2;
   const volatile int32_t  f3;
   const volatile signed f4 : 8;
};
#pragma pack(pop)

union U2 {
   uint32_t  f0;
   volatile uint16_t  f1;
   volatile uint8_t  f2;
};

union U3 {
   volatile struct S0  f0;
   const volatile struct S0  f1;
   const int16_t  f2;
   uint16_t  f3;
   volatile uint32_t  f4;
};

union U4 {
   struct S0  f0;
};

union U5 {
   const uint32_t  f0;
   const int64_t  f1;
   const int16_t  f2;
   const struct S0  f3;
   int8_t  f4;
};

/* --- GLOBAL VARIABLES --- */
static volatile uint8_t g_12 = 0UL;/* VOLATILE GLOBAL g_12 */
static int8_t g_32 = 0x0BL;
static int32_t g_55 = 6L;
static int32_t g_71 = 0xCF5738F5L;
static int16_t g_75[1] = {(-1L)};
static const int32_t g_78 = 0xCCFB42DEL;
static const int32_t *g_77[10][3] = {{(void*)0,(void*)0,(void*)0},{&g_78,&g_78,&g_78},{&g_78,(void*)0,&g_78},{&g_78,&g_78,&g_78},{(void*)0,(void*)0,(void*)0},{&g_78,&g_78,&g_78},{&g_78,(void*)0,&g_78},{&g_78,&g_78,&g_78},{(void*)0,(void*)0,(void*)0},{&g_78,&g_78,&g_78}};
static int64_t g_110 = (-2L);
static uint8_t g_115 = 255UL;
static int8_t g_129 = 0x78L;
static const int16_t g_138 = 6L;
static const int64_t g_163 = 3L;
static const int64_t *g_162 = &g_163;
static uint16_t g_166 = 6UL;
static int16_t g_172 = 0x5B94L;
static union U3 g_177[6] = {{{-1L,0x0DC5A684L,0UL,0xA74C124AL,-10L}},{{-1L,0x0DC5A684L,0UL,0xA74C124AL,-10L}},{{-1L,0x0DC5A684L,0UL,0xA74C124AL,-10L}},{{-1L,0x0DC5A684L,0UL,0xA74C124AL,-10L}},{{-1L,0x0DC5A684L,0UL,0xA74C124AL,-10L}},{{-1L,0x0DC5A684L,0UL,0xA74C124AL,-10L}}};
static union U3 *g_176 = &g_177[4];
static uint64_t g_196 = 0x503D4E83F1017A0ALL;
static union U3 g_206 = {{0x18042E1AL,0xE11363E6L,0x0648L,0x89FB3FE4L,0L}};/* VOLATILE GLOBAL g_206 */
static int8_t g_210[4][10] = {{(-5L),(-5L),0x3DL,0L,(-7L),0x3DL,(-7L),0L,0x3DL,0xD3L},{0x08L,0x3DL,0x95L,0x08L,0x79L,0x79L,0x08L,0x95L,0x3DL,0x08L},{0x95L,0xD3L,0x3DL,0x79L,0xD3L,0x79L,0x3DL,0xD3L,0x95L,0x95L},{0x08L,0xAAL,(-5L),0xD3L,0xD3L,(-5L),0xAAL,0x08L,(-5L),0x08L}};
static const union U3 g_236 = {{0xC535739DL,0x325AC4A7L,0UL,-3L,0x7E6FL}};/* VOLATILE GLOBAL g_236 */
static int64_t *g_270 = &g_110;
static uint32_t g_322 = 0x1E2D72D9L;
static uint64_t * const g_342 = &g_196;
static uint64_t * const *g_341 = &g_342;
static int32_t g_351 = (-5L);
static union U4 g_359 = {{0x705E52FBL,18446744073709551615UL,6UL,0L,-3L}};/* VOLATILE GLOBAL g_359 */
static int64_t g_370 = 3L;
static int8_t g_377[10] = {6L,6L,6L,6L,6L,6L,6L,6L,6L,6L};
static uint32_t g_378 = 0UL;
static uint8_t g_396 = 1UL;
static const union U3 g_409 = {{0x57DA44CEL,0x5BD11BAFL,0xD391L,0L,0x3AFDL}};/* VOLATILE GLOBAL g_409 */
static union U4 g_425 = {{0L,0x2B7D9B0CL,8UL,-2L,0xAA45L}};/* VOLATILE GLOBAL g_425 */
static int32_t g_426 = 0xEBE81074L;
static int64_t g_440 = 0xED370A6AB0EA905FLL;
static int32_t **g_517 = (void*)0;
static uint64_t *g_527 = &g_196;
static int16_t g_535 = 1L;
static uint64_t g_564 = 0xEBCEED2D178D8AB6LL;
static volatile union U4 * const g_584 = (void*)0;
static uint8_t g_613 = 0xB0L;
static union U4 g_619 = {{1L,9UL,5UL,0x8F0B1B88L,0xBCD6L}};/* VOLATILE GLOBAL g_619 */
static union U4 *g_620 = (void*)0;
static uint64_t **g_641 = &g_527;
static uint64_t ***g_640[1] = {&g_641};
static int16_t *g_654 = &g_535;
static int16_t **g_653[8][8] = {{(void*)0,(void*)0,&g_654,(void*)0,&g_654,&g_654,(void*)0,&g_654},{&g_654,&g_654,&g_654,&g_654,&g_654,&g_654,&g_654,(void*)0},{&g_654,&g_654,(void*)0,&g_654,(void*)0,&g_654,&g_654,(void*)0},{&g_654,&g_654,&g_654,&g_654,&g_654,&g_654,&g_654,&g_654},{(void*)0,&g_654,&g_654,(void*)0,&g_654,(void*)0,(void*)0,&g_654},{&g_654,&g_654,&g_654,&g_654,(void*)0,&g_654,&g_654,&g_654},{&g_654,&g_654,&g_654,&g_654,&g_654,(void*)0,&g_654,&g_654},{&g_654,&g_654,&g_654,&g_654,&g_654,&g_654,&g_654,(void*)0}};
static int16_t ** volatile *g_652 = &g_653[3][0];
static uint32_t g_670 = 4294967291UL;
static union U3 g_707 = {{0x53B83D33L,6UL,0x2A62L,3L,0x616DL}};/* VOLATILE GLOBAL g_707 */
static union U3 g_709 = {{3L,0x1C41316BL,0xC64AL,0x9E6D4C10L,-1L}};/* VOLATILE GLOBAL g_709 */
static union U4 g_738 = {{1L,8UL,65535UL,0L,-10L}};/* VOLATILE GLOBAL g_738 */
static uint8_t g_781[9] = {0xA7L,0xA7L,0xA7L,0xA7L,0xA7L,0xA7L,0xA7L,0xA7L,0xA7L};
static struct S1 g_845[7] = {{-7L,0x6F77B25E418DD2F8LL,0xF33C68DDL,1L,-7},{-7L,0x6F77B25E418DD2F8LL,0xF33C68DDL,1L,-7},{-7L,0x6F77B25E418DD2F8LL,0xF33C68DDL,1L,-7},{-7L,0x6F77B25E418DD2F8LL,0xF33C68DDL,1L,-7},{-7L,0x6F77B25E418DD2F8LL,0xF33C68DDL,1L,-7},{-7L,0x6F77B25E418DD2F8LL,0xF33C68DDL,1L,-7},{-7L,0x6F77B25E418DD2F8LL,0xF33C68DDL,1L,-7}};
static struct S1 *g_844[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static const uint64_t *g_955 = (void*)0;
static const uint64_t **g_954 = &g_955;
static uint16_t g_957 = 65534UL;
static uint32_t g_993 = 4294967291UL;
static int8_t g_1000 = 0x9BL;
static uint8_t g_1001 = 0xDEL;
static struct S1 g_1027 = {0x0EL,4UL,0x7B86BABAL,1L,10};/* VOLATILE GLOBAL g_1027 */
static volatile uint16_t g_1077[2][1] = {{65532UL},{65532UL}};
static volatile uint16_t *g_1076 = &g_1077[1][0];
static volatile uint16_t * volatile *g_1075[1][7][9] = {{{&g_1076,&g_1076,&g_1076,(void*)0,&g_1076,&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076,&g_1076,&g_1076,&g_1076,&g_1076,(void*)0},{&g_1076,&g_1076,(void*)0,&g_1076,&g_1076,&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076,&g_1076,(void*)0,&g_1076,(void*)0,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076,&g_1076,(void*)0,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,(void*)0,&g_1076,&g_1076,&g_1076,(void*)0,(void*)0,&g_1076},{&g_1076,&g_1076,(void*)0,&g_1076,&g_1076,&g_1076,&g_1076,&g_1076,&g_1076}}};
static union U4 g_1082[9] = {{{-8L,0x6037B1F0L,0xE429L,6L,0x4F6FL}},{{0x80D6FBBCL,0xE713923DL,65535UL,0xCDAB1390L,-1L}},{{-8L,0x6037B1F0L,0xE429L,6L,0x4F6FL}},{{0x80D6FBBCL,0xE713923DL,65535UL,0xCDAB1390L,-1L}},{{-8L,0x6037B1F0L,0xE429L,6L,0x4F6FL}},{{0x80D6FBBCL,0xE713923DL,65535UL,0xCDAB1390L,-1L}},{{-8L,0x6037B1F0L,0xE429L,6L,0x4F6FL}},{{0x80D6FBBCL,0xE713923DL,65535UL,0xCDAB1390L,-1L}},{{-8L,0x6037B1F0L,0xE429L,6L,0x4F6FL}}};
static struct S1 g_1167 = {0L,18446744073709551606UL,0xDCB0E219L,0x66171F6EL,-9};/* VOLATILE GLOBAL g_1167 */
static const struct S1 g_1171 = {8L,0x2F8E4BEF7CE33778LL,0L,1L,3};/* VOLATILE GLOBAL g_1171 */
static const struct S1 *g_1170 = &g_1171;
static const struct S1 * const *g_1169 = &g_1170;
static union U3 **g_1174 = &g_176;
static volatile int64_t g_1240[8] = {0x6E4F267480EBD29FLL,0x6E4F267480EBD29FLL,0x6E4F267480EBD29FLL,0x6E4F267480EBD29FLL,0x6E4F267480EBD29FLL,0x6E4F267480EBD29FLL,0x6E4F267480EBD29FLL,0x6E4F267480EBD29FLL};
static volatile int64_t *g_1239 = &g_1240[6];
static volatile int64_t **g_1238 = &g_1239;
static volatile int64_t ** const *g_1237 = &g_1238;
static union U4 g_1266 = {{0x454685FCL,18446744073709551606UL,65535UL,1L,-10L}};/* VOLATILE GLOBAL g_1266 */
static union U4 g_1268[1][3] = {{{{0xEF04B127L,0x6CDD95CFL,0xC6FDL,-7L,4L}},{{0xEF04B127L,0x6CDD95CFL,0xC6FDL,-7L,4L}},{{0xEF04B127L,0x6CDD95CFL,0xC6FDL,-7L,4L}}}};
static int8_t *g_1296 = (void*)0;
static uint16_t g_1349 = 3UL;
static int32_t * volatile g_1376[2][7] = {{&g_1027.f2,&g_1027.f2,&g_1027.f2,&g_1027.f2,&g_1027.f2,&g_1027.f2,&g_1027.f2},{&g_426,&g_426,&g_426,&g_426,&g_426,&g_426,&g_426}};
static const int32_t ** volatile g_1378 = &g_77[2][1];/* VOLATILE GLOBAL g_1378 */
static struct S0 * volatile g_1379 = &g_619.f0;/* VOLATILE GLOBAL g_1379 */
static volatile struct S0 g_1382 = {0L,0UL,0x91D6L,-3L,0L};/* VOLATILE GLOBAL g_1382 */
static int32_t * volatile g_1407 = &g_845[2].f2;/* VOLATILE GLOBAL g_1407 */
static struct S0 g_1417 = {0xDD5399DFL,18446744073709551615UL,65534UL,0xB18CF5FAL,0x1AC1L};/* VOLATILE GLOBAL g_1417 */
static struct S0 g_1418 = {0x77AA2154L,0xE808B0FFL,4UL,-9L,0x9175L};/* VOLATILE GLOBAL g_1418 */
static int32_t *g_1427 = (void*)0;
static int32_t ** volatile g_1426[6] = {&g_1427,&g_1427,&g_1427,&g_1427,&g_1427,&g_1427};
static int32_t ** volatile g_1428[9] = {&g_1427,&g_1427,&g_1427,&g_1427,&g_1427,&g_1427,&g_1427,&g_1427,&g_1427};
static int32_t ** volatile g_1430 = &g_1427;/* VOLATILE GLOBAL g_1430 */
static struct S0 g_1463 = {0xB5820ADDL,8UL,0UL,-6L,8L};/* VOLATILE GLOBAL g_1463 */
static const volatile union U2 g_1468 = {0x03494FE6L};/* VOLATILE GLOBAL g_1468 */
static union U5 g_1494[2][10] = {{{1UL},{0x1548B8ACL},{1UL},{18446744073709551606UL},{0x1548B8ACL},{0x585B4C4BL},{0x585B4C4BL},{0x1548B8ACL},{18446744073709551606UL},{1UL}},{{18446744073709551614UL},{18446744073709551614UL},{0UL},{0x1548B8ACL},{0x6090F03FL},{0UL},{0x6090F03FL},{0x1548B8ACL},{0UL},{18446744073709551614UL}}};
static volatile union U4 g_1504[3][10] = {{{{1L,18446744073709551615UL,65534UL,0L,-1L}},{{0xD01AA585L,0UL,0x2215L,-1L,0x353EL}},{{0xD01AA585L,0UL,0x2215L,-1L,0x353EL}},{{1L,18446744073709551615UL,65534UL,0L,-1L}},{{5L,1UL,0UL,0L,8L}},{{0x24FA8439L,0xE37BB8D4L,0x18A1L,0x1E94574FL,0L}},{{5L,1UL,0UL,0L,8L}},{{1L,18446744073709551615UL,65534UL,0L,-1L}},{{0xD01AA585L,0UL,0x2215L,-1L,0x353EL}},{{0xD01AA585L,0UL,0x2215L,-1L,0x353EL}}},{{{5L,1UL,0UL,0L,8L}},{{0xD01AA585L,0UL,0x2215L,-1L,0x353EL}},{{0xE2144303L,1UL,0x8FDAL,-7L,1L}},{{0xE4B063E7L,0x40E59D95L,1UL,1L,-6L}},{{0xE4B063E7L,0x40E59D95L,1UL,1L,-6L}},{{0xE2144303L,1UL,0x8FDAL,-7L,1L}},{{0xD01AA585L,0UL,0x2215L,-1L,0x353EL}},{{5L,1UL,0UL,0L,8L}},{{0xD01AA585L,0UL,0x2215L,-1L,0x353EL}},{{0xE2144303L,1UL,0x8FDAL,-7L,1L}}},{{{0x24FA8439L,0xE37BB8D4L,0x18A1L,0x1E94574FL,0L}},{{1L,18446744073709551615UL,65534UL,0L,-1L}},{{0xE4B063E7L,0x40E59D95L,1UL,1L,-6L}},{{1L,18446744073709551615UL,65534UL,0L,-1L}},{{0x24FA8439L,0xE37BB8D4L,0x18A1L,0x1E94574FL,0L}},{{0xE2144303L,1UL,0x8FDAL,-7L,1L}},{{0xE2144303L,1UL,0x8FDAL,-7L,1L}},{{0x24FA8439L,0xE37BB8D4L,0x18A1L,0x1E94574FL,0L}},{{1L,18446744073709551615UL,65534UL,0L,-1L}},{{0xE4B063E7L,0x40E59D95L,1UL,1L,-6L}}}};
static volatile union U5 g_1505 = {0xB57F6C2BL};/* VOLATILE GLOBAL g_1505 */
static const volatile struct S0 g_1517 = {-1L,0UL,65527UL,0x13604B67L,1L};/* VOLATILE GLOBAL g_1517 */
static struct S1 g_1532[8][8] = {{{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10},{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10},{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10}},{{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{0x3CL,2UL,1L,0x0B715A50L,4},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{0x3CL,2UL,1L,0x0B715A50L,4},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3}},{{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10},{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10},{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3}},{{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10},{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10},{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10}},{{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{0x3CL,2UL,1L,0x0B715A50L,4},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{0x3CL,2UL,1L,0x0B715A50L,4},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3}},{{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10},{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10},{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3}},{{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10},{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10},{6L,0UL,-4L,0x22B26B44L,10},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{6L,0UL,-4L,0x22B26B44L,10}},{{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{0x3CL,2UL,1L,0x0B715A50L,4},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{0x3CL,2UL,1L,0x0B715A50L,4},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3},{-2L,0x9805870A0ED38090LL,0x97D9F987L,2L,3}}};
static union U4 g_1543 = {{-1L,0x1DE77CD0L,0x149CL,0xC6370F2CL,5L}};/* VOLATILE GLOBAL g_1543 */
static union U4 g_1562 = {{2L,0x35A1FA65L,6UL,-8L,0x9D2CL}};/* VOLATILE GLOBAL g_1562 */
static int8_t g_1564 = 0x38L;
static union U5 *g_1573 = &g_1494[0][1];
static union U5 ** volatile g_1572[9][10] = {{(void*)0,(void*)0,(void*)0,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573},{&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573},{&g_1573,(void*)0,&g_1573,(void*)0,&g_1573,(void*)0,&g_1573,&g_1573,&g_1573,&g_1573},{&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,(void*)0,&g_1573,&g_1573,&g_1573},{&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573},{&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,(void*)0,&g_1573},{&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573},{&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573},{&g_1573,(void*)0,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573,&g_1573}};
static int32_t ** volatile g_1577[6] = {&g_1427,&g_1427,&g_1427,&g_1427,&g_1427,&g_1427};
static union U2 g_1584[3][4][3] = {{{{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}},{{0xD315F029L},{0x52D592CDL},{0xD315F029L}},{{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}},{{0xD315F029L},{0x52D592CDL},{0xD315F029L}}},{{{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}},{{0xD315F029L},{0x52D592CDL},{0xD315F029L}},{{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}},{{0xD315F029L},{0x52D592CDL},{0xD315F029L}}},{{{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}},{{0xD315F029L},{0x52D592CDL},{0xD315F029L}},{{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}},{{0xD315F029L},{0x52D592CDL},{0xD315F029L}}}};
static union U3 g_1587[5] = {{{0xB4601F91L,0xA20496D9L,1UL,3L,0L}},{{0xB4601F91L,0xA20496D9L,1UL,3L,0L}},{{0xB4601F91L,0xA20496D9L,1UL,3L,0L}},{{0xB4601F91L,0xA20496D9L,1UL,3L,0L}},{{0xB4601F91L,0xA20496D9L,1UL,3L,0L}}};
static volatile union U4 g_1588 = {{0xCD52EC83L,18446744073709551615UL,0x122DL,0xA4DBC35BL,-3L}};/* VOLATILE GLOBAL g_1588 */
static union U5 g_1599[3][3] = {{{18446744073709551613UL},{18446744073709551613UL},{18446744073709551613UL}},{{18446744073709551613UL},{18446744073709551613UL},{18446744073709551613UL}},{{18446744073709551613UL},{18446744073709551613UL},{18446744073709551613UL}}};
static union U4 g_1604[2] = {{{0xD4C726FAL,8UL,1UL,0x480E22CAL,0x0CEDL}},{{0xD4C726FAL,8UL,1UL,0x480E22CAL,0x0CEDL}}};
static volatile union U4 g_1610 = {{9L,0x15A4269FL,65528UL,-1L,1L}};/* VOLATILE GLOBAL g_1610 */
static struct S1 g_1708 = {-5L,0UL,0L,1L,11};/* VOLATILE GLOBAL g_1708 */
static uint64_t **g_1710 = &g_527;
static int32_t *g_1724 = &g_1417.f0;
static int32_t **g_1723 = &g_1724;
static int32_t * volatile g_1743[10][2] = {{&g_1167.f2,&g_1532[2][4].f2},{&g_1167.f2,&g_1167.f2},{&g_426,&g_426},{&g_426,&g_1167.f2},{&g_1167.f2,&g_1532[2][4].f2},{&g_1167.f2,&g_1532[2][4].f2},{&g_1167.f2,&g_1167.f2},{&g_426,&g_426},{&g_426,&g_1167.f2},{&g_1167.f2,&g_1532[2][4].f2}};
static volatile uint64_t g_1790 = 18446744073709551610UL;/* VOLATILE GLOBAL g_1790 */
static volatile uint64_t *g_1789 = &g_1790;
static volatile uint64_t **g_1788[8][6] = {{&g_1789,&g_1789,&g_1789,&g_1789,&g_1789,&g_1789},{&g_1789,&g_1789,&g_1789,&g_1789,&g_1789,&g_1789},{&g_1789,&g_1789,&g_1789,&g_1789,&g_1789,&g_1789},{&g_1789,&g_1789,&g_1789,&g_1789,&g_1789,&g_1789},{&g_1789,&g_1789,&g_1789,&g_1789,&g_1789,&g_1789},{&g_1789,&g_1789,&g_1789,&g_1789,&g_1789,&g_1789},{&g_1789,&g_1789,&g_1789,&g_1789,&g_1789,&g_1789},{&g_1789,&g_1789,&g_1789,&g_1789,&g_1789,&g_1789}};
static volatile uint64_t ***g_1787[2][9][4] = {{{&g_1788[4][1],(void*)0,(void*)0,(void*)0},{&g_1788[2][5],(void*)0,(void*)0,&g_1788[2][2]},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1788[0][1],&g_1788[2][5],&g_1788[3][0]},{&g_1788[2][5],(void*)0,(void*)0,&g_1788[2][5]},{&g_1788[2][5],(void*)0,&g_1788[2][5],&g_1788[3][2]},{&g_1788[2][2],(void*)0,&g_1788[3][2],&g_1788[2][5]},{(void*)0,(void*)0,&g_1788[2][4],(void*)0},{(void*)0,&g_1788[6][4],&g_1788[2][4],&g_1788[3][0]}},{{(void*)0,&g_1788[2][5],&g_1788[3][2],&g_1788[2][4]},{&g_1788[2][2],&g_1788[0][1],&g_1788[2][5],(void*)0},{&g_1788[2][5],(void*)0,(void*)0,&g_1788[2][5]},{&g_1788[2][5],(void*)0,&g_1788[2][5],&g_1788[3][2]},{(void*)0,&g_1788[6][1],(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1788[2][5]},{&g_1788[2][5],&g_1788[6][4],(void*)0,(void*)0},{&g_1788[4][1],(void*)0,&g_1788[3][2],(void*)0},{(void*)0,(void*)0,&g_1788[2][5],(void*)0}}};
static volatile uint64_t **** volatile g_1786[4] = {&g_1787[0][5][0],&g_1787[0][5][0],&g_1787[0][5][0],&g_1787[0][5][0]};
static volatile uint64_t **** volatile * volatile g_1785 = &g_1786[0];/* VOLATILE GLOBAL g_1785 */
static int8_t **g_1803 = &g_1296;
static int8_t *** const g_1802[7] = {&g_1803,&g_1803,&g_1803,&g_1803,&g_1803,&g_1803,&g_1803};
static int8_t ***g_1805 = &g_1803;
static int8_t **** const  volatile g_1804 = &g_1805;/* VOLATILE GLOBAL g_1804 */
static int32_t ** const  volatile g_1815 = &g_1427;/* VOLATILE GLOBAL g_1815 */
static union U5 **g_1861 = (void*)0;
static int32_t * volatile g_1868 = (void*)0;/* VOLATILE GLOBAL g_1868 */
static int32_t * volatile g_1869[7] = {&g_845[2].f2,&g_845[2].f2,&g_845[2].f2,&g_845[2].f2,&g_845[2].f2,&g_845[2].f2,&g_845[2].f2};
static const volatile union U4 g_1905[6][4] = {{{{0xA7772CE2L,0x1FD949E0L,0x13DAL,-8L,0xA4D5L}},{{4L,0UL,0x8543L,1L,0x19C6L}},{{-1L,0x8E357579L,0x54DAL,0xA872FB1DL,0x222BL}},{{-1L,0x8E357579L,0x54DAL,0xA872FB1DL,0x222BL}}},{{{0x57CDB4BAL,0UL,0x955AL,1L,0xDCE8L}},{{0x57CDB4BAL,0UL,0x955AL,1L,0xDCE8L}},{{0x90520717L,0x0C29BA2AL,0UL,0xDE88F3D9L,0xCAC6L}},{{0x1C1E504CL,0xD9351AB2L,5UL,0x2C153776L,0xA455L}}},{{{0x57CDB4BAL,0UL,0x955AL,1L,0xDCE8L}},{{-1L,18446744073709551612UL,0xFE67L,-8L,0x4B2DL}},{{-1L,0x8E357579L,0x54DAL,0xA872FB1DL,0x222BL}},{{0x57CDB4BAL,0UL,0x955AL,1L,0xDCE8L}}},{{{0xA7772CE2L,0x1FD949E0L,0x13DAL,-8L,0xA4D5L}},{{0x1C1E504CL,0xD9351AB2L,5UL,0x2C153776L,0xA455L}},{{0xA7772CE2L,0x1FD949E0L,0x13DAL,-8L,0xA4D5L}},{{-1L,0x8E357579L,0x54DAL,0xA872FB1DL,0x222BL}}},{{{4L,0UL,0x8543L,1L,0x19C6L}},{{0x1C1E504CL,0xD9351AB2L,5UL,0x2C153776L,0xA455L}},{{0x90520717L,0x0C29BA2AL,0UL,0xDE88F3D9L,0xCAC6L}},{{0x57CDB4BAL,0UL,0x955AL,1L,0xDCE8L}}},{{{0x1C1E504CL,0xD9351AB2L,5UL,0x2C153776L,0xA455L}},{{-1L,18446744073709551612UL,0xFE67L,-8L,0x4B2DL}},{{-1L,18446744073709551612UL,0xFE67L,-8L,0x4B2DL}},{{0x1C1E504CL,0xD9351AB2L,5UL,0x2C153776L,0xA455L}}}};
static int64_t **g_1932[4][1][1] = {{{(void*)0}},{{(void*)0}},{{(void*)0}},{{(void*)0}}};
static int64_t ***g_1931 = &g_1932[1][0][0];
static int64_t **** volatile g_1930 = &g_1931;/* VOLATILE GLOBAL g_1930 */
static int16_t ****g_1948 = (void*)0;
static union U2 g_2043 = {0x9E91615BL};/* VOLATILE GLOBAL g_2043 */
static struct S0 g_2071 = {0xA665FC76L,3UL,0x0B88L,0xF4D127FDL,-7L};/* VOLATILE GLOBAL g_2071 */
static struct S0 * volatile g_2072 = (void*)0;/* VOLATILE GLOBAL g_2072 */
static struct S0 g_2076 = {3L,0x26AD7011L,0x371AL,0x8EE387D0L,1L};/* VOLATILE GLOBAL g_2076 */
static union U5 g_2094 = {0UL};/* VOLATILE GLOBAL g_2094 */
static uint64_t ** const *g_2098 = &g_1710;
static uint64_t ** const **g_2097 = &g_2098;
static int32_t * volatile g_2149 = &g_845[2].f2;/* VOLATILE GLOBAL g_2149 */
static struct S0 g_2156 = {-1L,0xDA2E6C48L,65526UL,-9L,-1L};/* VOLATILE GLOBAL g_2156 */
static int32_t ** volatile g_2180[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static volatile struct S0 g_2186 = {0xC615B450L,0x6D8938F6L,0x55AAL,0L,9L};/* VOLATILE GLOBAL g_2186 */
static volatile union U4 g_2226 = {{-1L,1UL,0x3F6FL,8L,0x39BFL}};/* VOLATILE GLOBAL g_2226 */
static uint16_t g_2242 = 0x3A53L;
static volatile union U2 g_2248 = {18446744073709551614UL};/* VOLATILE GLOBAL g_2248 */
static int32_t g_2335 = (-1L);
static struct S1 * const *g_2359 = &g_844[2];
static struct S1 * const **g_2358[5][3] = {{&g_2359,&g_2359,&g_2359},{&g_2359,&g_2359,&g_2359},{&g_2359,&g_2359,&g_2359},{&g_2359,&g_2359,&g_2359},{&g_2359,&g_2359,&g_2359}};
static struct S1 * const ***g_2357 = &g_2358[1][0];
static struct S1 * const ****g_2356 = &g_2357;
static struct S0 g_2377[9] = {{5L,18446744073709551615UL,8UL,7L,0x0262L},{5L,18446744073709551615UL,8UL,7L,0x0262L},{5L,18446744073709551615UL,8UL,7L,0x0262L},{5L,18446744073709551615UL,8UL,7L,0x0262L},{5L,18446744073709551615UL,8UL,7L,0x0262L},{5L,18446744073709551615UL,8UL,7L,0x0262L},{5L,18446744073709551615UL,8UL,7L,0x0262L},{5L,18446744073709551615UL,8UL,7L,0x0262L},{5L,18446744073709551615UL,8UL,7L,0x0262L}};


/* --- FORWARD DECLARATIONS --- */
static struct S0  func_1(void);
static int32_t  func_2(int8_t  p_3);
static int8_t  func_4(int32_t  p_5, uint64_t  p_6, uint16_t  p_7, int8_t  p_8, uint8_t  p_9);
static int64_t  func_13(const uint32_t  p_14, int64_t  p_15, uint64_t  p_16, int32_t  p_17);
static int16_t  func_19(int32_t  p_20, uint16_t  p_21);
static int32_t * const  func_28(uint16_t  p_29, int16_t  p_30, uint32_t  p_31);
static uint32_t  func_39(int32_t  p_40);
static uint16_t  func_41(const int32_t * p_42);
static int32_t * func_43(uint8_t  p_44, const int32_t * p_45);
static uint8_t  func_50(uint64_t  p_51, int32_t * const  p_52, uint16_t  p_53);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2377
 * writes:
 */
static struct S0  func_1(void)
{ /* block id: 0 */
    int32_t l_18 = 0x5C22C920L;
    int32_t l_1330 = (-1L);
    int32_t l_1331 = 1L;
    const int8_t l_1332 = 0x47L;
    uint32_t *l_1333 = &g_322;
    uint16_t l_1354[1];
    union U3 *l_2173 = &g_177[4];
    int64_t l_2187 = 0x8B216B3F16F5FA8ALL;
    int32_t *l_2196 = &g_845[2].f2;
    int32_t *l_2197[8][2] = {{&g_1027.f2,&g_845[2].f2},{&g_845[2].f2,&g_1027.f2},{&g_1027.f2,&g_1708.f2},{&g_1027.f2,&g_1027.f2},{&g_845[2].f2,&g_845[2].f2},{&g_1027.f2,&g_1027.f2},{&g_1708.f2,&g_1027.f2},{&g_1027.f2,&g_845[2].f2}};
    uint32_t l_2198 = 0xBF1D1F10L;
    struct S1 **l_2206 = &g_844[4];
    struct S1 ***l_2205 = &l_2206;
    struct S1 ****l_2204 = &l_2205;
    union U4 *l_2215 = &g_1604[0];
    uint64_t * const *l_2218 = &g_342;
    uint32_t l_2231[5][10][5] = {{{0xDB5734B9L,0x12083997L,0xA959BF8EL,0x61D0089EL,0xA959BF8EL},{4UL,4UL,0UL,0UL,0x1E841423L},{0xA959BF8EL,18446744073709551606UL,1UL,0x1022EDCEL,6UL},{18446744073709551615UL,18446744073709551608UL,8UL,0x26AAC1D4L,0UL},{0xD9E5DD1EL,18446744073709551606UL,18446744073709551606UL,0xD9E5DD1EL,1UL},{0UL,4UL,0x51B4A1F4L,0x1E841423L,0x1E841423L},{0x12083997L,1UL,0x1022EDCEL,0x61D0089EL,0xFF751FD7L},{0UL,0x51B4A1F4L,0UL,0UL,0x51B4A1F4L},{0x33F090F1L,0xD9E5DD1EL,0x0F56854DL,6UL,18446744073709551606UL},{0xCA13FBD9L,4UL,18446744073709551615UL,18446744073709551608UL,8UL}},{{0xD9E5DD1EL,18446744073709551612UL,18446744073709551607UL,1UL,1UL},{0xCA13FBD9L,0x26AAC1D4L,0xCA13FBD9L,0UL,0UL},{0x33F090F1L,0x0F56854DL,0x61D0089EL,0xD9E5DD1EL,0xA959BF8EL},{0UL,18446744073709551608UL,0x1E841423L,18446744073709551615UL,0UL},{0x12083997L,0xA959BF8EL,0x61D0089EL,0xA959BF8EL,0x12083997L},{0x51B4A1F4L,0x8559317AL,0xCA13FBD9L,4UL,18446744073709551615UL},{6UL,18446744073709551606UL,18446744073709551607UL,0xDB5734B9L,0x1022EDCEL},{0x047B2C8FL,0xCA13FBD9L,18446744073709551615UL,0x8559317AL,18446744073709551615UL},{0xDB5734B9L,0xDB5734B9L,0x0F56854DL,18446744073709551607UL,0x12083997L},{18446744073709551615UL,8UL,0UL,0x1E841423L,0UL}},{{0x61D0089EL,1UL,0x1022EDCEL,18446744073709551612UL,0xA959BF8EL},{0x20C0A405L,8UL,8UL,0x20C0A405L,0UL},{18446744073709551606UL,0xDB5734B9L,0xFF751FD7L,0x12083997L,1UL},{0UL,0xCA13FBD9L,0x5687EE7AL,0x047B2C8FL,8UL},{1UL,18446744073709551606UL,0x12083997L,0x12083997L,18446744073709551606UL},{0UL,0x8559317AL,0x26AAC1D4L,0x20C0A405L,0x51B4A1F4L},{1UL,0xA959BF8EL,0xDB5734B9L,18446744073709551612UL,0xFF751FD7L},{0x8559317AL,18446744073709551608UL,0UL,0x1E841423L,0x1E841423L},{1UL,0x0F56854DL,1UL,18446744073709551607UL,0UL},{0UL,0x26AAC1D4L,0x047B2C8FL,0x8559317AL,4UL}},{{1UL,18446744073709551612UL,1UL,0xDB5734B9L,0x33F090F1L},{0UL,4UL,0x047B2C8FL,4UL,0UL},{18446744073709551606UL,0xD9E5DD1EL,1UL,0xA959BF8EL,0xDB5734B9L},{0x20C0A405L,0x51B4A1F4L,0UL,18446744073709551615UL,0x5687EE7AL},{0x61D0089EL,1UL,0xDB5734B9L,0xD9E5DD1EL,0xDB5734B9L},{18446744073709551615UL,18446744073709551615UL,0x26AAC1D4L,0UL,0UL},{0xDB5734B9L,0xFF751FD7L,0x12083997L,1UL,0x33F090F1L},{0x047B2C8FL,0UL,0x5687EE7AL,18446744073709551608UL,4UL},{6UL,0xFF751FD7L,0xFF751FD7L,6UL,0UL},{0x51B4A1F4L,18446744073709551615UL,8UL,0UL,0x1E841423L}},{{0x12083997L,1UL,0x1022EDCEL,0x61D0089EL,0xFF751FD7L},{0UL,0x51B4A1F4L,0UL,0UL,0x51B4A1F4L},{0x33F090F1L,0xD9E5DD1EL,0x0F56854DL,6UL,18446744073709551606UL},{0xCA13FBD9L,4UL,18446744073709551615UL,18446744073709551608UL,8UL},{6UL,1UL,18446744073709551606UL,0x12083997L,0x12083997L},{0UL,18446744073709551608UL,0UL,0x51B4A1F4L,0x26AAC1D4L},{18446744073709551607UL,18446744073709551612UL,0xD9E5DD1EL,6UL,0xDB5734B9L},{4UL,0UL,0UL,0x047B2C8FL,0UL},{1UL,0xDB5734B9L,0xD9E5DD1EL,0xDB5734B9L,1UL},{8UL,0x20C0A405L,0UL,18446744073709551615UL,0x047B2C8FL}}};
    int32_t l_2274 = (-2L);
    int32_t l_2336 = (-10L);
    int32_t ***l_2363 = &g_517;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_1354[i] = 0UL;
    return g_2377[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_1407 g_845.f2 g_342 g_196 g_1266.f0.f0 g_1268.f0.f0 g_1785 g_115 g_162 g_110 g_163 g_1802 g_1804 g_270 g_341 g_32 g_75 g_425.f0.f0 g_440 g_613 g_396 g_166 g_55 g_620 g_172 g_378 g_652 g_564 g_670 g_654 g_535 g_584 g_781 g_619.f0.f0 g_78 g_359.f0.f2 g_210 g_426 g_844 g_370 g_322 g_359.f0.f0 g_377 g_957 g_845.f1 g_738.f0.f2 g_993 g_1001 g_71 g_1027.f2 g_1075 g_1815 g_1266.f0.f1 g_1237 g_1238 g_1239 g_1240 g_1468 g_1427 g_1599 g_1905 g_1786 g_1430 g_1174 g_176 g_1930 g_1948 g_1587.f0.f2 g_425.f0.f2 g_1171.f1 g_1532.f2 g_641 g_1027.f1 g_1723 g_1724 g_1417.f0 g_12 g_1803 g_1296 g_1517 g_2043 g_2071 g_425.f0 g_1588.f0.f0 g_1599.f0 g_2097 g_1463.f2 g_1268 g_1587.f0.f4 g_619.f0.f2 g_1266.f0.f2 g_1417.f2 g_738.f0.f0 g_1000
 * writes: g_619.f0.f2 g_1027.f1 g_670 g_1167.f0 g_115 g_196 g_1805 g_110 g_32 g_440 g_426 g_55 g_620 g_564 g_640 g_75 g_535 g_172 g_378 g_652 g_377 g_351 g_707.f3 g_71 g_844 g_359.f0.f2 g_166 g_709.f3 g_781 g_396 g_177.f3 g_954 g_845.f2 g_993 g_1001 g_425.f0.f2 g_1427 g_1532.f2 g_613 g_1861 g_1543.f0.f4 g_1562.f0.f2 g_653 g_1266.f0.f2 g_1000 g_176 g_1417.f2 g_1931 g_738.f0.f0 g_1948 g_527 g_1708.f2 g_1610.f0 g_1463.f2 g_1504.f0 g_1417.f0 g_2076 g_2097
 */
static int32_t  func_2(int8_t  p_3)
{ /* block id: 688 */
    uint32_t *l_1765[1];
    uint32_t *l_1767 = &g_322;
    int32_t l_1782 = 0x74A153D6L;
    int8_t l_1866 = 1L;
    int32_t **l_1871[5] = {&g_1427,&g_1427,&g_1427,&g_1427,&g_1427};
    int32_t *l_1872 = &g_1532[2][4].f2;
    uint64_t * const **l_1903 = &g_341;
    uint64_t * const ***l_1902 = &l_1903;
    int32_t l_2101 = 9L;
    int i;
    for (i = 0; i < 1; i++)
        l_1765[i] = (void*)0;
lbl_2122:
    for (g_619.f0.f2 = 2; (g_619.f0.f2 > 38); ++g_619.f0.f2)
    { /* block id: 691 */
        int32_t l_1784 = 1L;
        uint64_t ****l_1792 = &g_640[0];
        uint64_t *****l_1791 = &l_1792;
        int32_t **l_1818 = (void*)0;
        uint8_t l_1851 = 255UL;
        int32_t l_1852[3];
        const uint32_t *l_1854 = &g_1494[0][1].f0;
        const uint32_t **l_1853 = &l_1854;
        int i;
        for (i = 0; i < 3; i++)
            l_1852[i] = (-1L);
        for (g_1027.f1 = 0; (g_1027.f1 <= 0); g_1027.f1 += 1)
        { /* block id: 694 */
            uint32_t **l_1766 = &l_1765[0];
            uint32_t *l_1776 = &g_670;
            int8_t *l_1781 = &g_1167.f0;
            int32_t l_1783 = 1L;
            int64_t **l_1801 = &g_270;
            union U5 **l_1841 = &g_1573;
            int32_t l_1855 = 0xB68A22BAL;
            int i;
            if ((p_3 , ((safe_mod_func_uint32_t_u_u(((safe_mod_func_int16_t_s_s((safe_rshift_func_int8_t_s_s((((*l_1766) = l_1765[0]) != (l_1767 = &g_322)), (((safe_sub_func_int16_t_s_s(((safe_mod_func_int32_t_s_s((*g_1407), (safe_lshift_func_uint32_t_u_s(4294967294UL, ((((((*l_1776) = (safe_add_func_int8_t_s_s(p_3, 0xD4L))) != ((safe_lshift_func_int8_t_s_s((safe_rshift_func_uint64_t_u_s((*g_342), 58)), (((*l_1781) = p_3) & g_1266.f0.f0))) >= p_3)) || l_1782) != l_1783) == l_1784))))) == 0x816DAAD18728CB08LL), l_1784)) >= l_1783) < 0L))), 0x5346L)) , l_1784), g_1268[0][0].f0.f0)) != p_3)))
            { /* block id: 699 */
                return l_1782;
            }
            else
            { /* block id: 701 */
                uint8_t *l_1793 = (void*)0;
                uint8_t *l_1794[7][2][3] = {{{&g_396,(void*)0,(void*)0},{(void*)0,&g_115,(void*)0}},{{&g_396,&g_396,(void*)0},{&g_396,&g_396,&g_781[7]}},{{&g_396,&g_396,&g_396},{&g_781[7],&g_115,(void*)0}},{{&g_396,(void*)0,&g_396},{&g_396,&g_781[7],(void*)0}},{{&g_396,&g_396,&g_396},{(void*)0,&g_781[7],&g_781[7]}},{{&g_396,(void*)0,(void*)0},{(void*)0,&g_115,(void*)0}},{{&g_396,&g_396,(void*)0},{&g_396,&g_396,&g_781[7]}}};
                int64_t **l_1800 = &g_270;
                int64_t ***l_1799[1][9][10] = {{{&l_1800,&l_1800,(void*)0,&l_1800,&l_1800,(void*)0,&l_1800,&l_1800,(void*)0,&l_1800},{&l_1800,&l_1800,&l_1800,&l_1800,&l_1800,(void*)0,&l_1800,&l_1800,(void*)0,&l_1800},{(void*)0,&l_1800,&l_1800,&l_1800,(void*)0,&l_1800,&l_1800,&l_1800,(void*)0,(void*)0},{(void*)0,(void*)0,&l_1800,&l_1800,&l_1800,&l_1800,&l_1800,(void*)0,(void*)0,&l_1800},{(void*)0,&l_1800,&l_1800,&l_1800,(void*)0,(void*)0,(void*)0,&l_1800,(void*)0,(void*)0},{&l_1800,&l_1800,(void*)0,&l_1800,&l_1800,(void*)0,&l_1800,&l_1800,(void*)0,&l_1800},{&l_1800,&l_1800,&l_1800,&l_1800,&l_1800,(void*)0,&l_1800,&l_1800,(void*)0,&l_1800},{(void*)0,&l_1800,&l_1800,&l_1800,(void*)0,&l_1800,&l_1800,&l_1800,(void*)0,(void*)0},{(void*)0,(void*)0,&l_1800,&l_1800,&l_1800,&l_1800,&l_1800,(void*)0,(void*)0,&l_1800}}};
                int32_t l_1806[1][5];
                uint32_t * const *l_1812 = (void*)0;
                struct S1 **l_1835[10] = {&g_844[2],&g_844[2],&g_844[2],&g_844[2],&g_844[2],&g_844[2],&g_844[2],&g_844[2],&g_844[2],&g_844[2]};
                int32_t l_1836 = 0x8AF443C0L;
                int i, j, k;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 5; j++)
                        l_1806[i][j] = (-5L);
                }
                if (((65527UL < (g_1785 == l_1791)) == ((g_115 ^= 255UL) <= ((((safe_div_func_int16_t_s_s((((((p_3 != l_1782) ^ ((safe_rshift_func_uint64_t_u_s((p_3 <= p_3), 34)) & ((*g_342) = ((l_1801 = &g_270) == (void*)0)))) ^ (*g_162)) != p_3) < 1L), l_1784)) == 0x0CB25A4A11E2E39ELL) , p_3) <= p_3))))
                { /* block id: 705 */
                    (*g_1804) = g_1802[6];
                }
                else
                { /* block id: 707 */
                    uint32_t l_1828 = 0xF35858F8L;
                    union U5 **l_1843 = &g_1573;
                    uint32_t **l_1847 = &l_1767;
                    union U5 ***l_1859 = (void*)0;
                    union U5 ***l_1860[7] = {&l_1841,&l_1841,&l_1841,&l_1841,&l_1841,&l_1841,&l_1841};
                    int32_t l_1862 = 0x2C704B96L;
                    uint16_t *l_1867[3];
                    int32_t *l_1870 = &l_1782;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_1867[i] = &g_1349;
                    if (l_1783)
                    { /* block id: 708 */
                        uint16_t l_1811 = 0x7B4AL;
                        int64_t **l_1813 = &g_270;
                        int32_t **l_1814 = (void*)0;
                        (*g_1815) = func_28((((**l_1801) = p_3) > ((**g_341)--)), (safe_sub_func_uint8_t_u_u(l_1811, (((void*)0 == l_1812) || ((void*)0 == l_1813)))), l_1783);
                        l_1836 &= ((p_3 & ((safe_sub_func_int64_t_s_s(0L, ((void*)0 == l_1818))) != (safe_mul_func_uint8_t_u_u((g_781[7] = (safe_mul_func_uint32_t_u_u(l_1782, (safe_mod_func_uint64_t_u_u((!l_1806[0][1]), (((safe_mul_func_int64_t_s_s((0x2FB392A05F870B38LL == (((l_1828 != (((safe_lshift_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u(((safe_add_func_int8_t_s_s((l_1835[2] != (void*)0), l_1806[0][2])) == p_3), p_3)), 28)) , 0xCCL) >= g_1266.f0.f1)) >= 7L) == p_3)), p_3)) >= (*g_270)) && g_425.f0.f0)))))), l_1783)))) && l_1783);
                    }
                    else
                    { /* block id: 714 */
                        union U5 ***l_1842 = &l_1841;
                        int32_t *l_1844 = &g_1532[2][4].f2;
                        int32_t *l_1850 = &g_845[2].f2;
                        l_1855 = ((safe_mul_func_uint32_t_u_u((((*l_1844) = ((safe_mul_func_int64_t_s_s(l_1782, (***g_1237))) || (((*l_1842) = l_1841) == l_1843))) <= (safe_rshift_func_uint16_t_u_u((l_1847 == (((((((*l_1850) = ((p_3 | (l_1783 ^= (l_1806[0][2] , ((safe_mul_func_uint64_t_u_u(((l_1828 ^ ((3L | 0L) && p_3)) , p_3), l_1782)) , 0xAC78F88BL)))) && l_1828)) >= p_3) == l_1851) <= l_1852[0]) || l_1783) , l_1853)), p_3))), p_3)) != 0x9C90L);
                        if (p_3)
                            continue;
                    }
                    (*l_1870) = (((safe_mul_func_uint8_t_u_u((~((l_1862 = ((g_613 |= p_3) <= (l_1843 != (g_1861 = (void*)0)))) > (((p_3 > 2UL) , (safe_sub_func_int8_t_s_s(((*l_1781) = (~(l_1855 = ((p_3 < l_1866) , ((g_1468 , (l_1836 , 18446744073709551612UL)) > (*g_162)))))), l_1783))) , g_993))), l_1782)) , l_1782) > l_1866);
                    return p_3;
                }
            }
            for (g_1543.f0.f4 = 0; g_1543.f0.f4 < 8; g_1543.f0.f4 += 1)
            {
                for (g_1562.f0.f2 = 0; g_1562.f0.f2 < 8; g_1562.f0.f2 += 1)
                {
                    g_653[g_1543.f0.f4][g_1562.f0.f2] = &g_654;
                }
            }
        }
    }
lbl_2028:
    (*g_1815) = &l_1782;
    l_1872 = (*g_1815);
    for (g_425.f0.f2 = 0; (g_425.f0.f2 > 12); ++g_425.f0.f2)
    { /* block id: 738 */
        uint32_t **l_1897 = (void*)0;
        int32_t l_1901 = 0x4320F055L;
        int32_t l_1921[10][9] = {{0x169C21A0L,0xF853F7FAL,0x8A658F01L,0x97ED17A9L,0xD79E8E30L,0xD79E8E30L,0x8A51EABEL,1L,(-1L)},{1L,0x27B79303L,0x963A5B3FL,0x9092451DL,0x9C2A36DEL,(-10L),0x9C9ACB52L,(-1L),7L},{0xB57A757EL,0x8A51EABEL,0L,0x8A658F01L,1L,0x97ED17A9L,1L,0x8A658F01L,0L},{0x27B79303L,0x27B79303L,0x09D67B39L,7L,0L,1L,(-9L),(-3L),1L},{0xD79E8E30L,(-1L),0x169C21A0L,(-1L),0x344F049CL,0xB57A757EL,0xB57A757EL,0x344F049CL,(-1L)},{0x09D67B39L,1L,0x09D67B39L,(-10L),(-1L),(-1L),(-1L),1L,0L},{0xF853F7FAL,0x169C21A0L,0L,0xB7156D6AL,0x8A51EABEL,4L,(-1L),4L,0x8A51EABEL},{(-10L),0x963A5B3FL,0x963A5B3FL,(-10L),1L,0x9C2A36DEL,(-3L),(-2L),(-1L)},{0x8A658F01L,0x66B12AB2L,1L,(-1L),0xB57A757EL,0xB7156D6AL,0x97ED17A9L,0x97ED17A9L,0xB7156D6AL},{1L,7L,(-10L),7L,1L,(-2L),0x09D67B39L,(-9L),0x963A5B3FL}};
        union U4 *l_1980 = &g_1604[0];
        int8_t *l_1999 = &g_1532[2][4].f0;
        int64_t l_2008 = 0xDBBE5F02DF8FEBA1LL;
        uint64_t * const **l_2016 = &g_341;
        uint8_t l_2025 = 6UL;
        uint32_t l_2038 = 0x88CBB4ECL;
        union U5 *l_2093 = &g_2094;
        int16_t *****l_2120 = &g_1948;
        int32_t *l_2123[9];
        int i, j;
        for (i = 0; i < 9; i++)
            l_2123[i] = &l_2101;
        for (g_1266.f0.f2 = 0; (g_1266.f0.f2 >= 58); ++g_1266.f0.f2)
        { /* block id: 741 */
            union U3 **l_1886 = &g_176;
            int32_t l_1892 = 0xC05E1494L;
            int32_t l_1893 = 0L;
            const uint32_t l_1894 = 4294967293UL;
            uint32_t *l_1895 = &g_993;
            uint32_t **l_1896[7][2][3] = {{{&l_1765[0],&l_1765[0],(void*)0},{&l_1765[0],&l_1765[0],&l_1767}},{{&l_1767,&l_1765[0],&l_1767},{&l_1767,&l_1765[0],&l_1765[0]}},{{(void*)0,&l_1765[0],&l_1765[0]},{&l_1765[0],(void*)0,&l_1767}},{{&l_1765[0],&l_1765[0],&l_1767},{&l_1765[0],&l_1767,(void*)0}},{{(void*)0,&l_1767,&l_1765[0]},{&l_1767,&l_1765[0],&l_1765[0]}},{{&l_1767,(void*)0,&l_1765[0]},{&l_1765[0],&l_1765[0],(void*)0}},{{&l_1765[0],&l_1765[0],&l_1767},{&l_1767,&l_1765[0],&l_1767}}};
            int32_t l_1898 = 7L;
            uint64_t *l_1969 = &g_564;
            uint64_t *l_1971 = &g_845[2].f1;
            int32_t l_2005[9] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
            int32_t l_2007 = 7L;
            int32_t *l_2070 = &l_2005[0];
            uint64_t l_2075[9] = {0xF2446AB837BEBB52LL,0xF2446AB837BEBB52LL,0xF2446AB837BEBB52LL,0xF2446AB837BEBB52LL,0xF2446AB837BEBB52LL,0xF2446AB837BEBB52LL,0xF2446AB837BEBB52LL,0xF2446AB837BEBB52LL,0xF2446AB837BEBB52LL};
            int i, j, k;
            if ((g_1599[0][1] , (p_3 || (+(safe_mul_func_int16_t_s_s((l_1898 |= (safe_add_func_uint32_t_u_u((safe_mod_func_int32_t_s_s((safe_lshift_func_int64_t_s_u((*g_162), 31)), p_3)), (l_1886 != (((+((((((((safe_sub_func_uint32_t_u_u((safe_div_func_int8_t_s_s((l_1892 = p_3), l_1893)), 0xA3B262F1L)) <= ((*l_1895) = ((l_1894 >= 4294967295UL) | (***g_1237)))) > (*g_270)) && l_1894) < 65528UL) , l_1896[3][1][2]) != l_1897) <= 0L)) <= 0x21CABC81L) , &g_176))))), 1L))))))
            { /* block id: 745 */
                uint64_t * const ****l_1904 = &l_1902;
                int8_t *l_1906 = &g_1000;
                int32_t l_1910 = (-1L);
                uint64_t *l_1917 = (void*)0;
                uint64_t *l_1918 = &g_564;
                uint32_t l_1924 = 0xF3DC7B7EL;
                uint8_t *l_1925 = &g_781[7];
                union U3 *l_1956 = (void*)0;
                int32_t *l_1963 = &g_1708.f2;
                (*g_1427) = ((safe_lshift_func_int64_t_s_s((l_1892 = 0xFA6BB968CC390B47LL), l_1901)) > (((*l_1906) = (((*l_1904) = l_1902) == (g_1905[3][3] , (*g_1785)))) , 0UL));
                if ((0x1570L & ((((*l_1925) = ((((safe_unary_minus_func_int8_t_s((safe_add_func_int8_t_s_s((p_3 = (l_1910 && p_3)), (((safe_lshift_func_int8_t_s_u(0x0DL, 3)) , (safe_add_func_uint32_t_u_u(((l_1901 = ((*l_1918) |= ((*****l_1904) = ((safe_lshift_func_int8_t_s_u(l_1893, 6)) && ((*g_1427) = (**g_1430)))))) ^ (safe_mul_func_uint64_t_u_u(18446744073709551615UL, (l_1921[1][4] && (safe_sub_func_uint8_t_u_u(0UL, l_1910)))))), 0x28F378ACL))) > l_1924))))) <= l_1910) & (*g_270)) <= 0x6E3033B39767F7E4LL)) & l_1910) >= l_1892)))
                { /* block id: 756 */
                    (*l_1886) = (*g_1174);
                }
                else
                { /* block id: 758 */
                    int64_t **l_1929 = &g_270;
                    int64_t ***l_1928 = &l_1929;
                    int32_t l_1958 = 0x3C0A7A41L;
                    int8_t l_1959 = 0x5DL;
                    uint64_t *l_1970 = &g_1027.f1;
                    for (g_1417.f2 = 0; (g_1417.f2 == 36); ++g_1417.f2)
                    { /* block id: 761 */
                        uint8_t l_1933 = 0x14L;
                        (*g_1930) = l_1928;
                        ++l_1933;
                        if (p_3)
                            break;
                    }
                    for (g_738.f0.f0 = 0; (g_738.f0.f0 > 12); ++g_738.f0.f0)
                    { /* block id: 768 */
                        int16_t *****l_1949 = &g_1948;
                        union U3 *l_1957 = &g_1587[3];
                        uint16_t *l_1960 = &g_619.f0.f2;
                        g_1532[2][4].f2 |= (safe_unary_minus_func_int64_t_s((safe_mod_func_int64_t_s_s((safe_add_func_uint32_t_u_u((safe_lshift_func_int8_t_s_s((p_3 ^ (safe_mul_func_uint8_t_u_u((((*l_1872) = p_3) == (!(((*l_1949) = g_1948) == (void*)0))), ((safe_div_func_uint16_t_u_u(((*l_1960) = (1UL > ((((safe_sub_func_uint32_t_u_u(((safe_div_func_int8_t_s_s(((((***l_1928) = ((18446744073709551608UL | (l_1956 != l_1957)) | ((l_1958 & (*g_654)) != 0UL))) | p_3) & 0xF14BL), l_1959)) , p_3), p_3)) | l_1959) == g_1587[3].f0.f2) | 18446744073709551614UL))), l_1958)) == g_425.f0.f2)))), p_3)), g_1171.f1)), 0x37642D391669BC10LL))));
                    }
                    for (g_110 = 23; (g_110 != 19); g_110--)
                    { /* block id: 777 */
                        const union U4 *l_1966 = &g_1266;
                        int32_t **l_1979 = &g_1724;
                        l_1963 = &l_1910;
                        if ((**g_1430))
                            break;
                        if (l_1958)
                            continue;
                        (*g_1427) = (((7UL & (p_3 == (l_1966 != ((safe_sub_func_int16_t_s_s((((*g_641) = l_1969) == (l_1971 = l_1970)), (!(p_3 || (safe_sub_func_uint64_t_u_u(((*l_1970)--), ((safe_mul_func_int8_t_s_s((0x44607E64E2AAE23FLL < ((&g_1724 == l_1979) > p_3)), p_3)) & p_3))))))) , l_1980)))) ^ g_166) >= p_3);
                    }
                }
                (*l_1963) = ((~255UL) != l_1921[1][4]);
            }
            else
            { /* block id: 788 */
                int8_t *l_1982 = &g_1167.f0;
                int32_t l_1998 = 1L;
                int32_t l_2001 = 0x1E5A697FL;
                int32_t l_2010[1][4][7] = {{{1L,0xFB8DD3BAL,(-1L),(-1L),(-1L),0xFB8DD3BAL,1L},{1L,0xFB8DD3BAL,(-1L),(-1L),(-1L),0xFB8DD3BAL,1L},{1L,0xFB8DD3BAL,(-1L),(-1L),(-1L),0xFB8DD3BAL,1L},{1L,0xFB8DD3BAL,(-1L),(-1L),(-1L),0xFB8DD3BAL,1L}}};
                uint32_t l_2012[9];
                int8_t l_2032 = (-1L);
                int i, j, k;
                for (i = 0; i < 9; i++)
                    l_2012[i] = 4294967295UL;
                if ((((*l_1982) = 0L) ^ (safe_rshift_func_uint8_t_u_u(l_1921[0][1], 0))))
                { /* block id: 790 */
                    int32_t l_1987 = (-9L);
                    uint16_t l_2000 = 9UL;
                    uint16_t l_2002 = 65533UL;
                    l_2001 |= ((safe_add_func_uint64_t_u_u(((l_1987 & p_3) , (((&p_3 == (l_1999 = (((**g_1723) , (safe_mul_func_int16_t_s_s((250UL > p_3), (safe_lshift_func_uint16_t_u_u(((safe_div_func_uint64_t_u_u((safe_mul_func_uint16_t_u_u((safe_mod_func_uint32_t_u_u(g_12, l_1901)), p_3)), l_1998)) >= 0x006780C1L), l_1921[1][4]))))) , (*g_1803)))) , l_1998) == 8UL)), l_2000)) >= 1L);
                    --l_2002;
                }
                else
                { /* block id: 794 */
                    int64_t l_2006 = 0x5D906A40D224E133LL;
                    int32_t l_2009 = 0xDE19AE08L;
                    int32_t l_2011[8] = {(-7L),0L,(-7L),(-7L),0L,(-7L),(-7L),0L};
                    int32_t *l_2015 = (void*)0;
                    int i;
                    l_2012[5]++;
                    l_2015 = &l_2005[3];
                    if ((((p_3 && 1L) || l_1921[1][4]) & ((void*)0 != l_2016)))
                    { /* block id: 797 */
                        volatile struct S0 *l_2017 = &g_1610.f0;
                        (*l_2017) = g_1517;
                    }
                    else
                    { /* block id: 799 */
                        uint16_t l_2018 = 2UL;
                        return l_2018;
                    }
                    for (g_1000 = 20; (g_1000 <= 24); g_1000++)
                    { /* block id: 804 */
                        const union U3 *l_2021[1][9];
                        const union U3 **l_2022 = (void*)0;
                        const union U3 **l_2023 = &l_2021[0][7];
                        int32_t l_2024[2];
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 9; j++)
                                l_2021[i][j] = (void*)0;
                        }
                        for (i = 0; i < 2; i++)
                            l_2024[i] = 0x3484611FL;
                        (*l_2015) = l_1921[2][6];
                        (*l_2023) = l_2021[0][2];
                        l_2025--;
                        if (g_1027.f1)
                            goto lbl_2028;
                    }
                }
                for (g_564 = 0; (g_564 < 13); g_564 = safe_add_func_int8_t_s_s(g_564, 1))
                { /* block id: 813 */
                    int64_t l_2031 = 0x063D9F1922BB7D67LL;
                    int32_t l_2033 = 0xF34855E1L;
                    int32_t l_2034 = 0x184FECAFL;
                    int32_t l_2035 = (-6L);
                    int32_t l_2036 = 0x450D050CL;
                    int32_t l_2037 = (-1L);
                    l_2038--;
                    if ((*g_1427))
                        continue;
                    if (l_2007)
                        continue;
                }
                l_2070 = (((*l_1982) = ((safe_div_func_int64_t_s_s(((g_2043 , (l_1894 , (4294967292UL > l_2010[0][3][0]))) || (safe_mul_func_int16_t_s_s((-2L), (!(l_2008 <= ((safe_div_func_uint8_t_u_u((g_1468 , (safe_unary_minus_func_uint16_t_u(((safe_sub_func_uint8_t_u_u(((safe_unary_minus_func_int32_t_s(((safe_mul_func_int16_t_s_s((safe_sub_func_int16_t_s_s(9L, (safe_mul_func_uint64_t_u_u((safe_lshift_func_int8_t_s_s((safe_add_func_int64_t_s_s((~(((safe_div_func_int32_t_s_s((safe_div_func_int16_t_s_s((safe_sub_func_uint64_t_u_u((((void*)0 == &l_2005[2]) , 0xCBEAA01A34013FF9LL), 4L)), p_3)), p_3)) <= 0xD329660BL) < l_2005[0])), 0x0185ED0EC25430D4LL)), p_3)), 18446744073709551607UL)))), p_3)) & p_3))) , l_2008), 0xE1L)) | p_3)))), 1L)) == p_3)))))), p_3)) != 0xAB05E289F072FADELL)) , (void*)0);
            }
            if (p_3)
            { /* block id: 821 */
                for (g_1463.f2 = 0; (g_1463.f2 <= 1); g_1463.f2 += 1)
                { /* block id: 824 */
                    g_1504[2][1].f0 = g_2071;
                }
                for (g_1000 = (-27); (g_1000 < (-8)); g_1000 = safe_add_func_uint16_t_u_u(g_1000, 1))
                { /* block id: 829 */
                    (*g_1427) = 4L;
                }
                l_2075[0] ^= l_2008;
            }
            else
            { /* block id: 833 */
                int8_t l_2121 = 1L;
                int32_t l_2137 = 0x641B762DL;
                int32_t l_2138 = 0x62A22258L;
                int32_t l_2141 = (-1L);
                int32_t l_2142 = 0x39663CF9L;
                int32_t l_2143 = 0x2A956390L;
                int32_t l_2144 = (-5L);
                uint64_t l_2145 = 0x8357FCB55C3C22C8LL;
                for (g_1417.f0 = 0; (g_1417.f0 <= 0); g_1417.f0 += 1)
                { /* block id: 836 */
                    uint64_t ** const **l_2100 = (void*)0;
                    int16_t *** const l_2116 = &g_653[3][0];
                    int16_t *** const *l_2115[6] = {(void*)0,&l_2116,&l_2116,(void*)0,&l_2116,&l_2116};
                    int16_t *** const **l_2114 = &l_2115[2];
                    int32_t l_2136 = 0L;
                    int32_t l_2139[4] = {0x05630040L,0x05630040L,0x05630040L,0x05630040L};
                    int64_t l_2140 = 0x2AE04BA2C30713F1LL;
                    int32_t *l_2148 = &l_1898;
                    int i;
                    g_2076 = g_425.f0;
                    if ((*l_1872))
                    { /* block id: 838 */
                        struct S1 **l_2085 = &g_844[2];
                        uint64_t ** const ***l_2099 = &g_2097;
                        uint8_t *l_2106 = (void*)0;
                        uint8_t *l_2107 = &g_1001;
                        l_1921[1][4] |= (safe_lshift_func_int16_t_s_s(((*g_654) &= (safe_lshift_func_uint8_t_u_u(((safe_sub_func_int32_t_s_s((((safe_lshift_func_int8_t_s_s((((*l_2085) = &g_1167) == &g_1532[5][1]), 5)) <= ((~(((safe_rshift_func_int32_t_s_u((g_1588.f0.f0 && (safe_mod_func_int32_t_s_s((-1L), g_1599[0][1].f0))), (safe_mul_func_uint32_t_u_u(((*l_1895) = 0xF2A8BD61L), (((void*)0 == l_2093) | (safe_mul_func_uint8_t_u_u(((((*l_2099) = g_2097) != l_2100) != p_3), g_377[7]))))))) == p_3) || 0xB381BDFAL)) && p_3)) ^ l_2101), 3L)) <= g_1463.f2), 3))), 8));
                        l_2121 = (safe_div_func_int64_t_s_s((((*l_2107) &= 0xCDL) != 0L), (safe_sub_func_int32_t_s_s((safe_mul_func_int64_t_s_s((safe_lshift_func_uint64_t_u_s(18446744073709551613UL, 54)), (((((l_2114 == (l_2120 = (((safe_mod_func_int32_t_s_s((+((void*)0 != (**l_2016))), ((*l_1895) &= (((*l_2085) = (void*)0) == &g_1708)))) | p_3) , &g_1948))) != 18446744073709551614UL) >= (-3L)) > p_3) != p_3))), l_1894))));
                        if (l_1893)
                            goto lbl_2122;
                    }
                    else
                    { /* block id: 850 */
                        int i, j;
                        l_2123[3] = l_1765[g_1417.f0];
                        (*g_1427) = ((safe_mul_func_uint32_t_u_u((*l_1872), 0xF9BE3B88L)) == (safe_sub_func_uint64_t_u_u(p_3, (p_3 > (safe_mul_func_uint8_t_u_u((p_3 & 3L), (((safe_rshift_func_int64_t_s_s((((p_3 | ((g_1268[g_1417.f0][(g_1417.f0 + 2)] , (safe_lshift_func_uint8_t_u_s(((safe_lshift_func_uint32_t_u_u(g_1587[3].f0.f4, g_377[7])) | p_3), 7))) <= 2L)) > 0x51C17F9FL) | 0x9D53624AL), p_3)) & 1UL) <= l_2121)))))));
                    }
                    l_2145--;
                    l_2148 = &l_1901;
                }
                return p_3;
            }
        }
    }
    return p_3;
}


/* ------------------------------------------ */
/* 
 * reads : g_654 g_535 g_1268.f0.f0 g_1378 g_1266.f0 g_1379 g_1382 g_781 g_341 g_342 g_196 g_166 g_1027.f1 g_845.f4 g_1001 g_270 g_1407 g_396 g_1417 g_1027.f3 g_55 g_1430 g_1427 g_1171.f1 g_845.f0 g_1167.f0 g_1463 g_1468 g_1027.f2 g_351 g_1494 g_359.f0.f1 g_162 g_110 g_163 g_1504 g_1505 g_1237 g_1238 g_1171.f4 g_1517 g_1532 g_210 g_78 g_32 g_115 g_71 g_75 g_172 g_1562 g_1418.f2 g_1268.f0.f2 g_1584 g_993 g_1587 g_1588 g_1027.f0 g_1599 g_1268 g_1604 g_1604.f0.f2 g_845.f2 g_1610 g_1171.f2 g_1174 g_176 g_425.f0.f2 g_370 g_1239 g_1240 g_425.f0.f1 g_1708 g_564 g_236.f0.f2 g_1723 g_1710 g_527 g_670 g_957 g_613
 * writes: g_77 g_619.f0 g_1167.f0 g_206.f0 g_196 g_166 g_1266.f0.f2 g_1027.f2 g_1001 g_110 g_845.f2 g_396 g_1418 g_1027.f0 g_55 g_1427 g_1000 g_670 g_359.f0 g_1238 g_115 g_75 g_162 g_172 g_1564 g_425.f0.f2 g_993 g_378 g_176 g_1710 g_564 g_535 g_1708.f2 g_957 g_1266.f0.f1 g_1082 g_613
 */
static int8_t  func_4(int32_t  p_5, uint64_t  p_6, uint16_t  p_7, int8_t  p_8, uint8_t  p_9)
{ /* block id: 509 */
    int32_t l_1357 = 0L;
    int32_t l_1358 = (-8L);
    int16_t l_1365[5];
    int8_t *l_1366 = (void*)0;
    uint64_t l_1369 = 1UL;
    uint64_t ***l_1373[2][8][10] = {{{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,(void*)0,(void*)0,&g_641,&g_641,&g_641,&g_641},{&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,(void*)0,&g_641}},{{(void*)0,&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{(void*)0,&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641},{(void*)0,(void*)0,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,(void*)0,&g_641,&g_641,&g_641,&g_641,(void*)0,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641},{&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,&g_641,(void*)0}}};
    uint64_t ***l_1374 = &g_641;
    uint32_t * const l_1375 = &g_670;
    uint64_t l_1377 = 0xE0F441920E3C5757LL;
    uint32_t l_1404[2][3][5];
    uint8_t l_1406 = 0x59L;
    int32_t l_1523 = 0xBB6E195CL;
    uint16_t ***l_1606 = (void*)0;
    union U3 * const l_1628[6] = {&g_177[3],&g_177[3],&g_177[3],&g_177[3],&g_177[3],&g_177[3]};
    int32_t l_1639 = (-2L);
    int32_t l_1643 = 0x15183FA4L;
    int32_t l_1646 = 0L;
    int32_t l_1648 = 3L;
    int32_t l_1651[5][5][3] = {{{0xBA33CAA5L,(-1L),(-2L)},{0x8C1268B6L,0x43F46647L,(-1L)},{(-1L),0xBA33CAA5L,0x30F49F93L},{0xF256CD5CL,0x43F46647L,0xF256CD5CL},{0xC8C7856AL,(-1L),0x56F671C2L}},{{1L,1L,0xF256CD5CL},{0x56F671C2L,0xC8C7856AL,0x30F49F93L},{(-2L),(-6L),(-1L)},{0x56F671C2L,0x56F671C2L,0x56F671C2L},{0xF256CD5CL,0L,(-1L)}},{{0xBA33CAA5L,0xADF1AB57L,0xBA33CAA5L},{(-2L),1L,0L},{0xC8C7856AL,0xBA33CAA5L,0xBA33CAA5L},{0L,(-9L),(-1L)},{0x30F49F93L,0xC8C7856AL,0x56F671C2L}},{{0L,0xD9764871L,0x8C1268B6L},{0xC8C7856AL,0x30F49F93L,(-2L)},{(-2L),0xD9764871L,(-2L)},{0xBA33CAA5L,0xC8C7856AL,0xADF1AB57L},{0xF256CD5CL,(-9L),(-2L)}},{{0xADF1AB57L,0xBA33CAA5L,(-2L)},{(-1L),1L,0x8C1268B6L},{0xADF1AB57L,0xADF1AB57L,0x56F671C2L},{0xF256CD5CL,0L,(-1L)},{0xBA33CAA5L,0xADF1AB57L,0xBA33CAA5L}}};
    uint8_t l_1652 = 0x1BL;
    uint8_t l_1756 = 0x79L;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_1365[i] = 2L;
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 5; k++)
                l_1404[i][j][k] = 0xC67C3A2EL;
        }
    }
    if ((safe_sub_func_uint16_t_u_u(((l_1357 && l_1358) < (safe_mod_func_int16_t_s_s((safe_mul_func_uint32_t_u_u(l_1358, (safe_div_func_uint16_t_u_u((l_1365[0] < ((((&g_1000 != l_1366) , (*g_654)) ^ (safe_div_func_int8_t_s_s((&g_1268[0][0] != &g_425), p_6))) != g_1268[0][0].f0.f0)), l_1369)))), 1UL))), 0x36B6L)))
    { /* block id: 510 */
        uint64_t ****l_1370 = &g_640[0];
        uint64_t ****l_1371 = &g_640[0];
        uint64_t ****l_1372[1];
        int i;
        for (i = 0; i < 1; i++)
            l_1372[i] = &g_640[0];
        l_1377 = (((l_1373[1][0][8] = (void*)0) != l_1374) != (&g_993 != l_1375));
    }
    else
    { /* block id: 513 */
        (*g_1378) = &g_78;
    }
    if (l_1365[3])
    { /* block id: 516 */
        int16_t l_1476 = 1L;
        int32_t l_1483 = (-3L);
        union U3 ** const l_1503 = &g_176;
        uint8_t l_1583 = 0UL;
        uint16_t ***l_1605 = (void*)0;
        int32_t l_1637 = (-6L);
        int32_t l_1645 = 0L;
        int32_t l_1647 = 7L;
        int32_t l_1649 = 0xEF245D21L;
        int32_t l_1650[2];
        int64_t *l_1698[7][7] = {{&g_370,&g_110,&g_110,&g_370,&g_110,&g_110,&g_370},{(void*)0,&g_440,&g_110,&g_110,&g_110,&g_440,(void*)0},{&g_370,&g_110,&g_110,&g_370,&g_110,&g_110,&g_370},{(void*)0,&g_440,&g_110,&g_110,&g_110,&g_440,(void*)0},{&g_370,&g_110,&g_110,&g_370,&g_110,&g_110,&g_370},{(void*)0,&g_440,&g_110,&g_110,&g_110,&g_440,(void*)0},{&g_370,&g_110,&g_110,&g_370,&g_110,&g_110,&g_370}};
        int32_t *l_1752 = &l_1649;
        int i, j;
        for (i = 0; i < 2; i++)
            l_1650[i] = 1L;
lbl_1580:
        (*g_1379) = g_1266.f0;
        if (p_6)
        { /* block id: 518 */
            return l_1365[0];
        }
        else
        { /* block id: 520 */
            int32_t l_1403 = (-2L);
            int32_t l_1522[6] = {0L,(-7L),(-7L),0L,(-7L),(-7L)};
            uint16_t l_1548 = 65535UL;
            int16_t l_1567[6];
            union U5 *l_1571 = &g_1494[0][1];
            int i;
            for (i = 0; i < 6; i++)
                l_1567[i] = 0x5DEFL;
            for (g_1167.f0 = 28; (g_1167.f0 != (-20)); g_1167.f0 = safe_sub_func_int64_t_s_s(g_1167.f0, 8))
            { /* block id: 523 */
                volatile struct S0 *l_1383[9] = {(void*)0,&g_1382,&g_1382,(void*)0,&g_1382,&g_1382,(void*)0,&g_1382,&g_1382};
                uint16_t *l_1396 = (void*)0;
                uint16_t *l_1397 = (void*)0;
                uint16_t *l_1398 = &g_707.f3;
                uint16_t *l_1399 = &g_166;
                uint8_t *l_1402[8];
                int32_t *l_1405 = &g_1027.f2;
                int i;
                for (i = 0; i < 8; i++)
                    l_1402[i] = &g_1001;
                g_206.f0 = g_1382;
                (*g_1407) = (((safe_mod_func_int16_t_s_s(((((((*g_270) = ((g_781[7] > (g_1001 ^= (((p_5 || ((**g_341) &= 1UL)) ^ ((safe_div_func_uint8_t_u_u(((safe_sub_func_uint32_t_u_u((safe_mod_func_int32_t_s_s(((safe_rshift_func_int32_t_s_u(p_8, 15)) , ((*l_1405) = ((safe_rshift_func_int64_t_s_s(((g_1266.f0.f2 = ((*l_1399) ^= 5UL)) < 65534UL), 54)) <= ((l_1377 ^ (l_1404[0][1][0] = ((safe_rshift_func_int64_t_s_u((l_1365[1] > ((l_1403 &= p_8) && 9UL)), 62)) && 0xD4L))) >= p_5)))), l_1406)), g_1027.f1)) > (-10L)), p_8)) ^ g_845[2].f4)) != p_6))) ^ 0xD890L)) > 0xB7B23415F69C9589LL) , 0xCEL) || l_1404[1][1][3]) == l_1369), p_9)) == p_5) <= p_5);
            }
            if (p_6)
            { /* block id: 535 */
                int32_t l_1415 = (-1L);
                int32_t l_1416 = (-1L);
                l_1416 |= (!((safe_add_func_int32_t_s_s((l_1357 & (l_1403 == (((p_8 < (&g_322 != l_1375)) < (safe_rshift_func_uint32_t_u_u(g_781[0], 5))) >= (g_396 &= (l_1403 , (((p_6 , p_5) > l_1358) == l_1415)))))), p_6)) || 0xF7L));
                g_1418 = g_1417;
                for (g_1027.f0 = 0; (g_1027.f0 == 12); g_1027.f0 = safe_add_func_int8_t_s_s(g_1027.f0, 2))
                { /* block id: 541 */
                    int32_t *l_1421 = &l_1416;
                    int32_t *l_1422 = &g_55;
                    if (((*l_1422) = ((*l_1421) |= (0x5AL < g_1027.f3))))
                    { /* block id: 544 */
                        (*l_1422) ^= (!(safe_add_func_int8_t_s_s(p_8, 0UL)));
                    }
                    else
                    { /* block id: 546 */
                        int32_t **l_1429 = (void*)0;
                        (*l_1421) = l_1403;
                        (*g_1430) = &p_5;
                        if ((**g_1430))
                            continue;
                    }
                }
            }
            else
            { /* block id: 552 */
                uint8_t l_1435 = 255UL;
                uint16_t *l_1450[9] = {&g_1266.f0.f2,&g_1266.f0.f2,&g_1266.f0.f2,&g_1266.f0.f2,&g_1266.f0.f2,&g_1266.f0.f2,&g_1266.f0.f2,&g_1266.f0.f2,&g_1266.f0.f2};
                int32_t l_1451 = 0x7032F24AL;
                int32_t *l_1452[2];
                union U4 *l_1541 = (void*)0;
                const union U4 *l_1542 = &g_1543;
                union U3 **l_1557[1];
                const int32_t *l_1589 = (void*)0;
                int i;
                for (i = 0; i < 2; i++)
                    l_1452[i] = &g_426;
                for (i = 0; i < 1; i++)
                    l_1557[i] = &g_176;
                if ((p_5 = (p_5 | (l_1451 &= ((l_1404[1][1][1] <= (safe_rshift_func_int8_t_s_s(((p_9 | (safe_rshift_func_int64_t_s_s(l_1435, 16))) < ((safe_rshift_func_uint64_t_u_u((safe_div_func_uint8_t_u_u(1UL, (safe_div_func_uint16_t_u_u((safe_div_func_int8_t_s_s((safe_div_func_int16_t_s_s((safe_mul_func_uint16_t_u_u(5UL, (safe_lshift_func_uint64_t_u_u(((*g_342) = l_1403), 22)))), (((g_1171.f1 < (g_845[2].f0 , 0x358CC8F8L)) && p_5) | l_1358))), g_1167.f0)), p_7)))), 62)) ^ 1L)), p_5))) < 0xA40ADF32BCBDEE02LL)))))
                { /* block id: 556 */
                    int16_t l_1482 = 0x2B20L;
                    int32_t l_1484 = 0L;
                    for (p_9 = 1; (p_9 <= 5); p_9 += 1)
                    { /* block id: 559 */
                        const int16_t *l_1469 = &g_535;
                        int32_t l_1485 = 0L;
                        int i;
                        l_1485 ^= (l_1484 = ((safe_rshift_func_int64_t_s_s((safe_lshift_func_int32_t_s_s(0x0C5CC23BL, 19)), (safe_mod_func_uint8_t_u_u((safe_div_func_int16_t_s_s((safe_add_func_uint32_t_u_u(((*l_1375) = ((l_1403 , (g_1463 , (((g_1000 = (safe_lshift_func_int8_t_s_s((((((safe_lshift_func_int32_t_s_u(((g_1468 , l_1469) != &l_1365[0]), (safe_mul_func_int32_t_s_s((safe_add_func_int8_t_s_s((safe_mod_func_int64_t_s_s((((*g_270) = (g_1027.f2 >= (((((l_1476 , ((((!((((safe_lshift_func_uint8_t_u_u(((((safe_div_func_int8_t_s_s(p_5, g_351)) || p_7) | l_1476) >= 0x39004A139E1A3DD5LL), 5)) , (void*)0) != (void*)0) < l_1482)) & l_1482) || p_8) > p_7)) == 18446744073709551615UL) == p_7) | l_1483) & 0xFD121A81L))) < 1L), l_1406)), l_1403)), p_9)))) == p_6) && l_1369) || 0L) & p_5), 6))) , 18446744073709551615UL) && p_5))) , 0xF5EF18BBL)), l_1482)), l_1482)), g_55)))) , l_1476));
                        l_1483 = ((safe_mod_func_uint8_t_u_u(((safe_rshift_func_uint64_t_u_s((**g_341), ((safe_sub_func_uint16_t_u_u(((safe_sub_func_int32_t_s_s((-1L), (g_1494[0][1] , l_1369))) && (((safe_sub_func_uint8_t_u_u(g_359.f0.f1, (l_1403 , ((safe_mod_func_uint64_t_u_u(((safe_lshift_func_int32_t_s_u((0x1FL ^ (l_1403 & (((safe_lshift_func_int16_t_s_s(((void*)0 != l_1503), l_1403)) ^ 8UL) != 1UL))), 13)) , p_6), l_1484)) , 0L)))) < (*g_162)) && 65535UL)), 1UL)) && l_1483))) == 4294967287UL), p_7)) == 0x99L);
                    }
                    return p_5;
                }
                else
                { /* block id: 568 */
                    int32_t l_1506[10][4][3] = {{{0x7D6C4370L,0L,0L},{0x673A955BL,0L,0x2AA15D9CL},{1L,0L,0L},{1L,0L,(-8L)}},{{0xBE0C98DDL,(-7L),(-7L)},{1L,1L,0xE27BF2CDL},{1L,0x34FAF37FL,0xE27BF2CDL},{0x673A955BL,0xE27BF2CDL,(-7L)}},{{0x7D6C4370L,0L,(-8L)},{0x385C4E39L,0xE27BF2CDL,0L},{0x61E50CDBL,0x34FAF37FL,0x2AA15D9CL},{0x61E50CDBL,1L,0L}},{{0x385C4E39L,(-7L),0x34FAF37FL},{0x7D6C4370L,0L,0L},{0x673A955BL,0L,0x2AA15D9CL},{1L,0L,0L}},{{1L,0L,(-8L)},{0xBE0C98DDL,(-7L),(-7L)},{1L,1L,0xE27BF2CDL},{1L,0x34FAF37FL,0xE27BF2CDL}},{{0x673A955BL,0xE27BF2CDL,(-7L)},{0x7D6C4370L,0L,(-8L)},{0x385C4E39L,0xE27BF2CDL,(-1L)},{0x929F4060L,(-1L),(-9L)}},{{0x929F4060L,0L,0xD25D4D34L},{0L,0xAAB93F17L,(-1L)},{0x34FAF37FL,(-1L),0xD25D4D34L},{0L,0x582ED8F6L,(-9L)}},{{0L,0x582ED8F6L,(-1L)},{8L,(-1L),5L},{0xE27BF2CDL,0xAAB93F17L,0xAAB93F17L},{8L,0L,9L}},{{0L,(-1L),9L},{0L,9L,0xAAB93F17L},{0x34FAF37FL,(-1L),5L},{0L,9L,(-1L)}},{{0x929F4060L,(-1L),(-9L)},{0x929F4060L,0L,0xD25D4D34L},{0L,0xAAB93F17L,(-1L)},{0x34FAF37FL,(-1L),0xD25D4D34L}}};
                    int32_t l_1524 = 0xB5170C14L;
                    int32_t *l_1547[2][3][3];
                    int i, j, k;
                    for (i = 0; i < 2; i++)
                    {
                        for (j = 0; j < 3; j++)
                        {
                            for (k = 0; k < 3; k++)
                                l_1547[i][j][k] = &g_425.f0.f0;
                        }
                    }
                    p_5 = (((void*)0 != &g_1075[0][3][6]) , ((((g_1504[2][1] , (g_1505 , ((l_1404[0][1][0] == ((*g_270) |= (l_1506[3][0][2] != (safe_rshift_func_uint16_t_u_s((safe_rshift_func_uint16_t_u_u(((void*)0 == (*g_1237)), 14)), 15))))) || ((safe_rshift_func_int16_t_s_s(((safe_rshift_func_uint16_t_u_s((p_6 && l_1403), 15)) | l_1357), l_1403)) > p_8)))) ^ p_8) > g_163) , p_6));
                    p_5 |= ((safe_lshift_func_uint32_t_u_s(g_1171.f4, 12)) ^ p_7);
                    g_359.f0 = g_1517;
                    for (l_1451 = 0; (l_1451 == 29); l_1451++)
                    { /* block id: 575 */
                        volatile int64_t ***l_1520 = &g_1238;
                        int32_t l_1521 = 0L;
                        uint8_t l_1525 = 252UL;
                        int32_t *l_1533 = &g_619.f0.f0;
                        union U4 *l_1540[10];
                        uint8_t *l_1544 = &g_115;
                        int32_t *l_1546 = (void*)0;
                        int32_t **l_1545[6];
                        int i;
                        for (i = 0; i < 10; i++)
                            l_1540[i] = (void*)0;
                        for (i = 0; i < 6; i++)
                            l_1545[i] = &l_1546;
                        (*l_1520) = (*g_1237);
                        --l_1525;
                        p_5 |= (safe_sub_func_uint32_t_u_u((l_1522[4] || (((safe_sub_func_int16_t_s_s((-10L), (p_7 = ((((g_1532[2][4] , l_1533) == (l_1547[1][1][1] = func_43(((*l_1544) = (safe_lshift_func_uint64_t_u_s((safe_rshift_func_int16_t_s_s((safe_add_func_uint8_t_u_u((((l_1541 = (l_1403 , l_1540[5])) != (g_210[0][1] , l_1542)) , (l_1521 ^ (*g_270))), l_1358)), 14)), 0))), &l_1451))) || 0x2420L) & l_1506[3][0][2])))) | l_1548) < l_1522[2])), l_1521));
                    }
                }
                for (l_1406 = (-11); (l_1406 == 59); ++l_1406)
                { /* block id: 587 */
                    uint8_t l_1563 = 0xB5L;
                    int32_t l_1565 = 0xA82AC81CL;
                    int32_t l_1566 = 0x7612BBDCL;
                    int32_t *l_1579[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    int32_t **l_1590 = &g_1427;
                    int i;
                    if ((0L | (safe_rshift_func_int8_t_s_s(((((safe_sub_func_uint32_t_u_u(g_196, ((g_425.f0.f2 = ((p_6 != (safe_add_func_uint16_t_u_u(((void*)0 != l_1557[0]), (safe_sub_func_int16_t_s_s((((g_1564 = (safe_rshift_func_uint16_t_u_u(((g_1562 , l_1403) > (((3L && l_1563) , p_5) , 0xB950L)), 9))) != (*g_270)) & g_1418.f2), g_1268[0][0].f0.f2))))) && (-1L))) , 0xB074BEAAL))) || l_1563) == (*g_270)) == (*g_270)), l_1522[2]))))
                    { /* block id: 590 */
                        uint32_t l_1568 = 0xC6F2F2C9L;
                        l_1568++;
                    }
                    else
                    { /* block id: 592 */
                        union U5 **l_1574 = (void*)0;
                        union U5 **l_1575 = &l_1571;
                        int32_t l_1576[4] = {(-9L),(-9L),(-9L),(-9L)};
                        int32_t **l_1578[7][9] = {{&l_1452[0],&l_1452[1],&l_1452[1],&l_1452[0],(void*)0,&l_1452[0],&l_1452[1],&l_1452[1],&l_1452[0]},{&g_1427,&l_1452[1],&l_1452[1],&l_1452[1],&g_1427,&g_1427,&l_1452[1],&l_1452[1],&l_1452[1]},{&l_1452[1],(void*)0,&l_1452[1],&l_1452[1],(void*)0,&l_1452[1],(void*)0,&l_1452[1],&l_1452[1]},{&g_1427,&g_1427,&l_1452[1],&l_1452[1],&l_1452[1],&g_1427,&g_1427,&l_1452[1],&l_1452[1]},{&l_1452[0],(void*)0,&l_1452[0],&l_1452[1],&l_1452[1],&l_1452[0],(void*)0,&l_1452[0],&l_1452[1]},{&l_1452[0],&l_1452[1],&l_1452[1],&l_1452[0],(void*)0,&l_1452[0],&l_1452[1],&l_1452[1],&l_1452[0]},{&g_1427,&l_1452[1],&l_1452[1],&l_1452[1],&g_1427,&g_1427,&l_1452[1],&l_1452[1],&l_1452[1]}};
                        int i, j;
                        (*l_1575) = l_1571;
                        if (l_1576[3])
                            continue;
                        l_1579[5] = &l_1522[2];
                    }
                    if (g_1417.f2)
                        goto lbl_1580;
                    g_55 |= ((((((safe_rshift_func_uint16_t_u_s(((p_5 <= ((*g_654) <= ((void*)0 == (*g_341)))) || p_8), 10)) || (l_1583 ^ (((g_1584[1][1][2] , ((g_993--) < (((l_1476 , ((g_1587[3] , g_210[0][1]) != g_396)) == l_1404[0][0][4]) >= 65535UL))) && p_9) ^ (*g_162)))) , 0x4D371392L) , g_1588) , p_8) ^ g_1027.f0);
                    (*l_1590) = func_43(l_1483, l_1589);
                }
            }
        }
        for (g_1027.f2 = 5; (g_1027.f2 >= 0); g_1027.f2 -= 1)
        { /* block id: 606 */
            int32_t *l_1607 = &g_845[2].f2;
            int32_t **l_1613 = &l_1607;
            struct S1 *l_1625 = &g_1027;
            int32_t l_1636[2][1][1];
            int64_t l_1642 = 0x54DDAD6722E992C3LL;
            uint64_t * const *l_1709[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            int i, j, k;
            for (i = 0; i < 2; i++)
            {
                for (j = 0; j < 1; j++)
                {
                    for (k = 0; k < 1; k++)
                        l_1636[i][j][k] = 0x2DAC8AB7L;
                }
            }
            (*l_1607) ^= (safe_lshift_func_uint64_t_u_u(0UL, (safe_lshift_func_uint8_t_u_u((safe_mod_func_uint16_t_u_u((safe_rshift_func_int64_t_s_s((l_1369 || ((g_1599[0][1] , (safe_mod_func_int32_t_s_s(((((g_1268[0][0] , ((0x3DL & (safe_lshift_func_int64_t_s_u(((((l_1483 = ((void*)0 != &g_1564)) < ((g_1604[0] , l_1605) != l_1606)) & p_7) < p_5), p_7))) >= (-10L))) | l_1377) ^ g_75[0]) | 255UL), p_8))) == 0x88L)), p_8)), 0xC784L)), g_1604[0].f0.f2))));
            if ((*l_1607))
                continue;
            (*l_1613) = func_43((safe_div_func_int32_t_s_s(((*l_1607) && (l_1483 | (g_1610 , (safe_mod_func_int64_t_s_s((-10L), l_1476))))), (*l_1607))), l_1607);
            for (g_196 = 0; (g_196 <= 0); g_196 += 1)
            { /* block id: 613 */
                uint8_t l_1614[8];
                uint8_t *l_1623 = (void*)0;
                uint8_t *l_1624 = &l_1406;
                int32_t *l_1629 = (void*)0;
                int32_t l_1630 = 0x47BF9A33L;
                int32_t l_1638 = 0L;
                int32_t l_1640 = 9L;
                int32_t l_1641[7] = {(-7L),(-1L),(-7L),(-7L),(-1L),(-7L),(-7L)};
                int32_t l_1644[8] = {0x9528D657L,0x9528D657L,0x9528D657L,0x9528D657L,0x9528D657L,0x9528D657L,0x9528D657L,0x9528D657L};
                int32_t * const l_1722[4][5][5] = {{{&g_1082[8].f0.f0,&g_359.f0.f0,(void*)0,&l_1641[4],&g_1082[8].f0.f0},{&g_619.f0.f0,(void*)0,&g_1082[8].f0.f0,&g_425.f0.f0,&g_1604[0].f0.f0},{&g_1266.f0.f0,&l_1641[4],&g_1463.f0,&l_1641[3],&g_1463.f0},{&g_619.f0.f0,&g_619.f0.f0,&g_1463.f0,(void*)0,(void*)0},{&g_1082[8].f0.f0,&l_1641[3],(void*)0,&l_1641[3],&g_1082[8].f0.f0}},{{&g_1604[0].f0.f0,&g_1082[8].f0.f0,(void*)0,&g_425.f0.f0,&g_425.f0.f0},{&g_1463.f0,&l_1641[3],&g_1463.f0,&l_1641[4],&g_1266.f0.f0},{(void*)0,&g_619.f0.f0,(void*)0,&g_1082[8].f0.f0,&g_425.f0.f0},{&g_1082[8].f0.f0,&l_1641[4],(void*)0,&g_359.f0.f0,&g_1082[8].f0.f0},{&g_425.f0.f0,(void*)0,(void*)0,&g_425.f0.f0,(void*)0}},{{&g_1266.f0.f0,&g_359.f0.f0,&g_1463.f0,&l_1641[3],&g_1463.f0},{&g_425.f0.f0,&g_619.f0.f0,(void*)0,(void*)0,&g_1604[0].f0.f0},{&g_1082[8].f0.f0,&l_1641[3],(void*)0,&l_1641[3],&g_1082[8].f0.f0},{(void*)0,&g_1082[8].f0.f0,&g_1463.f0,&g_425.f0.f0,&g_619.f0.f0},{&g_1463.f0,&l_1641[3],&g_1463.f0,&g_359.f0.f0,&g_1266.f0.f0}},{{&g_1604[0].f0.f0,&g_619.f0.f0,&g_1082[8].f0.f0,&g_1082[8].f0.f0,&g_619.f0.f0},{&g_1082[8].f0.f0,&g_359.f0.f0,(void*)0,&l_1641[4],&g_1082[8].f0.f0},{&g_619.f0.f0,(void*)0,&g_1082[8].f0.f0,&g_425.f0.f0,&g_1604[0].f0.f0},{&g_1266.f0.f0,&l_1641[4],&g_1463.f0,&l_1641[3],&g_1463.f0},{&g_619.f0.f0,&g_619.f0.f0,&g_1463.f0,(void*)0,(void*)0}}};
                int32_t * const *l_1721[5][7][1] = {{{&l_1722[2][1][2]},{&l_1722[3][2][1]},{&l_1722[3][2][1]},{&l_1722[2][1][2]},{&l_1722[2][1][2]},{&l_1722[2][1][2]},{&l_1722[3][2][1]}},{{&l_1722[3][2][1]},{&l_1722[2][1][2]},{&l_1722[2][1][2]},{&l_1722[2][1][2]},{&l_1722[3][2][1]},{&l_1722[3][2][1]},{&l_1722[2][1][2]}},{{&l_1722[2][1][2]},{&l_1722[2][1][2]},{&l_1722[3][2][1]},{&l_1722[3][2][1]},{&l_1722[2][1][2]},{&l_1722[2][1][2]},{&l_1722[2][1][2]}},{{&l_1722[3][2][1]},{&l_1722[3][2][1]},{&l_1722[2][1][2]},{&l_1722[2][1][2]},{&l_1722[2][1][2]},{&l_1722[3][2][1]},{&l_1722[3][2][1]}},{{&l_1722[2][1][2]},{&l_1722[2][1][2]},{&l_1722[2][1][2]},{&l_1722[3][2][1]},{&l_1722[3][2][1]},{&l_1722[2][1][2]},{&l_1722[2][1][2]}}};
                int64_t **l_1725 = &l_1698[2][3];
                uint16_t l_1726[7][8] = {{0x6651L,0xC5C2L,65529UL,8UL,0x9603L,8UL,65529UL,0xC5C2L},{0xC5C2L,0x995FL,0x0A9BL,65526UL,65529UL,0x0A9BL,1UL,0x6651L},{1UL,65533UL,1UL,1UL,0xC5C2L,65535UL,1UL,1UL},{0UL,1UL,0x0A9BL,0x0A9BL,1UL,0UL,65529UL,65533UL},{1UL,0UL,65529UL,65533UL,8UL,0x0A9BL,0x0B7FL,8UL},{65533UL,1UL,3UL,65533UL,0xC5C2L,65528UL,0xC5C2L,65533UL},{0x995FL,0xC5C2L,0x995FL,0x0A9BL,65526UL,65529UL,0x0A9BL,1UL}};
                int i, j, k;
                for (i = 0; i < 8; i++)
                    l_1614[i] = 9UL;
                if ((p_5 = ((l_1614[3] = 65534UL) | (safe_rshift_func_int16_t_s_u(((safe_rshift_func_int8_t_s_u(((safe_mod_func_uint32_t_u_u(((safe_mod_func_uint8_t_u_u(((*l_1624) = 251UL), p_6)) , (((void*)0 == l_1625) , g_1171.f2)), ((**l_1613) = (safe_rshift_func_uint16_t_u_s((l_1628[3] != (*g_1174)), 13))))) ^ (0x2C6228E201ABD3CBLL || l_1483)), 2)) > p_9), l_1523)))))
                { /* block id: 618 */
                    int32_t *l_1631 = &l_1358;
                    int32_t *l_1632 = &g_55;
                    int32_t *l_1633 = &g_845[2].f2;
                    int32_t *l_1634 = &g_845[2].f2;
                    int32_t *l_1635[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_1635[i] = (void*)0;
                    l_1652++;
                }
                else
                { /* block id: 620 */
                    uint32_t l_1655 = 0x5853AFD9L;
                    uint8_t *l_1667 = (void*)0;
                    uint8_t *l_1668[2];
                    int32_t *l_1669 = (void*)0;
                    int32_t *l_1670 = &l_1630;
                    int i;
                    for (i = 0; i < 2; i++)
                        l_1668[i] = &g_396;
                    (*l_1670) &= ((++l_1655) || (l_1358 = (safe_mul_func_int64_t_s_s((((*l_1624) = ((safe_rshift_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((*l_1607), ((p_6 = (((((l_1483 | (((safe_sub_func_int32_t_s_s(p_7, (safe_unary_minus_func_int16_t_s((l_1643 <= (**l_1613)))))) == (1UL || (p_5 != p_7))) >= g_425.f0.f2)) | (*g_162)) | p_5) | (**g_341)) != p_8)) & p_8))), l_1655)) , g_370)) && 1UL), (*g_1239)))));
                }
                if ((p_7 , (((safe_add_func_int8_t_s_s(l_1650[0], (++(*l_1624)))) || ((safe_lshift_func_int32_t_s_u((safe_mul_func_int16_t_s_s((safe_add_func_uint8_t_u_u(p_8, ((*l_1624) = (0x48350FB2L >= (safe_rshift_func_int8_t_s_s((l_1629 == l_1607), 3)))))), (l_1483 = l_1650[1]))), (p_6 > (safe_mul_func_int16_t_s_s(l_1365[4], 65534UL))))) != (*l_1607))) != l_1639)))
                { /* block id: 630 */
                    int32_t l_1701 = 5L;
                    int32_t l_1702 = 0x658CDACFL;
                    for (l_1523 = 2; (l_1523 >= 0); l_1523 -= 1)
                    { /* block id: 633 */
                        uint16_t l_1687 = 0xF019L;
                        int8_t *l_1699 = &g_1027.f0;
                        int32_t *l_1700[5][2][4] = {{{&l_1651[4][1][0],(void*)0,&l_1647,&l_1647},{&l_1523,&l_1523,&l_1647,&g_1167.f2}},{{&l_1651[4][1][0],&l_1645,&g_426,(void*)0},{&l_1649,&g_426,&g_1167.f2,&g_426}},{{&g_1167.f2,&g_426,&l_1649,(void*)0},{&g_426,&l_1645,&l_1651[4][1][0],&g_1167.f2}},{{&l_1647,&l_1523,&l_1523,&l_1647},{&l_1647,(void*)0,&l_1651[4][1][0],&l_1646}},{{&g_426,&l_1647,&l_1649,(void*)0},{&g_1167.f2,&l_1651[4][1][0],&g_1167.f2,(void*)0}}};
                        uint32_t l_1703 = 18446744073709551608UL;
                        int i, j, k;
                        p_5 = (safe_sub_func_uint32_t_u_u((l_1687 , 0UL), (safe_mul_func_uint64_t_u_u((safe_mul_func_uint32_t_u_u((safe_lshift_func_int32_t_s_s(((g_378 = l_1650[1]) < (safe_rshift_func_uint64_t_u_u((safe_mul_func_uint64_t_u_u((**g_341), (l_1687 <= ((*l_1699) = (((**l_1613) = ((((0L == p_8) == (((void*)0 == l_1698[1][4]) & g_425.f0.f1)) <= l_1645) ^ 2UL)) || p_6))))), p_5))), 16)), g_781[7])), l_1365[4]))));
                        (*l_1503) = (void*)0;
                        l_1703--;
                        (*l_1607) &= (safe_mul_func_uint16_t_u_u((g_1708 , l_1369), (l_1709[3] == (g_1710 = (void*)0))));
                    }
                    return (**l_1613);
                }
                else
                { /* block id: 644 */
                    (*l_1607) |= p_5;
                }
                for (g_564 = 0; (g_564 <= 2); g_564 += 1)
                { /* block id: 649 */
                    int64_t l_1727 = 0x88F44435BDF86BDALL;
                    int8_t l_1734 = 0xB2L;
                    int32_t *l_1742 = (void*)0;
                    int32_t *l_1744 = &l_1523;
                    g_1708.f2 ^= (safe_add_func_int64_t_s_s((((*l_1607) = 0x628EF39BL) < p_9), (l_1727 = ((safe_rshift_func_uint8_t_u_s(p_5, (safe_mod_func_int32_t_s_s(((safe_mul_func_int64_t_s_s(0L, (((g_1417.f4 && g_236.f0.f2) & (((((safe_sub_func_uint64_t_u_u((p_8 > (((*g_654) = (((0x32L >= (((l_1721[2][4][0] == g_1723) , l_1725) == (void*)0)) == p_6) == l_1645)) < 0x124CL)), (*g_162))) || p_5) < l_1637) , g_1027.f2) | p_6)) == p_6))) , l_1647), l_1726[2][6])))) | g_1708.f1))));
                    (*l_1744) |= (safe_rshift_func_int16_t_s_u((safe_rshift_func_uint32_t_u_u((safe_mod_func_uint8_t_u_u(((0x413E5B97A16112A6LL >= l_1734) || ((*g_654) > (*g_654))), ((p_9 , p_9) & (~(((*l_1607) ^ ((*g_1710) != (((safe_rshift_func_uint16_t_u_s((safe_mod_func_uint8_t_u_u((safe_mod_func_uint32_t_u_u(((*l_1375) |= ((p_7 , &g_640[g_196]) != &g_640[0])), 0x314ECE7CL)), p_7)), l_1644[3])) || p_6) , &p_6))) == 0x154B022E809DA520LL))))), 30)), 11));
                    for (l_1406 = 0; (l_1406 <= 2); l_1406 += 1)
                    { /* block id: 658 */
                        uint32_t l_1745 = 18446744073709551615UL;
                        int8_t **l_1749 = (void*)0;
                        int8_t ***l_1748 = &l_1749;
                        --l_1745;
                        (*l_1748) = (void*)0;
                        (*l_1607) &= ((safe_add_func_uint8_t_u_u(l_1745, 6UL)) , 1L);
                        (**l_1613) ^= 0x7806AC87L;
                    }
                    for (p_7 = 0; (p_7 <= 2); p_7 += 1)
                    { /* block id: 666 */
                        return g_1517.f2;
                    }
                }
            }
        }
        (*l_1752) ^= l_1646;
    }
    else
    { /* block id: 673 */
        int32_t *l_1755[10] = {&g_55,&g_55,&g_55,&l_1651[3][3][2],&g_1532[2][4].f2,&l_1651[3][3][2],&g_55,&g_55,&l_1651[3][3][2],&g_1532[2][4].f2};
        int i;
        for (g_957 = 0; (g_957 > 5); g_957 = safe_add_func_int64_t_s_s(g_957, 5))
        { /* block id: 676 */
            for (g_1266.f0.f1 = 0; g_1266.f0.f1 < 9; g_1266.f0.f1 += 1)
            {
                union U4 tmp = {{0xBE90287BL,0x24C9C07FL,0x3658L,0x22AEEB31L,0xDF3CL}};
                g_1082[g_1266.f0.f1] = tmp;
            }
            for (g_613 = 0; (g_613 <= 1); g_613 += 1)
            { /* block id: 680 */
                int i;
                if (l_1652)
                    break;
            }
            if (p_7)
                break;
        }
        l_1755[1] = &p_5;
    }
    return l_1756;
}


/* ------------------------------------------ */
/* 
 * reads : g_1349 g_426 g_270 g_110
 * writes: g_1349 g_1167.f2 g_1027.f2 g_426
 */
static int64_t  func_13(const uint32_t  p_14, int64_t  p_15, uint64_t  p_16, int32_t  p_17)
{ /* block id: 499 */
    int8_t l_1334 = (-3L);
    int32_t *l_1335 = &g_1027.f2;
    int32_t *l_1336 = (void*)0;
    int32_t l_1337 = 0xE4921584L;
    int32_t *l_1338 = &g_426;
    int32_t *l_1339 = (void*)0;
    int32_t *l_1340 = &g_426;
    int32_t *l_1341 = &g_845[2].f2;
    int32_t *l_1342 = &g_1027.f2;
    int32_t *l_1343 = (void*)0;
    int32_t *l_1344 = &g_1167.f2;
    int32_t *l_1345 = &g_426;
    int32_t *l_1346 = &l_1337;
    int32_t *l_1347 = (void*)0;
    int32_t *l_1348[3][9] = {{&g_1027.f2,&g_55,&g_55,&g_1027.f2,&g_1027.f2,&g_55,&g_55,&g_1027.f2,&g_1027.f2},{&g_426,&g_426,&g_426,&g_426,&g_426,&g_426,&g_426,&g_426,&g_426},{&g_1027.f2,&g_1027.f2,&g_55,&g_55,&g_1027.f2,&g_1027.f2,&g_55,&g_55,&g_1027.f2}};
    int i, j;
    g_1349--;
    for (p_16 = 19; (p_16 < 6); p_16 = safe_sub_func_uint32_t_u_u(p_16, 5))
    { /* block id: 503 */
        g_1027.f2 = ((*l_1344) = p_15);
        (*l_1340) ^= p_17;
    }
    return (*g_270);
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_55 g_71 g_77 g_78 g_115 g_110 g_75 g_162 g_172 g_176 g_163 g_166 g_270 g_370 g_342 g_196 g_138 g_426 g_210 g_129 g_341 g_322 g_359.f0.f0 g_396 g_351 g_440 g_425.f0.f2 g_517 g_359.f0.f2 g_584 g_425.f0.f0 g_377 g_613 g_620 g_378 g_652 g_564 g_670 g_654 g_535 g_781 g_619.f0.f0 g_844 g_845.f2 g_957 g_845.f1 g_738.f0.f2 g_993 g_1001 g_1027.f2 g_1075 g_1082.f0.f2 g_1000 g_1027.f1 g_1171.f1 g_619.f0.f2 g_1237 g_1167.f2 g_1171.f0 g_1268.f0.f0 g_1266.f0.f0 g_1296 g_1082.f0.f0 g_1167.f0
 * writes: g_55 g_71 g_75 g_110 g_115 g_162 g_166 g_172 g_176 g_196 g_210 g_426 g_396 g_359.f0.f2 g_527 g_129 g_206.f3 g_378 g_177.f3 g_32 g_440 g_620 g_564 g_640 g_535 g_652 g_670 g_377 g_351 g_707.f3 g_844 g_709.f3 g_781 g_954 g_845.f2 g_993 g_1001 g_425.f0.f2 g_619.f0.f0 g_1169 g_1167.f0 g_1174 g_77 g_1027.f1 g_1027.f2 g_370 g_1000 g_1296
 */
static int16_t  func_19(int32_t  p_20, uint16_t  p_21)
{ /* block id: 1 */
    uint64_t l_585[10][8][3] = {{{8UL,18446744073709551615UL,18446744073709551615UL},{6UL,0xCCCDB3AA12D2B3BCLL,0xA659A5DC7E224F4ALL},{18446744073709551615UL,0x0E6E700B07BD41CALL,0x4C85D07E076A8B6ALL},{0x2F9ADA0AB1737E3ALL,0x2B433FB912623655LL,1UL},{18446744073709551614UL,0x73D6D54DAE25B874LL,0x56D5EA817469EA82LL},{0x4E6AE61DF45AAB5BLL,0x4E6AE61DF45AAB5BLL,18446744073709551615UL},{0x8EDEC4534D0B4FEDLL,18446744073709551615UL,0x73D6D54DAE25B874LL},{0x73D6D54DAE25B874LL,1UL,0x3365100CFA2386A4LL}},{{0x4ED89C221E961FAALL,0x0FAA19B2AE30E295LL,0x22C6BA9A2D20BD8ALL},{1UL,0x73D6D54DAE25B874LL,0x3365100CFA2386A4LL},{8UL,0xE624849E123084BELL,0x73D6D54DAE25B874LL},{1UL,18446744073709551615UL,18446744073709551615UL},{0xA659A5DC7E224F4ALL,0xDEB56899CCE51689LL,0x56D5EA817469EA82LL},{0x4ED89C221E961FAALL,0x0E6E700B07BD41CALL,1UL},{18446744073709551610UL,7UL,0x4C85D07E076A8B6ALL},{18446744073709551614UL,18446744073709551610UL,0xA659A5DC7E224F4ALL}},{{0x22C6BA9A2D20BD8ALL,18446744073709551614UL,18446744073709551615UL},{18446744073709551608UL,1UL,0x3348C879100C95C7LL},{0x2F9ADA0AB1737E3ALL,1UL,0x8EDEC4534D0B4FEDLL},{0x694C583BF57B1920LL,18446744073709551614UL,0UL},{1UL,18446744073709551610UL,18446744073709551608UL},{1UL,7UL,0x73D6D54DAE25B874LL},{18446744073709551615UL,0x0E6E700B07BD41CALL,0x960CFE9C3F9F150CLL},{6UL,0xDEB56899CCE51689LL,6UL}},{{0x694C583BF57B1920LL,18446744073709551615UL,0x4C85D07E076A8B6ALL},{18446744073709551610UL,0xE624849E123084BELL,18446744073709551615UL},{0x8EDEC4534D0B4FEDLL,0x73D6D54DAE25B874LL,0xA659A5DC7E224F4ALL},{18446744073709551614UL,0x0FAA19B2AE30E295LL,0x960CFE9C3F9F150CLL},{0x8EDEC4534D0B4FEDLL,1UL,0x2F9ADA0AB1737E3ALL},{18446744073709551610UL,18446744073709551615UL,0x3365100CFA2386A4LL},{0x694C583BF57B1920LL,0x4E6AE61DF45AAB5BLL,18446744073709551614UL},{6UL,0x73D6D54DAE25B874LL,18446744073709551608UL}},{{18446744073709551615UL,0x2B433FB912623655LL,0x3348C879100C95C7LL},{1UL,0x0E6E700B07BD41CALL,0x4ED89C221E961FAALL},{1UL,0xCCCDB3AA12D2B3BCLL,0x56D5EA817469EA82LL},{0x694C583BF57B1920LL,18446744073709551615UL,18446744073709551615UL},{0x2F9ADA0AB1737E3ALL,7UL,18446744073709551615UL},{18446744073709551608UL,0xEEB5D9E247E2A96ELL,0x56D5EA817469EA82LL},{0x22C6BA9A2D20BD8ALL,0x0FAA19B2AE30E295LL,0x4ED89C221E961FAALL},{18446744073709551614UL,18446744073709551615UL,0x3348C879100C95C7LL}},{{18446744073709551610UL,0x694C583BF57B1920LL,18446744073709551608UL},{0x4ED89C221E961FAALL,18446744073709551614UL,18446744073709551614UL},{0xA659A5DC7E224F4ALL,0xEEB5D9E247E2A96ELL,0x3365100CFA2386A4LL},{1UL,0x2B433FB912623655LL,0x2F9ADA0AB1737E3ALL},{8UL,18446744073709551615UL,0x960CFE9C3F9F150CLL},{1UL,6UL,0xA659A5DC7E224F4ALL},{0x4ED89C221E961FAALL,18446744073709551615UL,18446744073709551615UL},{0x73D6D54DAE25B874LL,0x2B433FB912623655LL,0x4C85D07E076A8B6ALL}},{{0x8EDEC4534D0B4FEDLL,0xEEB5D9E247E2A96ELL,6UL},{0x4E6AE61DF45AAB5BLL,18446744073709551614UL,0x960CFE9C3F9F150CLL},{18446744073709551614UL,0x694C583BF57B1920LL,0x73D6D54DAE25B874LL},{0x2F9ADA0AB1737E3ALL,18446744073709551615UL,1UL},{0x22C6BA9A2D20BD8ALL,1UL,0x54DF8DBA267628F6LL},{0x4446A3DD339DF72BLL,6UL,0x4C85D07E076A8B6ALL},{0xA659A5DC7E224F4ALL,0x8EDEC4534D0B4FEDLL,0xDEB56899CCE51689LL},{0xA659A5DC7E224F4ALL,18446744073709551615UL,0x22C6BA9A2D20BD8ALL}},{{0x4446A3DD339DF72BLL,0x1B06277BF2F4B23ALL,0xD341ACC7B2E89AD5LL},{0x22C6BA9A2D20BD8ALL,0x694C583BF57B1920LL,1UL},{18446744073709551610UL,18446744073709551614UL,0x56D5EA817469EA82LL},{18446744073709551615UL,18446744073709551613UL,0x0E6E700B07BD41CALL},{9UL,9UL,0x22C6BA9A2D20BD8ALL},{0x4C85D07E076A8B6ALL,0x22C6BA9A2D20BD8ALL,18446744073709551613UL},{18446744073709551613UL,0x4E6AE61DF45AAB5BLL,0xC0940A9D51A227BBLL},{0UL,1UL,18446744073709551615UL}},{{18446744073709551615UL,18446744073709551613UL,0xC0940A9D51A227BBLL},{0xA659A5DC7E224F4ALL,18446744073709551608UL,18446744073709551613UL},{0x56D5EA817469EA82LL,0x4ED89C221E961FAALL,0x22C6BA9A2D20BD8ALL},{0xD341ACC7B2E89AD5LL,0x9C794C2872295453LL,0x0E6E700B07BD41CALL},{0UL,0x694C583BF57B1920LL,0x56D5EA817469EA82LL},{0xCCCDB3AA12D2B3BCLL,0x8EDEC4534D0B4FEDLL,1UL},{18446744073709551615UL,0xCCCDB3AA12D2B3BCLL,0xD341ACC7B2E89AD5LL},{18446744073709551615UL,0UL,0x22C6BA9A2D20BD8ALL}},{{1UL,0x4E6AE61DF45AAB5BLL,0xDEB56899CCE51689LL},{18446744073709551610UL,0x4E6AE61DF45AAB5BLL,0x4C85D07E076A8B6ALL},{18446744073709551614UL,0UL,0x54DF8DBA267628F6LL},{18446744073709551615UL,0xCCCDB3AA12D2B3BCLL,1UL},{0x56D5EA817469EA82LL,0x8EDEC4534D0B4FEDLL,18446744073709551613UL},{6UL,0x694C583BF57B1920LL,0x0FAA19B2AE30E295LL},{0x4446A3DD339DF72BLL,0x9C794C2872295453LL,0x4446A3DD339DF72BLL},{18446744073709551614UL,0x4ED89C221E961FAALL,1UL}}};
    int32_t l_1089 = 0xEC0202B9L;
    uint8_t *l_1094 = &g_115;
    int32_t *l_1097 = &l_1089;
    int64_t **l_1099 = &g_270;
    int64_t ** const *l_1098 = &l_1099;
    union U4 * const *l_1109 = &g_620;
    uint16_t *l_1112 = (void*)0;
    uint16_t **l_1111 = &l_1112;
    uint16_t ***l_1110 = &l_1111;
    uint32_t l_1157 = 0x6E6BC54AL;
    const struct S1 *l_1166 = &g_1167;
    const struct S1 * const *l_1165 = &l_1166;
    int16_t *l_1253 = &g_75[0];
    int16_t ** const l_1252 = &l_1253;
    int16_t ** const *l_1251 = &l_1252;
    uint32_t l_1298 = 1UL;
    const int16_t *l_1309[8][10][3] = {{{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]}},{{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]}},{{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]}},{{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_75[0],&g_75[0]},{&g_172,&g_172,(void*)0},{&g_75[0],&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]}},{{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]}},{{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]}},{{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]}},{{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]},{&g_138,&g_138,&g_172},{&g_138,&g_138,&g_75[0]}}};
    int i, j, k;
    for (p_20 = 0; (p_20 <= 26); ++p_20)
    { /* block id: 4 */
        int64_t *l_579 = &g_370;
        const int32_t l_587 = 0xCCA588D3L;
        int32_t *l_1090 = &g_55;
        int32_t **l_1091 = (void*)0;
        int32_t *l_1093 = (void*)0;
        int32_t **l_1092 = &l_1093;
        for (p_21 = (-9); (p_21 > 2); p_21++)
        { /* block id: 7 */
            uint32_t *l_571 = (void*)0;
            uint32_t *l_572 = (void*)0;
            uint32_t *l_573 = (void*)0;
            uint32_t *l_574 = &g_378;
            int64_t *l_580 = &g_440;
            int32_t l_581 = 0x1E3B734FL;
            uint16_t *l_586 = &g_177[4].f3;
            int32_t *l_1087 = &g_55;
            int32_t **l_1086 = &l_1087;
            int32_t *l_1088[5][3][3] = {{{&l_581,&g_845[2].f2,&g_426},{&g_55,&g_55,&g_845[2].f2},{&g_1027.f2,&g_1027.f2,&g_1027.f2}},{{&g_55,(void*)0,(void*)0},{&l_581,&g_1027.f2,&g_426},{&g_426,&g_55,(void*)0}},{{&g_1027.f2,&g_845[2].f2,&g_1027.f2},{&g_426,(void*)0,&g_845[2].f2},{&l_581,&g_845[2].f2,&g_426}},{{&g_55,&g_55,&g_845[2].f2},{&g_1027.f2,&g_1027.f2,&g_1027.f2},{&g_55,(void*)0,(void*)0}},{{&l_581,&g_1027.f2,&g_426},{&g_426,&g_55,(void*)0},{&g_1027.f2,&g_845[2].f2,&g_1027.f2}}};
            int i, j, k;
            (*l_1086) = func_28(g_32, (safe_add_func_uint64_t_u_u((safe_sub_func_uint8_t_u_u(((safe_div_func_uint32_t_u_u(p_20, ((*l_574) = func_39(g_32)))) > (safe_mod_func_uint16_t_u_u(((*l_586) = (safe_mul_func_uint64_t_u_u(((l_579 == l_580) > 5L), (((l_581 == (safe_add_func_uint16_t_u_u((g_584 != (void*)0), g_425.f0.f0))) || p_21) , l_585[4][0][1])))), g_377[5]))), l_587)), p_20)), g_377[7]);
            l_1089 ^= p_21;
        }
        (*l_1092) = (l_1090 = l_1090);
        (*l_1092) = &p_20;
    }
    l_1097 = func_43((++(*l_1094)), (l_585[6][4][1] , &l_1089));
lbl_1132:
    (*l_1097) = p_20;
    if (((l_1098 != &l_1099) , ((+0L) | (safe_mul_func_int8_t_s_s(0x52L, (((*l_1097) ^= p_20) , ((safe_add_func_uint64_t_u_u(((*l_1097) = (safe_rshift_func_int16_t_s_u(0xE9F4L, 7))), (safe_mod_func_uint32_t_u_u((l_1109 != ((((*g_654) ^= l_585[8][0][0]) < (((void*)0 != l_1110) & (*g_162))) , (void*)0)), p_21)))) & 0x40B872139C1F0C4CLL)))))))
    { /* block id: 416 */
        int16_t **l_1118 = (void*)0;
        uint32_t l_1129 = 0x35991D2CL;
        uint64_t ****l_1139 = &g_640[0];
        int64_t l_1164[1][1];
        uint8_t *l_1172[6] = {&g_613,&g_613,&g_781[7],&g_613,&g_613,&g_781[7]};
        uint32_t *l_1200 = (void*)0;
        int32_t *l_1201 = &g_1027.f2;
        uint16_t l_1241 = 0xBAF0L;
        union U4 *l_1267 = &g_1268[0][0];
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 1; j++)
                l_1164[i][j] = 0xF1965B7455E73EDCLL;
        }
        for (g_619.f0.f0 = 7; (g_619.f0.f0 >= 2); g_619.f0.f0 -= 1)
        { /* block id: 419 */
            uint64_t * const l_1115 = &g_1027.f1;
            int32_t l_1135 = 6L;
            uint32_t l_1136 = 1UL;
            uint64_t ** const *l_1184 = &g_641;
            uint32_t l_1211 = 9UL;
            int32_t l_1274[5][7][3] = {{{0xDF382936L,7L,0xED6B0188L},{(-4L),(-1L),0x9F0F27B1L},{0L,0L,0L},{0x9F0F27B1L,0x6CA7D8C1L,0xDF9D635EL},{(-4L),0L,0xD937AED7L},{(-1L),1L,0xD19AE849L},{0xDF9D635EL,0x9F0F27B1L,0x0CB86EE8L}},{{0xED6B0188L,0xA031AE04L,0xE83DC0CDL},{1L,0xED6B0188L,0x2BCBF492L},{(-1L),0xAC293AF1L,0x262C366CL},{0x27B36456L,0xD937AED7L,(-1L)},{0x27B36456L,0x2BCBF492L,1L},{(-1L),(-4L),0L},{1L,0xDF6A5007L,0x2E2963B7L}},{{0xED6B0188L,(-1L),(-1L)},{0xDF9D635EL,0x882DE5A1L,0x27B36456L},{(-1L),1L,0L},{(-4L),6L,0x9F0F27B1L},{0x9F0F27B1L,1L,0xAC293AF1L},{0L,6L,0xCB4A6B44L},{0x6CA7D8C1L,1L,0L}},{{(-1L),0x882DE5A1L,0xEDD18ECCL},{0xE06B8BCFL,(-1L),0x6CA7D8C1L},{0x882DE5A1L,0xDF6A5007L,7L},{0x6F99306EL,(-4L),0xA031AE04L},{(-1L),0x2BCBF492L,0xDF6A5007L},{0xDF382936L,0xD937AED7L,0xDF6A5007L},{7L,0xAC293AF1L,0xA031AE04L}},{{0xBF92A848L,0xED6B0188L,7L},{(-1L),0xA031AE04L,0x6CA7D8C1L},{0xEDD18ECCL,0x9F0F27B1L,0xEDD18ECCL},{0xE83DC0CDL,1L,0L},{0x75978BAEL,0L,0xCB4A6B44L},{(-1L),0x6CA7D8C1L,0xAC293AF1L},{0x0CB86EE8L,0L,0x9F0F27B1L}}};
            int i, j, k;
            if ((safe_lshift_func_int32_t_s_u(((l_1115 == ((((safe_mul_func_int32_t_s_s(((void*)0 != l_1118), (safe_add_func_int8_t_s_s((-1L), (safe_rshift_func_int64_t_s_u(((g_377[g_619.f0.f0] < ((safe_add_func_int64_t_s_s(((***l_1098) = 0xD404B896B1CBA7B1LL), ((safe_div_func_int8_t_s_s(g_322, ((*l_1094) |= (safe_mul_func_int32_t_s_s(l_1129, (safe_mod_func_int64_t_s_s(l_1129, 0xFB8F261EA435570BLL))))))) , l_1129))) != p_20)) ^ l_1129), (*l_1097))))))) >= p_21) < p_21) , &l_585[4][0][1])) == 0xD05557E1L), 6)))
            { /* block id: 422 */
                int32_t *l_1133 = &l_1089;
                int32_t *l_1134[1];
                uint64_t *****l_1140 = &l_1139;
                const struct S1 * const **l_1168[3];
                int i;
                for (i = 0; i < 1; i++)
                    l_1134[i] = &g_55;
                for (i = 0; i < 3; i++)
                    l_1168[i] = (void*)0;
                if (g_1027.f2)
                    goto lbl_1132;
                ++l_1136;
                (*l_1140) = l_1139;
                g_1169 = (((safe_add_func_uint64_t_u_u((safe_add_func_int64_t_s_s(((((safe_mod_func_int16_t_s_s(((((((safe_mod_func_int8_t_s_s(0x02L, g_781[3])) , (safe_div_func_uint32_t_u_u(((safe_sub_func_int8_t_s_s(g_1082[8].f0.f2, (g_322 , (((p_21 != (((-5L) && (safe_rshift_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(((l_1157 > (safe_mod_func_uint64_t_u_u((*l_1097), ((safe_rshift_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u((p_20 | l_1164[0][0]), l_1136)), 22)) && p_20)))) < p_21), g_166)), g_613))) , g_78)) == 0xA7L) , 0xA4L)))) , g_396), g_1000))) == 0x36L) & 0x694C2BC1L) & 0x470FL) != 0x5E2F9C71254B0FDFLL), l_1129)) ^ p_20) & l_1136) <= 0x6FL), 18446744073709551612UL)), (*g_270))) < 0x8693364EC272A591LL) , l_1165);
            }
            else
            { /* block id: 427 */
                int16_t l_1173 = (-10L);
                int32_t **l_1187[1][1];
                int i, j;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_1187[i][j] = &l_1097;
                }
                for (g_1167.f0 = 0; (g_1167.f0 <= 9); g_1167.f0 += 1)
                { /* block id: 430 */
                    union U3 **l_1175 = &g_176;
                    uint32_t *l_1178 = &l_1129;
                    int32_t l_1183[4] = {0L,0L,0L,0L};
                    uint64_t ** const *l_1186 = &g_641;
                    int i, j;
                    if (((((*l_1178) = ((l_1172[4] != ((((***l_1098) = (p_20 <= l_1173)) > ((*g_342) != (((g_1174 = &g_176) == l_1175) || l_1164[0][0]))) , (void*)0)) <= ((safe_add_func_uint16_t_u_u((((l_1135 |= ((*l_1094) = p_20)) > g_377[g_619.f0.f0]) >= (*g_654)), p_20)) || p_21))) , 0xBFL) & 9L))
                    { /* block id: 436 */
                        (*l_1097) &= p_20;
                        p_20 = (safe_lshift_func_int64_t_s_u(((*g_270) |= (((safe_mod_func_int32_t_s_s(((*g_341) != (*g_341)), p_21)) < l_1183[0]) >= p_20)), 23));
                    }
                    else
                    { /* block id: 440 */
                        uint64_t ** const **l_1185[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_1185[i] = (void*)0;
                        (*l_1097) = 0x86A66EE9L;
                        l_1186 = l_1184;
                    }
                }
                g_77[2][1] = &l_1089;
            }
            for (g_1001 = 1; (g_1001 <= 9); g_1001 += 1)
            { /* block id: 449 */
                const int64_t l_1188 = 0xCF47ECBCC729C842LL;
                uint32_t *l_1199 = &g_993;
                int64_t *l_1235 = &g_440;
                int32_t *l_1242 = &l_1089;
                union U4 *l_1265 = &g_1266;
                union U4 **l_1264[5];
                int8_t *l_1269 = (void*)0;
                int8_t *l_1270 = &g_377[g_619.f0.f0];
                int8_t *l_1271 = &g_1000;
                int16_t l_1272[4] = {0xAD2DL,0xAD2DL,0xAD2DL,0xAD2DL};
                uint8_t l_1273 = 0x37L;
                int i, j;
                for (i = 0; i < 5; i++)
                    l_1264[i] = &l_1265;
                if ((l_1188 ^ (safe_lshift_func_int64_t_s_s((safe_mul_func_uint16_t_u_u((p_20 >= (safe_add_func_uint32_t_u_u(p_20, (0x40L == p_20)))), ((((((1L || (((*l_1115) |= l_1129) == (g_1171.f1 == (safe_div_func_uint8_t_u_u(((*l_1094) = ((safe_sub_func_uint16_t_u_u((l_1199 != l_1200), p_21)) < (*l_1097))), p_20))))) , 0x261F0324L) && p_21) & g_71) & 0x02L) > p_21))), (*g_162)))))
                { /* block id: 452 */
                    if (g_71)
                        goto lbl_1132;
                }
                else
                { /* block id: 454 */
                    int32_t **l_1202[9][6][4] = {{{&l_1201,(void*)0,(void*)0,(void*)0},{&l_1097,&l_1201,&l_1201,&l_1097},{&l_1097,&l_1201,&l_1097,&l_1097},{&l_1201,&l_1201,&l_1097,(void*)0},{(void*)0,(void*)0,&l_1201,&l_1201},{&l_1097,&l_1201,&l_1201,(void*)0}},{{(void*)0,&l_1201,&l_1097,(void*)0},{&l_1201,(void*)0,&l_1097,(void*)0},{&l_1097,(void*)0,&l_1201,(void*)0},{&l_1097,&l_1201,(void*)0,(void*)0},{&l_1201,&l_1201,&l_1097,&l_1201},{&l_1201,(void*)0,(void*)0,(void*)0}},{{&l_1097,&l_1201,&l_1201,&l_1097},{&l_1097,&l_1201,&l_1097,&l_1097},{&l_1201,&l_1201,&l_1097,(void*)0},{(void*)0,(void*)0,&l_1201,&l_1201},{&l_1097,&l_1201,&l_1201,(void*)0},{(void*)0,&l_1201,&l_1097,(void*)0}},{{&l_1201,(void*)0,&l_1097,(void*)0},{&l_1097,(void*)0,&l_1201,(void*)0},{&l_1097,&l_1201,(void*)0,(void*)0},{&l_1097,&l_1097,&l_1201,&l_1201},{&l_1097,&l_1201,&l_1097,&l_1201},{&l_1201,&l_1201,(void*)0,(void*)0}},{{&l_1201,(void*)0,&l_1201,(void*)0},{(void*)0,&l_1201,&l_1201,&l_1201},{&l_1097,&l_1201,&l_1097,&l_1201},{&l_1201,&l_1097,&l_1097,(void*)0},{&l_1097,&l_1097,&l_1201,&l_1201},{(void*)0,&l_1201,&l_1201,&l_1201}},{{&l_1201,&l_1201,(void*)0,&l_1201},{&l_1201,&l_1097,&l_1097,(void*)0},{&l_1097,&l_1097,&l_1201,&l_1201},{&l_1097,&l_1201,&l_1097,&l_1201},{&l_1201,&l_1201,(void*)0,(void*)0},{&l_1201,(void*)0,&l_1201,(void*)0}},{{(void*)0,&l_1201,&l_1201,&l_1201},{&l_1097,&l_1201,&l_1097,&l_1201},{&l_1201,&l_1097,&l_1097,(void*)0},{&l_1097,&l_1097,&l_1201,&l_1201},{(void*)0,&l_1201,&l_1201,&l_1201},{&l_1201,&l_1201,(void*)0,&l_1201}},{{&l_1201,&l_1097,&l_1097,(void*)0},{&l_1097,&l_1097,&l_1201,&l_1201},{&l_1097,&l_1201,&l_1097,&l_1201},{&l_1201,&l_1201,(void*)0,(void*)0},{&l_1201,(void*)0,&l_1201,(void*)0},{(void*)0,&l_1201,&l_1201,&l_1201}},{{&l_1097,&l_1201,&l_1097,&l_1201},{&l_1201,&l_1097,&l_1097,(void*)0},{&l_1097,&l_1097,&l_1201,&l_1201},{(void*)0,&l_1201,&l_1201,&l_1201},{&l_1201,&l_1201,(void*)0,&l_1201},{&l_1201,&l_1097,&l_1097,(void*)0}}};
                    int i, j, k;
                    l_1201 = l_1201;
                }
                (*l_1201) = ((*l_1165) != (((safe_lshift_func_int64_t_s_s((safe_mod_func_uint8_t_u_u(252UL, (safe_rshift_func_int16_t_s_u((safe_add_func_uint16_t_u_u((g_619.f0.f2 , (*l_1201)), (p_21 <= 0UL))), 14)))), l_1211)) , ((&g_440 == l_1115) < p_20)) , (void*)0));
                (*l_1242) &= ((safe_sub_func_int8_t_s_s((((safe_div_func_int32_t_s_s((((p_21 = 8UL) != ((safe_div_func_int16_t_s_s((g_1082[8].f0.f2 , 0L), (+((safe_lshift_func_uint32_t_u_s((((~(safe_add_func_uint16_t_u_u(((p_20 > (safe_add_func_int8_t_s_s(p_20, ((l_1188 , ((safe_sub_func_int64_t_s_s((safe_mod_func_uint64_t_u_u((safe_unary_minus_func_int16_t_s((((safe_add_func_int8_t_s_s((g_377[g_1001] = (safe_add_func_uint32_t_u_u(4294967286UL, ((g_370 = ((*l_1235) = ((**l_1099) = 1L))) != ((!((*l_1097) = (((((((*l_1097) && g_71) && p_20) , l_1211) , (void*)0) != g_1237) || g_129))) || p_20))))), l_1188)) < 0x59L) <= l_1135))), l_1241)), l_1188)) && p_20)) || 1UL)))) > p_20), l_1188))) > (*l_1201)) != g_425.f0.f2), 15)) || p_20)))) | 0x402D578AC3ACE7B3LL)) , g_377[g_1001]), 0x0E001623L)) ^ l_1211) || g_163), (*l_1201))) & g_1167.f2);
                l_1274[0][6][1] |= (((l_1135 = ((*g_654) = 0L)) , ((safe_lshift_func_int64_t_s_s((((safe_mod_func_int8_t_s_s((((((((0x66L > ((p_21 = (safe_rshift_func_uint16_t_u_u((*l_1097), 5))) | (+((**g_341) = (~((*l_1201) >= ((((l_1251 = &g_653[0][6]) == &g_653[g_619.f0.f0][g_619.f0.f0]) , p_20) != (safe_rshift_func_int32_t_s_s((safe_mul_func_int64_t_s_s((safe_mul_func_int8_t_s_s((safe_mod_func_int8_t_s_s(((*l_1271) = ((*l_1270) = (safe_add_func_int8_t_s_s((g_620 == (l_1267 = g_620)), g_619.f0.f2)))), g_1171.f0)), 0xA6L)), (*g_270))), l_1135))))))))) , l_1272[3]) , l_1273) , 0xC7672B564C85F833LL) || g_377[g_619.f0.f0]) && (*l_1201)) ^ (*l_1097)), g_1082[8].f0.f2)) == (*l_1097)) || 0xE0D2L), 45)) <= 18446744073709551613UL)) | (*g_162));
            }
        }
        for (g_440 = (-30); (g_440 <= 8); ++g_440)
        { /* block id: 478 */
            uint32_t *l_1287 = &g_378;
            int32_t l_1297[10] = {8L,0L,8L,8L,0L,8L,8L,0L,8L,8L};
            uint8_t *l_1308 = &g_781[0];
            int32_t l_1310 = 0x1FB0DDFAL;
            int32_t l_1311 = 0xD0054655L;
            int i;
            (*l_1201) = ((safe_mod_func_int8_t_s_s(p_21, g_1268[0][0].f0.f0)) < (g_781[7] ^= ((((safe_rshift_func_int64_t_s_s((l_1297[2] = (safe_rshift_func_uint64_t_u_s(((safe_lshift_func_uint32_t_u_s(((*l_1287) |= (safe_rshift_func_int8_t_s_u(g_564, g_440))), (safe_rshift_func_uint8_t_u_u((safe_add_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((safe_add_func_uint8_t_u_u(g_613, (&g_1000 == (g_1296 = l_1172[4])))), 18446744073709551610UL)), ((1UL & p_21) > g_1266.f0.f0))), l_1297[0])))) < (-7L)), l_1298))), (*g_270))) , (*l_1165)) == (void*)0) >= 0UL)));
            l_1311 ^= (+(((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_s((l_1297[0] >= (safe_lshift_func_int64_t_s_s((g_370 &= ((((*g_162) != (l_1310 |= ((safe_add_func_int16_t_s_s(((l_1308 == (l_1297[4] , &g_781[1])) | (((((*l_1201) = (((((*g_270) , (void*)0) == ((*g_1296) , l_1309[6][1][0])) , g_1082[8].f0.f0) , (*g_162))) && 0xB831A3A50557A6AFLL) || 0xBCL) > p_20)), g_210[0][1])) != (-9L)))) == g_564) || l_1310)), 13))), 9)), 6L)) > p_21) , l_1297[7]));
        }
    }
    else
    { /* block id: 489 */
        int8_t l_1320 = 0xBBL;
        int8_t *l_1327[6];
        const int32_t l_1328 = 1L;
        int32_t l_1329[6] = {0xDE244FE7L,0xDE244FE7L,0xDE244FE7L,0xDE244FE7L,0xDE244FE7L,0xDE244FE7L};
        int i;
        for (i = 0; i < 6; i++)
            l_1327[i] = &g_1167.f0;
        l_1329[4] = ((*l_1097) = ((safe_mul_func_uint16_t_u_u((safe_mul_func_uint64_t_u_u(4UL, (safe_mod_func_uint32_t_u_u(((safe_sub_func_int64_t_s_s((7UL ^ (l_1320 = 65527UL)), (0x4B2942BBL & (safe_div_func_int16_t_s_s((*l_1097), (safe_sub_func_uint16_t_u_u((((safe_rshift_func_uint16_t_u_u((p_20 == (((l_1089 |= p_20) || ((p_21 <= (0UL == 0x6BL)) >= (*l_1097))) | (*l_1097))), 10)) , g_115) || 0UL), (*l_1097)))))))) || p_21), (*l_1097))))), p_20)) >= l_1328));
    }
    return p_20;
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_75 g_425.f0.f0 g_162 g_110 g_163 g_440 g_613 g_396 g_166 g_55 g_620 g_172 g_378 g_270 g_652 g_564 g_670 g_654 g_535 g_196 g_342 g_584 g_781 g_619.f0.f0 g_78 g_359.f0.f2 g_210 g_341 g_426 g_844 g_845.f2 g_370 g_322 g_359.f0.f0 g_377 g_957 g_845.f1 g_738.f0.f2 g_993 g_1001 g_71 g_1027.f2 g_1075 g_351 g_709.f3
 * writes: g_32 g_440 g_115 g_426 g_55 g_620 g_564 g_640 g_75 g_535 g_172 g_378 g_652 g_670 g_377 g_351 g_196 g_707.f3 g_71 g_844 g_359.f0.f2 g_166 g_709.f3 g_781 g_396 g_177.f3 g_954 g_110 g_845.f2 g_993 g_1001 g_425.f0.f2
 */
static int32_t * const  func_28(uint16_t  p_29, int16_t  p_30, uint32_t  p_31)
{ /* block id: 203 */
    int16_t l_588 = 0x84B3L;
    int32_t l_595 = 0L;
    union U4 *l_618 = &g_619;
    uint64_t **l_637 = (void*)0;
    uint64_t ***l_636 = &l_637;
    uint64_t ***l_638[7][5][7] = {{{&l_637,&l_637,(void*)0,(void*)0,(void*)0,&l_637,&l_637},{&l_637,&l_637,&l_637,(void*)0,(void*)0,(void*)0,(void*)0},{&l_637,&l_637,&l_637,(void*)0,(void*)0,(void*)0,(void*)0},{&l_637,&l_637,(void*)0,&l_637,&l_637,&l_637,(void*)0},{&l_637,&l_637,(void*)0,&l_637,(void*)0,(void*)0,(void*)0}},{{&l_637,&l_637,&l_637,&l_637,&l_637,(void*)0,&l_637},{(void*)0,(void*)0,&l_637,&l_637,&l_637,&l_637,&l_637},{&l_637,&l_637,&l_637,&l_637,&l_637,&l_637,(void*)0},{(void*)0,&l_637,(void*)0,&l_637,(void*)0,&l_637,(void*)0},{&l_637,&l_637,&l_637,&l_637,&l_637,&l_637,&l_637}},{{&l_637,&l_637,&l_637,(void*)0,&l_637,&l_637,(void*)0},{&l_637,(void*)0,&l_637,&l_637,&l_637,&l_637,&l_637},{(void*)0,&l_637,(void*)0,(void*)0,&l_637,&l_637,(void*)0},{&l_637,&l_637,&l_637,&l_637,&l_637,(void*)0,&l_637},{&l_637,&l_637,&l_637,&l_637,&l_637,(void*)0,&l_637}},{{(void*)0,&l_637,&l_637,(void*)0,&l_637,&l_637,&l_637},{&l_637,&l_637,&l_637,&l_637,&l_637,(void*)0,&l_637},{&l_637,&l_637,&l_637,&l_637,&l_637,&l_637,&l_637},{&l_637,&l_637,(void*)0,&l_637,(void*)0,(void*)0,&l_637},{&l_637,&l_637,(void*)0,&l_637,&l_637,(void*)0,&l_637}},{{&l_637,&l_637,&l_637,&l_637,&l_637,&l_637,(void*)0},{&l_637,&l_637,&l_637,&l_637,&l_637,&l_637,&l_637},{&l_637,&l_637,&l_637,&l_637,(void*)0,(void*)0,(void*)0},{&l_637,&l_637,&l_637,&l_637,&l_637,&l_637,&l_637},{&l_637,&l_637,(void*)0,&l_637,&l_637,&l_637,(void*)0}},{{&l_637,&l_637,&l_637,&l_637,&l_637,&l_637,(void*)0},{(void*)0,&l_637,&l_637,&l_637,&l_637,&l_637,&l_637},{&l_637,&l_637,&l_637,&l_637,&l_637,&l_637,&l_637},{&l_637,&l_637,&l_637,&l_637,&l_637,&l_637,&l_637},{&l_637,(void*)0,&l_637,&l_637,&l_637,&l_637,(void*)0}},{{&l_637,&l_637,(void*)0,&l_637,(void*)0,(void*)0,&l_637},{&l_637,&l_637,&l_637,(void*)0,&l_637,&l_637,&l_637},{&l_637,&l_637,&l_637,&l_637,(void*)0,&l_637,&l_637},{&l_637,&l_637,&l_637,&l_637,(void*)0,&l_637,&l_637},{&l_637,&l_637,&l_637,&l_637,&l_637,&l_637,&l_637}}};
    uint32_t *l_656 = &g_378;
    int32_t l_669[8] = {1L,1L,1L,1L,1L,1L,1L,1L};
    union U3 *l_708 = &g_709;
    const int16_t *l_717 = &g_172;
    const int16_t **l_716 = &l_717;
    const int16_t ***l_715 = &l_716;
    int16_t *l_747 = &l_588;
    int8_t *l_779 = &g_32;
    uint32_t l_805 = 3UL;
    union U3 **l_851 = &g_176;
    int16_t ***l_937 = &g_653[3][0];
    int16_t ****l_936 = &l_937;
    const uint64_t *l_952 = &g_564;
    const uint64_t **l_951[4][4] = {{&l_952,&l_952,&l_952,&l_952},{&l_952,&l_952,&l_952,&l_952},{&l_952,&l_952,&l_952,&l_952},{&l_952,&l_952,&l_952,&l_952}};
    uint64_t l_996[7] = {18446744073709551610UL,18446744073709551611UL,18446744073709551610UL,18446744073709551610UL,18446744073709551611UL,18446744073709551610UL,18446744073709551610UL};
    uint64_t l_1013 = 0UL;
    int64_t l_1025 = 0L;
    struct S1 *l_1026 = &g_1027;
    int64_t l_1028[2][7] = {{0xC385692757F56F08LL,0xC385692757F56F08LL,0xCDCAC2F8D3D1518ELL,0xC385692757F56F08LL,0xC385692757F56F08LL,0xCDCAC2F8D3D1518ELL,0xC385692757F56F08LL},{0xC385692757F56F08LL,0x427DC455F72C4001LL,0x427DC455F72C4001LL,0xC385692757F56F08LL,0x427DC455F72C4001LL,0x427DC455F72C4001LL,0xC385692757F56F08LL}};
    uint16_t *l_1037 = &g_425.f0.f2;
    uint8_t l_1038 = 0xBAL;
    int64_t l_1046 = 0x60BAED941F832A2ELL;
    volatile uint16_t * volatile *l_1079[4][9][4] = {{{(void*)0,&g_1076,(void*)0,&g_1076},{&g_1076,&g_1076,(void*)0,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,(void*)0},{&g_1076,&g_1076,&g_1076,(void*)0},{&g_1076,(void*)0,&g_1076,(void*)0},{&g_1076,&g_1076,(void*)0,(void*)0},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076}},{{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,(void*)0},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,(void*)0,&g_1076},{&g_1076,&g_1076,&g_1076,(void*)0},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076}},{{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,(void*)0,(void*)0},{&g_1076,&g_1076,(void*)0,&g_1076},{(void*)0,&g_1076,(void*)0,&g_1076},{&g_1076,&g_1076,(void*)0,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,(void*)0},{&g_1076,&g_1076,&g_1076,(void*)0},{&g_1076,(void*)0,&g_1076,(void*)0}},{{&g_1076,&g_1076,(void*)0,(void*)0},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,(void*)0},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076},{&g_1076,&g_1076,&g_1076,&g_1076}}};
    int i, j, k;
lbl_960:
    if (l_588)
    { /* block id: 204 */
        uint8_t l_596[10] = {0x0FL,0x0FL,0UL,0x67L,0UL,0x0FL,0x0FL,0UL,0x67L,0UL};
        int32_t l_644[6][7][5] = {{{0x23E1AF7FL,0xA13D8712L,0xBBF2B9FAL,0x839FB643L,0x839FB643L},{0x867D164AL,6L,0x867D164AL,0xC6DC02D0L,(-4L)},{(-1L),1L,1L,0x23E1AF7FL,(-8L)},{0x9FAC21F6L,0xC54DFCB7L,(-10L),0x11AC9D4FL,0L},{0x4DBCA335L,0xA2B276AFL,1L,(-8L),(-10L)},{7L,0xF584E6B7L,0x867D164AL,(-1L),0x2D6456FFL},{0x255587FAL,0L,0xBBF2B9FAL,0x70A53E3AL,0x67C8E55DL}},{{0xEE04306BL,4L,0x2D6456FFL,0xF584E6B7L,0x11AC9D4FL},{0x70A53E3AL,0L,1L,0xB760FEBBL,0x4DBCA335L},{0x11AC9D4FL,3L,0xE5D80AE6L,0x5BFCE8C9L,0L},{1L,0xAEDE3505L,0xDF0F8CB4L,0L,0xA2B276AFL},{1L,0x444E6032L,0x444E6032L,1L,(-3L)},{0L,0x70A53E3AL,0x25309283L,(-10L),0x839FB643L},{(-9L),4L,(-1L),0xEE04306BL,3L}},{{0xAEDE3505L,0x0E5EDA3BL,0x4DBCA335L,(-10L),0x0E5EDA3BL},{0L,0xE1C0AD85L,3L,1L,7L},{0xE3B519E1L,0xA2B276AFL,0L,0L,1L},{0xE1C0AD85L,(-1L),0xC6DC02D0L,0x5BFCE8C9L,1L},{0xB10875E4L,0xE7CD0ECFL,0x938F3063L,0xB760FEBBL,(-1L)},{0xC9519E02L,6L,0xEE04306BL,0xF584E6B7L,(-1L)},{0xAEDE3505L,0L,1L,0x70A53E3AL,1L}},{{1L,(-1L),0xD1335541L,(-1L),1L},{0x0E5EDA3BL,0x23E1AF7FL,0xE3B519E1L,(-8L),0x70A53E3AL},{1L,2L,0xC6DC02D0L,0x11AC9D4FL,(-1L)},{0x4E6CF95BL,0xB10875E4L,0xFED93C9BL,0x23E1AF7FL,0x70A53E3AL},{0x2D6456FFL,0x11AC9D4FL,4L,0xC6DC02D0L,1L},{0x70A53E3AL,5L,0x4DBCA335L,0x839FB643L,1L},{0x0578E4B4L,0x9FAC21F6L,1L,0xC54DFCB7L,(-1L)}},{{0x464482F0L,1L,5L,0x464482F0L,(-1L)},{7L,0x2D6456FFL,0x444E6032L,1L,1L},{(-10L),0xB10875E4L,0x8BFC1929L,0x4E6CF95BL,1L},{(-4L),7L,(-9L),(-9L),7L},{(-1L),0xEC3D8817L,1L,0x255587FAL,0x0E5EDA3BL},{4L,(-1L),0x8C464A7DL,0xC54DFCB7L,3L},{(-1L),0xC4370C23L,0x01FFECC0L,0x54BB99AEL,0x4DBCA335L}},{{(-3L),0x01306C3FL,0x5060506FL,2L,3L},{0x71290EFDL,0L,0x23E1AF7FL,0x464482F0L,0L},{1L,(-4L),0xE5D80AE6L,0xD1335541L,0xC6DC02D0L},{0xE3B519E1L,0xFED93C9BL,0xD4B1048BL,0L,0x938F3063L},{0x444E6032L,0x4121A72CL,(-4L),0x2D6456FFL,0xEE04306BL},{1L,5L,0x01FFECC0L,0x652A006CL,1L},{0xF584E6B7L,0x5060506FL,0xD1335541L,0x4121A72CL,0xD1335541L}}};
        int i, j, k;
        for (g_32 = 0; (g_32 <= 0); g_32 += 1)
        { /* block id: 207 */
            const uint32_t l_615 = 8UL;
            int32_t l_651 = 0x1FA7C76EL;
            for (g_440 = 3; (g_440 >= 0); g_440 -= 1)
            { /* block id: 210 */
                int32_t *l_589 = (void*)0;
                int32_t *l_590 = &g_426;
                int32_t *l_591 = &g_426;
                int32_t *l_592 = &g_55;
                int32_t *l_593 = &g_426;
                int32_t *l_594 = (void*)0;
                uint8_t *l_614 = &g_115;
                union U4 **l_621 = &g_620;
                int i;
                l_596[1]++;
                (*l_592) &= (g_75[g_32] | (safe_sub_func_int16_t_s_s(((safe_mul_func_uint64_t_u_u(((65526UL || 0x0B90L) ^ g_425.f0.f0), (safe_rshift_func_uint8_t_u_u((safe_add_func_uint64_t_u_u(((*l_591) = ((((*l_614) = (safe_sub_func_int32_t_s_s((-2L), (safe_mod_func_int64_t_s_s((((((l_596[1] , (((safe_mod_func_int64_t_s_s(0x181900239E6223E3LL, (*g_162))) & ((((0xBEA0L >= g_440) | l_595) & 0L) < 6L)) >= l_596[1])) | p_29) , &g_77[0][2]) == (void*)0) | p_31), g_613))))) == g_396) , 0x1597FA753CCF125ELL)), l_595)), g_166)))) < 0x9EC429AF80D826CFLL), l_595)));
                if (l_615)
                    break;
                (*l_593) = (safe_sub_func_uint32_t_u_u((l_618 == ((*l_621) = g_620)), 1UL));
            }
            for (g_564 = 0; (g_564 <= 3); g_564 += 1)
            { /* block id: 221 */
                uint64_t ****l_639[8] = {&l_636,&l_636,&l_636,&l_636,&l_636,&l_636,&l_636,&l_636};
                int16_t *l_647 = &l_588;
                int16_t *l_648 = &g_535;
                int16_t *l_649 = &g_172;
                int32_t l_650 = 0xDF2252E6L;
                int16_t ** volatile **l_655 = &g_652;
                int i;
                l_651 &= (p_30 ^ (((l_596[0] , (safe_sub_func_uint32_t_u_u((((safe_rshift_func_uint32_t_u_u((g_378 = ((p_31 , ((safe_lshift_func_uint16_t_u_u(((safe_rshift_func_int64_t_s_u((safe_rshift_func_int32_t_s_u(((safe_add_func_uint64_t_u_u((((*l_649) |= (((l_636 != (g_640[0] = l_638[3][3][1])) || (safe_add_func_int8_t_s_s((4UL | l_644[0][4][1]), 9UL))) <= ((safe_mod_func_int16_t_s_s(((*l_648) = ((*l_647) = (g_75[g_32] = p_31))), l_596[1])) != p_30))) == g_378), l_650)) , l_588), g_32)), p_30)) ^ l_650), 4)) < l_615)) != l_615)), p_29)) && (*g_270)) >= p_30), 0x0BFA9227L))) < 0x1EDDL) ^ (*g_270)));
                (*l_655) = g_652;
                return &g_55;
            }
        }
        return &g_55;
    }
    else
    { /* block id: 234 */
        int8_t l_661 = (-1L);
        int32_t l_668[10][8][3] = {{{0xAC476CD2L,1L,1L},{0x28AD5CB1L,1L,0xEB4BEAC0L},{0xD6680812L,0x2A691310L,0xFFE716FFL},{3L,(-3L),0L},{0x93066FB6L,0x9766265BL,0xAC476CD2L},{(-4L),0xDA11F161L,(-4L)},{1L,(-1L),1L},{0x57D91C38L,0x50379F08L,0x28AD5CB1L}},{{1L,1L,0x9766265BL},{0L,0x672DC300L,5L},{1L,0xD1F0CB5AL,0xDEC0C189L},{0x57D91C38L,0x2030D99BL,0x672DC300L},{1L,0L,1L},{(-4L),0x51902C89L,1L},{0x93066FB6L,(-1L),0x347BEF7BL},{3L,0x16BC9A17L,0x9BB8D947L}},{{0xD6680812L,0x347BEF7BL,0x8FB16E74L},{0x28AD5CB1L,0x55259EDDL,0xEFB3034AL},{0xAC476CD2L,0x9C0841A4L,1L},{(-1L),0x57D91C38L,0x57D91C38L},{0x8FB16E74L,(-1L),0x505B77DFL},{0L,0x9BB8D947L,0xA1BDC81EL},{(-1L),0x3F327079L,0xA4C76AA2L},{0x55259EDDL,0L,0xA0E53CFAL}},{{0xAF827031L,0x3F327079L,0x4A55C709L},{1L,0x9BB8D947L,1L},{1L,(-1L),(-6L)},{0x198E21DFL,0x57D91C38L,(-1L)},{1L,0x9C0841A4L,(-1L)},{0x6C2F7DB6L,0x55259EDDL,0x51902C89L},{0xCC394D7FL,0x347BEF7BL,0x4A3ADFBAL},{0xDA11F161L,0x16BC9A17L,0xAC6FBC52L}},{{0x9C0841A4L,(-1L),0xD6680812L},{0xAC6FBC52L,0x51902C89L,0xB063DA1BL},{0L,0L,(-6L)},{0L,0x2030D99BL,0x67460903L},{1L,0xD1F0CB5AL,0x93066FB6L},{0x3C18AA77L,0x672DC300L,0x55259EDDL},{(-1L),1L,0x93066FB6L},{0xB063DA1BL,0x50379F08L,0x67460903L}},{{0xADFC9EE7L,(-1L),(-6L)},{0x9BB8D947L,0xDA11F161L,0xB063DA1BL},{0xA0ACA859L,0x9766265BL,0xD6680812L},{(-1L),(-3L),0xAC6FBC52L},{0x4A55C709L,0x2A691310L,0x4A3ADFBAL},{(-1L),1L,0x51902C89L},{1L,1L,(-1L)},{4L,0xA0E53CFAL,1L}},{{(-1L),0xA0ACA859L,(-1L)},{0x672DC300L,0xA1BDC81EL,1L},{(-1L),0x3F327079L,(-1L)},{0x57D91C38L,(-3L),(-4L)},{0x50B93B3DL,0xADFC9EE7L,0x347BEF7BL},{0x57D91C38L,0L,4L},{(-1L),0xD6680812L,0xADFC9EE7L},{0x672DC300L,0L,(-1L)}},{{(-1L),0x9766265BL,1L},{0x67460903L,0x50379F08L,0xB063DA1BL},{1L,0x505B77DFL,0xAC476CD2L},{0x16BC9A17L,0xB063DA1BL,(-1L)},{(-1L),1L,(-1L)},{1L,(-4L),(-3L)},{1L,(-1L),(-1L)},{(-1L),0L,0L}},{{0L,0xAC476CD2L,0x93066FB6L},{0L,0x9BB8D947L,0xEFB3034AL},{1L,0xA4C76AA2L,0xD4D97DC0L},{0x6C2F7DB6L,0x9BB8D947L,0x55259EDDL},{1L,0xAC476CD2L,0x2A691310L},{5L,0L,0L},{(-1L),(-1L),1L},{(-9L),(-4L),0xA1BDC81EL}},{{(-6L),1L,0x9766265BL},{(-1L),0xB063DA1BL,0x7B678B7FL},{0xA0ACA859L,0x505B77DFL,0L},{(-4L),0x50379F08L,0x16BC9A17L},{0L,0x9766265BL,0L},{0L,0L,3L},{0xA4C76AA2L,0xD6680812L,1L},{(-3L),0L,0x67460903L}}};
        int16_t ***l_689 = &g_653[3][0];
        int16_t ****l_688[6] = {&l_689,&l_689,&l_689,&l_689,&l_689,&l_689};
        const uint64_t **l_694 = (void*)0;
        const uint64_t ***l_693 = &l_694;
        const uint64_t ****l_692 = &l_693;
        union U4 *l_737 = &g_738;
        union U3 **l_850[5] = {&g_176,&g_176,&g_176,&g_176,&g_176};
        int i, j, k;
        for (g_564 = 0; (g_564 <= 0); g_564 += 1)
        { /* block id: 237 */
            int32_t l_667 = 0xDDBFA053L;
            int64_t **l_772 = &g_270;
            int32_t l_780[6];
            union U4 **l_817 = &l_737;
            const union U3 **l_849 = (void*)0;
            int i;
            for (i = 0; i < 6; i++)
                l_780[i] = 0x99C2FC10L;
            if ((0x9A94DF30L & ((g_564 <= g_425.f0.f0) | ((&g_378 == l_656) && ((safe_mul_func_int64_t_s_s(0x310E410B4E7FC87ELL, p_30)) | ((safe_rshift_func_int64_t_s_s(((p_29 | ((l_661 || 18446744073709551615UL) | p_29)) && 65535UL), (*g_162))) , (-1L)))))))
            { /* block id: 238 */
                int32_t *l_662 = &g_55;
                int32_t *l_663 = &l_595;
                int32_t *l_664 = &l_595;
                int32_t *l_665 = &g_55;
                int32_t *l_666[4] = {&g_426,&g_426,&g_426,&g_426};
                int i;
                g_670--;
                return &g_426;
            }
            else
            { /* block id: 241 */
                int32_t *l_690[6];
                int32_t l_691 = (-1L);
                int32_t l_695 = (-1L);
                int32_t *l_696 = &l_667;
                union U3 *l_706[4];
                int8_t *l_710 = &g_377[9];
                int16_t ** const *l_815 = &g_653[3][0];
                int16_t ** const **l_814[5] = {&l_815,&l_815,&l_815,&l_815,&l_815};
                int i;
                for (i = 0; i < 6; i++)
                    l_690[i] = &g_71;
                for (i = 0; i < 4; i++)
                    l_706[i] = &g_707;
                (*l_696) = (safe_add_func_int32_t_s_s(((safe_rshift_func_int8_t_s_s((((safe_mul_func_uint8_t_u_u(((*g_654) || ((l_661 == 0xE7CFD41BEF0C2259LL) , ((((safe_sub_func_uint32_t_u_u((((safe_mod_func_uint32_t_u_u(((l_691 |= ((g_196 , (l_669[7] || ((p_30 >= (safe_sub_func_uint64_t_u_u((safe_div_func_int32_t_s_s(((safe_unary_minus_func_int8_t_s(1L)) ^ ((*g_654) = ((&g_652 == l_688[5]) , 0x1971L))), l_667)), (*g_270)))) , (-6L)))) > g_613)) , l_667), p_30)) != (*g_162)) , 0xABE29CB1L), g_396)) , 0L) , l_692) == &l_693))), p_31)) , 9UL) | p_31), 7)) >= l_695), g_163));
                if ((safe_mod_func_uint8_t_u_u(l_668[5][6][2], (safe_add_func_uint32_t_u_u(((*l_656) &= (((*g_654) |= l_595) && (+(65531UL & (((~(+(safe_sub_func_int8_t_s_s((l_706[2] == (l_708 = ((*g_270) , l_706[0]))), ((*l_710) = p_29))))) , (((safe_sub_func_uint64_t_u_u(((safe_mod_func_int64_t_s_s((l_667 < ((*g_270) > 0x895E6731CF2AFD43LL)), l_669[7])) , (*l_696)), p_30)) , 0x3B98326D50AE2CDALL) && p_31)) <= l_667))))), 0xB7FF08CFL)))))
                { /* block id: 249 */
                    int64_t l_720 = 0L;
                    uint64_t *l_732 = &g_564;
                    int8_t *l_739[6][5][8] = {{{&g_210[2][3],(void*)0,&g_377[7],&g_377[7],(void*)0,&g_377[7],(void*)0,&g_377[7]},{&g_210[2][3],(void*)0,(void*)0,&g_377[7],(void*)0,&l_661,&g_377[2],&g_210[3][6]},{&g_377[2],(void*)0,&g_210[0][9],(void*)0,&g_377[7],&l_661,&g_210[3][2],(void*)0},{&g_377[7],&g_377[7],(void*)0,&g_210[0][1],&g_377[7],&g_377[7],&g_210[0][1],(void*)0},{(void*)0,(void*)0,&g_377[8],&g_210[2][3],(void*)0,&g_377[0],&l_661,&g_377[7]}},{{&g_377[7],&l_661,&g_210[0][9],(void*)0,&g_377[7],&g_210[3][2],&g_377[7],&g_377[7]},{&l_661,(void*)0,&g_210[1][6],&g_210[2][3],(void*)0,(void*)0,(void*)0,(void*)0},{&g_210[0][1],&g_377[2],&l_661,&g_210[0][1],(void*)0,&g_210[0][1],&g_377[7],(void*)0},{&g_210[3][2],&g_210[3][6],&g_377[2],(void*)0,&g_377[7],(void*)0,&g_377[2],&g_210[3][6]},{&g_377[2],&l_661,&g_377[8],(void*)0,&g_210[2][4],&l_661,&g_377[7],&g_210[0][1]}},{{(void*)0,&l_661,&g_377[2],&g_377[7],&l_661,(void*)0,&g_377[7],&g_210[2][0]},{&l_661,&g_377[7],&g_377[8],&l_661,(void*)0,&g_210[0][1],&g_377[0],&l_661},{(void*)0,&g_210[0][1],&g_377[0],&l_661,&g_377[8],&l_661,&g_377[2],&l_661},{&g_377[7],(void*)0,&g_210[0][1],&g_377[7],&g_377[7],&g_210[0][1],(void*)0,&g_377[7]},{&g_210[0][1],&l_661,&g_210[2][4],&g_377[0],(void*)0,(void*)0,(void*)0,&g_210[1][6]}},{{(void*)0,&g_377[7],&l_661,&g_210[3][2],&g_377[0],(void*)0,&g_377[7],&g_377[8]},{&g_377[2],&l_661,&l_661,(void*)0,&l_661,&g_210[0][1],(void*)0,&g_210[3][2]},{&g_377[8],(void*)0,&g_377[7],&g_210[0][1],&g_210[0][9],&l_661,&g_210[0][1],&g_377[2]},{&l_661,&g_210[0][1],&l_661,(void*)0,&l_661,&g_210[0][1],&l_661,&l_661},{&g_377[7],&g_377[7],&g_377[7],&g_377[7],&g_210[3][2],(void*)0,(void*)0,&g_210[3][2]}},{{(void*)0,&l_661,(void*)0,(void*)0,&g_210[3][2],&l_661,&l_661,(void*)0},{&g_377[7],(void*)0,&g_377[0],&g_210[3][2],&l_661,&g_377[7],(void*)0,(void*)0},{&l_661,&g_210[1][6],(void*)0,(void*)0,&g_210[0][9],&g_210[3][6],&g_377[7],&g_377[7]},{&g_377[8],&l_661,&l_661,&l_661,&l_661,&g_377[8],&g_210[0][1],&g_210[2][0]},{&g_377[2],&l_661,&g_377[8],&l_661,&g_377[0],&g_210[0][1],(void*)0,&l_661}},{{(void*)0,&g_377[7],&g_377[7],&l_661,(void*)0,&g_377[2],&g_377[2],&g_210[2][0]},{&g_210[0][1],(void*)0,(void*)0,&l_661,&g_377[7],(void*)0,&g_377[8],&g_377[7]},{&g_377[7],&l_661,&g_210[2][4],(void*)0,&g_377[8],(void*)0,&l_661,(void*)0},{(void*)0,&g_210[3][2],&g_377[7],&g_210[3][2],(void*)0,(void*)0,&g_377[7],(void*)0},{&l_661,&l_661,&g_377[7],(void*)0,&l_661,(void*)0,(void*)0,&g_210[3][2]}}};
                    int16_t l_740 = 3L;
                    uint64_t ** const l_741 = &l_732;
                    const uint64_t l_782[3] = {7UL,7UL,7UL};
                    uint16_t *l_806 = &g_707.f3;
                    int32_t *l_807 = &l_695;
                    int i, j, k;
                    for (g_351 = 0; (g_351 <= 2); g_351 += 1)
                    { /* block id: 252 */
                        int16_t l_723 = (-7L);
                        if (p_31)
                            break;
                        l_723 = (((void*)0 != l_715) | (safe_mod_func_uint64_t_u_u(((*g_342) = l_720), (safe_lshift_func_int16_t_s_u((p_31 < l_668[9][6][1]), 3)))));
                        (*l_696) = ((safe_add_func_uint32_t_u_u((((safe_div_func_int16_t_s_s(((safe_mod_func_uint8_t_u_u((safe_lshift_func_int32_t_s_u((l_732 == (void*)0), 1)), (p_30 & ((((safe_mod_func_uint64_t_u_u((safe_rshift_func_uint64_t_u_s((g_584 == l_737), 40)), l_667)) ^ p_30) != (l_739[3][0][0] != &g_32)) == p_30)))) <= l_740), 0x5A75L)) < p_29) <= p_30), 0UL)) , p_29);
                        g_55 ^= ((((g_707.f3 = ((((l_741 != (void*)0) || (((safe_div_func_uint64_t_u_u(((&p_30 != &p_30) >= ((1L < (((((safe_unary_minus_func_int64_t_s((safe_lshift_func_int8_t_s_s(0x1FL, (&p_30 != (l_747 = (void*)0)))))) || (safe_mod_func_int64_t_s_s(((safe_sub_func_int64_t_s_s((((safe_rshift_func_int32_t_s_s((*l_696), l_720)) , 0xC2D0L) , (*g_162)), l_668[5][6][2])) ^ 0x32563B8E7DEECD70LL), p_31))) || l_723) <= p_29) , p_29)) <= p_31)), 9UL)) & l_668[3][5][2]) & 1UL)) >= l_667) ^ p_31)) <= p_30) < 0UL) & 0x3FB514DCF4F7CB32LL);
                    }
                    for (g_71 = 0; (g_71 <= 2); g_71 += 1)
                    { /* block id: 263 */
                        int16_t ***l_756 = &g_653[3][0];
                        int64_t ***l_769 = (void*)0;
                        int64_t **l_771[6];
                        int64_t ***l_770 = &l_771[2];
                        uint8_t *l_783 = &g_115;
                        int i;
                        for (i = 0; i < 6; i++)
                            l_771[i] = &g_270;
                        g_426 = (safe_rshift_func_uint32_t_u_s(p_29, 11));
                        (*l_696) &= 0xA9B4B169L;
                        if (p_29)
                            break;
                        l_669[7] &= ((((l_756 != &g_653[3][0]) , (((*l_783) = ((((safe_div_func_uint32_t_u_u(((*l_656) = ((safe_lshift_func_uint16_t_u_s((safe_mul_func_uint64_t_u_u((((safe_mod_func_uint64_t_u_u((safe_lshift_func_int64_t_s_s(((safe_add_func_int8_t_s_s(((((*l_770) = &g_270) != l_772) ^ ((*l_696) = (-7L))), g_396)) <= ((safe_rshift_func_uint64_t_u_s((g_75[0] >= ((safe_mul_func_int32_t_s_s((safe_sub_func_int16_t_s_s((p_31 , ((void*)0 != l_779)), l_780[5])), l_780[5])) && g_781[7])), (*g_162))) , (*g_342))), 16)), 18446744073709551615UL)) > p_30) | 0x4905EDB1B5C0D9FALL), l_780[3])), p_31)) <= 0x6E70L)), 4294967286UL)) , p_29) >= 0xAAFD81B0L) >= l_782[1])) <= g_619.f0.f0)) , l_780[5]) >= 1L);
                    }
                    (*l_696) &= 0xC4335425L;
                    if ((safe_div_func_int32_t_s_s((*l_696), ((*l_807) = ((safe_sub_func_int8_t_s_s(((((((g_78 != (l_668[1][2][0] ^= (0x950FL == ((safe_add_func_int64_t_s_s((*l_696), ((*g_342) = ((safe_rshift_func_int64_t_s_u(((((safe_sub_func_uint16_t_u_u(l_669[7], (safe_mul_func_uint8_t_u_u((((safe_div_func_int8_t_s_s((-6L), p_30)) >= ((((l_805 = (safe_sub_func_int8_t_s_s(((safe_mod_func_int64_t_s_s(((l_740 == (~((*g_654) = ((safe_rshift_func_int16_t_s_u((*l_696), 14)) | (-7L))))) == g_359.f0.f2), (-1L))) && 0x6DL), g_359.f0.f2))) == p_30) & (-8L)) != 0x81L)) == 0x624B1381L), (*l_696))))) >= p_30) >= (*l_696)) , (*g_270)), 37)) < 0x9888L)))) || 0xF7D15C7DL)))) | l_740) > 18446744073709551615UL) , &g_781[7]) != (void*)0) != p_29), 1L)) , 0xEFA26D19L)))))
                    { /* block id: 279 */
                        int16_t ** const **l_816 = &l_815;
                        int32_t l_824 = (-1L);
                        (*l_696) = ((safe_mod_func_uint16_t_u_u(65532UL, (*l_696))) , (safe_lshift_func_uint32_t_u_u((safe_add_func_uint8_t_u_u(((l_816 = l_814[0]) == ((((void*)0 != l_817) < (((safe_div_func_uint8_t_u_u((0xBBL != (((safe_sub_func_uint16_t_u_u(((l_780[5] , (*l_772)) == &g_440), 0x5D72L)) != 0x8266L) != 0xC6L)), l_824)) || 0xD948AD7060BD7BBDLL) , l_668[3][4][1])) , &g_652)), p_30)), g_210[0][1])));
                    }
                    else
                    { /* block id: 282 */
                        const int32_t * const l_841 = &l_780[1];
                        int32_t *l_842 = &l_669[7];
                        int32_t *l_843 = &l_668[5][6][2];
                        (*l_843) ^= (safe_rshift_func_int8_t_s_u((safe_add_func_uint64_t_u_u(l_595, ((l_667 = (safe_sub_func_int8_t_s_s((safe_add_func_uint32_t_u_u((safe_unary_minus_func_uint8_t_u(((safe_rshift_func_int32_t_s_s(l_595, 25)) ^ p_29))), ((+(((!(p_30 && (safe_sub_func_uint16_t_u_u((*l_696), ((+(l_841 != (l_842 = &g_426))) | ((((&g_210[2][7] != ((((*l_656) = ((*l_696) | (**g_341))) <= l_669[0]) , (void*)0)) <= p_31) != l_588) < l_669[7])))))) != 0x9549L) | p_30)) ^ (-2L)))), (*l_807)))) > 0x63BF7357D956EB4BLL))), 2));
                        if ((*l_842))
                            continue;
                        l_669[0] |= p_31;
                    }
                }
                else
                { /* block id: 290 */
                    struct S1 **l_846[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_846[i] = &g_844[3];
                    g_844[2] = g_844[2];
                    for (g_426 = 0; (g_426 <= 0); g_426 += 1)
                    { /* block id: 294 */
                        int32_t *l_852[10][7][1] = {{{&l_668[4][3][1]},{&l_668[3][3][2]},{&l_668[4][3][1]},{&l_668[4][3][1]},{&l_668[3][3][2]},{&l_668[4][3][1]},{&l_668[4][3][1]}},{{&l_668[3][3][2]},{&l_668[4][3][1]},{&l_668[4][3][1]},{&l_668[3][3][2]},{&l_668[4][3][1]},{&l_668[4][3][1]},{&l_668[3][3][2]}},{{&l_668[4][3][1]},{&l_668[4][3][1]},{&l_668[3][3][2]},{&l_668[4][3][1]},{&l_668[4][3][1]},{&l_668[3][3][2]},{&l_668[4][3][1]}},{{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]}},{{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0}},{{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]}},{{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]}},{{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0}},{{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]}},{{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]},{(void*)0},{&l_668[3][3][2]},{&l_668[3][3][2]}}};
                        int i, j, k;
                        g_55 |= ((0x2B3E4690L >= 1UL) < ((*l_696) = (l_849 != (l_851 = l_850[1]))));
                        (*l_817) = g_620;
                    }
                }
            }
            for (g_359.f0.f2 = 0; (g_359.f0.f2 <= 0); g_359.f0.f2 += 1)
            { /* block id: 304 */
                uint64_t *** const *l_860 = &g_640[0];
                for (g_535 = 0; (g_535 >= 0); g_535 -= 1)
                { /* block id: 307 */
                    uint64_t ****l_857 = &l_638[3][4][1];
                    if (p_30)
                        break;
                    for (g_172 = 2; (g_172 >= 0); g_172 -= 1)
                    { /* block id: 311 */
                        uint64_t *****l_858 = (void*)0;
                        uint64_t *****l_859 = &l_857;
                        int32_t *l_869 = &l_780[5];
                        int i, j;
                        (*l_869) = ((p_30 = (safe_div_func_uint8_t_u_u((((*l_859) = l_857) != l_860), ((-10L) || ((-1L) > ((safe_div_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((safe_mul_func_int64_t_s_s(l_805, 0x3DE326A5FF566BC0LL)), (safe_mod_func_int16_t_s_s(p_29, p_30)))), 1UL)) == (**g_341))))))) & 0L);
                        l_667 |= (safe_sub_func_int32_t_s_s(p_31, 0xA24A0C58L));
                        if (l_780[5])
                            break;
                    }
                    for (g_166 = 0; (g_166 <= 0); g_166 += 1)
                    { /* block id: 320 */
                        return &g_426;
                    }
                }
            }
        }
    }
    for (g_351 = 0; (g_351 > 17); g_351 = safe_add_func_int32_t_s_s(g_351, 1))
    { /* block id: 329 */
        int32_t l_884[7] = {(-8L),7L,(-8L),(-8L),7L,(-8L),(-8L)};
        int32_t l_918 = 0x89337454L;
        int32_t l_992 = (-1L);
        int i;
        for (g_709.f3 = 0; (g_709.f3 != 9); g_709.f3 = safe_add_func_int8_t_s_s(g_709.f3, 9))
        { /* block id: 332 */
            uint8_t *l_880[1];
            uint64_t ***l_881 = &g_641;
            int32_t l_914 = 0x737CA2E2L;
            uint16_t *l_917 = (void*)0;
            uint32_t l_963 = 1UL;
            uint32_t l_986 = 0x789990F3L;
            int32_t l_999 = 0x9035DCA8L;
            int32_t *l_1014 = &l_669[7];
            int i;
            for (i = 0; i < 1; i++)
                l_880[i] = &g_115;
            if ((l_588 || (l_588 || ((safe_div_func_int64_t_s_s((safe_add_func_int8_t_s_s(((void*)0 != &g_176), (g_781[7] = g_425.f0.f0))), 18446744073709551615UL)) , (((((void*)0 != l_881) < (*g_270)) >= g_564) <= p_30)))))
            { /* block id: 334 */
                uint64_t l_913 = 3UL;
                int16_t ****l_938 = &l_937;
                uint64_t ** const l_956 = &g_527;
                int32_t l_987[3][2];
                int i, j;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_987[i][j] = 0x9E2B92FDL;
                }
                for (g_426 = 0; (g_426 <= 6); g_426 = safe_add_func_int8_t_s_s(g_426, 3))
                { /* block id: 337 */
                    int32_t l_915 = 0x8D094913L;
                    uint16_t *l_916 = &g_177[4].f3;
                    if ((((p_29 & ((g_396--) < ((*l_779) = (0x345594E7L < ((safe_mod_func_int8_t_s_s(g_845[2].f2, (safe_sub_func_uint64_t_u_u((((safe_lshift_func_uint64_t_u_u(((*g_342) = (safe_lshift_func_uint32_t_u_s(((((*l_916) = (safe_rshift_func_int8_t_s_s(((safe_lshift_func_uint64_t_u_s((safe_mod_func_uint32_t_u_u(g_110, (safe_sub_func_int16_t_s_s((safe_rshift_func_int16_t_s_u(0x633DL, (safe_lshift_func_int64_t_s_u(((((safe_rshift_func_uint32_t_u_s((((((*g_654) = ((((safe_sub_func_int64_t_s_s(1L, (safe_div_func_int8_t_s_s(0L, g_370)))) | l_913) ^ p_30) , (*g_654))) , l_914) <= p_29) ^ g_322), l_915)) , (void*)0) == (void*)0) != g_359.f0.f0), l_884[2])))), 0x6B01L)))), 2)) > p_30), 3))) , l_917) != &g_166), 13))), p_31)) == p_29) | 0xC165L), (*g_270))))) == g_377[0]))))) , (void*)0) != (void*)0))
                    { /* block id: 343 */
                        int32_t *l_919 = &l_914;
                        (*l_919) ^= (l_918 ^= ((void*)0 != &g_370));
                        return &g_55;
                    }
                    else
                    { /* block id: 347 */
                        const uint64_t ***l_953[7] = {&l_951[3][0],&l_951[3][0],&l_951[3][0],&l_951[3][0],&l_951[3][0],&l_951[3][0],&l_951[3][0]};
                        uint32_t *l_958 = (void*)0;
                        uint32_t *l_959 = &g_670;
                        int i;
                        g_845[2].f2 &= ((safe_rshift_func_uint32_t_u_s((safe_sub_func_uint64_t_u_u((g_75[0] | (safe_rshift_func_uint8_t_u_s(g_172, g_196))), (safe_add_func_int64_t_s_s(((safe_rshift_func_int64_t_s_u((safe_div_func_uint8_t_u_u((safe_rshift_func_uint32_t_u_s(((*l_959) = (((l_936 != l_938) < (((((safe_mod_func_int64_t_s_s((safe_mod_func_uint32_t_u_u(((*l_656) = 0x57FBF8FAL), l_913)), (safe_rshift_func_uint8_t_u_u((safe_mul_func_int64_t_s_s(((*g_270) = ((0xA0L ^ ((safe_add_func_uint64_t_u_u((((safe_add_func_uint16_t_u_u(((g_954 = l_951[3][0]) != l_956), p_30)) >= p_29) >= 0xB8C81B30EC500006LL), p_30)) < g_957)) < 0xADEA2FB830327289LL)), 18446744073709551615UL)), 4)))) >= l_915) , (**g_341)) , 0xDFL) <= 0x75L)) != g_845[2].f1)), 18)), p_31)), 0)) | 0xA3L), p_30)))), 9)) < p_29);
                    }
                }
                if (g_619.f0.f0)
                    goto lbl_960;
                if ((p_29 , p_30))
                { /* block id: 356 */
                    int32_t *l_961 = &g_845[2].f2;
                    int32_t *l_962[4] = {&l_669[7],&l_669[7],&l_669[7],&l_669[7]};
                    uint32_t *l_980 = (void*)0;
                    uint32_t *l_981 = &l_805;
                    uint16_t *l_982 = (void*)0;
                    int32_t l_985 = 0xAE830523L;
                    int i;
                    ++l_963;
                    if ((safe_add_func_uint16_t_u_u(((safe_rshift_func_uint32_t_u_u(((*l_656) |= 0xAEEC32F6L), ((safe_lshift_func_uint64_t_u_u((l_963 != (safe_div_func_int64_t_s_s((((g_322 ^ (safe_add_func_int64_t_s_s((safe_add_func_int8_t_s_s((((safe_mul_func_uint32_t_u_u(((*l_981) = p_30), (l_982 != ((safe_sub_func_uint8_t_u_u(l_669[7], l_985)) , &g_957)))) > g_738.f0.f2) && l_986), p_30)), l_588))) , p_31) <= 4UL), l_669[7]))), 13)) >= 0x11B6CB251224BFFALL))) && 0x3E19L), l_913)))
                    { /* block id: 360 */
                        int8_t l_988 = 0L;
                        int32_t l_989 = 0x2A528E7BL;
                        int32_t l_990 = 0L;
                        int32_t l_991[5] = {1L,1L,1L,1L,1L};
                        int i;
                        g_993++;
                        l_996[4]--;
                        if (p_31)
                            break;
                    }
                    else
                    { /* block id: 364 */
                        (*l_961) |= 0xD441C933L;
                        ++g_1001;
                        (*l_961) = 0xB3FE6B94L;
                        (*l_961) = (safe_mod_func_int64_t_s_s(2L, l_669[7]));
                    }
                }
                else
                { /* block id: 370 */
                    for (g_564 = (-10); (g_564 < 14); g_564 = safe_add_func_uint8_t_u_u(g_564, 1))
                    { /* block id: 373 */
                        if (l_913)
                            break;
                    }
                }
                if (p_31)
                    continue;
            }
            else
            { /* block id: 378 */
                return &g_426;
            }
            (*l_1014) = (((safe_unary_minus_func_uint64_t_u(((safe_add_func_int8_t_s_s((l_999 = ((l_996[6] < (safe_mul_func_int64_t_s_s((*g_270), (((void*)0 != &g_71) > ((g_210[2][9] , (((l_1013 , g_620) == g_584) , (l_884[5] , &g_270))) != (void*)0))))) > 0xFBB7L)), l_884[2])) & l_992))) | g_71) & l_805);
        }
    }
    if (g_619.f0.f0)
        goto lbl_1039;
lbl_1039:
    g_845[2].f2 ^= ((p_30 = ((safe_div_func_uint64_t_u_u((safe_sub_func_uint64_t_u_u((safe_lshift_func_uint32_t_u_u(((p_31 >= l_595) < (safe_div_func_int8_t_s_s((safe_mod_func_uint16_t_u_u(((l_1025 , ((l_1026 != l_1026) >= (l_1028[0][5] != (safe_add_func_uint64_t_u_u((l_996[4] <= ((safe_lshift_func_int32_t_s_s((safe_div_func_uint16_t_u_u((((*l_1037) = ((l_618 != (void*)0) , g_564)) != g_370), p_31)), l_1038)) >= p_31)), (**g_341)))))) <= l_669[7]), p_29)), p_29))), 21)), (*g_342))), (*g_162))) < 0xA0535B4EL)) != g_359.f0.f0);
    if ((safe_rshift_func_uint32_t_u_u(g_1027.f2, (safe_sub_func_uint64_t_u_u(18446744073709551615UL, ((*g_270) = (((*g_654) = ((void*)0 != &g_670)) > (l_669[4] = ((l_1046 = p_31) <= (&l_638[3][3][1] != (void*)0))))))))))
    { /* block id: 393 */
        int16_t l_1055 = 3L;
        int32_t *l_1073 = &g_55;
        int32_t *l_1074 = &g_426;
        volatile uint16_t * volatile **l_1078[9][5][5] = {{{&g_1075[0][3][2],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][6][4],&g_1075[0][3][6]},{&g_1075[0][6][2],(void*)0,&g_1075[0][2][7],&g_1075[0][2][2],&g_1075[0][3][6]},{&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][6][2],(void*)0,&g_1075[0][3][8]},{&g_1075[0][3][8],&g_1075[0][6][8],&g_1075[0][3][6],(void*)0,&g_1075[0][0][8]},{&g_1075[0][0][6],&g_1075[0][5][6],&g_1075[0][3][6],&g_1075[0][2][2],&g_1075[0][6][8]}},{{&g_1075[0][3][6],&g_1075[0][1][1],&g_1075[0][6][4],&g_1075[0][6][4],&g_1075[0][1][1]},{(void*)0,&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][6]},{&g_1075[0][3][6],&g_1075[0][3][8],&g_1075[0][3][6],&g_1075[0][3][6],(void*)0},{&g_1075[0][6][2],&g_1075[0][1][2],(void*)0,&g_1075[0][3][6],(void*)0},{&g_1075[0][3][6],&g_1075[0][0][6],&g_1075[0][6][2],&g_1075[0][3][6],&g_1075[0][3][6]}},{{(void*)0,&g_1075[0][6][2],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][0][8]},{&g_1075[0][3][6],&g_1075[0][3][2],&g_1075[0][5][6],(void*)0,&g_1075[0][3][6]},{&g_1075[0][0][6],&g_1075[0][1][1],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][6]},{&g_1075[0][3][8],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][2][7]},{&g_1075[0][3][6],(void*)0,&g_1075[0][5][6],&g_1075[0][4][0],&g_1075[0][3][6]}},{{&g_1075[0][6][2],&g_1075[0][4][5],&g_1075[0][3][6],&g_1075[0][4][5],&g_1075[0][6][2]},{&g_1075[0][3][2],&g_1075[0][1][7],&g_1075[0][6][2],(void*)0,&g_1075[0][3][6]},{&g_1075[0][3][6],&g_1075[0][3][6],(void*)0,&g_1075[0][1][1],&g_1075[0][0][8]},{(void*)0,&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][1][7],&g_1075[0][3][6]},{&g_1075[0][1][7],&g_1075[0][1][1],&g_1075[0][3][6],(void*)0,&g_1075[0][6][2]}},{{&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][6][4],&g_1075[0][3][6],&g_1075[0][3][6]},{&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][2][7]},{&g_1075[0][6][2],&g_1075[0][2][2],&g_1075[0][3][6],&g_1075[0][0][6],&g_1075[0][3][6]},{&g_1075[0][5][6],&g_1075[0][2][2],&g_1075[0][6][2],&g_1075[0][3][6],(void*)0},{&g_1075[0][3][6],(void*)0,&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][0][6]}},{{&g_1075[0][3][2],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][2],&g_1075[0][3][6]},{&g_1075[0][3][6],&g_1075[0][4][0],&g_1075[0][3][6],&g_1075[0][2][7],&g_1075[0][3][6]},{&g_1075[0][6][1],&g_1075[0][3][6],&g_1075[0][2][7],&g_1075[0][3][6],&g_1075[0][6][8]},{(void*)0,&g_1075[0][3][6],&g_1075[0][1][1],&g_1075[0][2][7],&g_1075[0][6][2]},{&g_1075[0][3][6],(void*)0,&g_1075[0][3][8],&g_1075[0][3][2],&g_1075[0][4][0]}},{{(void*)0,&g_1075[0][3][6],(void*)0,&g_1075[0][3][6],&g_1075[0][6][1]},{(void*)0,&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][0][6]},{&g_1075[0][3][6],&g_1075[0][1][1],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][0][8]},{&g_1075[0][3][6],&g_1075[0][4][0],&g_1075[0][2][5],(void*)0,&g_1075[0][3][6]},{(void*)0,&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][6]}},{{(void*)0,(void*)0,(void*)0,&g_1075[0][2][5],&g_1075[0][3][6]},{&g_1075[0][3][6],&g_1075[0][3][6],&g_1075[0][3][6],(void*)0,&g_1075[0][6][4]},{(void*)0,&g_1075[0][3][2],(void*)0,&g_1075[0][4][0],&g_1075[0][3][6]},{&g_1075[0][6][1],&g_1075[0][0][8],&g_1075[0][3][6],&g_1075[0][6][4],&g_1075[0][0][6]},{&g_1075[0][3][6],(void*)0,(void*)0,&g_1075[0][3][6],(void*)0}},{{&g_1075[0][3][2],&g_1075[0][4][0],&g_1075[0][3][6],&g_1075[0][3][6],(void*)0},{&g_1075[0][3][6],&g_1075[0][6][2],&g_1075[0][2][5],&g_1075[0][3][6],(void*)0},{&g_1075[0][6][2],&g_1075[0][6][1],&g_1075[0][3][6],&g_1075[0][3][6],(void*)0},{&g_1075[0][3][6],&g_1075[0][5][6],&g_1075[0][3][6],&g_1075[0][3][6],(void*)0},{&g_1075[0][1][1],&g_1075[0][3][6],(void*)0,(void*)0,(void*)0}}};
        int i, j, k;
        (*l_1074) = (safe_add_func_int32_t_s_s((safe_div_func_int64_t_s_s((((((*g_162) | (safe_add_func_int32_t_s_s(((((((safe_mul_func_int16_t_s_s((0x9961E456L ^ l_1055), (((safe_sub_func_int32_t_s_s((+(((*l_1073) = (safe_mul_func_uint16_t_u_u(p_31, (safe_rshift_func_uint16_t_u_u((safe_sub_func_int16_t_s_s(0xF096L, (p_29 >= ((**g_341) |= (4294967295UL > (safe_sub_func_int16_t_s_s((safe_mod_func_uint64_t_u_u((safe_unary_minus_func_uint32_t_u(l_1055)), (((+(safe_mul_func_uint32_t_u_u(g_781[6], p_31))) < l_588) , p_31))), (-1L)))))))), 6))))) , g_359.f0.f2)), l_669[7])) < (-9L)) ^ 0x7A4E568E02A6633CLL))) < l_996[2]) , p_29) < p_31) && 65535UL) & 0xA885L), l_1055))) | p_30) , l_1028[0][5]) , p_31), p_29)), p_30));
        l_1079[3][4][1] = g_1075[0][3][6];
    }
    else
    { /* block id: 398 */
        const union U4 *l_1081 = &g_1082[8];
        const union U4 **l_1080 = &l_1081;
        union U4 **l_1083 = (void*)0;
        int32_t *l_1084 = (void*)0;
        int32_t *l_1085 = &g_845[2].f2;
        (*l_1085) ^= (l_1080 == l_1083);
        return l_1084;
    }
    return &g_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_32 g_55 g_71 g_77 g_78 g_115 g_110 g_75 g_162 g_172 g_176 g_163 g_166 g_270 g_370 g_342 g_196 g_138 g_426 g_210 g_129 g_341 g_322 g_359.f0.f0 g_396 g_351 g_440 g_425.f0.f2 g_517 g_359.f0.f2 g_206.f3
 * writes: g_55 g_71 g_75 g_110 g_115 g_162 g_166 g_172 g_176 g_196 g_210 g_426 g_396 g_359.f0.f2 g_527 g_129 g_206.f3
 */
static uint32_t  func_39(int32_t  p_40)
{ /* block id: 8 */
    int32_t * const l_54 = &g_55;
    uint8_t l_70 = 255UL;
    int16_t *l_74[4][2] = {{&g_75[0],&g_75[0]},{&g_75[0],&g_75[0]},{&g_75[0],&g_75[0]},{&g_75[0],&g_75[0]}};
    uint32_t l_76 = 4294967287UL;
    int32_t l_513 = 0x67AE3336L;
    int32_t *l_519 = &g_426;
    int32_t **l_518 = &l_519;
    int8_t *l_559 = &g_377[7];
    uint8_t l_560[6][3] = {{0xEDL,0xEDL,0x0AL},{255UL,255UL,1UL},{0xEDL,0xEDL,0x0AL},{255UL,255UL,1UL},{0xEDL,0xEDL,0x0AL},{255UL,255UL,1UL}};
    int i, j;
lbl_570:
    if ((func_41(func_43(((((((safe_add_func_int16_t_s_s((l_76 |= (safe_add_func_uint8_t_u_u(func_50(g_32, l_54, (safe_mul_func_int64_t_s_s((*l_54), g_55))), (safe_mul_func_int8_t_s_s(((safe_sub_func_uint8_t_u_u((((g_32 <= 1L) != (safe_div_func_int32_t_s_s((((g_71 = l_70) >= (safe_lshift_func_int16_t_s_u(g_32, p_40))) && 9UL), g_32))) <= (-6L)), p_40)) | g_32), p_40))))), g_32)) && (-3L)) , g_71) | p_40) != 0xE2CA82E93B6ABB57LL) , g_71), g_77[2][1])) >= l_70))
    { /* block id: 148 */
        int8_t l_510 = 3L;
        int32_t * const *l_516 = &l_54;
        uint64_t *l_524[6][1][8] = {{{&g_196,&g_196,&g_196,&g_196,(void*)0,&g_196,(void*)0,&g_196}},{{&g_196,(void*)0,&g_196,&g_196,&g_196,&g_196,&g_196,&g_196}},{{(void*)0,(void*)0,&g_196,&g_196,&g_196,&g_196,&g_196,(void*)0}},{{(void*)0,&g_196,&g_196,&g_196,&g_196,&g_196,&g_196,(void*)0}},{{&g_196,&g_196,(void*)0,&g_196,(void*)0,&g_196,&g_196,&g_196}},{{&g_196,&g_196,&g_196,&g_196,&g_196,&g_196,&g_196,&g_196}}};
        int i, j, k;
        for (g_55 = 0; (g_55 <= 1); g_55 += 1)
        { /* block id: 151 */
            uint8_t l_486[7] = {0xE3L,0xE3L,0xE3L,0xE3L,0xE3L,0xE3L,0xE3L};
            int32_t *l_488 = (void*)0;
            int32_t **l_487 = &l_488;
            int i;
            if (l_486[1])
                break;
            (*l_487) = &g_55;
            for (g_71 = 1; (g_71 >= 0); g_71 -= 1)
            { /* block id: 156 */
                uint32_t *l_507 = (void*)0;
                uint32_t *l_508 = &l_76;
                int32_t l_509 = (-1L);
                uint8_t *l_511 = (void*)0;
                uint8_t *l_512 = &g_396;
                uint64_t **l_525 = (void*)0;
                uint64_t **l_526[10];
                uint16_t *l_528[10] = {&g_425.f0.f2,&g_425.f0.f2,&g_166,&g_425.f0.f2,&g_166,&g_166,&g_166,&g_166,&g_166,&g_166};
                int i, j;
                for (i = 0; i < 10; i++)
                    l_526[i] = &l_524[0][0][5];
                l_513 ^= ((g_110 | (safe_mod_func_uint16_t_u_u((*l_54), (safe_div_func_int32_t_s_s(((((safe_mul_func_uint32_t_u_u((safe_add_func_uint32_t_u_u((**l_487), ((p_40 < (g_426 |= 5L)) , (((((safe_lshift_func_uint32_t_u_u((p_40 < (safe_mul_func_uint32_t_u_u((((((*l_512) |= (safe_div_func_uint8_t_u_u((**l_487), ((((((((**g_341) & ((safe_sub_func_int16_t_s_s(((safe_add_func_int8_t_s_s(((((*l_508) |= g_322) > g_78) || (*g_270)), p_40)) ^ p_40), p_40)) <= l_509)) & g_359.f0.f0) >= 0x32L) != p_40) , 0xE69611A5L) , 1L) || l_510)))) <= g_351) , 0x2EL) >= g_440), (*l_488)))), g_172)) | p_40) > 5UL) != g_138) , 0x8E596479L)))), l_509)) != g_425.f0.f2) ^ 0x988A3880585DC4AELL) & 0xEBC09C6AL), g_166))))) > p_40);
                l_513 = ((((((safe_lshift_func_uint16_t_u_u((g_359.f0.f2 &= (l_516 == (l_518 = g_517))), (safe_mul_func_uint16_t_u_u(((*l_519) &= ((safe_rshift_func_int8_t_s_u(((void*)0 != &g_166), 6)) & ((g_527 = l_524[0][0][5]) != (*g_341)))), p_40)))) || ((p_40 & (safe_add_func_uint16_t_u_u((g_71 , p_40), (**l_487)))) ^ 0x4058L)) || 0x55ED943A51B0FB55LL) & p_40) >= (**l_516)) | p_40);
            }
        }
    }
    else
    { /* block id: 168 */
        uint8_t l_540 = 253UL;
        int8_t *l_558 = &g_129;
        int32_t l_563 = 1L;
        for (g_129 = 0; (g_129 >= (-3)); g_129--)
        { /* block id: 171 */
            int32_t *l_543 = (void*)0;
            uint32_t *l_550 = &g_378;
        }
    }
    for (g_206.f3 = 0; (g_206.f3 != 34); ++g_206.f3)
    { /* block id: 196 */
        int16_t l_569 = 1L;
        if (l_569)
            break;
    }
    if (g_78)
        goto lbl_570;
    return (*l_519);
}


/* ------------------------------------------ */
/* 
 * reads : g_176 g_115 g_162 g_110 g_163 g_32 g_166 g_78 g_71 g_270 g_55 g_370 g_342 g_196 g_138 g_426 g_210 g_129
 * writes: g_176 g_115 g_196 g_55 g_210 g_71 g_110 g_426
 */
static uint16_t  func_41(const int32_t * p_42)
{ /* block id: 54 */
    union U3 **l_178 = (void*)0;
    union U3 **l_179 = (void*)0;
    union U3 **l_180 = &g_176;
    uint32_t l_192 = 4294967295UL;
    int8_t *l_207 = (void*)0;
    int32_t l_233 = (-1L);
    int64_t *l_268 = &g_110;
    uint8_t l_349 = 0xC5L;
    uint16_t l_361 = 65535UL;
    uint64_t **l_368 = (void*)0;
    int8_t l_439 = 0xAAL;
    int16_t *l_460 = &g_75[0];
    int16_t *l_461[2];
    int i;
    for (i = 0; i < 2; i++)
        l_461[i] = &g_75[0];
    (*l_180) = g_176;
    for (g_115 = 0; (g_115 <= 9); ++g_115)
    { /* block id: 58 */
        const int16_t **l_183 = (void*)0;
        int32_t l_191[7][8] = {{0xC5D80E87L,1L,0xAB2CF5B4L,(-4L),1L,(-4L),0xAB2CF5B4L,1L},{0x22A784F9L,0xAB2CF5B4L,0xC5D80E87L,0x22A784F9L,(-4L),(-4L),0x22A784F9L,0xC5D80E87L},{1L,1L,0xFBB7C968L,0L,0x22A784F9L,0xFBB7C968L,0x22A784F9L,0L},{0xC5D80E87L,0L,0xC5D80E87L,(-4L),0L,0xAB2CF5B4L,0xAB2CF5B4L,0L},{0L,0xAB2CF5B4L,0xAB2CF5B4L,0L,(-4L),0xC5D80E87L,0L,0xC5D80E87L},{0L,0x22A784F9L,0xFBB7C968L,0x22A784F9L,0L,0xFBB7C968L,1L,1L},{0xC5D80E87L,0x22A784F9L,(-4L),(-4L),0x22A784F9L,0xC5D80E87L,0xAB2CF5B4L,0x22A784F9L}};
        uint64_t *l_195 = &g_196;
        int32_t l_197 = 0x2DC146C1L;
        uint32_t l_198 = 0xA4C91E03L;
        uint8_t l_241[2][2][2] = {{{0UL,0x0FL},{0UL,0UL}},{{0x0FL,0UL},{0UL,0x0FL}}};
        uint64_t *l_286 = &g_196;
        uint8_t l_355[10] = {0UL,0UL,0x2DL,0UL,0UL,0x2DL,0UL,0UL,0x2DL,0UL};
        union U4 *l_358 = &g_359;
        uint64_t l_462[9][3] = {{18446744073709551608UL,0xB3E14DB46A2465E8LL,0xB58B7B8E3A09A71BLL},{0UL,0xB3E14DB46A2465E8LL,0xB3E14DB46A2465E8LL},{18446744073709551615UL,0xB3E14DB46A2465E8LL,18446744073709551615UL},{18446744073709551608UL,0xB3E14DB46A2465E8LL,0xB58B7B8E3A09A71BLL},{0UL,0xB3E14DB46A2465E8LL,0xB3E14DB46A2465E8LL},{18446744073709551615UL,0xB3E14DB46A2465E8LL,18446744073709551615UL},{18446744073709551608UL,0xB3E14DB46A2465E8LL,0xB58B7B8E3A09A71BLL},{0UL,0xB3E14DB46A2465E8LL,0xB3E14DB46A2465E8LL},{18446744073709551615UL,0xB3E14DB46A2465E8LL,18446744073709551615UL}};
        int8_t *l_483 = (void*)0;
        int8_t *l_484 = &g_210[0][1];
        int32_t *l_485[1][7][2] = {{{&l_197,&l_233},{&l_197,&l_197},{&l_233,&l_197},{&l_197,&l_233},{&l_197,&l_197},{&l_233,&l_197},{&l_197,&l_233}}};
        int i, j, k;
        if ((l_197 = (((void*)0 == l_183) > ((((!(safe_mul_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((((((safe_mod_func_uint64_t_u_u(((void*)0 != &g_172), (l_191[1][3] &= 18446744073709551607UL))) && (1UL || ((*l_195) = (l_191[1][3] , (l_192 > (safe_lshift_func_int8_t_s_u(l_192, l_191[1][3]))))))) & l_197) & l_198) >= l_198), 1UL)), 6UL))) , 1L) < 1UL) > 0xBCL))))
        { /* block id: 62 */
            union U3 *l_205 = &g_206;
            int8_t *l_208 = &g_32;
            int32_t *l_209[7][5] = {{(void*)0,&l_197,&l_197,(void*)0,&l_197},{&l_191[3][2],&l_197,&l_197,&l_191[1][3],&l_197},{&l_191[1][3],&l_191[1][3],(void*)0,&l_197,&l_197},{(void*)0,&l_191[3][2],&l_191[1][3],&l_191[1][3],&l_191[3][2]},{&l_191[4][6],&g_55,&l_197,(void*)0,&l_191[3][2]},{&l_191[1][3],(void*)0,&l_197,&l_197,&l_197},{&g_55,&l_197,(void*)0,&l_197,&l_197}};
            uint32_t *l_221 = (void*)0;
            uint32_t *l_222 = &l_192;
            const int32_t **l_223[1][6][6];
            uint8_t l_242 = 0x5AL;
            int16_t l_376 = 0x25B7L;
            uint32_t l_390 = 4294967295UL;
            const union U3 *l_408 = &g_409;
            uint16_t *l_437 = (void*)0;
            int i, j, k;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 6; j++)
                {
                    for (k = 0; k < 6; k++)
                        l_223[i][j][k] = &g_77[2][1];
                }
            }
            p_42 = ((safe_lshift_func_int64_t_s_u(((safe_mod_func_uint32_t_u_u(((safe_mul_func_uint64_t_u_u(((g_210[0][1] = (g_55 = ((l_205 != (void*)0) , (l_207 != ((*g_162) , l_208))))) <= 4294967295UL), ((((9UL ^ (((safe_mod_func_uint8_t_u_u((safe_add_func_uint16_t_u_u(((((*l_222) = (safe_div_func_int64_t_s_s((*g_162), (safe_rshift_func_int16_t_s_s(((safe_rshift_func_int16_t_s_s((l_197 >= 0x806AD61AL), l_197)) | l_191[1][3]), g_32))))) , 0x28L) | l_198), g_163)), l_191[0][7])) || 0x7D36B89AL) , l_191[1][3])) != g_166) , l_198) || g_78))) ^ l_197), 0x48762854L)) && 65531UL), 58)) , p_42);
            for (g_71 = (-4); (g_71 != (-12)); g_71 = safe_sub_func_uint32_t_u_u(g_71, 4))
            { /* block id: 69 */
                uint64_t l_232[1];
                const union U3 *l_235 = &g_236;
                const union U3 **l_234 = &l_235;
                uint64_t * const l_345 = (void*)0;
                uint64_t * const *l_344 = &l_345;
                uint64_t l_348[7][1];
                int64_t l_381[4][8] = {{1L,(-10L),0xC0A989A4C346C34DLL,0x41B177A25CE23C8DLL,(-6L),0xB3C7A56F86E5E8F5LL,0xB3C7A56F86E5E8F5LL,(-6L)},{0xDA6E78CDC0A4ABB3LL,1L,1L,0xDA6E78CDC0A4ABB3LL,(-6L),(-7L),(-9L),0xB3C7A56F86E5E8F5LL},{1L,(-3L),0xC95A83FDC593CD75LL,(-6L),8L,(-6L),0xC95A83FDC593CD75LL,(-3L)},{1L,(-3L),0xB3C7A56F86E5E8F5LL,0xC95A83FDC593CD75LL,0xC0A989A4C346C34DLL,(-7L),0x41B177A25CE23C8DLL,0x41B177A25CE23C8DLL}};
                int32_t l_394[9][9][3] = {{{0x49F6C776L,(-5L),0xF43E927BL},{0L,0xA1761797L,0x9622E391L},{1L,(-1L),7L},{(-1L),(-5L),6L},{0x7272809BL,(-5L),(-7L)},{(-4L),0x9D411D87L,0x9D411D87L},{0x7272809BL,0xEE4FA275L,0L},{(-1L),0x58376A84L,(-5L)},{1L,0L,0xC71D38BCL}},{{0L,6L,0x561A48FDL},{(-5L),0L,0xD5D8C8BEL},{(-1L),0x58376A84L,0xDAA40CD5L},{0x8FAEE335L,0xEE4FA275L,0x8D530198L},{1L,0x9D411D87L,0x58376A84L},{0L,(-5L),0x8D530198L},{4L,(-5L),0xDAA40CD5L},{0L,(-1L),0xD5D8C8BEL},{0x461FA0ABL,0xA1761797L,0x561A48FDL}},{{0xC415D9A1L,0xC71D38BCL,0xC71D38BCL},{0x461FA0ABL,0x6A6F4B9AL,(-5L)},{0L,0xF43E927BL,0L},{4L,(-5L),0x9D411D87L},{0L,0xD5D8C8BEL,(-7L)},{1L,(-5L),6L},{0x8FAEE335L,0xF43E927BL,7L},{(-1L),0x6A6F4B9AL,0x9622E391L},{(-5L),0xC71D38BCL,0xF43E927BL}},{{0L,0xA1761797L,0x9622E391L},{1L,(-1L),7L},{(-1L),(-5L),6L},{0x7272809BL,(-5L),(-7L)},{(-4L),0x9D411D87L,0x9D411D87L},{0x7272809BL,0xEE4FA275L,0L},{(-1L),0x58376A84L,(-5L)},{1L,0L,0xC71D38BCL},{0L,6L,0x561A48FDL}},{{(-5L),0L,0xD5D8C8BEL},{(-1L),0x58376A84L,0xDAA40CD5L},{0x8FAEE335L,0xEE4FA275L,0x8D530198L},{1L,0x9D411D87L,0x58376A84L},{0L,(-5L),0x8D530198L},{4L,(-5L),0xDAA40CD5L},{0L,(-1L),0xD5D8C8BEL},{0x461FA0ABL,0xA1761797L,0x561A48FDL},{0xC415D9A1L,0xC71D38BCL,0xC71D38BCL}},{{0x461FA0ABL,0x6A6F4B9AL,(-5L)},{0L,0xF43E927BL,0L},{4L,(-5L),0x9D411D87L},{0L,0xD5D8C8BEL,(-7L)},{1L,(-5L),6L},{0x8FAEE335L,0xF43E927BL,7L},{(-1L),0x6A6F4B9AL,0x9622E391L},{(-5L),0xC71D38BCL,0xF43E927BL},{0L,0xA1761797L,0x9622E391L}},{{1L,(-1L),7L},{(-1L),(-5L),6L},{0x7272809BL,(-5L),(-7L)},{(-4L),0x9D411D87L,0x9D411D87L},{0x7272809BL,0xEE4FA275L,0L},{(-1L),0x58376A84L,(-5L)},{1L,0L,0xC71D38BCL},{0L,6L,0x561A48FDL},{(-5L),0L,0xD5D8C8BEL}},{{(-1L),0x58376A84L,0xDAA40CD5L},{0x8FAEE335L,1L,0x4317772AL},{6L,(-1L),0x3DA05A86L},{0xF43E927BL,0x5085E4CAL,0x4317772AL},{(-5L),(-6L),1L},{0x8D530198L,0x62CC4299L,(-6L)},{1L,1L,0L},{0L,0x49F6C776L,0x49F6C776L},{1L,(-1L),0L}},{{0x8D530198L,(-1L),0L},{(-5L),0L,(-1L)},{0xF43E927BL,(-6L),0x9580A802L},{6L,0L,(-1L)},{1L,(-1L),0x13C091DBL},{0xC2D0C671L,(-1L),0xE4F0D6DFL},{0xD5D8C8BEL,0x49F6C776L,(-1L)},{0x58376A84L,1L,0xE4F0D6DFL},{(-1L),0x62CC4299L,0x13C091DBL}}};
                int32_t l_395[2];
                int32_t l_438 = 0x34784428L;
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_232[i] = 0x5AFB6801FEF549EFLL;
                for (i = 0; i < 7; i++)
                {
                    for (j = 0; j < 1; j++)
                        l_348[i][j] = 2UL;
                }
                for (i = 0; i < 2; i++)
                    l_395[i] = 1L;
            }
        }
        else
        { /* block id: 138 */
            int32_t *l_442 = &l_197;
            (*l_442) = (+((*g_270) | 0x08C961BB7CF57214LL));
        }
        g_426 &= ((safe_div_func_int64_t_s_s(((0x8B6A6388811302DELL != ((*g_270) |= (+((safe_lshift_func_uint64_t_u_u(((*l_195) = (safe_lshift_func_uint8_t_u_s((safe_mul_func_uint16_t_u_u((0UL > (safe_sub_func_int8_t_s_s((safe_mul_func_uint16_t_u_u(g_55, (g_370 >= (safe_lshift_func_int8_t_s_u(l_198, l_191[1][3]))))), (safe_add_func_uint32_t_u_u(l_233, ((l_460 == l_461[0]) ^ 0x77L)))))), l_462[3][2])), l_197))), l_192)) || 0x62C7A9D6L)))) || (*g_342)), l_197)) == g_138);
        l_233 = (safe_div_func_uint64_t_u_u((&g_110 == (void*)0), ((safe_unary_minus_func_uint16_t_u(g_210[0][5])) , ((safe_mul_func_int64_t_s_s((safe_sub_func_int16_t_s_s((safe_add_func_int8_t_s_s((safe_lshift_func_int16_t_s_u((((+65526UL) | (&g_378 == (void*)0)) || ((safe_div_func_int32_t_s_s((safe_mul_func_int8_t_s_s(((*l_484) ^= (l_198 == (((safe_lshift_func_uint16_t_u_s(l_191[1][3], 9)) & l_439) <= l_233))), g_32)), l_349)) , g_129)), 1)), 1L)), l_198)), 2UL)) | l_462[3][2]))));
    }
    return l_192;
}


/* ------------------------------------------ */
/* 
 * reads : g_55 g_78 g_32 g_115 g_110 g_71 g_75 g_162 g_172
 * writes: g_55 g_75 g_110 g_115 g_162 g_166 g_172
 */
static int32_t * func_43(uint8_t  p_44, const int32_t * p_45)
{ /* block id: 14 */
    uint32_t l_104 = 0x4589AA37L;
    uint16_t l_164 = 6UL;
    int32_t l_169 = 0xBBCB40BAL;
    for (g_55 = 2; (g_55 >= 0); g_55 -= 1)
    { /* block id: 17 */
        int64_t l_79 = (-1L);
        int32_t *l_83 = (void*)0;
        int16_t *l_84 = &g_75[0];
        int64_t *l_109[2];
        int32_t l_111 = 4L;
        const uint64_t l_126 = 1UL;
        int32_t l_130 = 1L;
        uint8_t l_171 = 0UL;
        int32_t l_173 = 0xE1293A16L;
        int i;
        for (i = 0; i < 2; i++)
            l_109[i] = &g_110;
        l_111 |= (l_79 <= (safe_mod_func_uint32_t_u_u((safe_unary_minus_func_int32_t_s((((g_55 || g_78) == (&g_55 == l_83)) <= (((*l_84) = p_44) < (+(safe_add_func_int8_t_s_s((safe_mod_func_int32_t_s_s(((safe_add_func_int32_t_s_s((p_44 > (safe_sub_func_int64_t_s_s((g_110 = (((safe_rshift_func_int32_t_s_u(((((safe_sub_func_uint16_t_u_u((((safe_rshift_func_uint32_t_u_u((safe_rshift_func_int16_t_s_u((safe_add_func_int64_t_s_s(l_104, (!(((safe_mod_func_uint8_t_u_u((!g_32), l_79)) != 0L) == (-1L))))), p_44)), g_78)) , g_78) > p_44), 1UL)) == p_44) < l_104) >= p_44), 27)) >= p_44) & 4294967288UL)), 0L))), 0L)) < l_79), p_44)), 0xF1L))))))), 0xEF7C86B8L)));
        for (p_44 = 0; (p_44 <= 2); p_44 += 1)
        { /* block id: 23 */
            uint8_t *l_114 = &g_115;
            int32_t *l_125 = &l_111;
            int32_t **l_124 = &l_125;
            uint64_t l_127 = 0x5B57BD3F66FFE497LL;
            int8_t *l_128[4] = {&g_129,&g_129,&g_129,&g_129};
            const int16_t *l_137 = &g_138;
            const int16_t **l_136 = &l_137;
            const int64_t * const l_143 = &g_110;
            const int64_t *l_160 = &g_110;
            const int64_t **l_161[3];
            uint16_t *l_165[10] = {&l_164,(void*)0,&l_164,&l_164,(void*)0,&l_164,&l_164,(void*)0,&l_164,&l_164};
            int32_t l_167 = 0xFFF795CCL;
            uint64_t *l_168[3];
            int32_t *l_170[6] = {&l_130,&l_130,&l_130,&l_130,&l_130,&l_130};
            int i;
            for (i = 0; i < 3; i++)
                l_161[i] = &l_160;
            for (i = 0; i < 3; i++)
                l_168[i] = &l_127;
            l_130 |= (safe_lshift_func_uint16_t_u_u((((*l_114)++) , (((l_111 = (g_32 != (safe_mul_func_uint16_t_u_u(5UL, ((*l_84) = ((g_110 ^= (-4L)) || (((*l_114) = (safe_rshift_func_int16_t_s_s((((((p_44 ^ (safe_sub_func_uint64_t_u_u((((((*l_124) = (l_83 = &g_55)) != ((g_71 != ((g_55 >= (p_44 || 0x9AL)) > 7UL)) , p_45)) <= p_44) != l_126), l_127))) , l_104) & 0x02F9331570527DF6LL) , 0UL) | 255UL), 9))) & p_44))))))) >= g_71) | l_104)), 13));
            g_172 ^= (l_171 |= ((l_169 ^= (+(((l_167 = (safe_mul_func_uint64_t_u_u(((((*l_136) = l_84) != (void*)0) <= (((((safe_div_func_uint16_t_u_u((safe_mul_func_uint32_t_u_u((l_143 == &g_110), ((safe_sub_func_uint16_t_u_u((safe_lshift_func_uint8_t_u_s(((safe_div_func_int16_t_s_s((safe_lshift_func_uint8_t_u_u(((~((g_166 = (((*l_84) = (g_75[0] | p_44)) >= (((safe_lshift_func_uint64_t_u_u(((5L == ((safe_mul_func_int16_t_s_s(((((&g_138 == ((((+((((g_162 = l_160) != &g_163) && 18446744073709551615UL) == p_44)) , (*g_162)) < l_104) , (void*)0)) , 0x76L) == p_44) & l_164), 0x02F7L)) < 18446744073709551615UL)) > 0L), 2)) || 0x1009L) ^ 0xF3L))) | l_104)) , 255UL), l_164)), g_78)) != g_55), g_115)), p_44)) , 0UL))), 0xB935L)) < 0xDE63DF0479FFEDCCLL) , 0UL) , 0UL) <= 0xA41C3341L)), 0x2A04F454AEDB1328LL))) <= 0xA8B0C0B0L) && p_44))) == 18446744073709551613UL));
            for (g_110 = 0; (g_110 <= 2); g_110 += 1)
            { /* block id: 42 */
                int32_t *l_174 = &l_167;
                if (l_173)
                    break;
                return &g_55;
            }
        }
    }
    for (l_164 = 0; (l_164 <= 2); l_164 += 1)
    { /* block id: 50 */
        int32_t *l_175 = &l_169;
        return &g_55;
    }
    return &g_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_55 g_32
 * writes: g_55
 */
static uint8_t  func_50(uint64_t  p_51, int32_t * const  p_52, uint16_t  p_53)
{ /* block id: 9 */
    int32_t l_60 = 1L;
    (*p_52) = ((safe_add_func_uint64_t_u_u(l_60, (safe_sub_func_uint16_t_u_u(p_53, (((g_55 , p_53) | p_53) <= 0x20C5ABFEDE048FFDLL))))) , (!(g_55 != g_55)));
    return g_32;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_12, "g_12", print_hash_value);
    transparent_crc(g_32, "g_32", print_hash_value);
    transparent_crc(g_55, "g_55", print_hash_value);
    transparent_crc(g_71, "g_71", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_75[i], "g_75[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_110, "g_110", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_129, "g_129", print_hash_value);
    transparent_crc(g_138, "g_138", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_166, "g_166", print_hash_value);
    transparent_crc(g_172, "g_172", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_177[i].f0.f0, "g_177[i].f0.f0", print_hash_value);
        transparent_crc(g_177[i].f0.f1, "g_177[i].f0.f1", print_hash_value);
        transparent_crc(g_177[i].f0.f2, "g_177[i].f0.f2", print_hash_value);
        transparent_crc(g_177[i].f0.f3, "g_177[i].f0.f3", print_hash_value);
        transparent_crc(g_177[i].f0.f4, "g_177[i].f0.f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_196, "g_196", print_hash_value);
    transparent_crc(g_206.f0.f0, "g_206.f0.f0", print_hash_value);
    transparent_crc(g_206.f0.f1, "g_206.f0.f1", print_hash_value);
    transparent_crc(g_206.f0.f2, "g_206.f0.f2", print_hash_value);
    transparent_crc(g_206.f0.f3, "g_206.f0.f3", print_hash_value);
    transparent_crc(g_206.f0.f4, "g_206.f0.f4", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_210[i][j], "g_210[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_236.f0.f0, "g_236.f0.f0", print_hash_value);
    transparent_crc(g_236.f0.f1, "g_236.f0.f1", print_hash_value);
    transparent_crc(g_236.f0.f2, "g_236.f0.f2", print_hash_value);
    transparent_crc(g_236.f0.f3, "g_236.f0.f3", print_hash_value);
    transparent_crc(g_236.f0.f4, "g_236.f0.f4", print_hash_value);
    transparent_crc(g_322, "g_322", print_hash_value);
    transparent_crc(g_351, "g_351", print_hash_value);
    transparent_crc(g_359.f0.f0, "g_359.f0.f0", print_hash_value);
    transparent_crc(g_359.f0.f1, "g_359.f0.f1", print_hash_value);
    transparent_crc(g_359.f0.f2, "g_359.f0.f2", print_hash_value);
    transparent_crc(g_359.f0.f3, "g_359.f0.f3", print_hash_value);
    transparent_crc(g_359.f0.f4, "g_359.f0.f4", print_hash_value);
    transparent_crc(g_370, "g_370", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_377[i], "g_377[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_378, "g_378", print_hash_value);
    transparent_crc(g_396, "g_396", print_hash_value);
    transparent_crc(g_409.f0.f0, "g_409.f0.f0", print_hash_value);
    transparent_crc(g_409.f0.f1, "g_409.f0.f1", print_hash_value);
    transparent_crc(g_409.f0.f2, "g_409.f0.f2", print_hash_value);
    transparent_crc(g_409.f0.f3, "g_409.f0.f3", print_hash_value);
    transparent_crc(g_409.f0.f4, "g_409.f0.f4", print_hash_value);
    transparent_crc(g_425.f0.f0, "g_425.f0.f0", print_hash_value);
    transparent_crc(g_425.f0.f1, "g_425.f0.f1", print_hash_value);
    transparent_crc(g_425.f0.f2, "g_425.f0.f2", print_hash_value);
    transparent_crc(g_425.f0.f3, "g_425.f0.f3", print_hash_value);
    transparent_crc(g_425.f0.f4, "g_425.f0.f4", print_hash_value);
    transparent_crc(g_426, "g_426", print_hash_value);
    transparent_crc(g_440, "g_440", print_hash_value);
    transparent_crc(g_535, "g_535", print_hash_value);
    transparent_crc(g_564, "g_564", print_hash_value);
    transparent_crc(g_613, "g_613", print_hash_value);
    transparent_crc(g_619.f0.f0, "g_619.f0.f0", print_hash_value);
    transparent_crc(g_619.f0.f1, "g_619.f0.f1", print_hash_value);
    transparent_crc(g_619.f0.f2, "g_619.f0.f2", print_hash_value);
    transparent_crc(g_619.f0.f3, "g_619.f0.f3", print_hash_value);
    transparent_crc(g_619.f0.f4, "g_619.f0.f4", print_hash_value);
    transparent_crc(g_670, "g_670", print_hash_value);
    transparent_crc(g_707.f0.f0, "g_707.f0.f0", print_hash_value);
    transparent_crc(g_707.f0.f1, "g_707.f0.f1", print_hash_value);
    transparent_crc(g_707.f0.f2, "g_707.f0.f2", print_hash_value);
    transparent_crc(g_707.f0.f3, "g_707.f0.f3", print_hash_value);
    transparent_crc(g_707.f0.f4, "g_707.f0.f4", print_hash_value);
    transparent_crc(g_709.f0.f0, "g_709.f0.f0", print_hash_value);
    transparent_crc(g_709.f0.f1, "g_709.f0.f1", print_hash_value);
    transparent_crc(g_709.f0.f2, "g_709.f0.f2", print_hash_value);
    transparent_crc(g_709.f0.f3, "g_709.f0.f3", print_hash_value);
    transparent_crc(g_709.f0.f4, "g_709.f0.f4", print_hash_value);
    transparent_crc(g_738.f0.f0, "g_738.f0.f0", print_hash_value);
    transparent_crc(g_738.f0.f1, "g_738.f0.f1", print_hash_value);
    transparent_crc(g_738.f0.f2, "g_738.f0.f2", print_hash_value);
    transparent_crc(g_738.f0.f3, "g_738.f0.f3", print_hash_value);
    transparent_crc(g_738.f0.f4, "g_738.f0.f4", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_781[i], "g_781[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_845[i].f0, "g_845[i].f0", print_hash_value);
        transparent_crc(g_845[i].f1, "g_845[i].f1", print_hash_value);
        transparent_crc(g_845[i].f2, "g_845[i].f2", print_hash_value);
        transparent_crc(g_845[i].f3, "g_845[i].f3", print_hash_value);
        transparent_crc(g_845[i].f4, "g_845[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_957, "g_957", print_hash_value);
    transparent_crc(g_993, "g_993", print_hash_value);
    transparent_crc(g_1000, "g_1000", print_hash_value);
    transparent_crc(g_1001, "g_1001", print_hash_value);
    transparent_crc(g_1027.f0, "g_1027.f0", print_hash_value);
    transparent_crc(g_1027.f1, "g_1027.f1", print_hash_value);
    transparent_crc(g_1027.f2, "g_1027.f2", print_hash_value);
    transparent_crc(g_1027.f3, "g_1027.f3", print_hash_value);
    transparent_crc(g_1027.f4, "g_1027.f4", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_1077[i][j], "g_1077[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_1082[i].f0.f0, "g_1082[i].f0.f0", print_hash_value);
        transparent_crc(g_1082[i].f0.f1, "g_1082[i].f0.f1", print_hash_value);
        transparent_crc(g_1082[i].f0.f2, "g_1082[i].f0.f2", print_hash_value);
        transparent_crc(g_1082[i].f0.f3, "g_1082[i].f0.f3", print_hash_value);
        transparent_crc(g_1082[i].f0.f4, "g_1082[i].f0.f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1167.f0, "g_1167.f0", print_hash_value);
    transparent_crc(g_1167.f1, "g_1167.f1", print_hash_value);
    transparent_crc(g_1167.f2, "g_1167.f2", print_hash_value);
    transparent_crc(g_1167.f3, "g_1167.f3", print_hash_value);
    transparent_crc(g_1167.f4, "g_1167.f4", print_hash_value);
    transparent_crc(g_1171.f0, "g_1171.f0", print_hash_value);
    transparent_crc(g_1171.f1, "g_1171.f1", print_hash_value);
    transparent_crc(g_1171.f2, "g_1171.f2", print_hash_value);
    transparent_crc(g_1171.f3, "g_1171.f3", print_hash_value);
    transparent_crc(g_1171.f4, "g_1171.f4", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1240[i], "g_1240[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1266.f0.f0, "g_1266.f0.f0", print_hash_value);
    transparent_crc(g_1266.f0.f1, "g_1266.f0.f1", print_hash_value);
    transparent_crc(g_1266.f0.f2, "g_1266.f0.f2", print_hash_value);
    transparent_crc(g_1266.f0.f3, "g_1266.f0.f3", print_hash_value);
    transparent_crc(g_1266.f0.f4, "g_1266.f0.f4", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_1268[i][j].f0.f0, "g_1268[i][j].f0.f0", print_hash_value);
            transparent_crc(g_1268[i][j].f0.f1, "g_1268[i][j].f0.f1", print_hash_value);
            transparent_crc(g_1268[i][j].f0.f2, "g_1268[i][j].f0.f2", print_hash_value);
            transparent_crc(g_1268[i][j].f0.f3, "g_1268[i][j].f0.f3", print_hash_value);
            transparent_crc(g_1268[i][j].f0.f4, "g_1268[i][j].f0.f4", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1349, "g_1349", print_hash_value);
    transparent_crc(g_1382.f0, "g_1382.f0", print_hash_value);
    transparent_crc(g_1382.f1, "g_1382.f1", print_hash_value);
    transparent_crc(g_1382.f2, "g_1382.f2", print_hash_value);
    transparent_crc(g_1382.f3, "g_1382.f3", print_hash_value);
    transparent_crc(g_1382.f4, "g_1382.f4", print_hash_value);
    transparent_crc(g_1417.f0, "g_1417.f0", print_hash_value);
    transparent_crc(g_1417.f1, "g_1417.f1", print_hash_value);
    transparent_crc(g_1417.f2, "g_1417.f2", print_hash_value);
    transparent_crc(g_1417.f3, "g_1417.f3", print_hash_value);
    transparent_crc(g_1417.f4, "g_1417.f4", print_hash_value);
    transparent_crc(g_1418.f0, "g_1418.f0", print_hash_value);
    transparent_crc(g_1418.f1, "g_1418.f1", print_hash_value);
    transparent_crc(g_1418.f2, "g_1418.f2", print_hash_value);
    transparent_crc(g_1418.f3, "g_1418.f3", print_hash_value);
    transparent_crc(g_1418.f4, "g_1418.f4", print_hash_value);
    transparent_crc(g_1463.f0, "g_1463.f0", print_hash_value);
    transparent_crc(g_1463.f1, "g_1463.f1", print_hash_value);
    transparent_crc(g_1463.f2, "g_1463.f2", print_hash_value);
    transparent_crc(g_1463.f3, "g_1463.f3", print_hash_value);
    transparent_crc(g_1463.f4, "g_1463.f4", print_hash_value);
    transparent_crc(g_1468.f0, "g_1468.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_1494[i][j].f0, "g_1494[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_1504[i][j].f0.f0, "g_1504[i][j].f0.f0", print_hash_value);
            transparent_crc(g_1504[i][j].f0.f1, "g_1504[i][j].f0.f1", print_hash_value);
            transparent_crc(g_1504[i][j].f0.f2, "g_1504[i][j].f0.f2", print_hash_value);
            transparent_crc(g_1504[i][j].f0.f3, "g_1504[i][j].f0.f3", print_hash_value);
            transparent_crc(g_1504[i][j].f0.f4, "g_1504[i][j].f0.f4", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1505.f0, "g_1505.f0", print_hash_value);
    transparent_crc(g_1517.f0, "g_1517.f0", print_hash_value);
    transparent_crc(g_1517.f1, "g_1517.f1", print_hash_value);
    transparent_crc(g_1517.f2, "g_1517.f2", print_hash_value);
    transparent_crc(g_1517.f3, "g_1517.f3", print_hash_value);
    transparent_crc(g_1517.f4, "g_1517.f4", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1532[i][j].f0, "g_1532[i][j].f0", print_hash_value);
            transparent_crc(g_1532[i][j].f1, "g_1532[i][j].f1", print_hash_value);
            transparent_crc(g_1532[i][j].f2, "g_1532[i][j].f2", print_hash_value);
            transparent_crc(g_1532[i][j].f3, "g_1532[i][j].f3", print_hash_value);
            transparent_crc(g_1532[i][j].f4, "g_1532[i][j].f4", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1543.f0.f0, "g_1543.f0.f0", print_hash_value);
    transparent_crc(g_1543.f0.f1, "g_1543.f0.f1", print_hash_value);
    transparent_crc(g_1543.f0.f2, "g_1543.f0.f2", print_hash_value);
    transparent_crc(g_1543.f0.f3, "g_1543.f0.f3", print_hash_value);
    transparent_crc(g_1543.f0.f4, "g_1543.f0.f4", print_hash_value);
    transparent_crc(g_1562.f0.f0, "g_1562.f0.f0", print_hash_value);
    transparent_crc(g_1562.f0.f1, "g_1562.f0.f1", print_hash_value);
    transparent_crc(g_1562.f0.f2, "g_1562.f0.f2", print_hash_value);
    transparent_crc(g_1562.f0.f3, "g_1562.f0.f3", print_hash_value);
    transparent_crc(g_1562.f0.f4, "g_1562.f0.f4", print_hash_value);
    transparent_crc(g_1564, "g_1564", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_1584[i][j][k].f0, "g_1584[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1587[i].f0.f0, "g_1587[i].f0.f0", print_hash_value);
        transparent_crc(g_1587[i].f0.f1, "g_1587[i].f0.f1", print_hash_value);
        transparent_crc(g_1587[i].f0.f2, "g_1587[i].f0.f2", print_hash_value);
        transparent_crc(g_1587[i].f0.f3, "g_1587[i].f0.f3", print_hash_value);
        transparent_crc(g_1587[i].f0.f4, "g_1587[i].f0.f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1588.f0.f0, "g_1588.f0.f0", print_hash_value);
    transparent_crc(g_1588.f0.f1, "g_1588.f0.f1", print_hash_value);
    transparent_crc(g_1588.f0.f2, "g_1588.f0.f2", print_hash_value);
    transparent_crc(g_1588.f0.f3, "g_1588.f0.f3", print_hash_value);
    transparent_crc(g_1588.f0.f4, "g_1588.f0.f4", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_1599[i][j].f0, "g_1599[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1604[i].f0.f0, "g_1604[i].f0.f0", print_hash_value);
        transparent_crc(g_1604[i].f0.f1, "g_1604[i].f0.f1", print_hash_value);
        transparent_crc(g_1604[i].f0.f2, "g_1604[i].f0.f2", print_hash_value);
        transparent_crc(g_1604[i].f0.f3, "g_1604[i].f0.f3", print_hash_value);
        transparent_crc(g_1604[i].f0.f4, "g_1604[i].f0.f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1610.f0.f0, "g_1610.f0.f0", print_hash_value);
    transparent_crc(g_1610.f0.f1, "g_1610.f0.f1", print_hash_value);
    transparent_crc(g_1610.f0.f2, "g_1610.f0.f2", print_hash_value);
    transparent_crc(g_1610.f0.f3, "g_1610.f0.f3", print_hash_value);
    transparent_crc(g_1610.f0.f4, "g_1610.f0.f4", print_hash_value);
    transparent_crc(g_1708.f0, "g_1708.f0", print_hash_value);
    transparent_crc(g_1708.f1, "g_1708.f1", print_hash_value);
    transparent_crc(g_1708.f2, "g_1708.f2", print_hash_value);
    transparent_crc(g_1708.f3, "g_1708.f3", print_hash_value);
    transparent_crc(g_1708.f4, "g_1708.f4", print_hash_value);
    transparent_crc(g_1790, "g_1790", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_1905[i][j].f0.f0, "g_1905[i][j].f0.f0", print_hash_value);
            transparent_crc(g_1905[i][j].f0.f1, "g_1905[i][j].f0.f1", print_hash_value);
            transparent_crc(g_1905[i][j].f0.f2, "g_1905[i][j].f0.f2", print_hash_value);
            transparent_crc(g_1905[i][j].f0.f3, "g_1905[i][j].f0.f3", print_hash_value);
            transparent_crc(g_1905[i][j].f0.f4, "g_1905[i][j].f0.f4", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2043.f0, "g_2043.f0", print_hash_value);
    transparent_crc(g_2071.f0, "g_2071.f0", print_hash_value);
    transparent_crc(g_2071.f1, "g_2071.f1", print_hash_value);
    transparent_crc(g_2071.f2, "g_2071.f2", print_hash_value);
    transparent_crc(g_2071.f3, "g_2071.f3", print_hash_value);
    transparent_crc(g_2071.f4, "g_2071.f4", print_hash_value);
    transparent_crc(g_2076.f0, "g_2076.f0", print_hash_value);
    transparent_crc(g_2076.f1, "g_2076.f1", print_hash_value);
    transparent_crc(g_2076.f2, "g_2076.f2", print_hash_value);
    transparent_crc(g_2076.f3, "g_2076.f3", print_hash_value);
    transparent_crc(g_2076.f4, "g_2076.f4", print_hash_value);
    transparent_crc(g_2094.f0, "g_2094.f0", print_hash_value);
    transparent_crc(g_2156.f0, "g_2156.f0", print_hash_value);
    transparent_crc(g_2156.f1, "g_2156.f1", print_hash_value);
    transparent_crc(g_2156.f2, "g_2156.f2", print_hash_value);
    transparent_crc(g_2156.f3, "g_2156.f3", print_hash_value);
    transparent_crc(g_2156.f4, "g_2156.f4", print_hash_value);
    transparent_crc(g_2186.f0, "g_2186.f0", print_hash_value);
    transparent_crc(g_2186.f1, "g_2186.f1", print_hash_value);
    transparent_crc(g_2186.f2, "g_2186.f2", print_hash_value);
    transparent_crc(g_2186.f3, "g_2186.f3", print_hash_value);
    transparent_crc(g_2186.f4, "g_2186.f4", print_hash_value);
    transparent_crc(g_2226.f0.f0, "g_2226.f0.f0", print_hash_value);
    transparent_crc(g_2226.f0.f1, "g_2226.f0.f1", print_hash_value);
    transparent_crc(g_2226.f0.f2, "g_2226.f0.f2", print_hash_value);
    transparent_crc(g_2226.f0.f3, "g_2226.f0.f3", print_hash_value);
    transparent_crc(g_2226.f0.f4, "g_2226.f0.f4", print_hash_value);
    transparent_crc(g_2242, "g_2242", print_hash_value);
    transparent_crc(g_2248.f0, "g_2248.f0", print_hash_value);
    transparent_crc(g_2335, "g_2335", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_2377[i].f0, "g_2377[i].f0", print_hash_value);
        transparent_crc(g_2377[i].f1, "g_2377[i].f1", print_hash_value);
        transparent_crc(g_2377[i].f2, "g_2377[i].f2", print_hash_value);
        transparent_crc(g_2377[i].f3, "g_2377[i].f3", print_hash_value);
        transparent_crc(g_2377[i].f4, "g_2377[i].f4", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 534
   depth: 1, occurrence: 12
XXX total union variables: 15

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 11
breakdown:
   indirect level: 0, occurrence: 2
   indirect level: 1, occurrence: 3
   indirect level: 2, occurrence: 3
   indirect level: 3, occurrence: 1
   indirect level: 4, occurrence: 1
   indirect level: 5, occurrence: 1
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 8
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 5
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 2

XXX max expression depth: 48
breakdown:
   depth: 1, occurrence: 286
   depth: 2, occurrence: 67
   depth: 3, occurrence: 4
   depth: 4, occurrence: 3
   depth: 5, occurrence: 4
   depth: 6, occurrence: 1
   depth: 7, occurrence: 2
   depth: 8, occurrence: 2
   depth: 9, occurrence: 1
   depth: 11, occurrence: 2
   depth: 12, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 2
   depth: 15, occurrence: 1
   depth: 17, occurrence: 2
   depth: 18, occurrence: 5
   depth: 19, occurrence: 3
   depth: 20, occurrence: 7
   depth: 21, occurrence: 8
   depth: 22, occurrence: 2
   depth: 23, occurrence: 5
   depth: 24, occurrence: 4
   depth: 25, occurrence: 4
   depth: 26, occurrence: 1
   depth: 27, occurrence: 4
   depth: 28, occurrence: 2
   depth: 29, occurrence: 1
   depth: 30, occurrence: 3
   depth: 31, occurrence: 3
   depth: 32, occurrence: 1
   depth: 33, occurrence: 2
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 1
   depth: 39, occurrence: 2
   depth: 42, occurrence: 1
   depth: 45, occurrence: 1
   depth: 48, occurrence: 1

XXX total number of pointers: 518

XXX times a variable address is taken: 1103
XXX times a pointer is dereferenced on RHS: 178
breakdown:
   depth: 1, occurrence: 150
   depth: 2, occurrence: 26
   depth: 3, occurrence: 2
XXX times a pointer is dereferenced on LHS: 238
breakdown:
   depth: 1, occurrence: 223
   depth: 2, occurrence: 11
   depth: 3, occurrence: 3
   depth: 4, occurrence: 0
   depth: 5, occurrence: 1
XXX times a pointer is compared with null: 50
XXX times a pointer is compared with address of another variable: 18
XXX times a pointer is compared with another pointer: 18
XXX times a pointer is qualified to be dereferenced: 4902

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2415
   level: 2, occurrence: 236
   level: 3, occurrence: 65
   level: 4, occurrence: 17
   level: 5, occurrence: 5
XXX number of pointers point to pointers: 212
XXX number of pointers point to scalars: 264
XXX number of pointers point to structs: 11
XXX percent of pointers has null in alias set: 30.5
XXX average alias set size: 1.36

XXX times a non-volatile is read: 1742
XXX times a non-volatile is write: 793
XXX times a volatile is read: 48
XXX    times read thru a pointer: 7
XXX times a volatile is write: 12
XXX    times written thru a pointer: 1
XXX times a volatile is available for access: 2.88e+03
XXX percentage of non-volatile access: 97.7

XXX forward jumps: 1
XXX backward jumps: 10

XXX stmts: 297
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 35
   depth: 1, occurrence: 35
   depth: 2, occurrence: 35
   depth: 3, occurrence: 55
   depth: 4, occurrence: 59
   depth: 5, occurrence: 78

XXX percentage a fresh-made variable is used: 18.5
XXX percentage an existing variable is used: 81.5
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

