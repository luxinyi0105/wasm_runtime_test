/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      1379340520
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   signed f0 : 2;
   const uint8_t  f1;
   uint8_t  f2;
   int16_t  f3;
   const int16_t  f4;
   const uint8_t  f5;
   volatile int32_t  f6;
};

struct S1 {
   int8_t  f0;
   uint8_t  f1;
   int16_t  f2;
   volatile uint16_t  f3;
};

union U2 {
   uint8_t  f0;
   uint64_t  f1;
   const uint8_t  f2;
   volatile int32_t  f3;
   int16_t  f4;
};

union U3 {
   int8_t  f0;
   uint64_t  f1;
   struct S1  f2;
};

union U4 {
   int32_t  f0;
   int32_t  f1;
   volatile struct S1  f2;
   struct S1  f3;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0xFD814383L;
static int32_t g_4 = 1L;
static int8_t g_34 = 0xE4L;
static int32_t g_39 = 0x3202F603L;
static const union U3 g_49 = {-1L};/* VOLATILE GLOBAL g_49 */
static int32_t *g_68 = &g_4;
static int32_t ** volatile g_67 = &g_68;/* VOLATILE GLOBAL g_67 */
static int32_t g_72 = (-1L);
static volatile int32_t g_76 = 0x7AF82577L;/* VOLATILE GLOBAL g_76 */
static volatile uint32_t g_78 = 18446744073709551615UL;/* VOLATILE GLOBAL g_78 */
static struct S0 g_94 = {-0,0xAFL,9UL,3L,5L,1UL,0xF3046699L};/* VOLATILE GLOBAL g_94 */
static uint32_t g_96 = 0UL;
static uint32_t g_98 = 4294967289UL;
static int64_t g_100 = 3L;
static int8_t g_102 = 3L;
static const union U4 g_108 = {2L};/* VOLATILE GLOBAL g_108 */
static const struct S1 g_110 = {0x4BL,0xAFL,-2L,65529UL};/* VOLATILE GLOBAL g_110 */
static uint16_t g_118[5] = {0x1FF7L,0x1FF7L,0x1FF7L,0x1FF7L,0x1FF7L};
static uint16_t g_122 = 65535UL;
static int8_t g_137 = 0xBCL;
static int8_t g_138 = 1L;
static volatile uint16_t g_139 = 0x943AL;/* VOLATILE GLOBAL g_139 */
static volatile uint32_t g_163 = 0x52EEBB87L;/* VOLATILE GLOBAL g_163 */
static volatile uint32_t *g_162 = &g_163;
static const union U4 g_169 = {0xA1A6899BL};/* VOLATILE GLOBAL g_169 */
static const int32_t g_177 = (-1L);
static const uint8_t *g_200 = &g_94.f5;
static const uint8_t g_202 = 0UL;
static volatile int64_t g_221 = 0x890952E1ABEA055ELL;/* VOLATILE GLOBAL g_221 */
static volatile int64_t *g_220 = &g_221;
static struct S1 g_235 = {0x52L,255UL,0xDBC7L,65535UL};/* VOLATILE GLOBAL g_235 */
static int64_t g_252 = 0xE442EAC8DC0C5F0CLL;
static volatile union U2 g_256 = {0xDAL};/* VOLATILE GLOBAL g_256 */
static struct S0 g_299 = {-1,252UL,255UL,0x5248L,0x48EDL,0x7BL,0x351E878FL};/* VOLATILE GLOBAL g_299 */
static int32_t g_307 = 1L;
static uint16_t * const g_314[9][10][2] = {{{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]}},{{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]}},{{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]}},{{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]}},{{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]}},{{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]}},{{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]}},{{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]}},{{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]},{&g_122,&g_118[0]}}};
static uint16_t * const *g_313 = &g_314[0][4][0];
static const union U4 g_315 = {0x432B5EFDL};/* VOLATILE GLOBAL g_315 */
static struct S1 g_347 = {0x09L,247UL,0x5446L,3UL};/* VOLATILE GLOBAL g_347 */
static struct S1 * volatile g_348 = (void*)0;/* VOLATILE GLOBAL g_348 */
static volatile union U3 g_351 = {9L};/* VOLATILE GLOBAL g_351 */
static union U4 g_353[6] = {{0x45C0F2A8L},{0x45C0F2A8L},{0x45C0F2A8L},{0x45C0F2A8L},{0x45C0F2A8L},{0x45C0F2A8L}};
static union U4 *g_355 = &g_353[3];
static volatile struct S1 g_356 = {0xEFL,253UL,0xAEA8L,0UL};/* VOLATILE GLOBAL g_356 */
static int32_t * volatile g_364 = &g_39;/* VOLATILE GLOBAL g_364 */
static volatile int16_t g_384 = 0x1D15L;/* VOLATILE GLOBAL g_384 */
static volatile int16_t g_385 = 0x3C2AL;/* VOLATILE GLOBAL g_385 */
static volatile uint8_t g_386 = 0x39L;/* VOLATILE GLOBAL g_386 */
static const uint16_t *g_405 = &g_118[3];
static const uint16_t **g_404 = &g_405;
static const uint16_t ***g_403 = &g_404;
static const union U4 g_407[7] = {{4L},{0x74716CADL},{0x74716CADL},{4L},{0x74716CADL},{0x74716CADL},{4L}};
static const union U4 g_416 = {6L};/* VOLATILE GLOBAL g_416 */
static int8_t g_426 = 1L;
static volatile uint64_t g_427 = 0x184A4C1BB28938DBLL;/* VOLATILE GLOBAL g_427 */
static uint16_t ** volatile * volatile * volatile *g_502 = (void*)0;
static uint16_t *g_507 = &g_122;
static uint16_t **g_506 = &g_507;
static uint16_t ** volatile * volatile g_505 = &g_506;/* VOLATILE GLOBAL g_505 */
static volatile struct S1 * volatile g_510 = &g_351.f2;/* VOLATILE GLOBAL g_510 */
static struct S0 g_519[10][7][3] = {{{{-0,0UL,0x06L,0x51E1L,9L,5UL,1L},{-0,0xCDL,0xC9L,-1L,-8L,248UL,6L},{-1,250UL,255UL,0x0296L,-4L,255UL,-6L}},{{1,0UL,0x57L,0x36F2L,0x3F6CL,251UL,-1L},{1,8UL,0xE5L,0x4428L,-5L,0x85L,-3L},{-0,0UL,0x92L,0xF1E7L,6L,255UL,3L}},{{0,8UL,0x49L,0x57ACL,0xF6A4L,0xDCL,9L},{0,0x7FL,1UL,6L,1L,1UL,0x7DE20BC2L},{-1,1UL,7UL,0xEB38L,0x3AF7L,0x90L,4L}},{{0,8UL,0x49L,0x57ACL,0xF6A4L,0xDCL,9L},{-0,0xC8L,0x80L,0x9433L,0x63A2L,255UL,0xB5AE8FC5L},{-0,0UL,0x06L,0x51E1L,9L,5UL,1L}},{{1,0UL,0x57L,0x36F2L,0x3F6CL,251UL,-1L},{-0,0xEDL,0x61L,0x98BFL,0x52D8L,0UL,0x64C1F111L},{-1,0x87L,0xD4L,1L,0x1DD4L,252UL,0xDBCE3D1AL}},{{-0,0UL,0x06L,0x51E1L,9L,5UL,1L},{1,0x90L,0xEEL,0x6B0DL,2L,8UL,1L},{1,0x46L,0x8EL,0x02EDL,0x102BL,255UL,0xF562C275L}},{{1,0x9AL,253UL,-4L,0xCAA1L,0x70L,-1L},{-0,0xC8L,0x80L,0x9433L,0x63A2L,255UL,0xB5AE8FC5L},{-1,250UL,255UL,0x0296L,-4L,255UL,-6L}}},{{{-0,0UL,0x06L,0x51E1L,9L,5UL,1L},{-0,0xD9L,0UL,0xA657L,0xAFBAL,0x64L,-7L},{-0,1UL,0xA0L,0xD850L,-10L,7UL,-9L}},{{1,0UL,0x57L,0x36F2L,0x3F6CL,251UL,-1L},{0,0UL,0UL,3L,0xAB42L,0x64L,-2L},{1,0x46L,0x8EL,0x02EDL,0x102BL,255UL,0xF562C275L}},{{0,8UL,0x49L,0x57ACL,0xF6A4L,0xDCL,9L},{-0,0xCDL,0xC9L,-1L,-8L,248UL,6L},{0,8UL,0x49L,0x57ACL,0xF6A4L,0xDCL,9L}},{{0,8UL,0x49L,0x57ACL,0xF6A4L,0xDCL,9L},{-0,0UL,0xDCL,0x8B53L,0x161FL,0x51L,-1L},{-1,0x60L,1UL,1L,1L,0UL,6L}},{{1,0UL,0x57L,0x36F2L,0x3F6CL,251UL,-1L},{1,0x90L,0xEEL,0x6B0DL,2L,8UL,1L},{-1,1UL,7UL,0xEB38L,0x3AF7L,0x90L,4L}},{{-0,0UL,0x06L,0x51E1L,9L,5UL,1L},{-0,0x59L,8UL,0x108FL,-4L,0x70L,0xC289B038L},{0,252UL,1UL,0x81A1L,0x6C8FL,0x44L,-1L}},{{0,0xF9L,246UL,0L,0xB9C6L,0x1CL,0xFE1B02E6L},{0,8UL,0x49L,0x57ACL,0xF6A4L,0xDCL,9L},{0,255UL,1UL,1L,-2L,0x22L,0x758278CDL}}},{{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{-0,0x43L,0UL,-10L,-1L,254UL,1L},{-1,0x64L,0UL,0x7DB6L,0L,0xB2L,-1L}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{-0,0UL,0x92L,0xF1E7L,6L,255UL,3L},{0,255UL,255UL,8L,0x9D02L,248UL,0xF3A3C741L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-0,0xC2L,247UL,-6L,0xAB2DL,0UL,0x53BC88BFL},{-0,0x0EL,0x57L,0x00D2L,-1L,0xBBL,7L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-1,1UL,7UL,0xEB38L,0x3AF7L,0x90L,4L},{-0,0x48L,2UL,0L,0xEB87L,5UL,1L}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{-1,0x21L,2UL,6L,0L,0xEDL,0xB41DC97FL},{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL}},{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{1,0x9AL,253UL,-4L,0xCAA1L,0x70L,-1L},{0,0xDEL,0UL,-4L,3L,0x61L,1L}},{{0,0xF9L,246UL,0L,0xB9C6L,0x1CL,0xFE1B02E6L},{-1,1UL,7UL,0xEB38L,0x3AF7L,0x90L,4L},{-1,0x64L,0UL,0x7DB6L,0L,0xB2L,-1L}}},{{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{0,0xBCL,0xFBL,-6L,0x64BDL,5UL,0L},{-1,0x6AL,250UL,0x4A8EL,-1L,0xFBL,0xF2F5A14BL}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{0,252UL,1UL,0x81A1L,0x6C8FL,0x44L,-1L},{0,0xDEL,0UL,-4L,3L,0x61L,1L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-0,0x43L,0UL,-10L,-1L,254UL,1L},{-0,255UL,0x66L,0xF7F3L,-10L,0x15L,1L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-1,0x87L,0xD4L,1L,0x1DD4L,252UL,0xDBCE3D1AL},{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{1,0x9AL,253UL,-4L,0xCAA1L,0x70L,-1L},{-0,0x0EL,0x57L,0x00D2L,-1L,0xBBL,7L}},{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{1,0xC5L,255UL,0xB8FEL,-9L,4UL,-4L},{1,0x8BL,0xD4L,0xE123L,0xF74DL,253UL,-4L}},{{0,0xF9L,246UL,0L,0xB9C6L,0x1CL,0xFE1B02E6L},{-1,0x87L,0xD4L,1L,0x1DD4L,252UL,0xDBCE3D1AL},{-1,0x6AL,250UL,0x4A8EL,-1L,0xFBL,0xF2F5A14BL}}},{{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{-0,0xC2L,247UL,-6L,0xAB2DL,0UL,0x53BC88BFL},{0,255UL,1UL,1L,-2L,0x22L,0x758278CDL}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{1,0x46L,0x8EL,0x02EDL,0x102BL,255UL,0xF562C275L},{1,0x8BL,0xD4L,0xE123L,0xF74DL,253UL,-4L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{0,0xBCL,0xFBL,-6L,0x64BDL,5UL,0L},{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{0,8UL,0x49L,0x57ACL,0xF6A4L,0xDCL,9L},{-1,0xEDL,255UL,0x5377L,0x0792L,0x11L,0L}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{1,0xC5L,255UL,0xB8FEL,-9L,4UL,-4L},{-0,255UL,0x66L,0xF7F3L,-10L,0x15L,1L}},{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{-1,0x21L,2UL,6L,0L,0xEDL,0xB41DC97FL},{0,255UL,255UL,8L,0x9D02L,248UL,0xF3A3C741L}},{{0,0xF9L,246UL,0L,0xB9C6L,0x1CL,0xFE1B02E6L},{0,8UL,0x49L,0x57ACL,0xF6A4L,0xDCL,9L},{0,255UL,1UL,1L,-2L,0x22L,0x758278CDL}}},{{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{-0,0x43L,0UL,-10L,-1L,254UL,1L},{-1,0x64L,0UL,0x7DB6L,0L,0xB2L,-1L}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{-0,0UL,0x92L,0xF1E7L,6L,255UL,3L},{0,255UL,255UL,8L,0x9D02L,248UL,0xF3A3C741L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-0,0xC2L,247UL,-6L,0xAB2DL,0UL,0x53BC88BFL},{-0,0x0EL,0x57L,0x00D2L,-1L,0xBBL,7L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-1,1UL,7UL,0xEB38L,0x3AF7L,0x90L,4L},{-0,0x48L,2UL,0L,0xEB87L,5UL,1L}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{-1,0x21L,2UL,6L,0L,0xEDL,0xB41DC97FL},{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL}},{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{1,0x9AL,253UL,-4L,0xCAA1L,0x70L,-1L},{0,0xDEL,0UL,-4L,3L,0x61L,1L}},{{0,0xF9L,246UL,0L,0xB9C6L,0x1CL,0xFE1B02E6L},{-1,1UL,7UL,0xEB38L,0x3AF7L,0x90L,4L},{-1,0x64L,0UL,0x7DB6L,0L,0xB2L,-1L}}},{{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{0,0xBCL,0xFBL,-6L,0x64BDL,5UL,0L},{-1,0x6AL,250UL,0x4A8EL,-1L,0xFBL,0xF2F5A14BL}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{0,252UL,1UL,0x81A1L,0x6C8FL,0x44L,-1L},{0,0xDEL,0UL,-4L,3L,0x61L,1L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-0,0x43L,0UL,-10L,-1L,254UL,1L},{-0,255UL,0x66L,0xF7F3L,-10L,0x15L,1L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-1,0x87L,0xD4L,1L,0x1DD4L,252UL,0xDBCE3D1AL},{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{1,0x9AL,253UL,-4L,0xCAA1L,0x70L,-1L},{-0,0x0EL,0x57L,0x00D2L,-1L,0xBBL,7L}},{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{1,0xC5L,255UL,0xB8FEL,-9L,4UL,-4L},{1,0x8BL,0xD4L,0xE123L,0xF74DL,253UL,-4L}},{{0,0xF9L,246UL,0L,0xB9C6L,0x1CL,0xFE1B02E6L},{-1,0x87L,0xD4L,1L,0x1DD4L,252UL,0xDBCE3D1AL},{-1,0x6AL,250UL,0x4A8EL,-1L,0xFBL,0xF2F5A14BL}}},{{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{-0,0xC2L,247UL,-6L,0xAB2DL,0UL,0x53BC88BFL},{0,255UL,1UL,1L,-2L,0x22L,0x758278CDL}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{1,0x46L,0x8EL,0x02EDL,0x102BL,255UL,0xF562C275L},{1,0x8BL,0xD4L,0xE123L,0xF74DL,253UL,-4L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{0,0xBCL,0xFBL,-6L,0x64BDL,5UL,0L},{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{0,8UL,0x49L,0x57ACL,0xF6A4L,0xDCL,9L},{-1,0xEDL,255UL,0x5377L,0x0792L,0x11L,0L}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{1,0xC5L,255UL,0xB8FEL,-9L,4UL,-4L},{-0,255UL,0x66L,0xF7F3L,-10L,0x15L,1L}},{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{-1,0x21L,2UL,6L,0L,0xEDL,0xB41DC97FL},{0,255UL,255UL,8L,0x9D02L,248UL,0xF3A3C741L}},{{0,0xF9L,246UL,0L,0xB9C6L,0x1CL,0xFE1B02E6L},{0,8UL,0x49L,0x57ACL,0xF6A4L,0xDCL,9L},{0,255UL,1UL,1L,-2L,0x22L,0x758278CDL}}},{{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{-0,0x43L,0UL,-10L,-1L,254UL,1L},{-1,0x64L,0UL,0x7DB6L,0L,0xB2L,-1L}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{-0,0UL,0x92L,0xF1E7L,6L,255UL,3L},{0,255UL,255UL,8L,0x9D02L,248UL,0xF3A3C741L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-0,0xC2L,247UL,-6L,0xAB2DL,0UL,0x53BC88BFL},{-0,0x0EL,0x57L,0x00D2L,-1L,0xBBL,7L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-1,1UL,7UL,0xEB38L,0x3AF7L,0x90L,4L},{-0,0x48L,2UL,0L,0xEB87L,5UL,1L}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{-1,0x21L,2UL,6L,0L,0xEDL,0xB41DC97FL},{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL}},{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{1,0x9AL,253UL,-4L,0xCAA1L,0x70L,-1L},{0,0xDEL,0UL,-4L,3L,0x61L,1L}},{{0,0xF9L,246UL,0L,0xB9C6L,0x1CL,0xFE1B02E6L},{-1,1UL,7UL,0xEB38L,0x3AF7L,0x90L,4L},{-1,0x64L,0UL,0x7DB6L,0L,0xB2L,-1L}}},{{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{0,0xBCL,0xFBL,-6L,0x64BDL,5UL,0L},{-1,0x6AL,250UL,0x4A8EL,-1L,0xFBL,0xF2F5A14BL}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{0,252UL,1UL,0x81A1L,0x6C8FL,0x44L,-1L},{0,0xDEL,0UL,-4L,3L,0x61L,1L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-0,0x43L,0UL,-10L,-1L,254UL,1L},{-0,255UL,0x66L,0xF7F3L,-10L,0x15L,1L}},{{-1,0x98L,251UL,5L,0xAD94L,4UL,0x846CCD1CL},{-1,0x87L,0xD4L,1L,0x1DD4L,252UL,0xDBCE3D1AL},{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL}},{{-0,0x98L,0x26L,0xAC27L,-1L,0UL,0x7BE341A8L},{1,0x9AL,253UL,-4L,0xCAA1L,0x70L,-1L},{-0,0x0EL,0x57L,0x00D2L,-1L,0xBBL,7L}},{{0,255UL,1UL,0x35A0L,-10L,250UL,0x19A8424EL},{1,0xC5L,255UL,0xB8FEL,-9L,4UL,-4L},{1,0x8BL,0xD4L,0xE123L,0xF74DL,253UL,-4L}},{{0,0xF9L,246UL,0L,0xB9C6L,0x1CL,0xFE1B02E6L},{-1,0x87L,0xD4L,1L,0x1DD4L,252UL,0xDBCE3D1AL},{-1,0x6AL,250UL,0x4A8EL,-1L,0xFBL,0xF2F5A14BL}}}};
static volatile struct S1 g_566 = {0xCEL,0x58L,0x8E54L,5UL};/* VOLATILE GLOBAL g_566 */
static union U4 **g_629[4][7] = {{&g_355,&g_355,(void*)0,&g_355,&g_355,&g_355,(void*)0},{&g_355,&g_355,&g_355,&g_355,&g_355,&g_355,&g_355},{&g_355,&g_355,(void*)0,&g_355,&g_355,&g_355,&g_355},{&g_355,&g_355,&g_355,&g_355,&g_355,&g_355,&g_355}};
static union U3 g_636[1][7] = {{{-1L},{-1L},{8L},{-1L},{-1L},{8L},{-1L}}};
static uint32_t g_648 = 0xD9F1C507L;
static int32_t * volatile g_649[4][2] = {{&g_72,(void*)0},{&g_72,&g_72},{(void*)0,&g_72},{&g_72,(void*)0}};
static int32_t * volatile g_650 = &g_353[0].f1;/* VOLATILE GLOBAL g_650 */
static union U4 * const  volatile * const g_656[1] = {&g_355};
static union U4 * const  volatile * const  volatile * volatile g_655[3] = {&g_656[0],&g_656[0],&g_656[0]};
static union U4 * const  volatile * const  volatile * volatile * volatile g_654[8][3] = {{&g_655[1],&g_655[1],&g_655[1]},{&g_655[1],&g_655[1],&g_655[1]},{&g_655[1],&g_655[1],&g_655[1]},{&g_655[1],&g_655[1],&g_655[1]},{&g_655[1],&g_655[1],&g_655[1]},{&g_655[1],&g_655[1],&g_655[1]},{&g_655[1],&g_655[1],&g_655[1]},{&g_655[1],&g_655[1],&g_655[1]}};
static volatile struct S1 g_684 = {-1L,0x5CL,0L,65528UL};/* VOLATILE GLOBAL g_684 */
static volatile struct S1 * volatile g_685 = &g_356;/* VOLATILE GLOBAL g_685 */
static int32_t * const  volatile g_692 = &g_72;/* VOLATILE GLOBAL g_692 */
static struct S0 g_703 = {-1,0xEDL,0x40L,0x07C8L,0L,0xA6L,0xCC9C6768L};/* VOLATILE GLOBAL g_703 */
static union U4 g_709[7] = {{0xD9F0A788L},{0xD9F0A788L},{0xD9F0A788L},{0xD9F0A788L},{0xD9F0A788L},{0xD9F0A788L},{0xD9F0A788L}};
static volatile union U3 g_710 = {0x56L};/* VOLATILE GLOBAL g_710 */
static struct S1 g_721 = {1L,0xA2L,7L,65534UL};/* VOLATILE GLOBAL g_721 */
static volatile union U2 g_730 = {0x9AL};/* VOLATILE GLOBAL g_730 */
static union U4 ***g_737 = &g_629[1][2];
static union U4 ****g_736 = &g_737;
static union U4 *****g_735 = &g_736;
static const int32_t *g_753 = (void*)0;
static int32_t * volatile g_755 = &g_39;/* VOLATILE GLOBAL g_755 */
static volatile struct S0 g_757 = {-0,5UL,0x04L,9L,0x63C7L,1UL,-4L};/* VOLATILE GLOBAL g_757 */
static struct S1 g_758 = {0L,1UL,0x5AC5L,0x25D9L};/* VOLATILE GLOBAL g_758 */
static struct S1 * volatile g_759 = &g_709[6].f3;/* VOLATILE GLOBAL g_759 */
static uint8_t **g_763 = (void*)0;
static uint8_t *** volatile g_762 = &g_763;/* VOLATILE GLOBAL g_762 */
static volatile struct S0 g_773 = {0,0xD4L,253UL,1L,0L,255UL,0x03E4087FL};/* VOLATILE GLOBAL g_773 */
static volatile struct S1 * volatile g_778 = &g_353[0].f2;/* VOLATILE GLOBAL g_778 */
static union U2 g_781 = {0UL};/* VOLATILE GLOBAL g_781 */
static int8_t *g_787 = &g_347.f0;
static int8_t **g_786 = &g_787;
static union U4 g_794 = {0xD8A24427L};/* VOLATILE GLOBAL g_794 */
static union U4 g_796 = {0xC5021E95L};/* VOLATILE GLOBAL g_796 */
static int32_t *g_821 = &g_3;
static int32_t ** const  volatile g_820 = &g_821;/* VOLATILE GLOBAL g_820 */
static struct S0 g_836 = {-1,0UL,0x1CL,3L,0x2BECL,0xDEL,1L};/* VOLATILE GLOBAL g_836 */
static volatile union U3 g_861[1] = {{0x56L}};
static struct S0 g_895 = {1,0x51L,9UL,0x4D79L,0xEFA5L,0x4BL,-2L};/* VOLATILE GLOBAL g_895 */
static int32_t ** volatile g_907 = (void*)0;/* VOLATILE GLOBAL g_907 */
static int32_t ** volatile *g_906 = &g_907;
static uint64_t *g_910 = &g_781.f1;
static union U3 g_925 = {1L};/* VOLATILE GLOBAL g_925 */
static volatile struct S1 g_953 = {-6L,0xFEL,1L,0xEF29L};/* VOLATILE GLOBAL g_953 */
static struct S1 g_956[10][4] = {{{-8L,0x22L,-10L,0xC08DL},{0x7BL,0xACL,-3L,9UL},{8L,4UL,0xA7EDL,2UL},{0x7BL,0xACL,-3L,9UL}},{{-8L,0x22L,-10L,0xC08DL},{0x5CL,255UL,-1L,0x8816L},{3L,0UL,0xD762L,0xC0B5L},{0x7BL,0xACL,-3L,9UL}},{{3L,0UL,0xD762L,0xC0B5L},{0x7BL,0xACL,-3L,9UL},{3L,0UL,0xD762L,0xC0B5L},{0x5CL,255UL,-1L,0x8816L}},{{-8L,0x22L,-10L,0xC08DL},{0x7BL,0xACL,-3L,9UL},{8L,4UL,0xA7EDL,2UL},{0x7BL,0xACL,-3L,9UL}},{{-8L,0x22L,-10L,0xC08DL},{0x5CL,255UL,-1L,0x8816L},{3L,0UL,0xD762L,0xC0B5L},{0x7BL,0xACL,-3L,9UL}},{{3L,0UL,0xD762L,0xC0B5L},{0x7BL,0xACL,-3L,9UL},{3L,0UL,0xD762L,0xC0B5L},{0x5CL,255UL,-1L,0x8816L}},{{-8L,0x22L,-10L,0xC08DL},{0x7BL,0xACL,-3L,9UL},{8L,4UL,0xA7EDL,2UL},{0x7BL,0xACL,-3L,9UL}},{{-8L,0x22L,-10L,0xC08DL},{0x5CL,255UL,-1L,0x8816L},{3L,0UL,0xD762L,0xC0B5L},{0x7BL,0xACL,-3L,9UL}},{{3L,0UL,0xD762L,0xC0B5L},{0x7BL,0xACL,-3L,9UL},{3L,0UL,0xD762L,0xC0B5L},{0x5CL,255UL,-1L,0x8816L}},{{-8L,0x22L,-10L,0xC08DL},{0x7BL,0xACL,-3L,9UL},{8L,4UL,0xA7EDL,2UL},{0x7BL,0xACL,-3L,9UL}}};
static struct S1 * volatile g_957 = &g_956[7][0];/* VOLATILE GLOBAL g_957 */
static const struct S0 *g_969 = (void*)0;
static const struct S0 ** volatile g_970 = (void*)0;/* VOLATILE GLOBAL g_970 */
static const struct S0 *g_972 = &g_519[5][2][0];
static const struct S0 ** volatile g_971[2][9][6] = {{{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972}},{{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{(void*)0,&g_972,&g_972,&g_972,&g_972,&g_972},{&g_972,&g_972,&g_972,&g_972,&g_972,&g_972},{&g_972,&g_972,&g_972,&g_972,&g_972,&g_972}}};
static struct S0 g_975 = {-0,0x58L,255UL,3L,0x219BL,0xA7L,-1L};/* VOLATILE GLOBAL g_975 */
static volatile struct S1 g_976 = {8L,0x83L,4L,65529UL};/* VOLATILE GLOBAL g_976 */
static volatile struct S1 * volatile g_977[3] = {&g_353[0].f2,&g_353[0].f2,&g_353[0].f2};
static uint16_t g_1004 = 65535UL;
static struct S1 g_1025 = {-1L,0x54L,0L,1UL};/* VOLATILE GLOBAL g_1025 */
static volatile struct S1 g_1031 = {0x8BL,0x45L,0L,0x9718L};/* VOLATILE GLOBAL g_1031 */
static volatile struct S1 * volatile g_1032 = &g_1031;/* VOLATILE GLOBAL g_1032 */
static volatile struct S1 *g_1033 = &g_566;
static struct S1 g_1045 = {0x46L,0UL,1L,0xBA81L};/* VOLATILE GLOBAL g_1045 */
static struct S1 *g_1044 = &g_1045;
static uint32_t g_1055 = 5UL;
static volatile struct S1 g_1065 = {0L,0xE8L,0x157FL,0x584AL};/* VOLATILE GLOBAL g_1065 */
static struct S1 g_1090 = {0L,0xD5L,0x69AAL,0xEF8CL};/* VOLATILE GLOBAL g_1090 */
static const volatile struct S0 g_1122[3][9] = {{{0,2UL,0UL,0x65CFL,3L,0x33L,0xE4BD9A46L},{-0,0xACL,1UL,-1L,0x879CL,0xD4L,0xBB556CAAL},{-1,0x7DL,0xFCL,5L,0x6971L,0x32L,1L},{-0,0x2FL,0x84L,0x1C53L,1L,0x65L,0x668A1B4AL},{-1,0x7DL,0xFCL,5L,0x6971L,0x32L,1L},{-0,0xACL,1UL,-1L,0x879CL,0xD4L,0xBB556CAAL},{0,2UL,0UL,0x65CFL,3L,0x33L,0xE4BD9A46L},{0,0UL,0x2AL,0x034EL,0x03EDL,8UL,0xB3EFFAA9L},{-1,250UL,0xEAL,1L,0x6168L,0xC5L,-1L}},{{1,0x4FL,246UL,0xBB8EL,1L,0x40L,0x37588C08L},{-1,250UL,0xEAL,1L,0x6168L,0xC5L,-1L},{0,2UL,0UL,0x65CFL,3L,0x33L,0xE4BD9A46L},{-0,7UL,0xD4L,0x74EFL,-1L,0xB9L,6L},{0,0UL,0x2AL,0x034EL,0x03EDL,8UL,0xB3EFFAA9L},{-0,7UL,0xD4L,0x74EFL,-1L,0xB9L,6L},{0,2UL,0UL,0x65CFL,3L,0x33L,0xE4BD9A46L},{-1,250UL,0xEAL,1L,0x6168L,0xC5L,-1L},{1,0x4FL,246UL,0xBB8EL,1L,0x40L,0x37588C08L}},{{-0,0xACL,1UL,-1L,0x879CL,0xD4L,0xBB556CAAL},{-0,7UL,0xD4L,0x74EFL,-1L,0xB9L,6L},{1,0x4FL,246UL,0xBB8EL,1L,0x40L,0x37588C08L},{0,0UL,0x2AL,0x034EL,0x03EDL,8UL,0xB3EFFAA9L},{0,7UL,0UL,0L,5L,0xD0L,-10L},{-1,0x7DL,0xFCL,5L,0x6971L,0x32L,1L},{0,7UL,0UL,0L,5L,0xD0L,-10L},{0,0UL,0x2AL,0x034EL,0x03EDL,8UL,0xB3EFFAA9L},{1,0x4FL,246UL,0xBB8EL,1L,0x40L,0x37588C08L}}};
static union U3 g_1123 = {0xBEL};/* VOLATILE GLOBAL g_1123 */
static volatile struct S1 g_1135 = {-9L,251UL,0xFB56L,0UL};/* VOLATILE GLOBAL g_1135 */
static struct S1 g_1165 = {0x9EL,7UL,0x421CL,0x1DDAL};/* VOLATILE GLOBAL g_1165 */
static int32_t * volatile g_1170 = &g_794.f1;/* VOLATILE GLOBAL g_1170 */
static const struct S1 g_1241 = {0xC5L,0x6BL,0L,0x68EFL};/* VOLATILE GLOBAL g_1241 */
static struct S1 g_1262 = {-1L,0x06L,0x9819L,65529UL};/* VOLATILE GLOBAL g_1262 */
static struct S1 g_1263[8][8] = {{{-1L,252UL,0x5654L,8UL},{0x62L,2UL,6L,9UL},{6L,0x5EL,0x7E17L,9UL},{0x62L,2UL,6L,9UL},{-1L,252UL,0x5654L,8UL},{0xD4L,1UL,0xB060L,0x45EAL},{1L,0xD2L,0x62CDL,1UL},{0xEAL,1UL,0L,0x644FL}},{{0x50L,0xB6L,0L,8UL},{1L,1UL,0x31CEL,0xF44BL},{0x62L,2UL,6L,9UL},{6L,0x6BL,-1L,0xECE6L},{-4L,0x62L,0L,1UL},{-4L,0x62L,0L,1UL},{6L,0x6BL,-1L,0xECE6L},{0x62L,2UL,6L,9UL}},{{0xEAL,1UL,0L,0x644FL},{0xEAL,1UL,0L,0x644FL},{0x62L,2UL,6L,9UL},{0xA7L,0x37L,1L,0x599EL},{0x55L,253UL,0xAB0EL,0xAA40L},{0x77L,1UL,0xB703L,0UL},{1L,0xD2L,0x62CDL,1UL},{0x50L,0xB6L,0L,8UL}},{{-4L,0x62L,0L,1UL},{1L,0xD2L,0x62CDL,1UL},{6L,0x5EL,0x7E17L,9UL},{0xEAL,1UL,0L,0x644FL},{6L,0x5EL,0x7E17L,9UL},{1L,0xD2L,0x62CDL,1UL},{-4L,0x62L,0L,1UL},{0x50L,0xB6L,0L,8UL}},{{1L,0xD2L,0x62CDL,1UL},{0x77L,1UL,0xB703L,0UL},{0x55L,253UL,0xAB0EL,0xAA40L},{0xA7L,0x37L,1L,0x599EL},{0x62L,2UL,6L,9UL},{0xEAL,1UL,0L,0x644FL},{0xEAL,1UL,0L,0x644FL},{0x62L,2UL,6L,9UL}},{{6L,0x6BL,-1L,0xECE6L},{-4L,0x62L,0L,1UL},{-4L,0x62L,0L,1UL},{6L,0x6BL,-1L,0xECE6L},{0x62L,2UL,6L,9UL},{1L,1UL,0x31CEL,0xF44BL},{0x50L,0xB6L,0L,8UL},{0xEAL,1UL,0L,0x644FL}},{{1L,0xD2L,0x62CDL,1UL},{0xD4L,1UL,0xB060L,0x45EAL},{-1L,252UL,0x5654L,8UL},{0x62L,2UL,6L,9UL},{6L,0x5EL,0x7E17L,9UL},{0x62L,2UL,6L,9UL},{-1L,252UL,0x5654L,8UL},{0xD4L,1UL,0xB060L,0x45EAL}},{{-4L,0x62L,0L,1UL},{0xD4L,1UL,0xB060L,0x45EAL},{0xEAL,1UL,0L,0x644FL},{-1L,252UL,0x5654L,8UL},{0x55L,253UL,0xAB0EL,0xAA40L},{1L,1UL,0x31CEL,0xF44BL},{0xA7L,0x37L,1L,0x599EL},{0xA7L,0x37L,1L,0x599EL}}};
static const union U2 * const g_1350[4][9] = {{(void*)0,&g_781,(void*)0,&g_781,&g_781,&g_781,&g_781,&g_781,&g_781},{(void*)0,&g_781,(void*)0,&g_781,&g_781,&g_781,&g_781,&g_781,&g_781},{(void*)0,&g_781,(void*)0,&g_781,&g_781,&g_781,&g_781,&g_781,&g_781},{(void*)0,&g_781,(void*)0,&g_781,&g_781,&g_781,&g_781,&g_781,&g_781}};
static const union U2 * const  volatile * volatile g_1349 = &g_1350[1][8];/* VOLATILE GLOBAL g_1349 */
static volatile struct S1 g_1378 = {-1L,0xB5L,0xFCD3L,0x706CL};/* VOLATILE GLOBAL g_1378 */
static const uint32_t g_1388 = 18446744073709551615UL;
static volatile union U2 * volatile g_1391 = (void*)0;/* VOLATILE GLOBAL g_1391 */
static volatile union U3 g_1395 = {0xD3L};/* VOLATILE GLOBAL g_1395 */
static struct S1 g_1402 = {0xF1L,7UL,-7L,0x8E7EL};/* VOLATILE GLOBAL g_1402 */
static int64_t g_1428 = 0x378AF40198DF0C13LL;
static uint64_t g_1429 = 0xD6C8C5A71A5FFC3ELL;
static union U2 g_1440 = {7UL};/* VOLATILE GLOBAL g_1440 */
static union U3 *g_1461 = &g_636[0][3];
static union U3 ** volatile g_1460 = &g_1461;/* VOLATILE GLOBAL g_1460 */
static union U3 ** volatile g_1471 = &g_1461;/* VOLATILE GLOBAL g_1471 */
static union U2 g_1486 = {0x69L};/* VOLATILE GLOBAL g_1486 */
static struct S0 g_1487[5] = {{-0,0xFBL,0x2AL,0xAC2BL,0xBCF4L,0x74L,1L},{-0,0xFBL,0x2AL,0xAC2BL,0xBCF4L,0x74L,1L},{-0,0xFBL,0x2AL,0xAC2BL,0xBCF4L,0x74L,1L},{-0,0xFBL,0x2AL,0xAC2BL,0xBCF4L,0x74L,1L},{-0,0xFBL,0x2AL,0xAC2BL,0xBCF4L,0x74L,1L}};
static union U2 g_1544 = {0x95L};/* VOLATILE GLOBAL g_1544 */
static volatile struct S1 g_1546 = {0x9AL,0xFBL,0x1D4BL,65535UL};/* VOLATILE GLOBAL g_1546 */
static const uint32_t g_1547 = 18446744073709551612UL;
static union U4 g_1553 = {1L};/* VOLATILE GLOBAL g_1553 */
static volatile struct S0 g_1647 = {-0,0xECL,0xE0L,0xEF6CL,0xDDAAL,0xC3L,0x3C3003BCL};/* VOLATILE GLOBAL g_1647 */
static uint32_t g_1677[5][10] = {{0x8637697DL,0xDC3424E6L,4294967295UL,4294967291UL,4294967295UL,0xDC3424E6L,0x8637697DL,3UL,0x841B5D9DL,0x841B5D9DL},{0x8637697DL,0x841B5D9DL,0xEBBB7834L,0xF17CE963L,0xF17CE963L,0xEBBB7834L,0x841B5D9DL,0x8637697DL,0x7C850275L,3UL},{0xEBBB7834L,0x841B5D9DL,0x8637697DL,0x7C850275L,3UL,0x7C850275L,0x8637697DL,0x841B5D9DL,0xEBBB7834L,0xF17CE963L},{4294967295UL,0xDC3424E6L,0x8637697DL,3UL,0x841B5D9DL,0x841B5D9DL,3UL,0x8637697DL,0xDC3424E6L,0xEBBB7834L},{1UL,0xDC3424E6L,0xF17CE963L,0x841B5D9DL,4294967291UL,0xEBBB7834L,4294967291UL,0x841B5D9DL,0xF17CE963L,0xDC3424E6L}};
static uint16_t ** volatile * volatile * volatile g_1679[8][2][6] = {{{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505},{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505}},{{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505},{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505}},{{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505},{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505}},{{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505},{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505}},{{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505},{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505}},{{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505},{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505}},{{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505},{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505}},{{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505},{&g_505,&g_505,&g_505,&g_505,&g_505,&g_505}}};
static union U2 g_1692 = {0xA8L};/* VOLATILE GLOBAL g_1692 */
static struct S0 g_1696 = {0,1UL,252UL,0x4F48L,3L,0x65L,0x8E6C18C3L};/* VOLATILE GLOBAL g_1696 */
static uint16_t g_1699 = 65535UL;
static struct S1 g_1706 = {0xE2L,0xBCL,7L,65535UL};/* VOLATILE GLOBAL g_1706 */
static struct S1 g_1707 = {0xA2L,0xA6L,1L,0xBA61L};/* VOLATILE GLOBAL g_1707 */
static struct S1 g_1708 = {9L,248UL,1L,3UL};/* VOLATILE GLOBAL g_1708 */
static struct S1 g_1709 = {0xB9L,252UL,6L,1UL};/* VOLATILE GLOBAL g_1709 */
static struct S1 g_1710 = {0xBAL,0x3DL,0x1785L,65531UL};/* VOLATILE GLOBAL g_1710 */
static union U4 g_1716 = {-1L};/* VOLATILE GLOBAL g_1716 */
static int32_t ** volatile g_1720 = &g_68;/* VOLATILE GLOBAL g_1720 */
static uint8_t ***g_1779 = &g_763;
static uint8_t ****g_1778 = &g_1779;
static volatile union U4 * volatile * const  volatile * const * volatile g_1821 = (void*)0;/* VOLATILE GLOBAL g_1821 */
static uint32_t g_1835 = 1UL;
static volatile union U3 g_1842 = {0xADL};/* VOLATILE GLOBAL g_1842 */
static uint32_t **g_1847 = (void*)0;
static volatile int32_t g_1873 = 0L;/* VOLATILE GLOBAL g_1873 */
static volatile union U4 g_1880 = {0x7865CC78L};/* VOLATILE GLOBAL g_1880 */
static const union U4 g_1889 = {0L};/* VOLATILE GLOBAL g_1889 */
static int8_t ***g_1900[6][9][1] = {{{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786}},{{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786}},{{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786}},{{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786}},{{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786}},{{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786},{&g_786}}};
static struct S1 **g_1909 = &g_1044;
static struct S1 * volatile g_1919 = (void*)0;/* VOLATILE GLOBAL g_1919 */
static const volatile struct S0 g_1946 = {1,0xCDL,247UL,-3L,0x58D0L,0x16L,0x0073E8F6L};/* VOLATILE GLOBAL g_1946 */
static union U2 g_1953 = {1UL};/* VOLATILE GLOBAL g_1953 */
static int32_t ***g_1969 = (void*)0;
static struct S1 g_2010 = {1L,1UL,0xBE0CL,65530UL};/* VOLATILE GLOBAL g_2010 */
static union U4 ** volatile g_2044[4] = {&g_355,&g_355,&g_355,&g_355};
static union U4 ** const  volatile g_2045 = &g_355;/* VOLATILE GLOBAL g_2045 */
static struct S0 *g_2059 = &g_895;
static struct S0 ** volatile g_2058 = &g_2059;/* VOLATILE GLOBAL g_2058 */
static int64_t g_2084 = 0x1DF31F13FAA4F2DALL;
static uint16_t ***g_2097 = &g_506;
static uint16_t ****g_2096[3][4][1] = {{{(void*)0},{&g_2097},{(void*)0},{(void*)0}},{{&g_2097},{(void*)0},{(void*)0},{&g_2097}},{{(void*)0},{(void*)0},{&g_2097},{(void*)0}}};
static uint16_t *****g_2095 = &g_2096[0][3][0];
static uint16_t *****g_2099[6] = {&g_2096[0][3][0],&g_2096[0][3][0],&g_2096[0][3][0],&g_2096[0][3][0],&g_2096[0][3][0],&g_2096[0][3][0]};
static uint16_t *****g_2100 = &g_2096[0][3][0];
static uint16_t *****g_2101 = &g_2096[0][3][0];
static union U2 g_2135 = {0x92L};/* VOLATILE GLOBAL g_2135 */
static int32_t ****g_2137 = &g_1969;
static int32_t *****g_2136 = &g_2137;
static const volatile struct S0 g_2157 = {0,0x9AL,253UL,-6L,0x942AL,0x19L,-5L};/* VOLATILE GLOBAL g_2157 */
static union U2 g_2161 = {1UL};/* VOLATILE GLOBAL g_2161 */
static union U2 g_2162 = {0xCCL};/* VOLATILE GLOBAL g_2162 */


/* --- FORWARD DECLARATIONS --- */
static union U2  func_1(void);
static struct S1  func_5(uint32_t  p_6, int32_t  p_7, int32_t  p_8, int64_t  p_9, const uint64_t  p_10);
static uint64_t  func_13(int8_t  p_14);
static int8_t  func_22(int32_t  p_23);
static uint32_t  func_24(uint32_t  p_25);
static uint64_t  func_26(uint16_t  p_27, uint32_t  p_28, uint32_t  p_29, const uint64_t  p_30);
static int32_t * func_40(uint16_t  p_41);
static int8_t  func_51(const int8_t * p_52, int8_t * p_53, int32_t * p_54, int16_t  p_55);
static const int8_t * func_56(const int32_t * p_57, int16_t  p_58);
static const union U4  func_59(const int8_t * p_60, int8_t * const  p_61, uint16_t  p_62);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_2162
 * writes: g_3 g_4
 */
static union U2  func_1(void)
{ /* block id: 0 */
    uint16_t l_2[5][10] = {{65529UL,7UL,1UL,0UL,0UL,1UL,7UL,65529UL,65529UL,7UL},{65529UL,0UL,7UL,7UL,0UL,65529UL,1UL,1UL,65529UL,0UL},{0UL,7UL,7UL,0UL,65529UL,1UL,1UL,65529UL,0UL,7UL},{0UL,0UL,1UL,7UL,65529UL,65529UL,7UL,1UL,0UL,0UL},{65529UL,7UL,1UL,0UL,0UL,1UL,7UL,65529UL,65529UL,7UL}};
    int32_t l_35 = (-4L);
    uint32_t l_1653 = 4294967293UL;
    int32_t **l_1967 = &g_68;
    int32_t ***l_1966[9] = {&l_1967,&l_1967,&l_1967,&l_1967,&l_1967,&l_1967,&l_1967,&l_1967,&l_1967};
    struct S1 **l_2024[5];
    uint8_t * const l_2107 = &g_299.f2;
    uint16_t l_2139 = 0x025FL;
    int32_t l_2143 = 0xC7D46AC6L;
    const struct S0 **l_2159 = &g_972;
    int i, j;
    for (i = 0; i < 5; i++)
        l_2024[i] = &g_1044;
    for (g_3 = 4; (g_3 >= 0); g_3 -= 1)
    { /* block id: 3 */
        uint32_t l_19 = 0x36717B38L;
        uint16_t ***l_1928 = (void*)0;
        uint16_t ***l_1929[1][5][6] = {{{&g_506,&g_506,&g_506,&g_506,&g_506,(void*)0},{&g_506,&g_506,&g_506,&g_506,&g_506,(void*)0},{&g_506,&g_506,&g_506,&g_506,&g_506,(void*)0},{&g_506,&g_506,&g_506,&g_506,&g_506,(void*)0},{&g_506,&g_506,&g_506,&g_506,&g_506,(void*)0}}};
        uint8_t *l_1938 = (void*)0;
        uint8_t *l_1939 = &g_1440.f0;
        uint8_t *l_1944[1][2];
        const int32_t l_1945 = (-6L);
        int64_t l_2007 = 0xF521800D64FB58F0LL;
        uint32_t l_2023[5] = {18446744073709551609UL,18446744073709551609UL,18446744073709551609UL,18446744073709551609UL,18446744073709551609UL};
        int32_t l_2025[4][5] = {{0xA09CBE01L,6L,0xA09CBE01L,0xA09CBE01L,6L},{6L,0xA09CBE01L,0xA09CBE01L,6L,0xA09CBE01L},{6L,6L,0L,6L,6L},{0xA09CBE01L,6L,0xA09CBE01L,0xA09CBE01L,6L}};
        int32_t l_2026 = (-1L);
        union U4 *l_2043[5][3][9] = {{{(void*)0,&g_1716,(void*)0,&g_1716,(void*)0,(void*)0,&g_1716,(void*)0,&g_1716},{&g_709[4],&g_353[1],&g_709[6],&g_709[2],&g_353[1],&g_353[1],&g_353[4],&g_709[6],&g_709[6]},{(void*)0,(void*)0,&g_1716,&g_1716,&g_1716,(void*)0,(void*)0,&g_1716,(void*)0}},{{&g_353[3],&g_353[1],&g_353[0],&g_709[4],&g_353[1],&g_353[0],&g_353[4],&g_353[0],&g_353[1]},{&g_353[0],&g_1716,&g_1716,&g_353[0],&g_353[0],&g_709[3],&g_1716,&g_1716,&g_709[3]},{&g_709[4],&g_353[1],&g_709[6],&g_709[4],&g_353[0],&g_353[0],&g_709[4],&g_709[6],&g_353[1]}},{{&g_1716,&g_353[0],(void*)0,&g_1716,&g_353[0],&g_1716,(void*)0,(void*)0,(void*)0},{&g_709[4],&g_353[0],&g_353[1],&g_709[2],&g_353[1],&g_353[0],&g_709[4],&g_353[1],&g_709[6]},{&g_353[0],&g_353[0],&g_709[3],&g_1716,&g_1716,&g_709[3],(void*)0,&g_709[3],&g_1716}},{{&g_353[3],&g_353[1],&g_353[1],&g_709[6],&g_709[6],&g_1553,&g_353[0],&g_794,&g_1553},{&g_1716,&g_794,(void*)0,&g_709[3],&g_794,&g_794,&g_709[3],(void*)0,&g_794},{&g_353[0],&g_709[6],(void*)0,&g_353[1],&g_709[6],&g_794,&g_353[0],(void*)0,(void*)0}},{{&g_1716,&g_794,&g_794,&g_353[0],&g_794,&g_794,&g_1716,&g_794,(void*)0},{&g_709[6],&g_709[6],&g_1553,&g_353[0],&g_794,&g_1553,&g_353[0],&g_1553,&g_794},{(void*)0,&g_794,&g_794,(void*)0,&g_1553,&g_709[6],&g_709[3],&g_794,&g_709[6]}}};
        uint32_t *l_2078[6];
        uint32_t **l_2077 = &l_2078[3];
        uint64_t l_2119[5][4][3] = {{{0UL,0UL,0UL},{1UL,1UL,1UL},{0UL,0UL,0UL},{1UL,1UL,1UL}},{{0UL,0UL,0UL},{1UL,1UL,1UL},{0UL,0UL,0UL},{1UL,1UL,1UL}},{{0UL,0UL,0UL},{1UL,1UL,1UL},{0UL,0UL,0UL},{1UL,1UL,1UL}},{{0UL,0UL,0UL},{1UL,1UL,1UL},{0UL,0UL,0UL},{1UL,1UL,1UL}},{{0UL,0UL,0UL},{1UL,1UL,1UL},{0UL,0UL,0UL},{1UL,1UL,1UL}}};
        uint8_t ***l_2132 = &g_763;
        int i, j, k;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_1944[i][j] = (void*)0;
        }
        for (i = 0; i < 6; i++)
            l_2078[i] = (void*)0;
        for (g_4 = 4; (g_4 >= 0); g_4 -= 1)
        { /* block id: 6 */
            int8_t *l_33[1];
            struct S1 *l_1920 = &g_636[0][2].f2;
            int i, j;
            for (i = 0; i < 1; i++)
                l_33[i] = &g_34;
        }
    }
    return g_2162;
}


/* ------------------------------------------ */
/* 
 * reads : g_1033 g_566
 * writes:
 */
static struct S1  func_5(uint32_t  p_6, int32_t  p_7, int32_t  p_8, int64_t  p_9, const uint64_t  p_10)
{ /* block id: 921 */
    return (*g_1033);
}


/* ------------------------------------------ */
/* 
 * reads : g_1546.f0 g_502 g_39 g_1025.f2 g_1677 g_1692 g_1696 g_519.f0 g_506 g_507 g_1699 g_1720 g_68 g_313 g_314 g_122 g_118 g_753 g_4 g_787 g_1647.f4 g_72 g_307 g_703.f6 g_786 g_347.f0 g_220 g_221 g_505 g_1402.f1 g_235.f2 g_1262.f0 g_1821 g_836.f0 g_94.f2 g_1835 g_1716 g_1842 g_1847 g_1241.f2 g_1122.f1 g_67 g_1647 g_1873 g_235.f1 g_94.f4 g_1428 g_1544.f1 g_755 g_794.f0
 * writes: g_794.f0 g_122 g_252 g_1004 g_68 g_925.f2.f2 g_118 g_347.f0 g_307 g_1778 g_1677 g_709.f1 g_39 g_721.f0 g_1090.f0 g_1262.f2 g_72 g_1553.f3.f2 g_1486.f1 g_1428 g_1544.f1
 */
static uint64_t  func_13(int8_t  p_14)
{ /* block id: 804 */
    int16_t l_1654 = 0x6890L;
    int32_t l_1655 = 7L;
    int32_t *l_1656 = &g_794.f1;
    int32_t *l_1657 = &g_39;
    int32_t l_1658 = 0xA1A1F6D7L;
    int32_t *l_1659 = &g_72;
    int32_t *l_1660 = &g_709[6].f1;
    int32_t *l_1661 = &l_1655;
    int32_t *l_1662 = &g_307;
    int32_t *l_1663[6][6] = {{&g_4,(void*)0,(void*)0,&g_4,(void*)0,(void*)0},{&g_4,(void*)0,(void*)0,&g_4,(void*)0,(void*)0},{&g_4,(void*)0,(void*)0,&g_4,(void*)0,(void*)0},{&g_4,(void*)0,(void*)0,&g_4,(void*)0,(void*)0},{&g_4,(void*)0,(void*)0,&g_4,(void*)0,(void*)0},{&g_4,(void*)0,(void*)0,&g_4,(void*)0,(void*)0}};
    uint8_t l_1664 = 1UL;
    uint16_t ** volatile * volatile * volatile *l_1678 = &g_1679[3][1][1];
    const struct S0 **l_1693 = &g_972;
    union U4 ****l_1717 = &g_737;
    uint16_t l_1750 = 3UL;
    int8_t ***l_1896 = (void*)0;
    int32_t l_1913 = 6L;
    int i, j;
lbl_1751:
    l_1664--;
    for (g_794.f0 = 5; (g_794.f0 >= 0); g_794.f0 -= 1)
    { /* block id: 808 */
        uint64_t l_1667 = 0x729569C4FBC42E24LL;
        int64_t *l_1674 = (void*)0;
        int64_t *l_1675[3];
        int32_t l_1676 = 0x8F4C7762L;
        int64_t l_1697 = (-1L);
        union U2 * const *l_1711 = (void*)0;
        uint8_t ***l_1776 = &g_763;
        uint8_t ****l_1775 = &l_1776;
        uint32_t l_1783 = 0x1E290F98L;
        union U4 **** const l_1822 = &g_737;
        struct S1 **l_1906 = (void*)0;
        int i;
        for (i = 0; i < 3; i++)
            l_1675[i] = &g_100;
        if ((l_1667 > (safe_sub_func_int16_t_s_s((g_1546.f0 != ((safe_sub_func_int64_t_s_s((((((l_1676 = (l_1667 >= ((l_1667 > ((void*)0 == g_502)) == p_14))) && l_1667) & 0x1D97L) | p_14) < (*l_1657)), g_1025.f2)) <= g_1677[0][3])), l_1667))))
        { /* block id: 810 */
            uint32_t l_1686 = 0UL;
            const int8_t *l_1691 = &g_426;
            const int8_t * const *l_1690 = &l_1691;
            uint16_t *l_1698 = &g_1004;
            int32_t l_1700[6];
            uint64_t l_1721 = 0x29358F1D160E0F0DLL;
            int i;
            for (i = 0; i < 6; i++)
                l_1700[i] = 0x8079D45DL;
            l_1678 = g_502;
            if ((safe_mul_func_uint64_t_u_u(0xBF84027DFF2D6367LL, (l_1700[2] = ((safe_rshift_func_int64_t_s_s((safe_lshift_func_uint16_t_u_u(((*l_1698) = (l_1686 , ((~((g_252 = (((**g_506) = (safe_lshift_func_uint16_t_u_s((l_1690 == (void*)0), ((((((((&g_972 != (g_1692 , l_1693)) || (safe_add_func_uint64_t_u_u((g_1696 , ((void*)0 != &l_1676)), 0x80785013FEA642B6LL))) , l_1697) , 0xDBD774C5B67F11FDLL) > l_1676) & 9L) ^ g_519[4][2][2].f0) >= 0xF181L)))) || 0x67ABL)) <= p_14)) && p_14))), 6)), l_1686)) < g_1699)))))
            { /* block id: 816 */
                struct S1 * const l_1705[1][5][7] = {{{&g_1709,&g_1708,&g_1708,&g_1709,&g_1706,&g_1709,&g_1708},{&g_1707,&g_1707,&g_1708,&g_1710,&g_1708,&g_1707,&g_1707},{&g_1707,&g_1708,&g_1710,&g_1708,&g_1707,&g_1707,&g_1708},{&g_1709,&g_1706,&g_1709,&g_1708,&g_1708,&g_1709,&g_1706},{&g_1708,&g_1706,&g_1710,&g_1710,&g_1706,&g_1708,&g_1706}}};
                struct S1 * const *l_1704 = &l_1705[0][4][2];
                struct S1 * const **l_1703 = &l_1704;
                int32_t l_1718 = 0x64C01FE1L;
                int32_t *l_1719 = &g_39;
                int i, j, k;
                (*g_1720) = (l_1700[4] , ((safe_add_func_uint8_t_u_u((&g_685 == ((*l_1703) = &g_1044)), (l_1711 != (void*)0))) , l_1719));
            }
            else
            { /* block id: 819 */
                return l_1721;
            }
        }
        else
        { /* block id: 822 */
            uint32_t l_1722 = 18446744073709551615UL;
            ++l_1722;
            return p_14;
        }
        if (p_14)
        { /* block id: 826 */
            int8_t l_1736 = 0xD5L;
            uint8_t **** const l_1782 = &g_1779;
            int16_t l_1808 = 0x1350L;
            int64_t l_1809 = (-6L);
            union U3 * const *l_1833 = &g_1461;
            for (l_1667 = 0; (l_1667 <= 5); l_1667 += 1)
            { /* block id: 829 */
                uint64_t l_1725 = 18446744073709551615UL;
                uint32_t *l_1739 = &g_648;
                uint32_t *l_1741 = (void*)0;
                int32_t l_1748 = 1L;
                int32_t l_1813 = 0xB17E00CDL;
                int32_t l_1814 = 0x4875A586L;
                uint32_t l_1815 = 0x3FF7DEFEL;
                uint8_t l_1836 = 5UL;
                for (g_925.f2.f2 = 0; (g_925.f2.f2 <= 5); g_925.f2.f2 += 1)
                { /* block id: 832 */
                    uint32_t *l_1743 = &g_648;
                    uint8_t *****l_1777 = (void*)0;
                    uint32_t *l_1784 = &g_1677[3][7];
                    int i, j;
                    if (p_14)
                    { /* block id: 833 */
                        return p_14;
                    }
                    else
                    { /* block id: 835 */
                        uint32_t **l_1740 = &l_1739;
                        uint32_t **l_1742[10] = {&l_1741,&l_1741,&l_1741,&l_1741,&l_1741,&l_1741,&l_1741,&l_1741,&l_1741,&l_1741};
                        int32_t l_1749 = 0x3C612854L;
                        int i;
                        (*l_1662) ^= (((((l_1725 & (p_14 != p_14)) != (safe_add_func_int8_t_s_s(((*g_787) = ((safe_mul_func_uint32_t_u_u(((void*)0 == (*g_1720)), (((safe_rshift_func_int32_t_s_s((safe_mul_func_int16_t_s_s(0L, (safe_mul_func_uint16_t_u_u((++(**g_313)), ((((*l_1740) = l_1739) == (l_1743 = l_1741)) == (((safe_div_func_int32_t_s_s((safe_mul_func_uint8_t_u_u(l_1748, p_14)), (*g_753))) > l_1749) <= 0x5EL)))))), l_1749)) & l_1750) , 1L))) != 0UL)), l_1725))) , g_1647.f4) , (*l_1659)) , p_14);
                    }
                    if (g_1696.f4)
                        goto lbl_1751;
                    (*g_68) = (((((safe_unary_minus_func_int8_t_s(0x14L)) >= p_14) >= 0x7EL) < (((*l_1660) = (safe_mod_func_uint32_t_u_u((safe_mul_func_uint8_t_u_u(((safe_div_func_int32_t_s_s(0x0EC81CD8L, (safe_lshift_func_int16_t_s_u(g_703.f6, 6)))) || (safe_lshift_func_int8_t_s_u((safe_mod_func_int64_t_s_s((safe_div_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_u(((**g_786) < (((*l_1784) = (safe_rshift_func_int64_t_s_u(((l_1748 = ((0xF6L || (((safe_rshift_func_int16_t_s_u(((~(safe_unary_minus_func_uint16_t_u((((g_1778 = l_1775) == ((safe_add_func_uint64_t_u_u(p_14, (*g_220))) , l_1782)) < p_14)))) == l_1783), l_1736)) , 65535UL) ^ 0x1556L)) , l_1697)) <= l_1736), 0))) ^ 0x444551E5L)), 3)) || 0xBDL), p_14)), g_1696.f1)), 5))), p_14)), (-7L)))) == 2L)) > p_14);
                }
                for (g_721.f0 = 1; (g_721.f0 >= 0); g_721.f0 -= 1)
                { /* block id: 851 */
                    uint64_t *l_1810 = &g_1486.f1;
                    uint64_t *l_1811 = (void*)0;
                    uint64_t *l_1812[5][4] = {{&g_1429,&g_1429,&g_1429,&g_1429},{(void*)0,&g_1429,(void*)0,&g_1429},{&g_1429,&l_1667,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1429,(void*)0},{&g_1429,&l_1667,&g_1429,&g_1429}};
                    uint32_t *l_1850 = (void*)0;
                    uint32_t **l_1849 = &l_1850;
                    int i, j, k;
                    (*g_68) |= (((((safe_lshift_func_int16_t_s_s((safe_mod_func_int16_t_s_s(((safe_mod_func_int8_t_s_s((safe_sub_func_uint8_t_u_u((safe_sub_func_uint64_t_u_u(((l_1736 == ((safe_add_func_uint8_t_u_u((safe_add_func_int64_t_s_s((safe_lshift_func_int16_t_s_u((((**g_506)++) == l_1667), 12)), (l_1813 ^= ((((-1L) == (l_1748 | ((((safe_mod_func_uint32_t_u_u((l_1748 > (((void*)0 == (*g_505)) <= (l_1676 & ((safe_unary_minus_func_int32_t_s((*g_753))) < l_1808)))), 0x09A5BE62L)) >= l_1809) , 4294967288UL) ^ g_1402.f1))) != 0x0BL) > p_14)))), l_1676)) != 255UL)) <= p_14), g_235.f2)), 0UL)), (**g_786))) != p_14), l_1814)), l_1809)) || 6L) != g_1262.f0) || l_1815) != p_14);
                    if ((4L >= ((+0xE66AL) >= ((l_1809 , (safe_mod_func_uint16_t_u_u((l_1676 | p_14), p_14))) == (safe_lshift_func_uint64_t_u_s((g_1821 != l_1822), (0xAA37F42CL < 0x5FDB88DFL)))))))
                    { /* block id: 855 */
                        uint32_t l_1834 = 0x5D8A3155L;
                        int32_t l_1837 = 0x150E4C19L;
                        uint32_t ***l_1848[7][2][4] = {{{(void*)0,(void*)0,&g_1847,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1847,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,&g_1847,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1847,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,&g_1847,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}}};
                        int i, j, k;
                        (*l_1657) &= ((safe_lshift_func_uint16_t_u_u(0x94E0L, 7)) || 0xA551DDB7L);
                        l_1837 ^= (safe_rshift_func_int64_t_s_u((l_1813 ^= (l_1814 || ((*g_220) == ((safe_mul_func_uint64_t_u_u(0UL, (safe_rshift_func_uint16_t_u_u((((safe_sub_func_int16_t_s_s(((((l_1833 == (p_14 , &g_1461)) < (((((*g_68) |= 0xCF1CDD1EL) & p_14) & p_14) != g_836.f0)) == l_1834) > g_94.f2), l_1783)) ^ p_14) > 0UL), 3)))) != g_1835)))), l_1836));
                        (*l_1657) = (p_14 <= (g_1716 , (((safe_lshift_func_int16_t_s_u((0x7CL & p_14), 5)) && ((safe_div_func_int32_t_s_s((g_1842 , (safe_mul_func_int64_t_s_s((((p_14 >= ((safe_sub_func_uint8_t_u_u(l_1814, (((l_1849 = g_1847) != &g_162) && (**g_786)))) <= 0x0AL)) , (-1L)) ^ p_14), g_1241.f2))), l_1837)) && 0x28L)) < p_14)));
                    }
                    else
                    { /* block id: 862 */
                        return p_14;
                    }
                    for (g_1090.f0 = 0; (g_1090.f0 <= 1); g_1090.f0 += 1)
                    { /* block id: 867 */
                        uint32_t l_1851[3][10] = {{4294967295UL,0x47D4B2C6L,4294967295UL,4294967295UL,0x47D4B2C6L,4294967295UL,4294967295UL,0x47D4B2C6L,4294967295UL,4294967295UL},{0x47D4B2C6L,0x47D4B2C6L,0x64507CD8L,0x47D4B2C6L,0x47D4B2C6L,0x64507CD8L,0x47D4B2C6L,0x47D4B2C6L,0x64507CD8L,0x47D4B2C6L},{0x47D4B2C6L,4294967295UL,4294967295UL,0x47D4B2C6L,4294967295UL,4294967295UL,0x47D4B2C6L,4294967295UL,4294967295UL,0x47D4B2C6L}};
                        int i, j;
                        ++l_1851[1][9];
                        (*g_68) ^= (-1L);
                        if (l_1676)
                            continue;
                        return g_1122[0][4].f1;
                    }
                }
            }
            for (g_1262.f2 = 0; (g_1262.f2 <= 5); g_1262.f2 += 1)
            { /* block id: 877 */
                uint8_t ** const *l_1855[6];
                uint8_t ** const **l_1854 = &l_1855[0];
                int i, j;
                for (i = 0; i < 6; i++)
                    l_1855[i] = (void*)0;
                l_1854 = (void*)0;
                (*g_68) &= ((*l_1659) = (safe_lshift_func_int8_t_s_s((**g_786), 4)));
                (*l_1659) ^= (**g_67);
            }
        }
        else
        { /* block id: 883 */
            int32_t l_1878 = 1L;
            for (g_1553.f3.f2 = 1; (g_1553.f3.f2 <= 5); g_1553.f3.f2 += 1)
            { /* block id: 886 */
                int8_t ***l_1859 = &g_786;
                int8_t ****l_1858 = &l_1859;
                int32_t l_1865 = 1L;
                int16_t *l_1866[7];
                uint64_t *l_1879 = &g_1486.f1;
                int i;
                for (i = 0; i < 7; i++)
                    l_1866[i] = &g_1263[5][3].f2;
                (*l_1858) = &g_786;
                (*l_1657) = ((*l_1662) = 0x35D134BAL);
                if ((((safe_mod_func_int64_t_s_s((g_1428 ^= (safe_div_func_uint32_t_u_u(l_1697, (g_1647 , (+((((l_1865 , l_1866[3]) == &l_1654) , (safe_rshift_func_uint16_t_u_s(((((***l_1859) = (*l_1661)) < (safe_sub_func_uint64_t_u_u(((*l_1879) = ((safe_add_func_uint64_t_u_u(g_1873, ((safe_rshift_func_int64_t_s_s((g_235.f1 && ((((safe_sub_func_uint16_t_u_u(((void*)0 == &l_1717), 0L)) != l_1878) , p_14) <= 0xCDL)), 28)) | g_94.f4))) , 0xBF3F7DA8ECCEC6C3LL)), p_14))) < 0x56F22AF7A455E71DLL), 7))) == l_1783)))))), p_14)) <= p_14) != (-1L)))
                { /* block id: 893 */
                    return p_14;
                }
                else
                { /* block id: 895 */
                    return p_14;
                }
            }
        }
    }
    for (g_1544.f1 = 0; (g_1544.f1 != 50); ++g_1544.f1)
    { /* block id: 916 */
        uint16_t ** const *l_1917 = &g_506;
        uint16_t ** const **l_1916 = &l_1917;
        uint16_t ** const ***l_1918 = &l_1916;
        (*l_1918) = l_1916;
        if ((*g_755))
            continue;
    }
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_502 g_1165.f2 g_162 g_163 g_1090.f2 g_364 g_405 g_118 g_1031.f2 g_299.f1 g_235.f2 g_507 g_68 g_3 g_307 g_4 g_220 g_221 g_787 g_347.f0 g_1241 g_1090.f1 g_404 g_1135.f0 g_347.f1 g_786 g_256.f0 g_1262 g_1263 g_1033 g_122 g_39 g_426 g_755 g_925.f0 g_1055 g_1045.f1 g_403 g_1123 g_506 g_67 g_1349 g_169.f0 g_1378 g_94.f0 g_1025.f0 g_1388 g_1402 g_925.f2.f0 g_1429 g_1440 g_753 g_721.f1 g_1460 g_519.f2 g_820 g_1471 g_1025.f1 g_1045.f2 g_1553 g_1428 g_650 g_108.f0 g_347.f2 g_758.f1 g_1440.f0 g_781.f0 g_1544 g_1647 g_299.f3 g_96 g_202 g_836.f4 g_794.f0
 * writes: g_39 g_235.f2 g_122 g_1090.f1 g_703.f3 g_347.f0 g_299.f3 g_566 g_794.f0 g_100 g_299.f2 g_1055 g_1044 g_68 g_1025.f0 g_1391 g_256.f3 g_861 g_925.f2.f0 g_1429 g_721.f1 g_34 g_821 g_1461 g_1025.f1 g_1402.f1 g_1045.f2 g_910 g_1486.f1 g_1428 g_353.f1 g_758.f1 g_353.f3.f1 g_1440.f0
 */
static int8_t  func_22(int32_t  p_23)
{ /* block id: 592 */
    int64_t *l_1175 = (void*)0;
    int32_t l_1176 = 0xF4E252E2L;
    int64_t *l_1177[10] = {&g_100,&g_100,&g_100,&g_100,&g_100,&g_100,&g_100,&g_100,&g_100,&g_100};
    int32_t l_1178 = (-1L);
    union U4 ***l_1181 = &g_629[1][2];
    int32_t l_1182 = 1L;
    int32_t *l_1188 = (void*)0;
    int32_t *l_1189[10];
    int32_t l_1190 = (-2L);
    int32_t **l_1204 = &g_68;
    int32_t l_1212 = 7L;
    int64_t l_1224 = 0L;
    uint16_t *** const *l_1234 = (void*)0;
    uint16_t *** const **l_1233 = &l_1234;
    int32_t ****l_1258 = (void*)0;
    uint64_t l_1311[3];
    uint8_t l_1379 = 0x82L;
    union U4 *****l_1406 = &g_736;
    union U3 *l_1458[1];
    int64_t l_1501 = 0x35D3636F5849E84CLL;
    int32_t l_1533 = 0x7ECD363FL;
    uint32_t l_1538 = 1UL;
    int32_t l_1550 = 0xB82E358FL;
    int16_t l_1605 = (-1L);
    uint8_t l_1632[7] = {0x4FL,0x4FL,255UL,0x4FL,0x4FL,255UL,0x4FL};
    int16_t l_1639 = 8L;
    uint32_t *l_1640 = &l_1538;
    uint8_t ****l_1651[2];
    int32_t l_1652[7][2][10] = {{{0xD3700E13L,0xCE01A5F0L,0xCE01A5F0L,0xD3700E13L,0x012236F9L,0x8DA18482L,0x779B1BF3L,0x996E4F9AL,0xCE01A5F0L,0xBFC5EA5FL},{0x012236F9L,0xBFC5EA5FL,0xCC3BD3FFL,(-5L),0xEFF95482L,0xCC3BD3FFL,0xCE01A5F0L,0x779B1BF3L,0xCE01A5F0L,0xCC3BD3FFL}},{{1L,0xD3700E13L,0L,0xD3700E13L,1L,(-3L),(-1L),1L,0L,0xEFF95482L},{0x779B1BF3L,0x012236F9L,(-5L),1L,3L,0x8DA18482L,0xEFF95482L,0x012236F9L,0x012236F9L,0xEFF95482L}},{{0x996E4F9AL,1L,0xCC3BD3FFL,0xCC3BD3FFL,1L,0x996E4F9AL,(-5L),0xD3700E13L,0x8DA18482L,0xCC3BD3FFL},{0xBFC5EA5FL,0x779B1BF3L,0xBAF1F459L,(-1L),0xEFF95482L,0L,(-1L),0xBFC5EA5FL,(-1L),0xBFC5EA5FL}},{{0xBFC5EA5FL,0x996E4F9AL,0x012236F9L,1L,0x012236F9L,0x996E4F9AL,0xBFC5EA5FL,0x23738B70L,0xBAF1F459L,3L},{0xBAF1F459L,0x8DA18482L,0x23738B70L,0xBAF1F459L,3L,(-3L),0x49DB65F8L,0xCE01A5F0L,0x23738B70L,0x23738B70L}},{{3L,0x8DA18482L,0xEFF95482L,0x012236F9L,0x012236F9L,0xEFF95482L,0x8DA18482L,3L,1L,(-5L)},{0xCC3BD3FFL,0xBAF1F459L,(-1L),0xCE01A5F0L,(-3L),0L,(-5L),(-3L),0xBAF1F459L,0x012236F9L}},{{0x49DB65F8L,3L,(-1L),(-3L),0x996E4F9AL,(-3L),(-1L),3L,0x49DB65F8L,(-1L)},{0xCE01A5F0L,0xCC3BD3FFL,0xEFF95482L,(-5L),0xCC3BD3FFL,0xBFC5EA5FL,0x012236F9L,0xCE01A5F0L,(-1L),(-5L)}},{{0x8DA18482L,0x49DB65F8L,0x23738B70L,(-5L),(-1L),(-1L),(-5L),0x23738B70L,0x49DB65F8L,0x8DA18482L},{0x23738B70L,0xCE01A5F0L,0x49DB65F8L,(-3L),3L,0xBAF1F459L,0x23738B70L,0x8DA18482L,0xBAF1F459L,0x49DB65F8L}}};
    int i, j, k;
    for (i = 0; i < 10; i++)
        l_1189[i] = (void*)0;
    for (i = 0; i < 3; i++)
        l_1311[i] = 18446744073709551615UL;
    for (i = 0; i < 1; i++)
        l_1458[i] = &g_636[0][3];
    for (i = 0; i < 2; i++)
        l_1651[i] = (void*)0;
    if (((safe_sub_func_int8_t_s_s(1L, (safe_lshift_func_uint8_t_u_s(((l_1178 |= (l_1176 = (g_502 != g_502))) | ((safe_mul_func_uint16_t_u_u(((((void*)0 == l_1181) , ((*g_364) = ((l_1182 , ((0x86295BDE42FE3BA5LL != ((g_1165.f2 < ((safe_sub_func_int8_t_s_s((((safe_add_func_int64_t_s_s((l_1182 = (((safe_unary_minus_func_int32_t_s(1L)) , 2L) == p_23)), 0x8181644BCDACCDD8LL)) ^ (*g_162)) != 0xFF8DL), 0xE5L)) , g_1090.f2)) & 0x9CB5B2A15576ABCALL)) && p_23)) >= p_23))) & 0x6C7583FFL), (*g_405))) | l_1190)), p_23)))) , p_23))
    { /* block id: 597 */
        uint32_t l_1193 = 18446744073709551610UL;
        uint8_t l_1194 = 0x1FL;
        l_1194 &= (safe_rshift_func_uint32_t_u_s(0x98A4D507L, l_1193));
        return p_23;
    }
    else
    { /* block id: 600 */
        const union U4 ** const ** const *l_1197 = (void*)0;
        uint16_t l_1200 = 0x0D64L;
        int32_t **l_1206[4][6];
        int32_t ***l_1205 = &l_1206[2][5];
        struct S0 *l_1260 = &g_895;
        struct S0 **l_1259 = &l_1260;
        int64_t l_1308 = 0L;
        uint32_t *l_1333 = &g_1055;
        int32_t l_1336 = (-7L);
        int32_t l_1387 = 0xB4320713L;
        uint16_t l_1417[4];
        int32_t l_1419 = 7L;
        int32_t *l_1504 = (void*)0;
        int8_t l_1507 = 3L;
        int i, j;
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 6; j++)
                l_1206[i][j] = &g_68;
        }
        for (i = 0; i < 4; i++)
            l_1417[i] = 0x0A44L;
        if ((safe_add_func_int16_t_s_s((((0UL > (l_1197 == (void*)0)) & (safe_add_func_int64_t_s_s(l_1200, p_23))) >= (safe_mod_func_int16_t_s_s((((g_1031.f2 == (((+(p_23 >= (l_1177[4] != (l_1175 = (void*)0)))) , l_1200) , l_1200)) && 0x7CF5CB407D2BD7A5LL) <= g_299.f1), l_1200))), 65534UL)))
        { /* block id: 602 */
            int16_t *l_1207 = &g_235.f2;
            int32_t l_1213 = 0x144F871AL;
            union U4 **l_1218[10][9][1] = {{{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355}},{{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355}},{{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355}},{{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355}},{{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355}},{{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355}},{{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355}},{{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355}},{{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355}},{{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355},{&g_355}}};
            int32_t l_1223 = 0x5A5F9146L;
            uint8_t ** const *l_1229 = &g_763;
            uint16_t *** const **l_1235[3];
            int8_t l_1385[3];
            uint8_t *l_1413 = (void*)0;
            uint8_t *l_1414 = &g_895.f2;
            uint32_t *l_1418[10] = {(void*)0,(void*)0,&g_98,(void*)0,(void*)0,&g_98,(void*)0,(void*)0,&g_98,(void*)0};
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_1235[i] = &l_1234;
            for (i = 0; i < 3; i++)
                l_1385[i] = 0x4CL;
            p_23 = ((l_1204 = &g_68) == (((((void*)0 == l_1205) , ((void*)0 == l_1207)) && ((safe_add_func_int16_t_s_s((p_23 , p_23), (safe_mul_func_int16_t_s_s(l_1212, ((*l_1207) |= ((l_1213 > p_23) == 250UL)))))) , (*g_162))) , (void*)0));
            if (((safe_sub_func_int16_t_s_s((safe_add_func_uint16_t_u_u(((*g_507) = (l_1213 && ((void*)0 == l_1218[2][2][0]))), 6UL)), (***l_1205))) < (((safe_sub_func_int32_t_s_s((safe_add_func_int32_t_s_s((l_1223 = l_1213), l_1224)), ((l_1213 >= (safe_lshift_func_uint16_t_u_s((safe_lshift_func_int8_t_s_u(((void*)0 != l_1229), 4)), p_23))) && (*g_220)))) , &l_1224) == &l_1224)))
            { /* block id: 608 */
                uint32_t l_1230 = 0x00FD914FL;
                l_1230--;
                l_1235[2] = l_1233;
            }
            else
            { /* block id: 611 */
                int32_t l_1238[2][9][4] = {{{(-2L),0xB576F5F4L,0xF92B8BBFL,(-1L)},{0x9E89B539L,0x44BCF42FL,0x0CA3B5D5L,1L},{2L,(-1L),8L,0x0CA3B5D5L},{6L,3L,3L,6L},{1L,3L,1L,8L},{0x880CCBFFL,0x9B2D7C4EL,(-5L),0x22F128D9L},{3L,(-1L),0xC77088A3L,0x22F128D9L},{0L,0x9B2D7C4EL,1L,8L},{(-1L),3L,2L,0x1A2BD8B7L}},{{0L,0x880CCBFFL,0x22F128D9L,2L},{3L,0x9E89B539L,(-5L),(-1L)},{(-10L),3L,0L,0xFAE1B95BL},{(-1L),0x9B2D7C4EL,(-1L),0xC77088A3L},{0x1A2BD8B7L,8L,0xC77088A3L,0xF92B8BBFL},{0L,0L,0xB576F5F4L,8L},{8L,1L,0xB576F5F4L,(-1L)},{0L,(-10L),0xC77088A3L,0xB576F5F4L},{0x1A2BD8B7L,0x9E89B539L,(-1L),3L}}};
                uint8_t *l_1242 = &g_1090.f1;
                int32_t l_1249 = 0x3E69BD6EL;
                int16_t *l_1257 = &g_703.f3;
                int16_t *l_1261 = &g_299.f3;
                union U2 *l_1306 = (void*)0;
                int32_t l_1309 = (-1L);
                int32_t *l_1337 = &l_1238[0][6][2];
                struct S1 *l_1338 = (void*)0;
                uint8_t l_1384 = 0x7CL;
                union U4 ***l_1394 = &g_629[3][6];
                int32_t *l_1401[7];
                uint16_t l_1403 = 0UL;
                int i, j, k;
                for (i = 0; i < 7; i++)
                    l_1401[i] = (void*)0;
                l_1249 = (safe_add_func_uint16_t_u_u((((*g_787) == p_23) == l_1238[0][6][2]), ((safe_sub_func_uint8_t_u_u((l_1213 = (g_1241 , (0x90D1D435F7854B6BLL | (((++(*l_1242)) | (l_1223 | (((safe_lshift_func_int64_t_s_u((safe_mul_func_uint32_t_u_u(p_23, l_1223)), 24)) && (**g_404)) <= l_1223))) | g_1135.f0)))), p_23)) > g_347.f1)));
lbl_1340:
                if ((safe_unary_minus_func_uint8_t_u(((((*l_1261) = (((((p_23 , ((void*)0 != (*g_786))) < (safe_div_func_int8_t_s_s(((**g_786) = ((((l_1249 &= l_1223) <= ((safe_lshift_func_int16_t_s_u((((p_23 | ((g_347.f1 == ((*l_1257) = (safe_mul_func_int16_t_s_s(((*l_1207) = p_23), 1UL)))) != (-9L))) >= l_1238[0][6][2]) | 0L), 14)) < g_256.f0)) , &g_906) != l_1258)), p_23))) >= p_23) , l_1259) == &l_1260)) && l_1213) != (-1L)))))
                { /* block id: 620 */
                    int8_t l_1264 = 0x20L;
                    int32_t l_1265 = (-1L);
                    uint64_t l_1267 = 0x70A44658F4226ED9LL;
                    if (((g_1262 , p_23) == p_23))
                    { /* block id: 621 */
                        int32_t l_1266 = (-8L);
                        (*g_1033) = g_1263[5][3];
                        --l_1267;
                        return l_1265;
                    }
                    else
                    { /* block id: 625 */
                        return (*g_787);
                    }
                }
                else
                { /* block id: 628 */
                    uint32_t l_1287 = 4294967295UL;
                    int32_t l_1305 = 0x9CB209EAL;
                    union U2 **l_1307 = &l_1306;
                    int32_t l_1310 = (-1L);
                    for (g_794.f0 = 0; (g_794.f0 >= (-15)); --g_794.f0)
                    { /* block id: 631 */
                        (*g_364) = (!(safe_mod_func_uint8_t_u_u((((~(safe_add_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u((safe_mul_func_int16_t_s_s((safe_add_func_uint32_t_u_u(((((--(*l_1242)) ^ (((~0x0988350664B9AB60LL) | (((l_1287 &= (*g_507)) , (void*)0) != &g_972)) ^ ((safe_rshift_func_int32_t_s_s((safe_div_func_int16_t_s_s(((safe_mul_func_int64_t_s_s((((0xAAL > (safe_add_func_int64_t_s_s((g_100 = (*g_220)), (safe_lshift_func_uint16_t_u_u(((safe_unary_minus_func_uint8_t_u((l_1213 ^= (g_299.f2 = 0xC2L)))) > (safe_mod_func_int16_t_s_s((safe_add_func_uint8_t_u_u((safe_rshift_func_uint64_t_u_u((&g_1055 == (void*)0), g_39)), l_1238[0][6][2])), 65532UL))), p_23))))) , 0x4810L) > (*g_405)), g_426)) | (*g_68)), 0xE7B6L)), p_23)) == 0xF0L))) | p_23) != (*g_787)), l_1305)), 0x1728L)), p_23)), 0L))) <= 18446744073709551615UL) != (**l_1204)), l_1305)));
                    }
                    (*l_1307) = l_1306;
                    l_1311[1]--;
                }
                if (((safe_mul_func_int32_t_s_s((safe_mul_func_int64_t_s_s((l_1223 <= ((p_23 | (safe_mul_func_int8_t_s_s((safe_add_func_uint8_t_u_u((safe_lshift_func_int8_t_s_u(((safe_lshift_func_uint16_t_u_s(((*g_755) , p_23), (safe_mul_func_int16_t_s_s((((*l_1337) = (safe_div_func_int64_t_s_s((g_100 = (l_1309 &= ((!((*l_1261) = (l_1336 = (((*l_1333) |= ((l_1249 = (g_925.f0 != (safe_mod_func_int8_t_s_s(((l_1188 == l_1333) <= (0xE9L | ((safe_mul_func_int16_t_s_s(l_1249, p_23)) != 0x88D2L))), 0x5FL)))) ^ 0x1E965D54L)) <= p_23)))) > (***l_1205)))), 0xB4C6F0421A6735B7LL))) , g_1045.f1), (***g_403))))) | 0xA5L), 4)), p_23)), 0xAFL))) < p_23)), 0x6310CD49D7B46508LL)), p_23)) | l_1223))
                { /* block id: 649 */
                    uint64_t l_1348 = 6UL;
                    int32_t l_1355[9][10][2] = {{{0x088FD80EL,0xC6EA1C53L},{0x2A1AAB73L,0x3E5BD4FFL},{0xF9601BABL,0x7485EAADL},{(-9L),8L},{0x1D3C9A36L,0xF3F948BEL},{0x4A4AE0BEL,1L},{0x3E5BD4FFL,(-5L)},{0xFBA63799L,6L},{8L,0x839652CCL},{8L,1L}},{{0xDAB9430DL,(-6L)},{0x667143C9L,(-1L)},{5L,5L},{1L,0x3C5CCBECL},{1L,0x2A1AAB73L},{0x6E84B570L,0L},{0xF3F948BEL,0x6E84B570L},{0x839652CCL,0x088FD80EL},{0x839652CCL,0x6E84B570L},{0xF3F948BEL,0L}},{{0x6E84B570L,0x2A1AAB73L},{1L,0x3C5CCBECL},{1L,5L},{5L,(-1L)},{0x667143C9L,(-6L)},{0xDAB9430DL,1L},{8L,0x839652CCL},{8L,6L},{0xFBA63799L,(-5L)},{0x3E5BD4FFL,1L}},{{0x4A4AE0BEL,0xF3F948BEL},{0x1D3C9A36L,8L},{(-9L),0x7485EAADL},{0xF9601BABL,0x3E5BD4FFL},{0x2A1AAB73L,0xC6EA1C53L},{0x088FD80EL,0xBB1DDB07L},{(-1L),0x0F76056AL},{0xC6EA1C53L,0x7CF0D227L},{(-1L),0x81390620L},{0x3E9F9FB2L,0x81390620L}},{{(-1L),0x7CF0D227L},{0xC6EA1C53L,0x0F76056AL},{(-1L),0xBB1DDB07L},{0x088FD80EL,0xC6EA1C53L},{0x2A1AAB73L,0x3E5BD4FFL},{0xF9601BABL,0x7485EAADL},{(-9L),8L},{0x1D3C9A36L,0xF3F948BEL},{0x4A4AE0BEL,1L},{0x3E5BD4FFL,(-5L)}},{{0xFBA63799L,6L},{8L,0x839652CCL},{8L,1L},{0xDAB9430DL,(-6L)},{0x667143C9L,(-1L)},{5L,5L},{1L,0x3C5CCBECL},{1L,0x2A1AAB73L},{0x6E84B570L,0L},{0xF3F948BEL,0x6E84B570L}},{{0x839652CCL,0x088FD80EL},{0x839652CCL,0x6E84B570L},{0xF3F948BEL,0L},{0x6E84B570L,0x2A1AAB73L},{1L,0x3C5CCBECL},{1L,5L},{5L,(-1L)},{0x667143C9L,(-6L)},{0L,0x0F76056AL},{0xF9601BABL,0x7BD839DDL}},{{0x839652CCL,0x7485EAADL},{1L,0xC6EA1C53L},{0x667143C9L,0x81390620L},{(-5L),(-1L)},{0x6E84B570L,0xF9601BABL},{0L,(-6L)},{0x3C5CCBECL,0x667143C9L},{0x1D3C9A36L,0x3E9F9FB2L},{0xCCA3D463L,0xFBA63799L},{0x2560B948L,0x7CF0D227L}},{{0x3E9F9FB2L,0x2A1AAB73L},{8L,1L},{0xBB1DDB07L,1L},{8L,0x2A1AAB73L},{0x3E9F9FB2L,0x7CF0D227L},{0x2560B948L,0xFBA63799L},{0xCCA3D463L,0x3E9F9FB2L},{0x1D3C9A36L,0x667143C9L},{0x3C5CCBECL,(-6L)},{0L,0xF9601BABL}}};
                    union U4 ***l_1371 = &l_1218[2][2][0];
                    int32_t l_1389 = 0xD3223711L;
                    int i, j, k;
                    for (l_1178 = 0; (l_1178 <= 0); l_1178 += 1)
                    { /* block id: 652 */
                        struct S1 **l_1339 = &g_1044;
                        (*l_1339) = l_1338;
                        if (g_1241.f2)
                            goto lbl_1340;
                    }
                    if (((((&g_655[1] != ((((g_1123 , &l_1238[0][6][2]) == (void*)0) > (((**g_506) = l_1238[0][4][1]) & p_23)) , (((((**l_1204) < ((0x71L && ((*g_162) || 0x2EF6E969L)) > p_23)) != 0L) ^ 1L) , (void*)0))) ^ l_1238[0][6][2]) < 7L) , 0xFE4369CCL))
                    { /* block id: 657 */
                        union U3 *l_1342 = &g_1123;
                        union U3 **l_1341 = &l_1342;
                        const int32_t l_1351[5][8][6] = {{{0L,0xD31C299CL,0xF1842E6DL,0xA417111EL,0x4A78597AL,0x768C3253L},{(-10L),1L,1L,0x14DF6D42L,0xB950FA30L,(-8L)},{0xFA79822FL,0xCD121F13L,0xD31C299CL,(-10L),0L,0L},{0xAFD73CA7L,(-2L),0xB950FA30L,0L,6L,1L},{(-10L),0x768C3253L,0x2B32D0C6L,0L,3L,0xBECEAD77L},{0xAFD73CA7L,1L,8L,(-10L),0x768C3253L,(-4L)},{0xFA79822FL,0x5435696FL,(-1L),0x14DF6D42L,(-8L),(-1L)},{(-10L),0xBECEAD77L,0x900795B7L,0xA417111EL,0L,0x5435696FL}},{{0L,(-1L),(-10L),2L,1L,0x900795B7L},{0x7BBB423BL,3L,(-10L),0x70E193A9L,0xBECEAD77L,0x5435696FL},{0L,(-1L),0x900795B7L,0xC95A22A3L,(-4L),(-1L)},{0xC95A22A3L,(-4L),(-1L),7L,(-1L),(-4L)},{0x7644F688L,0L,8L,0x103B73DAL,0x5435696FL,0xBECEAD77L},{0x8AD7AB60L,0x34547CEAL,0x2B32D0C6L,0xED06B646L,0x900795B7L,1L},{0x14DF6D42L,0x34547CEAL,0xB950FA30L,0xAFD73CA7L,0x5435696FL,0L},{7L,0L,0xD31C299CL,0x8AD7AB60L,(-1L),(-8L)}},{{1L,(-4L),1L,6L,(-4L),0x768C3253L},{0x416EE959L,(-1L),0xF1842E6DL,0L,0xBECEAD77L,3L},{0x41F67B47L,3L,0x5435696FL,0x907D5C9FL,1L,6L},{0x41F67B47L,(-1L),1L,0L,0L,0L},{0x416EE959L,0xBECEAD77L,1L,6L,(-8L),0xB950FA30L},{1L,0x5435696FL,(-4L),0x8AD7AB60L,0x768C3253L,0x4A78597AL},{7L,1L,0x768C3253L,0xAFD73CA7L,3L,0xAB31996BL},{0x14DF6D42L,0x768C3253L,0L,0xED06B646L,6L,0xAB31996BL}},{{0x8AD7AB60L,(-2L),0x768C3253L,0L,(-8L),0xCCE7C5DEL},{0xCD121F13L,0xD06A9448L,0xB9AAE6E1L,0x2B32D0C6L,6L,6L},{(-1L),0L,0L,(-1L),0xCCE7C5DEL,(-8L)},{(-8L),0xB814E2BBL,0x65B2D5FDL,1L,0L,0x14137554L},{(-4L),(-1L),0x2FC01BB4L,0xD31C299CL,0L,1L},{0x900795B7L,0xB814E2BBL,(-8L),0x34547CEAL,0xCCE7C5DEL,1L},{0xAB31996BL,0L,0x96C8145AL,(-2L),6L,(-1L)},{1L,0xD06A9448L,0xB814E2BBL,0xAB31996BL,(-8L),(-2L)}},{{1L,0x0EA98CB0L,6L,(-8L),0x14137554L,0x96C8145AL},{6L,1L,0x2BB55BCFL,(-8L),1L,0x3A67EFADL},{1L,0xF9536EBCL,(-1L),0xAB31996BL,1L,0xB9AAE6E1L},{1L,0x2FC01BB4L,0xFF450C85L,(-2L),(-1L),0xFF450C85L},{0xAB31996BL,0x3A67EFADL,(-1L),0x34547CEAL,(-2L),0x2FC01BB4L},{0x900795B7L,0xFF450C85L,(-3L),0xD31C299CL,0x96C8145AL,(-1L)},{(-4L),1L,(-3L),1L,0x3A67EFADL,0x2FC01BB4L},{(-8L),0x4AA422AEL,(-1L),(-1L),0xB9AAE6E1L,0xFF450C85L}}};
                        int8_t *l_1386 = &g_1025.f0;
                        int i, j, k;
                        (*g_67) = &p_23;
                        (*l_1341) = (void*)0;
                        l_1223 = (safe_mul_func_int32_t_s_s(((***l_1205) = ((void*)0 != l_1333)), (((safe_rshift_func_uint64_t_u_s((((+l_1348) || (g_1349 == &g_1350[2][8])) , l_1351[4][7][0]), l_1348)) , (8UL ^ ((safe_mul_func_int8_t_s_s(((!(((l_1355[0][8][1] = 0x621FL) != 0x0F95L) < g_169.f0)) || l_1223), l_1238[0][6][2])) , (*g_787)))) == 0L)));
                        l_1389 = ((safe_div_func_int16_t_s_s((safe_mod_func_int32_t_s_s((-1L), (safe_sub_func_int8_t_s_s(p_23, ((safe_rshift_func_int32_t_s_u((safe_mul_func_int8_t_s_s(((*l_1386) &= (safe_mul_func_int8_t_s_s(((safe_mul_func_int64_t_s_s(((~((l_1371 != (void*)0) ^ (l_1355[6][1][1] ^= p_23))) || ((safe_sub_func_uint16_t_u_u((((safe_lshift_func_uint32_t_u_s((safe_div_func_uint32_t_u_u(0xF0833216L, (((*l_1257) = ((g_1378 , l_1379) && (safe_mod_func_int8_t_s_s((safe_div_func_uint8_t_u_u(l_1384, (*g_787))), (-7L))))) & p_23))), p_23)) < g_94.f0) , l_1213), l_1385[2])) >= 0xE95BL)), 18446744073709551609UL)) && (-1L)), l_1384))), (***l_1205))), l_1387)) ^ l_1238[0][6][2]))))), 0x40EFL)) <= g_1388);
                    }
                    else
                    { /* block id: 667 */
                        union U2 **l_1390[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
                        int32_t l_1400 = 0x10DC3D91L;
                        int i;
                        g_1391 = (void*)0;
                        l_1401[2] = &l_1223;
                        return p_23;
                    }
                    (*g_1033) = g_1402;
                }
                else
                { /* block id: 676 */
                    p_23 ^= l_1403;
                }
                for (g_256.f3 = 0; g_256.f3 < 1; g_256.f3 += 1)
                {
                    union U3 tmp = {0x66L};
                    g_861[g_256.f3] = tmp;
                }
            }
            (**l_1205) = &p_23;
        }
        else
        { /* block id: 687 */
            int64_t l_1426 = 0L;
            int32_t l_1472 = 9L;
            int32_t l_1473 = 6L;
            int32_t l_1508 = 0x29DCCC9DL;
            int32_t l_1509 = 0L;
            int32_t l_1512[7][4] = {{0x2BACF0DDL,0xAB18CCD4L,(-1L),0xAB18CCD4L},{0xAB18CCD4L,8L,(-1L),(-1L)},{0x2BACF0DDL,0x2BACF0DDL,0xAB18CCD4L,(-1L)},{8L,8L,8L,0xAB18CCD4L},{8L,0xAB18CCD4L,0xAB18CCD4L,8L},{0x2BACF0DDL,0xAB18CCD4L,(-1L),0xAB18CCD4L},{0xAB18CCD4L,8L,(-1L),(-1L)}};
            uint16_t l_1516 = 65529UL;
            union U4 **l_1541 = (void*)0;
            uint64_t l_1576 = 1UL;
            struct S0 *l_1600[3][8] = {{&g_975,&g_975,&g_519[7][3][2],&g_975,&g_975,&g_519[7][3][2],&g_975,&g_975},{&g_299,&g_975,&g_299,&g_299,&g_975,&g_299,&g_299,&g_975},{&g_975,&g_299,&g_299,&g_975,&g_299,&g_299,&g_975,&g_299}};
            int i, j;
            for (g_925.f2.f0 = 0; (g_925.f2.f0 <= 3); g_925.f2.f0 += 1)
            { /* block id: 690 */
                int64_t l_1425 = 0xF3E1DBAE06DB0F5ALL;
                union U4 *l_1470 = &g_796;
                int i;
                for (g_235.f2 = 0; (g_235.f2 <= 2); g_235.f2 += 1)
                { /* block id: 693 */
                    uint64_t *l_1424[5];
                    int8_t l_1427 = 0x40L;
                    const int64_t l_1443 = 0x4C12349FC9ADD085LL;
                    int i;
                    for (i = 0; i < 5; i++)
                        l_1424[i] = &g_1123.f1;
                    if (l_1417[g_235.f2])
                        break;
                    p_23 = (safe_rshift_func_int64_t_s_u((safe_sub_func_uint16_t_u_u(8UL, l_1311[g_235.f2])), (g_1429++)));
                    for (g_721.f1 = 0; (g_721.f1 <= 2); g_721.f1 += 1)
                    { /* block id: 699 */
                        union U3 *l_1457 = &g_925;
                        union U3 **l_1456 = &l_1457;
                        int32_t l_1459[8];
                        int i;
                        for (i = 0; i < 8; i++)
                            l_1459[i] = 0xAC52480CL;
                        (*g_755) = ((((safe_sub_func_uint16_t_u_u(((l_1417[(g_721.f1 + 1)] ^= (safe_rshift_func_uint64_t_u_s(((safe_mod_func_uint32_t_u_u((safe_add_func_uint8_t_u_u(((g_1440 , &p_23) == ((*l_1204) = &p_23)), (safe_div_func_uint16_t_u_u(l_1443, (safe_lshift_func_int32_t_s_s((safe_rshift_func_int32_t_s_s((*g_753), 27)), 24)))))), p_23)) > (safe_add_func_int32_t_s_s(0xE831584BL, ((safe_div_func_uint64_t_u_u(((safe_lshift_func_int8_t_s_s((**g_786), (safe_lshift_func_uint16_t_u_s(((255UL != 0xF4L) || p_23), p_23)))) & l_1426), p_23)) && p_23)))), l_1425))) , l_1417[(g_721.f1 + 1)]), 0xFFDEL)) > p_23) >= p_23) , p_23);
                        l_1458[0] = ((*l_1456) = &g_925);
                        if (l_1459[6])
                            continue;
                    }
                }
                if ((((g_1460 == (void*)0) < ((!(((safe_mul_func_uint64_t_u_u(l_1425, l_1426)) , 18446744073709551609UL) >= p_23)) , 0x061BL)) < (safe_mod_func_int16_t_s_s(0x3166L, g_519[4][2][2].f2))))
                { /* block id: 708 */
                    uint32_t l_1467[5][10][4] = {{{7UL,18446744073709551606UL,1UL,3UL},{0xC023A28DL,0x0ECBA0F2L,18446744073709551615UL,0x56B103A4L},{0x3E4C4A0CL,0x7A23ABD5L,18446744073709551615UL,1UL},{18446744073709551615UL,0xDFEDF057L,18446744073709551610UL,18446744073709551613UL},{0UL,0x4522AD35L,0xCA110468L,18446744073709551613UL},{0x8B1F0EA7L,8UL,0x3BDC09EEL,0xA9983022L},{0xE377157EL,18446744073709551615UL,0xE377157EL,0x64738A68L},{2UL,18446744073709551615UL,18446744073709551610UL,0UL},{0xDFEDF057L,18446744073709551615UL,0x2F1DA1B4L,18446744073709551615UL},{18446744073709551606UL,18446744073709551615UL,0x2F1DA1B4L,0x8B1F0EA7L}},{{0xDFEDF057L,3UL,1UL,0xD3ACC90DL},{2UL,4UL,1UL,0x10460051L},{1UL,0x10460051L,0UL,1UL},{0xD21E9E43L,18446744073709551611UL,0x10460051L,0x976B0D2FL},{0xB1A6D22FL,0x64738A68L,0x7A23ABD5L,2UL},{7UL,18446744073709551613UL,0x900F6046L,6UL},{0x7FB8D706L,0xDFEDF057L,1UL,2UL},{18446744073709551606UL,7UL,18446744073709551611UL,0x0ECBA0F2L},{0UL,1UL,2UL,0UL},{18446744073709551615UL,0xE377157EL,0x3E4C4A0CL,1UL}},{{18446744073709551615UL,1UL,8UL,18446744073709551615UL},{0x231E0806L,0UL,1UL,0UL},{0x8B1F0EA7L,0x4522AD35L,18446744073709551613UL,18446744073709551612UL},{18446744073709551613UL,18446744073709551609UL,18446744073709551615UL,0x231E0806L},{18446744073709551615UL,0x2F1DA1B4L,0xDFEDF057L,1UL},{1UL,0x30DE12A7L,18446744073709551610UL,0UL},{0x0BA1BB0FL,0x56B103A4L,1UL,0x59E326CDL},{0x408AA646L,18446744073709551615UL,1UL,18446744073709551615UL},{1UL,0xB1CE7052L,0xB1CE7052L,1UL},{0x42482FABL,0x0BA1BB0FL,0x2F1DA1B4L,0xA9983022L}},{{0x7AA06CDEL,0x59E326CDL,18446744073709551615UL,18446744073709551612UL},{0xC023A28DL,18446744073709551613UL,18446744073709551606UL,18446744073709551612UL},{18446744073709551615UL,0x59E326CDL,18446744073709551609UL,0xA9983022L},{1UL,0x0BA1BB0FL,18446744073709551610UL,1UL},{0UL,0xB1CE7052L,0x7282A0DBL,18446744073709551615UL},{18446744073709551613UL,18446744073709551615UL,18446744073709551609UL,0x59E326CDL},{5UL,0x56B103A4L,18446744073709551615UL,0UL},{5UL,0x30DE12A7L,3UL,1UL},{0x64738A68L,0x2F1DA1B4L,5UL,0x231E0806L},{0x4522AD35L,18446744073709551609UL,0x56B103A4L,18446744073709551612UL}},{{18446744073709551612UL,0x4522AD35L,0xD21E9E43L,0UL},{0x900F6046L,0UL,0x8B1F0EA7L,18446744073709551615UL},{18446744073709551609UL,1UL,0x408AA646L,1UL},{18446744073709551612UL,0xE377157EL,7UL,0UL},{2UL,1UL,5UL,0x0ECBA0F2L},{1UL,7UL,0UL,2UL},{18446744073709551615UL,0xDFEDF057L,1UL,6UL},{18446744073709551615UL,18446744073709551613UL,6UL,2UL},{18446744073709551610UL,0x64738A68L,1UL,0x976B0D2FL},{0xCA110468L,18446744073709551611UL,1UL,1UL}}};
                    int i, j, k;
                    for (g_34 = 0; (g_34 <= 3); g_34 += 1)
                    { /* block id: 711 */
                        if (p_23)
                            break;
                        p_23 ^= (-1L);
                        if ((**g_67))
                            break;
                    }
                    (*g_820) = &p_23;
                    ++l_1467[0][2][0];
                    l_1470 = l_1470;
                }
                else
                { /* block id: 719 */
                    (*g_1471) = l_1458[0];
                }
                for (g_1025.f1 = 0; (g_1025.f1 <= 3); g_1025.f1 += 1)
                { /* block id: 724 */
                    uint8_t l_1474 = 0x9CL;
                    for (g_1055 = 0; (g_1055 <= 2); g_1055 += 1)
                    { /* block id: 727 */
                        ++l_1474;
                    }
                    for (g_1402.f1 = 2; (g_1402.f1 <= 7); g_1402.f1 += 1)
                    { /* block id: 732 */
                        (**l_1205) = &p_23;
                    }
                }
            }
            for (g_1045.f2 = (-15); (g_1045.f2 < 0); g_1045.f2++)
            { /* block id: 740 */
                int32_t *****l_1497 = &l_1258;
                int8_t l_1498 = 6L;
                uint8_t *l_1502[6] = {&g_347.f1,&g_1025.f1,&g_347.f1,&g_347.f1,&g_1025.f1,&g_347.f1};
                int8_t *l_1503 = &g_138;
                int32_t l_1505 = 0x95D01B52L;
                int32_t l_1506 = 0xA07FC30DL;
                int32_t l_1510 = (-1L);
                int32_t l_1511 = 0x3B8924CEL;
                int32_t l_1513 = (-1L);
                int32_t l_1514 = 6L;
                int32_t l_1515 = 0x91EEE79AL;
                int i;
            }
            if (((((g_910 = (void*)0) != (void*)0) && 2L) , 0x1BBE498BL))
            { /* block id: 776 */
                uint64_t *l_1564 = (void*)0;
                uint64_t *l_1565 = &g_1486.f1;
                int32_t l_1566 = 1L;
                int32_t l_1608 = (-1L);
                int64_t l_1612 = 1L;
                (*g_650) = (safe_add_func_uint64_t_u_u(l_1550, (g_1428 |= ((safe_mod_func_int8_t_s_s(0L, (**g_786))) > (g_1553 , ((safe_add_func_int8_t_s_s((((safe_mod_func_int32_t_s_s((safe_rshift_func_uint64_t_u_s(((*l_1565) = (((void*)0 != &g_1044) >= ((safe_rshift_func_int32_t_s_u(((*g_755) &= (safe_sub_func_int16_t_s_s(((((*g_404) == (void*)0) , p_23) || p_23), 1L))), 7)) >= p_23))), 11)), (*g_753))) >= 0xAA87L) < 0x0896L), p_23)) >= l_1566))))));
                for (l_1507 = 0; (l_1507 >= 9); l_1507++)
                { /* block id: 783 */
                    int32_t l_1574 = 0L;
                    int32_t l_1606 = 0x88906639L;
                    uint16_t **l_1607 = &g_507;
                    uint8_t *l_1609[4];
                    int i;
                    for (i = 0; i < 4; i++)
                        l_1609[i] = &g_1544.f0;
                    if (p_23)
                        break;
                    l_1608 ^= (safe_mod_func_uint8_t_u_u((((safe_add_func_int64_t_s_s(p_23, (~(l_1574 | (!(l_1606 &= (l_1576 , ((((((((((safe_rshift_func_int64_t_s_s((0x52D99C7CL && (safe_sub_func_uint32_t_u_u((safe_rshift_func_int64_t_s_u(1L, 3)), (safe_rshift_func_uint32_t_u_u(((~(((safe_div_func_uint32_t_u_u(((((safe_mul_func_int32_t_s_s((safe_add_func_int64_t_s_s((l_1605 = (((**l_1204) == ((safe_sub_func_uint16_t_u_u((safe_add_func_int16_t_s_s((safe_add_func_uint16_t_u_u((safe_mod_func_int32_t_s_s((((*l_1259) = &g_94) == l_1600[2][4]), (safe_mod_func_uint16_t_u_u((safe_add_func_int16_t_s_s(((((*g_220) , (-5L)) == l_1566) , g_39), (***g_403))), (***g_403))))), 0xF14EL)), (-3L))), 0x11D5L)) != 0x432CE1DCL)) != l_1512[6][2])), (***l_1205))), l_1566)) <= g_108.f0) , 4294967292UL) <= 0x7B98FFDEL), 0x25B4CC33L)) | p_23) <= g_1262.f2)) & 6L), p_23))))), 18)) || p_23) && p_23) & p_23) && 0x2632D34B28A3B3F4LL) & p_23) , p_23) || g_347.f2) , p_23) | 0xBBL)))))))) , l_1607) == (*g_403)), (*g_787)));
                    (**l_1205) = &p_23;
                    l_1612 = ((--g_758.f1) <= (0xB3L == p_23));
                }
            }
            else
            { /* block id: 793 */
                uint16_t l_1619[5][10][5] = {{{1UL,9UL,6UL,9UL,1UL},{0xD325L,65535UL,65531UL,65529UL,0xC853L},{0xE7E0L,0x1CF9L,8UL,0UL,65531UL},{0x263FL,5UL,0x7537L,65535UL,0xC853L},{5UL,0UL,65535UL,0UL,1UL},{0xC853L,0x4816L,65535UL,0xCE35L,0x263FL},{1UL,0x654DL,8UL,0x285EL,8UL},{0xC853L,0xC853L,65532UL,6UL,0xD325L},{5UL,0x285EL,6UL,0x2585L,5UL},{0x263FL,65535UL,65535UL,0xCE35L,65529UL}},{{0xE7E0L,0x285EL,0xE7E0L,0x654DL,65531UL},{0xD325L,0xC853L,0x4816L,65535UL,0xCE35L},{1UL,0x654DL,65535UL,1UL,5UL},{65529UL,0x4816L,0x4816L,65529UL,0x927FL},{1UL,0UL,0xE7E0L,0x1CF9L,8UL},{0xCE35L,5UL,65535UL,6UL,0x9288L},{1UL,0x1CF9L,6UL,0x1CF9L,1UL},{0x927FL,65535UL,65532UL,65529UL,5UL},{0xE7E0L,9UL,8UL,1UL,65531UL},{0x9288L,5UL,65535UL,65535UL,5UL}},{{5UL,1UL,65535UL,0x654DL,1UL},{5UL,0x4816L,0x7537L,0xCE35L,0x9288L},{1UL,0UL,8UL,0x2585L,8UL},{5UL,0xC853L,65531UL,6UL,0x927FL},{5UL,0x2585L,6UL,0x285EL,5UL},{0x9288L,65535UL,65533UL,0xCE35L,0xCE35L},{0xE7E0L,0x2585L,0xE7E0L,0UL,65531UL},{0x927FL,0xC853L,6UL,65535UL,65529UL},{1UL,0UL,65535UL,0UL,5UL},{0xCE35L,0x4816L,6UL,65529UL,0xD325L}},{{1UL,1UL,0xE7E0L,9UL,8UL},{65529UL,5UL,65533UL,6UL,0x263FL},{1UL,9UL,6UL,9UL,1UL},{0xD325L,65535UL,65531UL,65529UL,0xC853L},{0xE7E0L,0x1CF9L,8UL,0UL,65531UL},{0x263FL,5UL,0x7537L,65535UL,0xC853L},{5UL,0UL,65535UL,0UL,1UL},{0xC853L,0x4816L,65535UL,0xCE35L,0x263FL},{1UL,0x654DL,8UL,0x285EL,8UL},{0xC853L,0xC853L,65532UL,6UL,0xD325L}},{{5UL,0x285EL,6UL,0x2585L,5UL},{0x263FL,65535UL,65535UL,0xCE35L,65529UL},{0xE7E0L,0x285EL,0xE7E0L,0x654DL,65531UL},{0xD325L,0xC853L,0x4816L,65535UL,0xCE35L},{1UL,0x654DL,65535UL,1UL,5UL},{65529UL,0x4816L,0x4816L,65529UL,0x927FL},{1UL,0UL,0xE7E0L,0x1CF9L,8UL},{0xCE35L,5UL,65535UL,6UL,0x9288L},{1UL,0x1CF9L,6UL,0x1CF9L,1UL},{0x927FL,65535UL,65532UL,65529UL,5UL}}};
                uint8_t *l_1635 = &g_353[0].f3.f1;
                uint8_t *l_1636 = &g_1440.f0;
                int i, j, k;
                (*g_755) &= (safe_lshift_func_uint32_t_u_s((safe_mod_func_uint8_t_u_u(((**g_786) , ((*l_1636) |= ((*l_1635) = ((safe_mul_func_uint64_t_u_u(l_1619[0][6][4], (l_1509 ^= (!(safe_mul_func_uint64_t_u_u(((safe_sub_func_int32_t_s_s((p_23 || ((safe_rshift_func_int8_t_s_u(((((+((0UL <= (safe_rshift_func_uint32_t_u_s(((safe_div_func_uint8_t_u_u(p_23, ((0x7FFC6CD6L | ((l_1632[1] , l_1619[4][5][3]) ^ ((safe_mul_func_uint64_t_u_u(18446744073709551610UL, l_1426)) != p_23))) ^ (*g_507)))) == l_1472), 8))) <= (*g_753))) | p_23) , (void*)0) == (void*)0), l_1516)) | p_23)), 1L)) >= p_23), 0x72E8879899916E5ELL)))))) <= p_23)))), l_1512[6][3])), 28));
            }
        }
    }
    p_23 = (safe_add_func_uint16_t_u_u(p_23, (((*l_1640) ^= l_1639) , (g_781.f0 <= ((safe_sub_func_int64_t_s_s(((safe_add_func_uint32_t_u_u(((safe_lshift_func_int16_t_s_s(((g_1544 , p_23) || (((g_1647 , (safe_rshift_func_uint32_t_u_u((~((p_23 , ((*g_162) != (((void*)0 == l_1651[0]) > g_299.f3))) > g_96)), 0))) != p_23) , g_202)), p_23)) | l_1652[2][1][9]), 4294967289UL)) >= g_836.f4), (-1L))) || (**l_1204))))));
    return p_23;
}


/* ------------------------------------------ */
/* 
 * reads : g_505 g_506 g_507 g_122 g_1170 g_820
 * writes: g_122 g_794.f1 g_821
 */
static uint32_t  func_24(uint32_t  p_25)
{ /* block id: 586 */
    int64_t l_1168 = 0x322C6A27C73F6B83LL;
    int32_t l_1169 = (-1L);
    (*g_1170) = (safe_rshift_func_uint32_t_u_s(l_1168, (((*g_507) = (***g_505)) > (l_1169 = p_25))));
    (*g_820) = &l_1169;
    return p_25;
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_39 g_49 g_67 g_78 g_68 g_426 g_4 g_506 g_507 g_386 g_654 g_252 g_353 g_162 g_163 g_96 g_299.f1 g_200 g_94.f5 g_519.f0 g_220 g_221 g_684 g_685 g_94.f2 g_692 g_72 g_502 g_703 g_364 g_299.f0 g_709 g_710 g_94.f3 g_100 g_721 g_636 g_730 g_736 g_737 g_407 g_755 g_757 g_758 g_759 g_762 g_235.f0 g_307 g_773 g_356 g_778 g_820 g_821 g_3 g_299.f2 g_786 g_787 g_202 g_1031 g_1032 g_1033 g_1025.f2 g_1044 g_347.f0 g_1045.f2 g_1055 g_122 g_177 g_1065 g_566 g_895.f5 g_796.f1 g_753 g_169.f0 g_1090 g_648 g_1122 g_1123 g_1135 g_510 g_794.f0 g_975.f2 g_519.f3 g_405 g_118 g_1165
 * writes: g_34 g_39 g_68 g_78 g_252 g_299.f3 g_629 g_122 g_96 g_356 g_94.f2 g_353.f1 g_72 g_235.f2 g_347.f0 g_299.f0 g_703.f3 g_735 g_353.f3.f1 g_235.f1 g_753 g_709.f3 g_763 g_235.f0 g_307 g_94.f3 g_426 g_703.f0 g_299.f2 g_353.f2 g_1031 g_1033 g_1025.f2 g_1044 g_796.f1 g_821 g_721.f2 g_566 g_200 g_351.f2 g_100 g_654 g_975.f2 g_703.f2 g_1123.f1
 */
static uint64_t  func_26(uint16_t  p_27, uint32_t  p_28, uint32_t  p_29, const uint64_t  p_30)
{ /* block id: 8 */
    int32_t *l_1064 = &g_796.f1;
    int32_t l_1127 = (-8L);
    uint8_t l_1128 = 0x5CL;
    union U4 *****l_1134 = &g_736;
    struct S1 **l_1138 = (void*)0;
    for (g_34 = 27; (g_34 <= 6); --g_34)
    { /* block id: 11 */
        int32_t *l_38 = &g_39;
        (*l_38) |= 0x62B132DCL;
    }
    l_1064 = func_40((safe_unary_minus_func_int16_t_s(0L)));
    for (g_721.f2 = 2; (g_721.f2 >= 0); g_721.f2 -= 1)
    { /* block id: 523 */
        int32_t * const *l_1079 = (void*)0;
        int32_t * const **l_1078 = &l_1079;
        int32_t *l_1080[4][3][2] = {{{&g_307,&g_39},{&g_39,&g_307},{&g_39,&g_72}},{{&g_4,&g_4},{&g_39,&g_4},{&g_4,&g_72}},{{&g_39,&g_307},{&g_39,&g_39},{&g_307,&g_72}},{{&g_307,&g_39},{&g_39,&g_307},{&g_39,&g_72}}};
        int16_t l_1113 = 0x1C46L;
        const int32_t *l_1164 = (void*)0;
        int i, j, k;
        (*g_1033) = g_1065;
        for (g_703.f3 = 0; (g_703.f3 <= 0); g_703.f3 += 1)
        { /* block id: 527 */
            return (*l_1064);
        }
        for (g_307 = 0; (g_307 <= 2); g_307 += 1)
        { /* block id: 532 */
            union U4 *** const *l_1068[1][6][5] = {{{&g_737,&g_737,&g_737,&g_737,&g_737},{&g_737,&g_737,&g_737,&g_737,&g_737},{&g_737,&g_737,&g_737,&g_737,&g_737},{&g_737,&g_737,&g_737,&g_737,&g_737},{&g_737,&g_737,&g_737,&g_737,&g_737},{&g_737,&g_737,&g_737,&g_737,&g_737}}};
            union U4 *** const **l_1069 = (void*)0;
            union U4 *** const **l_1070 = &l_1068[0][3][0];
            int32_t *l_1071 = &g_796.f1;
            int32_t **l_1081[5][6][3] = {{{&l_1080[0][1][1],&g_68,&l_1071},{&l_1080[0][1][1],&g_821,&l_1080[1][2][1]},{&l_1080[0][1][1],&l_1080[0][1][1],&g_68},{&g_821,&l_1080[0][1][1],&l_1080[0][1][1]},{&l_1080[1][2][1],&l_1080[0][1][1],&l_1080[1][2][1]},{&l_1080[0][0][1],&g_821,&l_1071}},{{(void*)0,&g_68,&l_1080[1][2][1]},{&l_1071,&l_1080[0][0][1],&l_1080[0][1][1]},{&l_1080[0][0][1],&l_1080[0][1][1],&g_68},{&l_1071,&l_1071,&l_1080[1][2][1]},{(void*)0,&l_1080[0][2][0],&l_1071},{&l_1080[0][0][1],&l_1071,&l_1080[0][0][1]}},{{&l_1080[1][2][1],&l_1080[0][1][1],&l_1080[0][1][1]},{&g_821,&l_1080[0][0][1],&l_1080[0][0][1]},{&l_1080[0][1][1],&g_68,&l_1071},{&l_1080[0][1][1],&g_821,&l_1080[1][2][1]},{&l_1080[0][1][1],&l_1080[0][1][1],&g_68},{&g_821,&l_1080[0][1][1],&l_1080[0][1][1]}},{{&l_1080[1][2][1],&l_1080[0][1][1],&l_1080[1][2][1]},{&l_1080[0][0][1],&g_821,&l_1071},{(void*)0,&g_68,&l_1080[1][2][1]},{&l_1071,&l_1080[0][0][1],&l_1080[0][1][1]},{&l_1080[0][0][1],&l_1080[0][1][1],&g_68},{&l_1071,&l_1071,&l_1080[1][2][1]}},{{(void*)0,&l_1080[0][2][0],&l_1071},{&l_1080[0][0][1],&l_1071,&l_1080[0][0][1]},{&l_1080[1][2][1],&l_1080[0][1][1],&l_1080[0][1][1]},{&g_821,&l_1080[0][0][1],&l_1080[0][0][1]},{&l_1080[0][1][1],&g_68,&l_1071},{&l_1080[0][1][1],&g_821,&l_1080[1][2][1]}}};
            int64_t l_1082 = (-4L);
            uint8_t *** const l_1084 = &g_763;
            struct S0 *l_1088 = &g_836;
            uint8_t *l_1118[9][3] = {{&g_94.f2,&g_94.f2,&g_703.f2},{&g_94.f2,&g_94.f2,&g_703.f2},{&g_94.f2,&g_94.f2,&g_703.f2},{&g_94.f2,&g_94.f2,&g_703.f2},{&g_94.f2,&g_94.f2,&g_94.f2},{&g_975.f2,&g_975.f2,&g_94.f2},{&g_975.f2,&g_975.f2,&g_94.f2},{&g_975.f2,&g_975.f2,&g_94.f2},{&g_975.f2,&g_975.f2,&g_94.f2}};
            int8_t l_1150[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
            uint8_t l_1152 = 0xBAL;
            int i, j, k;
            l_1082 = (((((*g_1033) , (void*)0) == ((*l_1070) = l_1068[0][5][3])) & ((((*l_1071) = (-9L)) & (safe_rshift_func_uint64_t_u_s((safe_mul_func_uint32_t_u_u((safe_mul_func_int16_t_s_s((-9L), (l_1078 == (void*)0))), ((((l_1080[0][1][1] = l_1080[0][1][1]) == (g_202 , l_1064)) | (*l_1064)) >= g_895.f5))), 29))) < p_29)) & (*l_1064));
            if ((*g_68))
                continue;
            for (p_27 = 0; (p_27 <= 0); p_27 += 1)
            { /* block id: 540 */
                int32_t *l_1083[1][2];
                uint64_t l_1112 = 0x8F0E83EF7B533FF0LL;
                int i, j;
                for (i = 0; i < 1; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_1083[i][j] = (void*)0;
                }
                (*g_67) = l_1064;
                (*g_820) = l_1083[0][0];
                if (((void*)0 == l_1084))
                { /* block id: 543 */
                    int8_t l_1087 = (-3L);
                    uint8_t *l_1089 = &g_94.f2;
                    int i, j, k;
                    if (((safe_add_func_int16_t_s_s((((*l_1064) ^ ((((*g_755) = ((((p_30 == l_1087) , ((void*)0 != l_1088)) <= (*l_1064)) | ((((*l_1089) |= (*l_1064)) || p_27) >= ((*l_1071) ^= p_28)))) || (*g_162)) >= p_27)) == (*g_753)), p_30)) >= g_169.f0))
                    { /* block id: 547 */
                        (*g_1033) = g_1090;
                    }
                    else
                    { /* block id: 549 */
                        int16_t l_1101[3][1][1];
                        int i, j, k;
                        for (i = 0; i < 3; i++)
                        {
                            for (j = 0; j < 1; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_1101[i][j][k] = 0L;
                            }
                        }
                        (*l_1071) ^= (safe_lshift_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u((safe_div_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(l_1087, (safe_rshift_func_uint64_t_u_u((l_1101[2][0][0] || (*g_220)), 56)))), ((*g_507) = (*l_1064)))), 0x00BD26740C3F476BLL)), ((safe_div_func_uint32_t_u_u((safe_unary_minus_func_int16_t_s(((safe_rshift_func_int8_t_s_s((safe_mod_func_int8_t_s_s(((safe_unary_minus_func_int32_t_s(0x4BEBE05EL)) && g_648), (safe_lshift_func_uint64_t_u_s((p_27 < 0L), g_519[4][2][2].f0)))), (*g_787))) , l_1112))), p_28)) , 0UL)));
                        if (l_1113)
                            break;
                        if (l_1101[0][0][0])
                            break;
                        return p_27;
                    }
                }
                else
                { /* block id: 556 */
                    uint8_t **l_1119 = &l_1118[0][2];
                    const uint8_t *l_1120 = (void*)0;
                    const uint8_t **l_1121 = &g_200;
                    int32_t l_1124 = 1L;
                    int64_t l_1146 = (-1L);
                    int32_t l_1151[6][1];
                    int i, j;
                    for (i = 0; i < 6; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_1151[i][j] = 0xB6763519L;
                    }
                    if (((p_27 && ((((((safe_add_func_int8_t_s_s((*g_787), (((*l_1119) = l_1118[0][2]) == ((*l_1121) = l_1120)))) , g_1122[0][4]) , (g_1123 , (((-1L) != (*l_1064)) > ((*l_1071) = (((((*l_1064) | 18446744073709551609UL) == p_28) ^ (*l_1064)) || (*g_220)))))) | l_1124) , (**g_506)) != p_27)) != p_30))
                    { /* block id: 560 */
                        int32_t l_1125 = (-1L);
                        int32_t l_1126 = 0L;
                        uint8_t l_1131 = 255UL;
                        int i, j, k;
                        l_1128++;
                        ++l_1131;
                        g_735 = l_1134;
                    }
                    else
                    { /* block id: 564 */
                        uint8_t l_1147 = 246UL;
                        uint32_t l_1148 = 0xCFD81CD4L;
                        int32_t l_1149[5][5] = {{0x3DC19BA4L,(-1L),(-1L),0x3DC19BA4L,0x3DC19BA4L},{0L,4L,0L,4L,0L},{0x3DC19BA4L,0x3DC19BA4L,(-1L),(-1L),0x3DC19BA4L},{1L,4L,1L,4L,1L},{0x3DC19BA4L,(-1L),(-1L),0x3DC19BA4L,0x3DC19BA4L}};
                        int i, j;
                        (*g_510) = g_1135;
                        g_654[(g_721.f2 + 1)][g_721.f2] = ((safe_lshift_func_int64_t_s_s((g_100 = (((void*)0 == l_1138) == ((p_27 >= (l_1149[1][4] = ((0x91FE9EB0L >= ((void*)0 == &g_252)) > (safe_sub_func_int16_t_s_s((((~p_29) > (l_1148 &= ((safe_mul_func_uint16_t_u_u(((((safe_lshift_func_int32_t_s_s(p_29, ((void*)0 != &p_29))) , (void*)0) == (void*)0) , l_1146), l_1124)) > l_1147))) , g_1135.f2), 0x64AEL))))) <= l_1150[5]))), g_794.f0)) , (void*)0);
                        l_1152++;
                        if (p_28)
                            break;
                    }
                    (*g_364) = (safe_unary_minus_func_uint8_t_u((((((**l_1119) &= 0xEAL) < (*l_1071)) >= (safe_div_func_uint32_t_u_u(((((*l_1071) & (*g_220)) && (*l_1071)) ^ (safe_mul_func_uint8_t_u_u((((safe_lshift_func_int64_t_s_u(3L, 29)) == p_29) <= (((safe_add_func_uint32_t_u_u(((g_519[4][2][2].f3 & g_3) ^ (*g_405)), 0xD1D152E3L)) | p_28) != 0xB81D140A5591DF67LL)), (*l_1064)))), p_30))) | g_235.f0)));
                }
            }
            for (g_1123.f1 = 0; (g_1123.f1 <= 0); g_1123.f1 += 1)
            { /* block id: 579 */
                l_1164 = (void*)0;
            }
        }
    }
    (*g_1033) = g_1165;
    return p_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_49 g_34 g_67 g_39 g_78 g_68 g_426 g_4 g_506 g_507 g_386 g_654 g_252 g_353 g_162 g_163 g_96 g_299.f1 g_200 g_94.f5 g_519.f0 g_220 g_221 g_684 g_685 g_94.f2 g_692 g_72 g_502 g_703 g_364 g_299.f0 g_709 g_710 g_94.f3 g_100 g_721 g_636 g_730 g_736 g_737 g_407 g_755 g_757 g_758 g_759 g_762 g_235.f0 g_307 g_773 g_356 g_778 g_820 g_821 g_3 g_299.f2 g_786 g_787 g_202 g_1031 g_1032 g_1033 g_1025.f2 g_1044 g_347.f0 g_1045.f2 g_1055 g_122 g_177
 * writes: g_34 g_68 g_39 g_78 g_252 g_299.f3 g_629 g_122 g_96 g_356 g_94.f2 g_353.f1 g_72 g_235.f2 g_347.f0 g_299.f0 g_703.f3 g_735 g_353.f3.f1 g_235.f1 g_753 g_709.f3 g_763 g_235.f0 g_307 g_94.f3 g_426 g_703.f0 g_299.f2 g_353.f2 g_1031 g_1033 g_1025.f2 g_1044 g_796.f1 g_821
 */
static int32_t * func_40(uint16_t  p_41)
{ /* block id: 14 */
    const int8_t *l_63 = &g_34;
    int32_t l_64 = (-1L);
    const int32_t *l_752 = &g_177;
    const int32_t **l_751[2][10] = {{&l_752,&l_752,&l_752,&l_752,&l_752,&l_752,&l_752,&l_752,&l_752,&l_752},{&l_752,&l_752,&l_752,&l_752,&l_752,&l_752,&l_752,&l_752,&l_752,&l_752}};
    int32_t *l_1061 = &g_796.f1;
    int32_t *l_1062 = (void*)0;
    int32_t *l_1063 = &g_3;
    int i, j;
    (*l_1061) = (safe_mul_func_int64_t_s_s((safe_rshift_func_uint8_t_u_s(p_41, (safe_mod_func_uint16_t_u_u(((g_49 , ((~func_51(func_56((g_753 = (func_59(l_63, &g_34, l_64) , (*g_67))), p_41), (*g_786), &l_64, g_202)) & (*l_752))) <= (*l_752)), 0x1DABL)))), 1L));
    (*g_820) = l_1062;
    return l_1063;
}


/* ------------------------------------------ */
/* 
 * reads : g_1031 g_1032 g_1033 g_1025.f2 g_162 g_163 g_1044 g_299.f1 g_787 g_347.f0 g_1045.f2 g_1055 g_506 g_507 g_122 g_692 g_72
 * writes: g_1031 g_1033 g_1025.f2 g_1044 g_347.f0 g_703.f3
 */
static int8_t  func_51(const int8_t * p_52, int8_t * p_53, int32_t * p_54, int16_t  p_55)
{ /* block id: 504 */
    volatile struct S1 **l_1034 = &g_1033;
    int32_t l_1039 = 2L;
    union U4 ***l_1057 = &g_629[1][2];
    (*g_1032) = g_1031;
    (*l_1034) = g_1033;
    for (g_1025.f2 = (-24); (g_1025.f2 > (-23)); ++g_1025.f2)
    { /* block id: 509 */
        struct S1 **l_1046 = &g_1044;
        uint8_t l_1054 = 6UL;
        int16_t *l_1056 = &g_703.f3;
        (*p_54) = ((*g_162) & (((*l_1056) = ((safe_mod_func_int16_t_s_s(l_1039, (((safe_add_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s((((*l_1046) = g_1044) != (void*)0), (safe_div_func_uint64_t_u_u((((((*g_787) ^= (((p_55 | 18446744073709551615UL) != (safe_lshift_func_uint16_t_u_u((~(safe_add_func_int16_t_s_s((((l_1039 ^ (l_1039 || ((p_55 && (-1L)) & 0xEECEL))) , g_299.f1) | l_1039), l_1054))), l_1039))) >= p_55)) , g_1045.f2) , 1UL) && l_1039), 0xD682277FAA54CADALL)))), l_1039)) | 0L) , g_1055))) >= 0xC8L)) < (**g_506)));
    }
    (*p_54) |= (l_1057 != (((+l_1039) == (safe_sub_func_int32_t_s_s((-9L), (*g_692)))) , l_1057));
    return (*g_787);
}


/* ------------------------------------------ */
/* 
 * reads : g_755 g_39 g_703.f3 g_757 g_758 g_759 g_762 g_235.f0 g_68 g_307 g_72 g_94.f3 g_426 g_773 g_703.f2 g_703.f0 g_685 g_356 g_778 g_820 g_821 g_3 g_67 g_299.f2 g_364 g_786 g_787
 * writes: g_39 g_703.f3 g_709.f3 g_763 g_68 g_235.f0 g_307 g_72 g_94.f3 g_426 g_703.f0 g_299.f2 g_353.f2
 */
static const int8_t * func_56(const int32_t * p_57, int16_t  p_58)
{ /* block id: 348 */
    union U4 *****l_754 = &g_736;
    int16_t l_756[5][6] = {{1L,2L,1L,2L,1L,2L},{0xD470L,2L,0xD470L,2L,0xD470L,2L},{1L,2L,1L,2L,1L,2L},{0xD470L,2L,0xD470L,2L,0xD470L,2L},{1L,2L,1L,2L,1L,2L}};
    uint8_t *l_761 = &g_299.f2;
    uint8_t ** const l_760 = &l_761;
    uint32_t *l_817 = &g_648;
    int32_t l_822 = 1L;
    int32_t l_878 = 1L;
    uint8_t l_914 = 0xEBL;
    uint64_t l_965[1][8][3] = {{{18446744073709551610UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551615UL,0UL},{0x095DAD9569C917D8LL,18446744073709551610UL,5UL},{18446744073709551615UL,18446744073709551615UL,5UL},{18446744073709551610UL,0x095DAD9569C917D8LL,0UL},{18446744073709551615UL,18446744073709551615UL,18446744073709551615UL},{18446744073709551615UL,18446744073709551610UL,18446744073709551615UL},{18446744073709551610UL,18446744073709551615UL,18446744073709551615UL}}};
    int32_t l_986 = (-6L);
    int32_t l_987 = 0x16C29B09L;
    int i, j, k;
    (*g_755) |= ((void*)0 == l_754);
    for (g_703.f3 = 0; (g_703.f3 <= 2); g_703.f3 += 1)
    { /* block id: 352 */
        int32_t *l_764 = &g_307;
        int32_t **l_765 = &g_68;
        const int8_t *l_768[8][3][4] = {{{&g_138,&g_102,&g_721.f0,&g_102},{&g_721.f0,&g_102,&g_138,(void*)0},{&g_102,(void*)0,(void*)0,&g_721.f0}},{{&g_235.f0,&g_102,&g_102,&g_235.f0},{&g_235.f0,(void*)0,(void*)0,&g_235.f0},{&g_102,&g_235.f0,&g_138,&g_138}},{{&g_721.f0,(void*)0,&g_721.f0,&g_138},{&g_138,&g_235.f0,&g_102,&g_235.f0},{(void*)0,(void*)0,&g_235.f0,&g_235.f0}},{{&g_102,&g_102,&g_235.f0,&g_721.f0},{(void*)0,(void*)0,&g_102,(void*)0},{&g_138,&g_102,&g_721.f0,&g_102}},{{&g_721.f0,&g_102,&g_138,(void*)0},{&g_102,(void*)0,(void*)0,&g_721.f0},{&g_235.f0,&g_102,&g_102,&g_235.f0}},{{&g_235.f0,(void*)0,(void*)0,&g_235.f0},{&g_102,&g_235.f0,&g_138,&g_138},{&g_721.f0,(void*)0,(void*)0,&g_102}},{{(void*)0,&g_102,(void*)0,(void*)0},{&g_721.f0,&g_235.f0,&g_102,&g_102},{&g_138,&g_138,&g_102,(void*)0}},{{&g_721.f0,&g_138,(void*)0,&g_235.f0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_235.f0}}};
        int i, j, k;
        (*g_759) = (l_756[3][0] , (g_757 , g_758));
        (*g_762) = l_760;
        (*l_765) = l_764;
        for (g_235.f0 = 2; (g_235.f0 >= 0); g_235.f0 -= 1)
        { /* block id: 358 */
            (**l_765) = (safe_lshift_func_int64_t_s_s(0x097D614AD57A15F8LL, 55));
            for (g_307 = 2; (g_307 >= 0); g_307 -= 1)
            { /* block id: 362 */
                for (g_72 = 4; (g_72 >= 0); g_72 -= 1)
                { /* block id: 365 */
                    for (g_94.f3 = 2; (g_94.f3 >= 0); g_94.f3 -= 1)
                    { /* block id: 368 */
                        return l_768[2][1][1];
                    }
                }
            }
            return l_768[2][1][1];
        }
    }
    for (g_426 = 1; (g_426 >= (-23)); --g_426)
    { /* block id: 378 */
        int32_t *l_775[5];
        union U4 *l_793 = &g_794;
        uint64_t *l_909 = &g_781.f1;
        int16_t l_912 = 0x0E13L;
        uint32_t l_935[2][5];
        uint64_t l_938 = 0x2F7BAD9636EDC7E1LL;
        const struct S0 *l_974 = &g_975;
        uint64_t l_988[6][9] = {{1UL,0x6B0514C231D35126LL,0xCE96CF96705644D9LL,18446744073709551607UL,0x97BADF727E6F72D2LL,18446744073709551606UL,4UL,0x8534FFB4906B2B8BLL,0x4E32082CC50967F2LL},{0xCE96CF96705644D9LL,18446744073709551606UL,18446744073709551607UL,18446744073709551615UL,1UL,18446744073709551615UL,18446744073709551607UL,18446744073709551606UL,0xCE96CF96705644D9LL},{0UL,1UL,18446744073709551607UL,0x2DF1EA9E84B45BA8LL,0xF4D28E0ACF52ED7ALL,4UL,0x97BADF727E6F72D2LL,0x770116BA193CC202LL,18446744073709551615UL},{0UL,4UL,0xCE96CF96705644D9LL,0x770116BA193CC202LL,0x8ED4BF8F0F2483D9LL,0UL,0UL,0UL,0UL},{0UL,0xF4D28E0ACF52ED7ALL,0x97BADF727E6F72D2LL,0xF4D28E0ACF52ED7ALL,0UL,4UL,0x2DF1EA9E84B45BA8LL,0UL,0x6B0514C231D35126LL},{0xCE96CF96705644D9LL,0x8534FFB4906B2B8BLL,0x6B0514C231D35126LL,0x97BADF727E6F72D2LL,0UL,0x4E32082CC50967F2LL,0x86F195F468480434LL,0x770116BA193CC202LL,4UL}};
        uint32_t *l_1020 = &g_96;
        uint32_t **l_1019 = &l_1020;
        int32_t **l_1027[2];
        int i, j;
        for (i = 0; i < 5; i++)
            l_775[i] = &g_353[0].f1;
        for (i = 0; i < 2; i++)
        {
            for (j = 0; j < 5; j++)
                l_935[i][j] = 0xF9015434L;
        }
        for (i = 0; i < 2; i++)
            l_1027[i] = (void*)0;
        g_703.f0 &= ((safe_lshift_func_uint64_t_u_u(p_58, (g_773 , (+p_58)))) ^ g_703.f2);
        for (g_299.f2 = (-18); (g_299.f2 == 7); g_299.f2 = safe_add_func_uint8_t_u_u(g_299.f2, 6))
        { /* block id: 382 */
            const int8_t *l_779 = &g_34;
            union U4 *l_782 = &g_709[0];
            union U4 *l_797 = (void*)0;
            uint32_t *l_816 = &g_648;
            int32_t l_825 = 0x79ED3C13L;
            int32_t *l_860[10][3] = {{&g_3,&g_307,&g_3},{(void*)0,(void*)0,(void*)0},{&g_3,&g_307,&g_3},{(void*)0,(void*)0,(void*)0},{&g_3,&g_307,&g_3},{(void*)0,(void*)0,(void*)0},{&g_3,&g_307,&g_3},{(void*)0,(void*)0,(void*)0},{&g_3,&g_307,&g_3},{(void*)0,(void*)0,(void*)0}};
            int32_t **l_863[4];
            int32_t *** const l_862[6] = {&l_863[0],&l_863[0],&l_863[0],&l_863[0],&l_863[0],&l_863[0]};
            int16_t l_894 = 0x4A43L;
            uint16_t * const l_902 = &g_118[4];
            uint32_t *l_1018[3][4] = {{&g_98,&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98,&g_98},{&g_98,&g_98,&g_98,&g_98}};
            uint32_t **l_1017 = &l_1018[2][3];
            int i, j;
            for (i = 0; i < 4; i++)
                l_863[i] = (void*)0;
            for (p_58 = 4; (p_58 >= 0); p_58 -= 1)
            { /* block id: 385 */
                (*g_778) = (*g_685);
                return l_779;
            }
        }
        if ((**g_820))
            break;
        p_57 = (*g_67);
    }
    for (g_299.f2 = 0; (g_299.f2 > 9); g_299.f2 = safe_add_func_int16_t_s_s(g_299.f2, 9))
    { /* block id: 500 */
        int32_t l_1030 = (-10L);
        l_1030 |= (*g_364);
    }
    return (*g_786);
}


/* ------------------------------------------ */
/* 
 * reads : g_34 g_67 g_39 g_78 g_68 g_426 g_4 g_506 g_507 g_386 g_654 g_252 g_353 g_162 g_163 g_96 g_299.f1 g_200 g_94.f5 g_519.f0 g_220 g_221 g_684 g_685 g_94.f2 g_692 g_72 g_502 g_703 g_364 g_299.f0 g_709 g_710 g_94.f3 g_100 g_721 g_636 g_730 g_736 g_737 g_407
 * writes: g_34 g_68 g_39 g_78 g_252 g_299.f3 g_629 g_122 g_96 g_356 g_94.f2 g_353.f1 g_72 g_235.f2 g_347.f0 g_299.f0 g_703.f3 g_735 g_353.f3.f1 g_235.f1
 */
static const union U4  func_59(const int8_t * p_60, int8_t * const  p_61, uint16_t  p_62)
{ /* block id: 15 */
    int32_t l_75 = (-3L);
    int32_t l_77 = 7L;
    int32_t l_103 = 0xBBD83FE2L;
    int32_t **l_207 = &g_68;
    uint64_t l_226[7] = {18446744073709551614UL,0xE2ECC4F0A1780323LL,18446744073709551614UL,18446744073709551614UL,0xE2ECC4F0A1780323LL,18446744073709551614UL,18446744073709551614UL};
    const uint8_t *l_250 = (void*)0;
    uint16_t l_259 = 0xCC2CL;
    int8_t l_309 = (-3L);
    union U4 *l_352[9][9] = {{&g_353[0],&g_353[2],&g_353[2],&g_353[0],&g_353[0],&g_353[0],(void*)0,&g_353[2],&g_353[0]},{&g_353[4],(void*)0,&g_353[0],&g_353[2],&g_353[5],&g_353[0],&g_353[5],&g_353[0],(void*)0},{&g_353[5],&g_353[0],(void*)0,&g_353[1],&g_353[0],&g_353[2],&g_353[0],(void*)0,(void*)0},{&g_353[1],&g_353[4],&g_353[5],&g_353[1],&g_353[5],&g_353[4],&g_353[1],(void*)0,&g_353[0]},{&g_353[0],&g_353[0],&g_353[3],&g_353[2],&g_353[2],&g_353[0],&g_353[4],&g_353[0],&g_353[2]},{&g_353[3],&g_353[5],(void*)0,&g_353[0],&g_353[0],&g_353[3],&g_353[2],(void*)0,&g_353[3]},{&g_353[5],(void*)0,&g_353[0],&g_353[3],&g_353[5],(void*)0,&g_353[0],&g_353[0],&g_353[0]},{&g_353[3],&g_353[0],&g_353[0],&g_353[0],&g_353[0],&g_353[3],&g_353[5],(void*)0,&g_353[4]},{(void*)0,&g_353[2],&g_353[0],(void*)0,&g_353[0],&g_353[2],&g_353[0],&g_353[3],&g_353[0]}};
    int32_t l_382[5][10][4] = {{{1L,9L,6L,1L},{(-1L),0x7E528EABL,3L,0x85808407L},{0x8EA9E55EL,1L,(-9L),9L},{1L,0xFEB184F4L,(-1L),(-8L)},{(-1L),(-1L),0x7E528EABL,6L},{(-1L),(-9L),9L,0xB586226DL},{1L,0xBF0036B7L,(-1L),0xBF0036B7L},{0xBC12E71CL,(-1L),0xC07732DFL,0xCB6A71BAL},{1L,(-1L),6L,9L},{9L,0xB43228F5L,0xCB6A71BAL,0L}},{{9L,0x8464F591L,6L,0x9081E52AL},{1L,0L,0xC07732DFL,0x63441199L},{0xBC12E71CL,0x85808407L,(-1L),1L},{1L,0L,9L,0xF9F6BCFAL},{(-1L),0x8EA9E55EL,0x7E528EABL,0x6943293BL},{(-1L),3L,(-1L),(-1L)},{1L,1L,(-9L),0xB43228F5L},{0x8EA9E55EL,0x9081E52AL,3L,1L},{(-1L),0xF9F6BCFAL,6L,3L},{1L,0xF9F6BCFAL,1L,1L}},{{0xF9F6BCFAL,0x9081E52AL,1L,0xB43228F5L},{0xCB6A71BAL,1L,0xFEB184F4L,(-1L)},{9L,3L,1L,0x6943293BL},{0x8464F591L,0x8EA9E55EL,0xB586226DL,0xF9F6BCFAL},{0xC07732DFL,0L,(-1L),1L},{0L,0x85808407L,0L,0x63441199L},{0x53D6C6D5L,0L,(-8L),0x9081E52AL},{1L,0x8464F591L,1L,0L},{0x7E528EABL,0xB43228F5L,1L,9L},{1L,(-1L),(-8L),0xCB6A71BAL}},{{0x53D6C6D5L,(-1L),0L,0xBF0036B7L},{0L,0xBF0036B7L,(-1L),0xB586226DL},{0xC07732DFL,(-9L),0xB586226DL,6L},{0x8464F591L,(-1L),1L,(-8L)},{9L,0xFEB184F4L,0xFEB184F4L,9L},{0xCB6A71BAL,1L,1L,0x85808407L},{0xF9F6BCFAL,0x7E528EABL,1L,1L},{1L,9L,6L,1L},{(-1L),0x7E528EABL,3L,0x85808407L},{0x8EA9E55EL,1L,(-9L),9L}},{{1L,0xFEB184F4L,(-1L),(-8L)},{(-1L),(-1L),0x8464F591L,1L},{9L,0xCB6A71BAL,0xC07732DFL,(-1L)},{9L,0xB586226DL,0L,0xB586226DL},{1L,9L,0x53D6C6D5L,0x7E528EABL},{0x6943293BL,0x63441199L,1L,0xC07732DFL},{0xC07732DFL,0L,0x7E528EABL,0xBC12E71CL},{0xC07732DFL,6L,1L,0x7B892A87L},{0x6943293BL,0xBC12E71CL,0x53D6C6D5L,3L},{1L,0L,0L,(-1L)}}};
    int32_t l_389 = 0x75217F3FL;
    struct S0 *l_518 = &g_519[4][2][2];
    uint64_t l_613 = 18446744073709551606UL;
    uint16_t ***l_644[5][8] = {{&g_506,&g_506,&g_506,(void*)0,&g_506,&g_506,&g_506,&g_506},{&g_506,(void*)0,&g_506,&g_506,&g_506,&g_506,&g_506,&g_506},{&g_506,&g_506,&g_506,&g_506,&g_506,&g_506,&g_506,&g_506},{&g_506,&g_506,&g_506,&g_506,&g_506,&g_506,&g_506,&g_506},{&g_506,&g_506,&g_506,&g_506,&g_506,&g_506,&g_506,&g_506}};
    union U4 *****l_734 = (void*)0;
    union U4 ** const *l_744 = (void*)0;
    int i, j, k;
    for (g_34 = (-19); (g_34 <= (-17)); g_34 = safe_add_func_uint16_t_u_u(g_34, 6))
    { /* block id: 18 */
        int16_t l_74 = 0L;
        int32_t l_133[10][6][4] = {{{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L}},{{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L}},{{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L}},{{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L}},{{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L}},{{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L}},{{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L}},{{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L}},{{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L}},{{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L},{1L,0x19E39778L,1L,0x34994D0EL},{1L,0x34994D0EL,1L,0x19E39778L}}};
        int32_t l_134 = 0x3CEA4A79L;
        int32_t ***l_249[7][7] = {{&l_207,(void*)0,&l_207,&l_207,&l_207,&l_207,&l_207},{&l_207,&l_207,&l_207,&l_207,(void*)0,&l_207,&l_207},{&l_207,&l_207,&l_207,&l_207,&l_207,&l_207,&l_207},{&l_207,&l_207,&l_207,&l_207,(void*)0,(void*)0,&l_207},{&l_207,&l_207,&l_207,&l_207,&l_207,&l_207,&l_207},{&l_207,&l_207,&l_207,&l_207,&l_207,&l_207,&l_207},{&l_207,&l_207,&l_207,&l_207,&l_207,&l_207,&l_207}};
        int32_t l_251 = 0L;
        int32_t l_310 = 0x1BD6ACCCL;
        int16_t l_316 = 1L;
        int i, j, k;
        (*g_67) = &g_4;
        for (g_39 = (-2); (g_39 == 4); g_39 = safe_add_func_int32_t_s_s(g_39, 1))
        { /* block id: 22 */
            int32_t *l_71 = &g_72;
            int32_t *l_73[2][2][9] = {{{&g_3,&g_72,&g_72,&g_72,&g_3,&g_4,&g_72,(void*)0,&g_72},{(void*)0,&g_72,&g_4,&g_72,&g_3,&g_4,&g_72,&g_4,&g_3}},{{&g_4,&g_39,&g_39,&g_4,&g_4,&g_72,(void*)0,&g_72,(void*)0},{&g_4,&g_3,&g_4,&g_72,(void*)0,&g_4,&g_4,(void*)0,&g_72}}};
            uint8_t l_125[9][9][2] = {{{1UL,0xD5L},{0xD3L,0xD3L},{0xFBL,0x3DL},{0x7AL,254UL},{7UL,9UL},{1UL,7UL},{5UL,0x88L},{5UL,7UL},{1UL,9UL}},{{7UL,254UL},{0x7AL,0x3DL},{0xFBL,0xD3L},{0xD3L,0xD5L},{1UL,0xE2L},{0x1EL,7UL},{9UL,0x60L},{1UL,1UL},{0xF8L,5UL}},{{7UL,0x60L},{0xD3L,1UL},{0x1EL,0x7AL},{0x3DL,0xD5L},{5UL,9UL},{0xFBL,1UL},{0xE2L,254UL},{1UL,5UL},{1UL,1UL}},{{1UL,0x88L},{0x3DL,1UL},{1UL,0xD3L},{1UL,254UL},{0x7BL,5UL},{0xFBL,5UL},{9UL,0xD5L},{5UL,0x7BL},{0x1EL,1UL}},{{5UL,0x60L},{1UL,0x3DL},{0xF8L,0x3DL},{1UL,0x60L},{5UL,1UL},{0x1EL,0x7BL},{5UL,0xD5L},{9UL,5UL},{0xFBL,5UL}},{{0x7BL,254UL},{1UL,0xD3L},{1UL,1UL},{0x3DL,0x88L},{1UL,1UL},{1UL,5UL},{1UL,254UL},{0xE2L,1UL},{0xFBL,9UL}},{{5UL,0xD5L},{0x3DL,0x7AL},{0x1EL,1UL},{0xD3L,0x60L},{7UL,5UL},{0xF8L,1UL},{1UL,0x60L},{9UL,7UL},{0x1EL,0xE2L}},{{1UL,0xD5L},{0xD3L,0xD3L},{0xFBL,0x3DL},{0x7AL,254UL},{7UL,9UL},{1UL,7UL},{5UL,0x88L},{5UL,7UL},{1UL,9UL}},{{7UL,254UL},{0x7AL,0x3DL},{0xFBL,0xD3L},{0xD3L,0xD5L},{1UL,0xE2L},{0x1EL,7UL},{9UL,0x60L},{1UL,1UL},{0xF8L,5UL}}};
            const uint8_t *l_201 = &g_202;
            uint64_t l_228 = 0x50F9E0A5FCD0D6B2LL;
            int16_t *l_257[8][10] = {{&g_94.f3,&g_94.f3,&g_94.f3,&g_94.f3,&g_235.f2,&g_94.f3,&g_94.f3,&g_235.f2,&g_235.f2,&g_94.f3},{&g_235.f2,&g_235.f2,(void*)0,(void*)0,&g_235.f2,&g_235.f2,(void*)0,&g_94.f3,&g_235.f2,&g_235.f2},{&g_235.f2,&g_94.f3,&g_94.f3,&g_235.f2,&g_235.f2,&g_94.f3,&g_94.f3,&g_235.f2,&g_94.f3,&g_94.f3},{&g_235.f2,&g_235.f2,(void*)0,&g_94.f3,&g_235.f2,&g_235.f2,&g_94.f3,(void*)0,&g_235.f2,&g_235.f2},{&g_235.f2,&g_94.f3,(void*)0,&g_235.f2,&g_235.f2,(void*)0,(void*)0,&g_235.f2,&g_235.f2,(void*)0},{&g_235.f2,&g_235.f2,&g_94.f3,&g_94.f3,&g_235.f2,&g_94.f3,&g_94.f3,&g_94.f3,&g_94.f3,&g_235.f2},{&g_235.f2,(void*)0,(void*)0,&g_235.f2,&g_235.f2,(void*)0,&g_94.f3,&g_235.f2,&g_235.f2,&g_94.f3},{&g_235.f2,&g_235.f2,(void*)0,(void*)0,&g_235.f2,&g_235.f2,(void*)0,&g_94.f3,&g_235.f2,&g_235.f2}};
            uint32_t *l_283 = &g_98;
            uint32_t l_344 = 0xCD818A97L;
            int i, j, k;
            ++g_78;
            for (p_62 = 0; (p_62 <= 1); p_62 += 1)
            { /* block id: 26 */
                const uint32_t l_91[9][7][4] = {{{0x2899D3D8L,4294967290UL,0x33F623BAL,0x7E6D0914L},{3UL,7UL,0UL,0x7E6D0914L},{4294967290UL,4294967290UL,4294967290UL,0UL},{0xF9107178L,0x2899D3D8L,1UL,0xF9107178L},{3UL,0UL,4294967294UL,0x2899D3D8L},{0UL,4294967290UL,4294967294UL,4294967294UL},{3UL,3UL,1UL,0x7E6D0914L}},{{0xF9107178L,5UL,4294967290UL,0x2899D3D8L},{4294967290UL,0x2899D3D8L,0UL,4294967290UL},{3UL,0x2899D3D8L,0x33F623BAL,0x2899D3D8L},{0x2899D3D8L,5UL,4294967294UL,0x7E6D0914L},{7UL,3UL,0UL,4294967294UL},{0xF9107178L,4294967290UL,5UL,0x2899D3D8L},{0xF9107178L,0UL,0UL,0xF9107178L}},{{7UL,0x2899D3D8L,4294967294UL,0UL},{0x2899D3D8L,4294967290UL,0x33F623BAL,0x7E6D0914L},{3UL,7UL,0UL,0x7E6D0914L},{4294967290UL,4294967290UL,4294967290UL,0UL},{0xF9107178L,0x2899D3D8L,1UL,0xF9107178L},{3UL,0UL,4294967294UL,0x2899D3D8L},{0UL,4294967290UL,4294967294UL,4294967294UL}},{{3UL,3UL,1UL,0x7E6D0914L},{0xF9107178L,5UL,4294967290UL,0x2899D3D8L},{4294967290UL,0x2899D3D8L,0UL,4294967290UL},{3UL,0x2899D3D8L,0x33F623BAL,0x2899D3D8L},{0x2899D3D8L,5UL,4294967294UL,0x7E6D0914L},{7UL,3UL,0UL,4294967294UL},{0xF9107178L,4294967290UL,5UL,0x2899D3D8L}},{{0xF9107178L,0UL,0UL,0xF9107178L},{7UL,0x2899D3D8L,4294967294UL,0UL},{0x2899D3D8L,7UL,4294967290UL,5UL},{0UL,1UL,5UL,5UL},{0x33F623BAL,7UL,0x33F623BAL,5UL},{4294967294UL,4294967290UL,0xF9107178L,4294967294UL},{0UL,5UL,0xB8EBACA8L,4294967290UL}},{{5UL,7UL,0xB8EBACA8L,0xB8EBACA8L},{0UL,0UL,0xF9107178L,5UL},{4294967294UL,0x4177E56DL,0x33F623BAL,4294967290UL},{0x33F623BAL,4294967290UL,5UL,0x33F623BAL},{0UL,4294967290UL,4294967290UL,4294967290UL},{4294967290UL,0x4177E56DL,0xB8EBACA8L,5UL},{1UL,0UL,5UL,0xB8EBACA8L}},{{4294967294UL,7UL,0x7E6D0914L,4294967290UL},{4294967294UL,5UL,5UL,4294967294UL},{1UL,4294967290UL,0xB8EBACA8L,5UL},{4294967290UL,7UL,4294967290UL,5UL},{0UL,1UL,5UL,5UL},{0x33F623BAL,7UL,0x33F623BAL,5UL},{4294967294UL,4294967290UL,0xF9107178L,4294967294UL}},{{0UL,5UL,0xB8EBACA8L,4294967290UL},{5UL,7UL,0xB8EBACA8L,0xB8EBACA8L},{0UL,0UL,0xF9107178L,5UL},{4294967294UL,0x4177E56DL,0x33F623BAL,4294967290UL},{0x33F623BAL,4294967290UL,5UL,0x33F623BAL},{0UL,4294967290UL,4294967290UL,4294967290UL},{4294967290UL,0x4177E56DL,0xB8EBACA8L,5UL}},{{1UL,0UL,5UL,0xB8EBACA8L},{4294967294UL,7UL,0x7E6D0914L,4294967290UL},{4294967294UL,5UL,5UL,4294967294UL},{1UL,4294967290UL,0xB8EBACA8L,5UL},{4294967290UL,7UL,4294967290UL,5UL},{0UL,1UL,5UL,5UL},{0x33F623BAL,7UL,0x33F623BAL,5UL}}};
                uint32_t *l_95 = &g_96;
                uint32_t *l_97 = &g_98;
                int64_t *l_99 = &g_100;
                int8_t *l_101 = &g_102;
                int64_t l_135 = 1L;
                uint16_t l_212 = 0x2694L;
                uint8_t *l_245[8] = {&l_125[6][2][1],&l_125[6][2][1],&l_125[6][2][1],&l_125[6][2][1],&l_125[6][2][1],&l_125[6][2][1],&l_125[6][2][1],&l_125[6][2][1]};
                uint8_t **l_244 = &l_245[3];
                int16_t *l_258 = (void*)0;
                uint32_t l_289[4][6][2] = {{{0xCFB0ABCBL,4294967292UL},{0xCFB0ABCBL,0xCFB0ABCBL},{1UL,4294967292UL},{1UL,0xCFB0ABCBL},{0xCFB0ABCBL,4294967292UL},{0xCFB0ABCBL,0xCFB0ABCBL}},{{1UL,4294967292UL},{1UL,0xCFB0ABCBL},{0xCFB0ABCBL,4294967292UL},{0xCFB0ABCBL,0xCFB0ABCBL},{1UL,4294967292UL},{1UL,0xCFB0ABCBL}},{{0xCFB0ABCBL,4294967292UL},{0xCFB0ABCBL,0xCFB0ABCBL},{1UL,4294967292UL},{1UL,0xCFB0ABCBL},{0xCFB0ABCBL,4294967292UL},{0xCFB0ABCBL,0xCFB0ABCBL}},{{1UL,4294967292UL},{1UL,0xCFB0ABCBL},{0xCFB0ABCBL,4294967292UL},{0xCFB0ABCBL,0xCFB0ABCBL},{1UL,4294967292UL},{1UL,0xCFB0ABCBL}}};
                int32_t l_324[10] = {0x70606D16L,5L,0x70606D16L,1L,0x70606D16L,0x44BCF00CL,(-4L),0x44BCF00CL,0x70606D16L,0x70606D16L};
                int i, j, k;
            }
        }
    }
    for (l_103 = (-22); (l_103 != (-12)); l_103 = safe_add_func_uint32_t_u_u(l_103, 5))
    { /* block id: 138 */
        int32_t l_360 = 2L;
        int32_t l_379 = (-10L);
        int32_t l_380 = 0x85F11115L;
        int32_t l_381 = 0L;
        int32_t l_383[4][7] = {{0x677EC04DL,0x677EC04DL,5L,(-7L),0xE7F4204EL,(-10L),(-1L)},{(-1L),0xF1D2E8DBL,5L,5L,0xF1D2E8DBL,(-1L),(-8L)},{(-1L),5L,0xE6E452DEL,(-8L),0xE7F4204EL,0xE7F4204EL,(-8L)},{(-7L),0x42FE442EL,(-7L),(-10L),(-8L),(-1L),(-1L)}};
        uint32_t *l_535 = &g_96;
        int i, j;
    }
    for (l_259 = 0; (l_259 <= 6); l_259 += 1)
    { /* block id: 276 */
        int32_t l_621[7] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
        const union U4 *l_625 = &g_108;
        const union U4 **l_624 = &l_625;
        int32_t l_631 = 7L;
        struct S1 *l_651 = &g_347;
        uint32_t l_678[10][3][8] = {{{0x23FA874CL,0xAA152406L,18446744073709551615UL,0xD63CCE0AL,4UL,0x13B6E891L,18446744073709551611UL,0x103BD23FL},{4UL,0x13B6E891L,18446744073709551611UL,0x103BD23FL,0UL,0x760BF34BL,18446744073709551613UL,0UL},{0x309FC8B0L,0UL,0x59FC942EL,18446744073709551615UL,0UL,0x4460FC8EL,1UL,0xBF978CBCL}},{{0x13B6E891L,0x268F8A7FL,4UL,1UL,18446744073709551615UL,0x73DACCCEL,0xC415998CL,0x3EDB6E51L},{0xFFC4C54AL,0xD7A30625L,0UL,18446744073709551611UL,0x2A7EC7B1L,0xC0336632L,18446744073709551611UL,1UL},{18446744073709551615UL,0x760BF34BL,18446744073709551610UL,18446744073709551615UL,0xD5CF1D67L,0x268F8A7FL,0xF93CE937L,0xF274F710L}},{{18446744073709551611UL,0xCF69452DL,0xB0516263L,0x309FC8B0L,0x1E945587L,0UL,0x760BF34BL,0x6BBA0BE7L},{0x7C924B33L,0x581DEDB5L,18446744073709551608UL,0xE4403E51L,1UL,0x23FA874CL,0UL,18446744073709551615UL},{0x93A25D23L,0x309FC8B0L,0xF011F1B9L,0x3675D974L,1UL,18446744073709551611UL,1UL,0x2C16B951L}},{{0xD5CF1D67L,0xBF978CBCL,1UL,0x17AEE287L,0x160626DAL,0xC866A409L,6UL,0x908B0993L},{0UL,0UL,0xBF978CBCL,0UL,18446744073709551611UL,1UL,0UL,0UL},{0x2A7EC7B1L,18446744073709551615UL,0x93A25D23L,0x93A25D23L,18446744073709551615UL,0x2A7EC7B1L,0xB0516263L,0xC415998CL}},{{0xBF978CBCL,0x3675D974L,0UL,0UL,0xF011F1B9L,0x0558465FL,0x309FC8B0L,0x23D49496L},{0x268F8A7FL,18446744073709551615UL,18446744073709551615UL,0UL,0xC0336632L,8UL,2UL,0xC415998CL},{0x1E945587L,0xC0336632L,18446744073709551610UL,0x93A25D23L,18446744073709551613UL,0xCF69452DL,1UL,0UL}},{{0x9B7F116FL,6UL,18446744073709551615UL,0UL,0x9C2F7040L,0x5A22E776L,0x103BD23FL,0x908B0993L},{0x23D49496L,0xE4403E51L,0x0E40178FL,0x17AEE287L,0xE9CAFB8EL,0UL,0xFFC4C54AL,0x2C16B951L},{18446744073709551615UL,4UL,0xAA152406L,0x3675D974L,0x309FC8B0L,0xE4403E51L,0x73DACCCEL,18446744073709551615UL}},{{1UL,0xD63CCE0AL,18446744073709551615UL,0xE4403E51L,0x760BF34BL,18446744073709551610UL,0x268F8A7FL,0x0558465FL},{18446744073709551612UL,0x309FC8B0L,0x7B94CF11L,18446744073709551611UL,0xF011F1B9L,0x85709B21L,1UL,0xD5CF1D67L},{1UL,18446744073709551615UL,0x9B7F116FL,0x8ABF2DE4L,0x23FA874CL,18446744073709551609UL,0xB3321DDEL,1UL}},{{0UL,18446744073709551615UL,7UL,18446744073709551615UL,0x6BBA0BE7L,18446744073709551615UL,18446744073709551615UL,0x581DEDB5L},{18446744073709551614UL,0x1E945587L,0xC415998CL,0x6AEEB924L,0x5A22E776L,0x8D74AC84L,18446744073709551614UL,18446744073709551615UL},{0xF274F710L,18446744073709551611UL,18446744073709551615UL,0x8F51FF40L,8UL,1UL,0x0558465FL,0x0E40178FL}},{{18446744073709551608UL,0xD5CF1D67L,0x59FC942EL,0xE9CAFB8EL,18446744073709551610UL,0x3675D974L,18446744073709551610UL,0xE9CAFB8EL},{0UL,1UL,0UL,0x59FC942EL,0UL,18446744073709551613UL,0UL,0x8D74AC84L},{0x760BF34BL,0x5A22E776L,18446744073709551611UL,0x93A25D23L,18446744073709551611UL,18446744073709551615UL,0UL,0x2C16B951L}},{{0x760BF34BL,0x23D49496L,0UL,0xE4403E51L,0UL,18446744073709551614UL,18446744073709551615UL,0xB3321DDEL},{0UL,18446744073709551611UL,18446744073709551610UL,0x268F8A7FL,18446744073709551610UL,0xC0336632L,18446744073709551615UL,18446744073709551611UL},{18446744073709551608UL,0x647A5E6FL,0xB3321DDEL,4UL,8UL,18446744073709551611UL,0xCF69452DL,0x23D49496L}}};
        int8_t *l_715 = &l_309;
        int32_t *l_722 = &l_382[0][4][2];
        union U4 ***l_733 = &g_629[0][4];
        union U4 ****l_732 = &l_733;
        union U4 *****l_731[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        union U4 ** const **l_745 = &l_744;
        uint32_t *l_746 = &g_96;
        int64_t *l_747[5];
        uint8_t *l_748 = &g_353[0].f3.f1;
        uint8_t *l_749[1];
        int32_t *l_750 = &l_75;
        int i, j, k;
        for (i = 0; i < 5; i++)
            l_747[i] = (void*)0;
        for (i = 0; i < 1; i++)
            l_749[i] = &g_235.f1;
        for (g_252 = 0; (g_252 <= 5); g_252 += 1)
        { /* block id: 279 */
            int16_t *l_618[1];
            const union U4 ***l_626 = &l_624;
            union U4 **l_628 = &g_355;
            union U4 ***l_627[10][9] = {{&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,(void*)0,&l_628,&l_628},{&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,&l_628},{&l_628,&l_628,&l_628,&l_628,&l_628,(void*)0,&l_628,&l_628,&l_628},{&l_628,&l_628,&l_628,(void*)0,(void*)0,&l_628,&l_628,&l_628,&l_628},{(void*)0,&l_628,&l_628,(void*)0,(void*)0,&l_628,&l_628,&l_628,&l_628},{&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,(void*)0,&l_628,&l_628},{&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,(void*)0,&l_628,&l_628},{&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,(void*)0,&l_628,&l_628},{&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,&l_628},{&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,&l_628,&l_628}};
            int32_t l_630 = 0x4B0178D5L;
            union U4 * const  volatile * const  volatile * volatile * volatile l_658[7][1] = {{(void*)0},{&g_655[1]},{(void*)0},{&g_655[1]},{(void*)0},{&g_655[1]},{(void*)0}};
            int32_t l_663 = (-1L);
            int32_t l_664 = 1L;
            int i, j;
            for (i = 0; i < 1; i++)
                l_618[i] = (void*)0;
            (*l_207) = (*g_67);
            if ((!((safe_div_func_int32_t_s_s(((+((*p_61) ^= (4L >= ((((g_299.f3 = p_62) , 4294967295UL) , g_426) < ((l_621[1] = ((((safe_lshift_func_uint16_t_u_s(((0xA7L == l_621[1]) != (safe_mod_func_int16_t_s_s((((*l_626) = l_624) != (g_629[1][2] = (void*)0)), ((**g_506) = (**l_207))))), g_386)) > p_62) < p_62) <= 0x8ADF9228L)) , p_62))))) < p_62), l_630)) || l_621[4])))
            { /* block id: 287 */
                int16_t l_645 = 0L;
                int32_t l_662 = (-1L);
                int32_t l_668 = (-1L);
                int32_t l_669 = 0L;
                int32_t l_670 = 0L;
                if ((l_631 ^= l_621[6]))
                { /* block id: 289 */
                    uint32_t l_646 = 5UL;
                    int32_t l_665 = 0x28ACA288L;
                    int32_t l_666 = 0x4C8512A6L;
                    int32_t l_667[1][1][2];
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 1; j++)
                        {
                            for (k = 0; k < 2; k++)
                                l_667[i][j][k] = (-1L);
                        }
                    }
                    for (g_96 = 1; (g_96 <= 6); g_96 += 1)
                    { /* block id: 292 */
                        uint32_t *l_647 = &g_648;
                        struct S1 **l_652 = (void*)0;
                        int32_t *l_653 = &l_630;
                        int i;
                    }
                    for (l_389 = 5; (l_389 >= 0); l_389 -= 1)
                    { /* block id: 303 */
                        union U4 * const  volatile * const  volatile * volatile * volatile *l_657[2][7] = {{&g_654[0][0],&g_654[0][0],&g_654[0][0],&g_654[0][0],&g_654[0][0],&g_654[0][0],&g_654[0][0]},{&g_654[4][0],&g_654[7][1],&g_654[4][0],&g_654[4][0],&g_654[7][1],&g_654[4][0],&g_654[4][0]}};
                        int32_t *l_659 = &g_353[0].f1;
                        int32_t *l_660 = &g_39;
                        int32_t *l_661[10] = {&g_72,&g_72,&l_630,&g_72,&g_72,&l_630,&g_72,&g_72,&l_630,&g_72};
                        uint32_t l_671[10];
                        int i, j;
                        for (i = 0; i < 10; i++)
                            l_671[i] = 0UL;
                        l_658[4][0] = g_654[0][0];
                        (*l_207) = (*g_67);
                        --l_671[4];
                        return g_353[g_252];
                    }
                }
                else
                { /* block id: 309 */
                    (*l_207) = (*g_67);
                    if (((((((safe_sub_func_int64_t_s_s((p_62 < l_668), ((safe_add_func_int8_t_s_s(((*g_162) <= (4UL & ((**l_207) | ((l_678[6][1][4] , (--g_96)) | 9UL)))), 0xB6L)) == (safe_rshift_func_int64_t_s_s((+g_299.f1), l_669))))) | 0x5A2E9466L) & (*g_200)) <= g_519[4][2][2].f0) && (*g_220)) | (*p_61)))
                    { /* block id: 312 */
                        (*g_685) = g_684;
                    }
                    else
                    { /* block id: 314 */
                        uint8_t *l_688 = &g_94.f2;
                        int32_t *l_691 = &g_353[0].f1;
                        (*g_692) &= ((*l_691) = (safe_div_func_uint8_t_u_u(((*l_688)++), 254UL)));
                    }
                }
                for (g_235.f2 = 0; g_235.f2 < 4; g_235.f2 += 1)
                {
                    for (g_347.f0 = 0; g_347.f0 < 7; g_347.f0 += 1)
                    {
                        g_629[g_235.f2][g_347.f0] = &g_355;
                    }
                }
            }
            else
            { /* block id: 321 */
                int64_t l_706 = 0xF646CD4564648187LL;
                int32_t *l_707 = &l_77;
                int32_t *l_708[7];
                int8_t **l_716 = &l_715;
                int i;
                for (i = 0; i < 7; i++)
                    l_708[i] = &g_307;
                g_299.f0 |= ((*l_707) = (((l_621[2] = ((void*)0 == g_502)) && ((**l_207) , (safe_lshift_func_uint64_t_u_s((((safe_sub_func_int32_t_s_s((safe_div_func_uint32_t_u_u((safe_mul_func_int64_t_s_s(((safe_mul_func_int32_t_s_s((g_703 , (*g_364)), (safe_mul_func_uint32_t_u_u(l_678[7][2][0], (((&g_138 == p_61) == p_62) , l_706))))) & l_631), (-1L))), p_62)), g_39)) | p_62) , p_62), 15)))) , (*g_68)));
                l_621[6] |= (((g_709[6] , (g_710 , (*g_162))) | ((0x8854E0C6L <= ((l_678[9][0][4] != ((safe_mul_func_uint8_t_u_u((p_62 <= (safe_rshift_func_int8_t_s_s((g_94.f3 != ((&g_426 != ((*l_716) = l_715)) && 254UL)), 5))), (*g_200))) == 0x0D789472L)) > l_664)) != g_100)) && g_4);
            }
        }
        (*l_722) = (safe_div_func_uint32_t_u_u(4294967293UL, (safe_rshift_func_int64_t_s_u((g_721 , (p_62 > ((*p_61) | 0x27L))), 32))));
        for (g_703.f3 = 0; (g_703.f3 <= 6); g_703.f3 += 1)
        { /* block id: 332 */
            if ((*g_364))
                break;
            if (p_62)
                break;
            (*l_722) = (**l_207);
        }
        (*l_750) |= ((g_235.f1 = ((*l_748) = (safe_mod_func_uint64_t_u_u(((!((((p_62 <= ((*l_722) = (g_636[0][4] , (0UL & (safe_mul_func_uint32_t_u_u((((safe_lshift_func_int32_t_s_u(((g_735 = (l_734 = (g_730 , l_731[6]))) == &l_732), 30)) > (safe_div_func_uint16_t_u_u(((safe_div_func_uint16_t_u_u((safe_lshift_func_uint32_t_u_u(((*l_746) = ((((*l_745) = l_744) == (*g_736)) , 0x00AF99B0L)), 22)), (**l_207))) == p_62), 1L))) > (*l_722)), p_62)))))) , (*l_722)) != g_703.f4) && (**l_207))) , 0UL), g_72)))) != 255UL);
    }
    return g_407[1];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_4, "g_4", print_hash_value);
    transparent_crc(g_34, "g_34", print_hash_value);
    transparent_crc(g_39, "g_39", print_hash_value);
    transparent_crc(g_49.f0, "g_49.f0", print_hash_value);
    transparent_crc(g_72, "g_72", print_hash_value);
    transparent_crc(g_76, "g_76", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    transparent_crc(g_94.f0, "g_94.f0", print_hash_value);
    transparent_crc(g_94.f1, "g_94.f1", print_hash_value);
    transparent_crc(g_94.f2, "g_94.f2", print_hash_value);
    transparent_crc(g_94.f3, "g_94.f3", print_hash_value);
    transparent_crc(g_94.f4, "g_94.f4", print_hash_value);
    transparent_crc(g_94.f5, "g_94.f5", print_hash_value);
    transparent_crc(g_94.f6, "g_94.f6", print_hash_value);
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    transparent_crc(g_108.f0, "g_108.f0", print_hash_value);
    transparent_crc(g_110.f0, "g_110.f0", print_hash_value);
    transparent_crc(g_110.f1, "g_110.f1", print_hash_value);
    transparent_crc(g_110.f2, "g_110.f2", print_hash_value);
    transparent_crc(g_110.f3, "g_110.f3", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_118[i], "g_118[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_122, "g_122", print_hash_value);
    transparent_crc(g_137, "g_137", print_hash_value);
    transparent_crc(g_138, "g_138", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_169.f0, "g_169.f0", print_hash_value);
    transparent_crc(g_177, "g_177", print_hash_value);
    transparent_crc(g_202, "g_202", print_hash_value);
    transparent_crc(g_221, "g_221", print_hash_value);
    transparent_crc(g_235.f0, "g_235.f0", print_hash_value);
    transparent_crc(g_235.f1, "g_235.f1", print_hash_value);
    transparent_crc(g_235.f2, "g_235.f2", print_hash_value);
    transparent_crc(g_235.f3, "g_235.f3", print_hash_value);
    transparent_crc(g_252, "g_252", print_hash_value);
    transparent_crc(g_256.f0, "g_256.f0", print_hash_value);
    transparent_crc(g_299.f0, "g_299.f0", print_hash_value);
    transparent_crc(g_299.f1, "g_299.f1", print_hash_value);
    transparent_crc(g_299.f2, "g_299.f2", print_hash_value);
    transparent_crc(g_299.f3, "g_299.f3", print_hash_value);
    transparent_crc(g_299.f4, "g_299.f4", print_hash_value);
    transparent_crc(g_299.f5, "g_299.f5", print_hash_value);
    transparent_crc(g_299.f6, "g_299.f6", print_hash_value);
    transparent_crc(g_307, "g_307", print_hash_value);
    transparent_crc(g_315.f0, "g_315.f0", print_hash_value);
    transparent_crc(g_347.f0, "g_347.f0", print_hash_value);
    transparent_crc(g_347.f1, "g_347.f1", print_hash_value);
    transparent_crc(g_347.f2, "g_347.f2", print_hash_value);
    transparent_crc(g_347.f3, "g_347.f3", print_hash_value);
    transparent_crc(g_351.f0, "g_351.f0", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_353[i].f0, "g_353[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_356.f0, "g_356.f0", print_hash_value);
    transparent_crc(g_356.f1, "g_356.f1", print_hash_value);
    transparent_crc(g_356.f2, "g_356.f2", print_hash_value);
    transparent_crc(g_356.f3, "g_356.f3", print_hash_value);
    transparent_crc(g_384, "g_384", print_hash_value);
    transparent_crc(g_385, "g_385", print_hash_value);
    transparent_crc(g_386, "g_386", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_407[i].f0, "g_407[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_416.f0, "g_416.f0", print_hash_value);
    transparent_crc(g_426, "g_426", print_hash_value);
    transparent_crc(g_427, "g_427", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_519[i][j][k].f0, "g_519[i][j][k].f0", print_hash_value);
                transparent_crc(g_519[i][j][k].f1, "g_519[i][j][k].f1", print_hash_value);
                transparent_crc(g_519[i][j][k].f2, "g_519[i][j][k].f2", print_hash_value);
                transparent_crc(g_519[i][j][k].f3, "g_519[i][j][k].f3", print_hash_value);
                transparent_crc(g_519[i][j][k].f4, "g_519[i][j][k].f4", print_hash_value);
                transparent_crc(g_519[i][j][k].f5, "g_519[i][j][k].f5", print_hash_value);
                transparent_crc(g_519[i][j][k].f6, "g_519[i][j][k].f6", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_566.f0, "g_566.f0", print_hash_value);
    transparent_crc(g_566.f1, "g_566.f1", print_hash_value);
    transparent_crc(g_566.f2, "g_566.f2", print_hash_value);
    transparent_crc(g_566.f3, "g_566.f3", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_636[i][j].f0, "g_636[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_648, "g_648", print_hash_value);
    transparent_crc(g_684.f0, "g_684.f0", print_hash_value);
    transparent_crc(g_684.f1, "g_684.f1", print_hash_value);
    transparent_crc(g_684.f2, "g_684.f2", print_hash_value);
    transparent_crc(g_684.f3, "g_684.f3", print_hash_value);
    transparent_crc(g_703.f0, "g_703.f0", print_hash_value);
    transparent_crc(g_703.f1, "g_703.f1", print_hash_value);
    transparent_crc(g_703.f2, "g_703.f2", print_hash_value);
    transparent_crc(g_703.f3, "g_703.f3", print_hash_value);
    transparent_crc(g_703.f4, "g_703.f4", print_hash_value);
    transparent_crc(g_703.f5, "g_703.f5", print_hash_value);
    transparent_crc(g_703.f6, "g_703.f6", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_709[i].f0, "g_709[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_710.f0, "g_710.f0", print_hash_value);
    transparent_crc(g_721.f0, "g_721.f0", print_hash_value);
    transparent_crc(g_721.f1, "g_721.f1", print_hash_value);
    transparent_crc(g_721.f2, "g_721.f2", print_hash_value);
    transparent_crc(g_721.f3, "g_721.f3", print_hash_value);
    transparent_crc(g_730.f0, "g_730.f0", print_hash_value);
    transparent_crc(g_757.f0, "g_757.f0", print_hash_value);
    transparent_crc(g_757.f1, "g_757.f1", print_hash_value);
    transparent_crc(g_757.f2, "g_757.f2", print_hash_value);
    transparent_crc(g_757.f3, "g_757.f3", print_hash_value);
    transparent_crc(g_757.f4, "g_757.f4", print_hash_value);
    transparent_crc(g_757.f5, "g_757.f5", print_hash_value);
    transparent_crc(g_757.f6, "g_757.f6", print_hash_value);
    transparent_crc(g_758.f0, "g_758.f0", print_hash_value);
    transparent_crc(g_758.f1, "g_758.f1", print_hash_value);
    transparent_crc(g_758.f2, "g_758.f2", print_hash_value);
    transparent_crc(g_758.f3, "g_758.f3", print_hash_value);
    transparent_crc(g_773.f0, "g_773.f0", print_hash_value);
    transparent_crc(g_773.f1, "g_773.f1", print_hash_value);
    transparent_crc(g_773.f2, "g_773.f2", print_hash_value);
    transparent_crc(g_773.f3, "g_773.f3", print_hash_value);
    transparent_crc(g_773.f4, "g_773.f4", print_hash_value);
    transparent_crc(g_773.f5, "g_773.f5", print_hash_value);
    transparent_crc(g_773.f6, "g_773.f6", print_hash_value);
    transparent_crc(g_781.f0, "g_781.f0", print_hash_value);
    transparent_crc(g_794.f0, "g_794.f0", print_hash_value);
    transparent_crc(g_796.f0, "g_796.f0", print_hash_value);
    transparent_crc(g_836.f0, "g_836.f0", print_hash_value);
    transparent_crc(g_836.f1, "g_836.f1", print_hash_value);
    transparent_crc(g_836.f2, "g_836.f2", print_hash_value);
    transparent_crc(g_836.f3, "g_836.f3", print_hash_value);
    transparent_crc(g_836.f4, "g_836.f4", print_hash_value);
    transparent_crc(g_836.f5, "g_836.f5", print_hash_value);
    transparent_crc(g_836.f6, "g_836.f6", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_861[i].f0, "g_861[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_895.f0, "g_895.f0", print_hash_value);
    transparent_crc(g_895.f1, "g_895.f1", print_hash_value);
    transparent_crc(g_895.f2, "g_895.f2", print_hash_value);
    transparent_crc(g_895.f3, "g_895.f3", print_hash_value);
    transparent_crc(g_895.f4, "g_895.f4", print_hash_value);
    transparent_crc(g_895.f5, "g_895.f5", print_hash_value);
    transparent_crc(g_895.f6, "g_895.f6", print_hash_value);
    transparent_crc(g_925.f0, "g_925.f0", print_hash_value);
    transparent_crc(g_953.f0, "g_953.f0", print_hash_value);
    transparent_crc(g_953.f1, "g_953.f1", print_hash_value);
    transparent_crc(g_953.f2, "g_953.f2", print_hash_value);
    transparent_crc(g_953.f3, "g_953.f3", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_956[i][j].f0, "g_956[i][j].f0", print_hash_value);
            transparent_crc(g_956[i][j].f1, "g_956[i][j].f1", print_hash_value);
            transparent_crc(g_956[i][j].f2, "g_956[i][j].f2", print_hash_value);
            transparent_crc(g_956[i][j].f3, "g_956[i][j].f3", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_975.f0, "g_975.f0", print_hash_value);
    transparent_crc(g_975.f1, "g_975.f1", print_hash_value);
    transparent_crc(g_975.f2, "g_975.f2", print_hash_value);
    transparent_crc(g_975.f3, "g_975.f3", print_hash_value);
    transparent_crc(g_975.f4, "g_975.f4", print_hash_value);
    transparent_crc(g_975.f5, "g_975.f5", print_hash_value);
    transparent_crc(g_975.f6, "g_975.f6", print_hash_value);
    transparent_crc(g_976.f0, "g_976.f0", print_hash_value);
    transparent_crc(g_976.f1, "g_976.f1", print_hash_value);
    transparent_crc(g_976.f2, "g_976.f2", print_hash_value);
    transparent_crc(g_976.f3, "g_976.f3", print_hash_value);
    transparent_crc(g_1004, "g_1004", print_hash_value);
    transparent_crc(g_1025.f0, "g_1025.f0", print_hash_value);
    transparent_crc(g_1025.f1, "g_1025.f1", print_hash_value);
    transparent_crc(g_1025.f2, "g_1025.f2", print_hash_value);
    transparent_crc(g_1025.f3, "g_1025.f3", print_hash_value);
    transparent_crc(g_1031.f0, "g_1031.f0", print_hash_value);
    transparent_crc(g_1031.f1, "g_1031.f1", print_hash_value);
    transparent_crc(g_1031.f2, "g_1031.f2", print_hash_value);
    transparent_crc(g_1031.f3, "g_1031.f3", print_hash_value);
    transparent_crc(g_1045.f0, "g_1045.f0", print_hash_value);
    transparent_crc(g_1045.f1, "g_1045.f1", print_hash_value);
    transparent_crc(g_1045.f2, "g_1045.f2", print_hash_value);
    transparent_crc(g_1045.f3, "g_1045.f3", print_hash_value);
    transparent_crc(g_1055, "g_1055", print_hash_value);
    transparent_crc(g_1065.f0, "g_1065.f0", print_hash_value);
    transparent_crc(g_1065.f1, "g_1065.f1", print_hash_value);
    transparent_crc(g_1065.f2, "g_1065.f2", print_hash_value);
    transparent_crc(g_1065.f3, "g_1065.f3", print_hash_value);
    transparent_crc(g_1090.f0, "g_1090.f0", print_hash_value);
    transparent_crc(g_1090.f1, "g_1090.f1", print_hash_value);
    transparent_crc(g_1090.f2, "g_1090.f2", print_hash_value);
    transparent_crc(g_1090.f3, "g_1090.f3", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 9; j++)
        {
            transparent_crc(g_1122[i][j].f0, "g_1122[i][j].f0", print_hash_value);
            transparent_crc(g_1122[i][j].f1, "g_1122[i][j].f1", print_hash_value);
            transparent_crc(g_1122[i][j].f2, "g_1122[i][j].f2", print_hash_value);
            transparent_crc(g_1122[i][j].f3, "g_1122[i][j].f3", print_hash_value);
            transparent_crc(g_1122[i][j].f4, "g_1122[i][j].f4", print_hash_value);
            transparent_crc(g_1122[i][j].f5, "g_1122[i][j].f5", print_hash_value);
            transparent_crc(g_1122[i][j].f6, "g_1122[i][j].f6", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1123.f0, "g_1123.f0", print_hash_value);
    transparent_crc(g_1135.f0, "g_1135.f0", print_hash_value);
    transparent_crc(g_1135.f1, "g_1135.f1", print_hash_value);
    transparent_crc(g_1135.f2, "g_1135.f2", print_hash_value);
    transparent_crc(g_1135.f3, "g_1135.f3", print_hash_value);
    transparent_crc(g_1165.f0, "g_1165.f0", print_hash_value);
    transparent_crc(g_1165.f1, "g_1165.f1", print_hash_value);
    transparent_crc(g_1165.f2, "g_1165.f2", print_hash_value);
    transparent_crc(g_1165.f3, "g_1165.f3", print_hash_value);
    transparent_crc(g_1241.f0, "g_1241.f0", print_hash_value);
    transparent_crc(g_1241.f1, "g_1241.f1", print_hash_value);
    transparent_crc(g_1241.f2, "g_1241.f2", print_hash_value);
    transparent_crc(g_1241.f3, "g_1241.f3", print_hash_value);
    transparent_crc(g_1262.f0, "g_1262.f0", print_hash_value);
    transparent_crc(g_1262.f1, "g_1262.f1", print_hash_value);
    transparent_crc(g_1262.f2, "g_1262.f2", print_hash_value);
    transparent_crc(g_1262.f3, "g_1262.f3", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1263[i][j].f0, "g_1263[i][j].f0", print_hash_value);
            transparent_crc(g_1263[i][j].f1, "g_1263[i][j].f1", print_hash_value);
            transparent_crc(g_1263[i][j].f2, "g_1263[i][j].f2", print_hash_value);
            transparent_crc(g_1263[i][j].f3, "g_1263[i][j].f3", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1378.f0, "g_1378.f0", print_hash_value);
    transparent_crc(g_1378.f1, "g_1378.f1", print_hash_value);
    transparent_crc(g_1378.f2, "g_1378.f2", print_hash_value);
    transparent_crc(g_1378.f3, "g_1378.f3", print_hash_value);
    transparent_crc(g_1388, "g_1388", print_hash_value);
    transparent_crc(g_1395.f0, "g_1395.f0", print_hash_value);
    transparent_crc(g_1402.f0, "g_1402.f0", print_hash_value);
    transparent_crc(g_1402.f1, "g_1402.f1", print_hash_value);
    transparent_crc(g_1402.f2, "g_1402.f2", print_hash_value);
    transparent_crc(g_1402.f3, "g_1402.f3", print_hash_value);
    transparent_crc(g_1428, "g_1428", print_hash_value);
    transparent_crc(g_1429, "g_1429", print_hash_value);
    transparent_crc(g_1440.f0, "g_1440.f0", print_hash_value);
    transparent_crc(g_1486.f0, "g_1486.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1487[i].f0, "g_1487[i].f0", print_hash_value);
        transparent_crc(g_1487[i].f1, "g_1487[i].f1", print_hash_value);
        transparent_crc(g_1487[i].f2, "g_1487[i].f2", print_hash_value);
        transparent_crc(g_1487[i].f3, "g_1487[i].f3", print_hash_value);
        transparent_crc(g_1487[i].f4, "g_1487[i].f4", print_hash_value);
        transparent_crc(g_1487[i].f5, "g_1487[i].f5", print_hash_value);
        transparent_crc(g_1487[i].f6, "g_1487[i].f6", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1544.f0, "g_1544.f0", print_hash_value);
    transparent_crc(g_1546.f0, "g_1546.f0", print_hash_value);
    transparent_crc(g_1546.f1, "g_1546.f1", print_hash_value);
    transparent_crc(g_1546.f2, "g_1546.f2", print_hash_value);
    transparent_crc(g_1546.f3, "g_1546.f3", print_hash_value);
    transparent_crc(g_1547, "g_1547", print_hash_value);
    transparent_crc(g_1553.f0, "g_1553.f0", print_hash_value);
    transparent_crc(g_1647.f0, "g_1647.f0", print_hash_value);
    transparent_crc(g_1647.f1, "g_1647.f1", print_hash_value);
    transparent_crc(g_1647.f2, "g_1647.f2", print_hash_value);
    transparent_crc(g_1647.f3, "g_1647.f3", print_hash_value);
    transparent_crc(g_1647.f4, "g_1647.f4", print_hash_value);
    transparent_crc(g_1647.f5, "g_1647.f5", print_hash_value);
    transparent_crc(g_1647.f6, "g_1647.f6", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_1677[i][j], "g_1677[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1692.f0, "g_1692.f0", print_hash_value);
    transparent_crc(g_1696.f0, "g_1696.f0", print_hash_value);
    transparent_crc(g_1696.f1, "g_1696.f1", print_hash_value);
    transparent_crc(g_1696.f2, "g_1696.f2", print_hash_value);
    transparent_crc(g_1696.f3, "g_1696.f3", print_hash_value);
    transparent_crc(g_1696.f4, "g_1696.f4", print_hash_value);
    transparent_crc(g_1696.f5, "g_1696.f5", print_hash_value);
    transparent_crc(g_1696.f6, "g_1696.f6", print_hash_value);
    transparent_crc(g_1699, "g_1699", print_hash_value);
    transparent_crc(g_1706.f0, "g_1706.f0", print_hash_value);
    transparent_crc(g_1706.f1, "g_1706.f1", print_hash_value);
    transparent_crc(g_1706.f2, "g_1706.f2", print_hash_value);
    transparent_crc(g_1706.f3, "g_1706.f3", print_hash_value);
    transparent_crc(g_1707.f0, "g_1707.f0", print_hash_value);
    transparent_crc(g_1707.f1, "g_1707.f1", print_hash_value);
    transparent_crc(g_1707.f2, "g_1707.f2", print_hash_value);
    transparent_crc(g_1707.f3, "g_1707.f3", print_hash_value);
    transparent_crc(g_1708.f0, "g_1708.f0", print_hash_value);
    transparent_crc(g_1708.f1, "g_1708.f1", print_hash_value);
    transparent_crc(g_1708.f2, "g_1708.f2", print_hash_value);
    transparent_crc(g_1708.f3, "g_1708.f3", print_hash_value);
    transparent_crc(g_1709.f0, "g_1709.f0", print_hash_value);
    transparent_crc(g_1709.f1, "g_1709.f1", print_hash_value);
    transparent_crc(g_1709.f2, "g_1709.f2", print_hash_value);
    transparent_crc(g_1709.f3, "g_1709.f3", print_hash_value);
    transparent_crc(g_1710.f0, "g_1710.f0", print_hash_value);
    transparent_crc(g_1710.f1, "g_1710.f1", print_hash_value);
    transparent_crc(g_1710.f2, "g_1710.f2", print_hash_value);
    transparent_crc(g_1710.f3, "g_1710.f3", print_hash_value);
    transparent_crc(g_1716.f0, "g_1716.f0", print_hash_value);
    transparent_crc(g_1835, "g_1835", print_hash_value);
    transparent_crc(g_1842.f0, "g_1842.f0", print_hash_value);
    transparent_crc(g_1873, "g_1873", print_hash_value);
    transparent_crc(g_1880.f0, "g_1880.f0", print_hash_value);
    transparent_crc(g_1889.f0, "g_1889.f0", print_hash_value);
    transparent_crc(g_1946.f0, "g_1946.f0", print_hash_value);
    transparent_crc(g_1946.f1, "g_1946.f1", print_hash_value);
    transparent_crc(g_1946.f2, "g_1946.f2", print_hash_value);
    transparent_crc(g_1946.f3, "g_1946.f3", print_hash_value);
    transparent_crc(g_1946.f4, "g_1946.f4", print_hash_value);
    transparent_crc(g_1946.f5, "g_1946.f5", print_hash_value);
    transparent_crc(g_1946.f6, "g_1946.f6", print_hash_value);
    transparent_crc(g_1953.f0, "g_1953.f0", print_hash_value);
    transparent_crc(g_2010.f0, "g_2010.f0", print_hash_value);
    transparent_crc(g_2010.f1, "g_2010.f1", print_hash_value);
    transparent_crc(g_2010.f2, "g_2010.f2", print_hash_value);
    transparent_crc(g_2010.f3, "g_2010.f3", print_hash_value);
    transparent_crc(g_2084, "g_2084", print_hash_value);
    transparent_crc(g_2135.f0, "g_2135.f0", print_hash_value);
    transparent_crc(g_2157.f0, "g_2157.f0", print_hash_value);
    transparent_crc(g_2157.f1, "g_2157.f1", print_hash_value);
    transparent_crc(g_2157.f2, "g_2157.f2", print_hash_value);
    transparent_crc(g_2157.f3, "g_2157.f3", print_hash_value);
    transparent_crc(g_2157.f4, "g_2157.f4", print_hash_value);
    transparent_crc(g_2157.f5, "g_2157.f5", print_hash_value);
    transparent_crc(g_2157.f6, "g_2157.f6", print_hash_value);
    transparent_crc(g_2161.f0, "g_2161.f0", print_hash_value);
    transparent_crc(g_2162.f0, "g_2162.f0", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 508
   depth: 1, occurrence: 36
XXX total union variables: 30

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 25
breakdown:
   indirect level: 0, occurrence: 13
   indirect level: 1, occurrence: 9
   indirect level: 2, occurrence: 3
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 18
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 18
XXX times a single bitfield on LHS: 7
XXX times a single bitfield on RHS: 11

XXX max expression depth: 46
breakdown:
   depth: 1, occurrence: 210
   depth: 2, occurrence: 54
   depth: 3, occurrence: 4
   depth: 4, occurrence: 4
   depth: 5, occurrence: 3
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 9, occurrence: 1
   depth: 10, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 2
   depth: 17, occurrence: 6
   depth: 18, occurrence: 4
   depth: 19, occurrence: 1
   depth: 20, occurrence: 3
   depth: 22, occurrence: 2
   depth: 23, occurrence: 2
   depth: 25, occurrence: 1
   depth: 26, occurrence: 2
   depth: 27, occurrence: 2
   depth: 28, occurrence: 3
   depth: 29, occurrence: 2
   depth: 33, occurrence: 2
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 46, occurrence: 1

XXX total number of pointers: 462

XXX times a variable address is taken: 1004
XXX times a pointer is dereferenced on RHS: 294
breakdown:
   depth: 1, occurrence: 217
   depth: 2, occurrence: 61
   depth: 3, occurrence: 16
XXX times a pointer is dereferenced on LHS: 287
breakdown:
   depth: 1, occurrence: 263
   depth: 2, occurrence: 21
   depth: 3, occurrence: 3
XXX times a pointer is compared with null: 58
XXX times a pointer is compared with address of another variable: 12
XXX times a pointer is compared with another pointer: 12
XXX times a pointer is qualified to be dereferenced: 5092

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1567
   level: 2, occurrence: 336
   level: 3, occurrence: 132
   level: 4, occurrence: 13
   level: 5, occurrence: 8
XXX number of pointers point to pointers: 209
XXX number of pointers point to scalars: 200
XXX number of pointers point to structs: 37
XXX percent of pointers has null in alias set: 29.2
XXX average alias set size: 1.44

XXX times a non-volatile is read: 1729
XXX times a non-volatile is write: 827
XXX times a volatile is read: 140
XXX    times read thru a pointer: 48
XXX times a volatile is write: 69
XXX    times written thru a pointer: 16
XXX times a volatile is available for access: 3.26e+03
XXX percentage of non-volatile access: 92.4

XXX forward jumps: 0
XXX backward jumps: 5

XXX stmts: 214
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 35
   depth: 1, occurrence: 28
   depth: 2, occurrence: 29
   depth: 3, occurrence: 33
   depth: 4, occurrence: 38
   depth: 5, occurrence: 51

XXX percentage a fresh-made variable is used: 20.5
XXX percentage an existing variable is used: 79.5
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

