/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      1093964884
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   int64_t  f0;
   uint16_t  f1;
   signed f2 : 5;
   int64_t  f3;
   int32_t  f4;
};

union U1 {
   int32_t  f0;
   uint32_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = 0x248C66F5L;
static volatile int8_t g_5 = (-1L);/* VOLATILE GLOBAL g_5 */
static volatile uint64_t g_7 = 0xD7C1188E17B844A7LL;/* VOLATILE GLOBAL g_7 */
static uint16_t g_40[9][3][9] = {{{65535UL,0x319BL,0x10F4L,65531UL,1UL,65534UL,65529UL,65534UL,0x798BL},{0x6D77L,0xEF13L,0x319BL,3UL,65535UL,0x57F5L,0xEDF6L,5UL,65533UL},{0x0079L,1UL,0x718CL,0xA46BL,1UL,65527UL,0x825DL,65529UL,0UL}},{{65535UL,0x2F3AL,0x132DL,0x0953L,0UL,0UL,0x1DD2L,65535UL,0x564DL},{5UL,0UL,1UL,0UL,0xF620L,0x564DL,1UL,0x564DL,0xF620L},{65531UL,1UL,1UL,0x6437L,0xC8A2L,0x988EL,65530UL,65528UL,0x8D27L}},{{0x4B1CL,1UL,5UL,65535UL,0x74D3L,0xFA8FL,1UL,0x825DL,65527UL},{0UL,0xA6AEL,1UL,0UL,0xC8A2L,65528UL,65529UL,0UL,3UL},{1UL,0UL,0x72D5L,65534UL,0xEF13L,0x0079L,0x7268L,0xD749L,1UL}},{{65535UL,0x10F4L,0x7268L,0x4137L,0x0079L,0xC242L,1UL,65531UL,65533UL},{0x0790L,1UL,65535UL,65529UL,0UL,0UL,0x9150L,0UL,0x4B1CL},{3UL,1UL,0x825DL,0UL,2UL,65534UL,0xADF6L,0x0790L,0UL}},{{65527UL,0x8D27L,0UL,65535UL,0x72D5L,3UL,0UL,5UL,0x825DL},{0x564DL,0xC242L,0UL,65531UL,0x132DL,1UL,2UL,0UL,1UL},{0x7268L,0UL,0x825DL,0UL,5UL,1UL,65535UL,65529UL,0x601CL}},{{65535UL,8UL,65535UL,0x798BL,65535UL,0UL,7UL,0xFA8FL,0x7268L},{65529UL,65534UL,0x7268L,1UL,0x74B7L,0x6D77L,0x10F4L,0x284AL,0UL},{0xA46BL,0UL,0x72D5L,0xFBF3L,0UL,0xFBF3L,0x72D5L,0UL,0xA46BL}},{{0xEF13L,0x825DL,1UL,0xADF6L,1UL,0x798BL,1UL,1UL,65528UL},{65533UL,65535UL,5UL,0x0953L,65528UL,0xC01FL,1UL,65534UL,0x3B72L},{0xEF13L,1UL,1UL,0xEDF6L,7UL,65535UL,1UL,0xD975L,65528UL}},{{0xA46BL,0x57F5L,0xADF6L,0x91C8L,0UL,1UL,3UL,0x8D27L,0x0245L},{65529UL,65527UL,65534UL,0xD749L,1UL,65534UL,65527UL,0x06A9L,1UL},{65535UL,0x0079L,65534UL,1UL,4UL,0x1F32L,65528UL,0xDFD9L,0xFA8FL}},{{0x7268L,65535UL,0xD975L,65533UL,0x601CL,0UL,0x2302L,0xFBF3L,65535UL},{0x564DL,0x7C91L,0x4B1CL,0xEBB6L,65535UL,65535UL,65535UL,0xFBF3L,65533UL},{65527UL,0x8CA8L,0x8EB0L,65527UL,0x8CA8L,0xEDF6L,1UL,0UL,65529UL}}};
static uint8_t g_43[1] = {0x8EL};
static union U0 g_57 = {-7L};
static int8_t g_66 = 0xD5L;
static uint64_t g_78 = 18446744073709551615UL;
static volatile union U1 g_97[4][6] = {{{1L},{-7L},{-7L},{1L},{1L},{-7L}},{{1L},{1L},{-7L},{-7L},{1L},{1L}},{{1L},{-7L},{-7L},{1L},{1L},{-7L}},{{1L},{1L},{-7L},{-7L},{1L},{1L}}};
static int64_t g_107 = 1L;
static int16_t g_119 = 0x7928L;
static uint64_t g_139 = 18446744073709551608UL;
static union U0 * volatile g_143 = &g_57;/* VOLATILE GLOBAL g_143 */
static union U0 * volatile * volatile g_142 = &g_143;/* VOLATILE GLOBAL g_142 */
static uint64_t g_160 = 18446744073709551615UL;
static union U1 g_178[1] = {{1L}};
static union U1 *g_182 = &g_178[0];
static union U1 **g_181 = &g_182;
static union U1 ** volatile * volatile g_180[7][1] = {{&g_181},{&g_181},{&g_181},{&g_181},{&g_181},{&g_181},{&g_181}};
static int32_t ** volatile g_183 = (void*)0;/* VOLATILE GLOBAL g_183 */
static int32_t *g_185 = &g_3;
static int32_t ** volatile g_184 = &g_185;/* VOLATILE GLOBAL g_184 */
static int32_t * volatile g_233 = &g_178[0].f0;/* VOLATILE GLOBAL g_233 */
static uint32_t g_236 = 4294967288UL;
static volatile int8_t g_246 = 0x3BL;/* VOLATILE GLOBAL g_246 */
static volatile int8_t g_250 = 0x40L;/* VOLATILE GLOBAL g_250 */
static int32_t g_251 = 0x8D6D82E6L;
static volatile uint64_t g_252 = 1UL;/* VOLATILE GLOBAL g_252 */
static const int32_t *g_273 = (void*)0;
static const int32_t *g_275 = (void*)0;
static uint16_t * const *g_286 = (void*)0;
static const uint8_t g_290[10] = {0x34L,0x34L,0x34L,0x34L,0x34L,0x34L,0x34L,0x34L,0x34L,0x34L};
static const uint8_t g_292 = 0x67L;
static const uint8_t *g_291 = &g_292;
static volatile uint8_t g_309 = 0x38L;/* VOLATILE GLOBAL g_309 */
static volatile uint8_t *g_308[9] = {&g_309,&g_309,&g_309,&g_309,&g_309,&g_309,&g_309,&g_309,&g_309};
static volatile uint8_t **g_307 = &g_308[8];
static volatile uint8_t ***g_306 = &g_307;
static volatile uint8_t **** volatile g_310 = &g_306;/* VOLATILE GLOBAL g_310 */
static volatile int32_t g_321[2][8] = {{(-5L),(-1L),0x267486EBL,0x267486EBL,(-1L),(-5L),(-1L),0x267486EBL},{0L,(-1L),0L,(-5L),(-5L),0L,(-1L),0L}};
static volatile int32_t g_322 = 0x4365AD23L;/* VOLATILE GLOBAL g_322 */
static uint64_t g_323 = 1UL;
static union U0 * const g_347 = &g_57;
static union U0 * const *g_346 = &g_347;
static uint8_t g_407 = 0x6AL;
static uint32_t g_410 = 0x2F73B9A5L;
static int32_t * const  volatile g_411[2] = {(void*)0,(void*)0};
static int32_t * volatile g_412 = (void*)0;/* VOLATILE GLOBAL g_412 */
static int32_t * volatile g_413 = &g_178[0].f0;/* VOLATILE GLOBAL g_413 */
static int32_t * volatile g_429 = &g_3;/* VOLATILE GLOBAL g_429 */
static uint32_t *g_471 = &g_410;
static uint32_t ** volatile g_470 = &g_471;/* VOLATILE GLOBAL g_470 */
static uint32_t ** volatile *g_469 = &g_470;
static uint32_t ** volatile * volatile *g_468 = &g_469;
static uint8_t **g_480 = (void*)0;
static uint16_t *g_486 = &g_40[7][2][3];
static uint16_t **g_485 = &g_486;
static int32_t * volatile g_488 = (void*)0;/* VOLATILE GLOBAL g_488 */
static uint16_t g_548 = 0x8D3FL;
static int16_t g_549 = 0L;
static uint16_t g_550[4] = {4UL,4UL,4UL,4UL};
static uint16_t *** volatile g_587 = (void*)0;/* VOLATILE GLOBAL g_587 */
static uint16_t *** volatile g_589 = &g_485;/* VOLATILE GLOBAL g_589 */
static int32_t ** volatile g_591 = &g_185;/* VOLATILE GLOBAL g_591 */
static int32_t ** volatile g_598 = &g_185;/* VOLATILE GLOBAL g_598 */
static union U0 ***g_647 = (void*)0;
static union U0 **** volatile g_646 = &g_647;/* VOLATILE GLOBAL g_646 */
static int8_t g_657[2] = {0x21L,0x21L};
static uint8_t g_680 = 246UL;
static int8_t g_737 = 0x92L;
static const int32_t g_761 = 1L;
static const int32_t *g_760 = &g_761;
static uint16_t g_811 = 1UL;
static int32_t * volatile g_814 = &g_178[0].f0;/* VOLATILE GLOBAL g_814 */
static uint8_t g_872 = 0UL;
static int32_t g_873[1][7][5] = {{{(-6L),(-6L),0xE70A520AL,(-4L),0xE70A520AL},{(-6L),(-6L),0xE70A520AL,(-4L),0xE70A520AL},{(-6L),(-6L),0xE70A520AL,(-4L),0xE70A520AL},{(-6L),(-6L),0xE70A520AL,(-4L),0xE70A520AL},{(-6L),(-6L),0xE70A520AL,(-4L),0xE70A520AL},{(-6L),(-6L),0xE70A520AL,(-4L),0xE70A520AL},{(-6L),(-6L),0xE70A520AL,(-4L),0xE70A520AL}}};
static uint32_t **g_898 = &g_471;
static uint32_t ***g_897 = &g_898;


/* --- FORWARD DECLARATIONS --- */
static union U0  func_1(void);
static int32_t  func_10(int32_t  p_11, int64_t  p_12);
static uint8_t  func_13(uint8_t  p_14);
static int32_t * func_21(const int32_t  p_22, int32_t * p_23, int32_t * p_24);
static const int32_t  func_25(uint32_t  p_26, uint8_t  p_27, uint32_t  p_28);
static uint32_t  func_29(const uint8_t  p_30, uint32_t  p_31, uint16_t  p_32);
static int32_t  func_33(const int8_t  p_34, uint16_t  p_35, int32_t * p_36, int32_t * p_37);
static uint16_t ** func_44(uint16_t * p_45, uint32_t  p_46, uint16_t ** const  p_47, uint16_t ** p_48);
static uint32_t  func_50(uint8_t  p_51, uint16_t * p_52);
static uint8_t  func_58(uint16_t  p_59, uint8_t * const  p_60, uint8_t * p_61, uint64_t  p_62);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_7 g_3 g_43 g_471 g_251 g_291 g_292 g_290 g_139 g_407 g_657 g_410 g_468 g_469 g_470 g_160 g_185 g_589 g_485 g_486 g_40 g_550 g_548 g_184 g_591 g_598 g_57.f0 g_429 g_107 g_142 g_143 g_57 g_322 g_236 g_246 g_737 g_178.f0 g_323 g_250 g_119 g_811 g_814 g_413 g_321 g_549 g_306 g_307 g_308 g_309 g_761 g_181 g_872 g_873 g_233 g_897 g_680 g_347
 * writes: g_7 g_40 g_3 g_43 g_410 g_66 g_657 g_549 g_680 g_236 g_548 g_185 g_57.f1 g_321 g_107 g_486 g_57.f4 g_760 g_178.f0 g_57.f0 g_119 g_182 g_407 g_897 g_811
 */
static union U0  func_1(void)
{ /* block id: 0 */
    int32_t *l_2 = &g_3;
    int32_t *l_4 = (void*)0;
    int32_t *l_6[7][3] = {{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3}};
    int8_t *l_656[1];
    int32_t l_658 = (-1L);
    int8_t l_659 = 0x5AL;
    int32_t **l_702 = &l_2;
    uint32_t l_703 = 0x13B15E57L;
    int32_t l_704 = (-5L);
    uint16_t l_782 = 1UL;
    uint16_t l_783 = 0xC44CL;
    union U0 l_847 = {-1L};
    uint32_t l_889 = 0x56CF7C15L;
    int i, j;
    for (i = 0; i < 1; i++)
        l_656[i] = &g_657[0];
    g_7--;
    if (func_10(((((func_13((safe_div_func_uint32_t_u_u(((g_657[0] = (safe_sub_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s((((*l_702) = func_21(func_25(((*g_471) = func_29(g_7, g_3, g_3)), (safe_lshift_func_uint64_t_u_u((safe_rshift_func_int32_t_s_s((safe_lshift_func_int16_t_s_s(g_251, (safe_add_func_int8_t_s_s((g_657[1] ^= (g_66 = ((*g_291) ^ (((g_290[0] , g_139) & (*g_291)) == g_407)))), (*g_291))))), l_658)), 33)), l_659), g_185, l_4)) != l_4), 11)), l_703))) != l_704), g_57.f0))) , (*g_471)) <= 5UL) >= g_290[0]) == l_782), l_783))
    { /* block id: 349 */
        return (*g_143);
    }
    else
    { /* block id: 351 */
        union U1 **l_834 = (void*)0;
        int32_t l_843 = 2L;
        union U1 l_868 = {3L};
        int32_t l_874 = (-8L);
        (*g_185) = (*g_413);
        for (l_704 = 0; (l_704 == (-28)); l_704 = safe_sub_func_uint32_t_u_u(l_704, 1))
        { /* block id: 355 */
            uint32_t l_823 = 0x47099114L;
            int32_t *l_838[7];
            union U1 *l_844 = &g_178[0];
            int i;
            for (i = 0; i < 7; i++)
                l_838[i] = &l_704;
            for (g_57.f0 = 0; (g_57.f0 != (-7)); g_57.f0--)
            { /* block id: 358 */
                int16_t *l_835 = &g_119;
                int32_t l_836 = 0x182D0FFEL;
                (*l_2) ^= ((safe_mul_func_int8_t_s_s(((safe_lshift_func_int8_t_s_u((0L || ((**g_470) && 4294967295UL)), ((l_823 , &g_182) != &g_182))) ^ 65529UL), (safe_lshift_func_int16_t_s_s(((*l_835) = (safe_div_func_uint32_t_u_u((safe_sub_func_uint8_t_u_u((((safe_mul_func_int64_t_s_s((l_823 < ((safe_mod_func_int64_t_s_s((((*g_291) >= l_823) , l_823), (-4L))) | (*g_471))), 0x343A1702E8E05BA5LL)) , l_834) == (void*)0), 0L)), 0x2BC42A49L))), 5)))) & l_836);
                l_843 = ((-10L) >= ((((+((((g_321[1][3] , (((249UL & ((l_836 ^ 0xACE81BDBL) < ((g_549 |= 0x74D8L) > (l_838[1] == ((*l_702) = func_21((safe_mod_func_uint64_t_u_u(((safe_lshift_func_int16_t_s_s((((((0xA5A37D5000E07E42LL < (&g_180[5][0] != (void*)0)) , (**l_702)) & l_836) <= (***g_306)) <= g_290[4]), 3)) < g_43[0]), g_761)), &g_3, &l_836)))))) < g_761) , (**g_307))) == (*g_291)) , l_843) & l_836)) <= 0x050B61B1L) > 0L) , 0L));
                (*g_181) = l_844;
            }
            for (l_783 = (-5); (l_783 < 54); l_783 = safe_add_func_uint64_t_u_u(l_783, 7))
            { /* block id: 368 */
                return l_847;
            }
        }
        (*g_814) = ((safe_mul_func_int32_t_s_s(((*g_185) |= 0x29014378L), (***g_469))) & (((safe_sub_func_int16_t_s_s(((safe_sub_func_uint16_t_u_u(((g_407 &= (safe_unary_minus_func_uint32_t_u((safe_add_func_int32_t_s_s((safe_div_func_int32_t_s_s(0x7424F416L, (safe_div_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(((((!l_843) | ((safe_div_func_uint32_t_u_u((((safe_lshift_func_uint32_t_u_s((l_868 , ((safe_mul_func_int8_t_s_s((((0x13886D1EL == ((!l_868.f0) == l_843)) & (l_843 & (*g_291))) == 0x9E78L), (-1L))) & l_868.f0)), 23)) , g_872) , 0x76E72991L), 3UL)) <= g_290[0])) >= 0xD8214CADEA211369LL) ^ l_843), l_868.f0)), 7UL)))), 0x200661BCL))))) ^ l_868.f0), g_40[6][1][5])) && g_873[0][3][3]), l_843)) | 4L) | l_874));
    }
    for (g_548 = 0; (g_548 == 34); g_548 = safe_add_func_uint8_t_u_u(g_548, 5))
    { /* block id: 378 */
        int16_t *l_879 = &g_549;
        uint8_t *l_880 = (void*)0;
        uint8_t *l_881[7][8] = {{&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_680,&g_407,&g_680,&g_43[0]},{&g_43[0],&g_43[0],&g_43[0],&g_407,&g_43[0],&g_407,&g_680,&g_407},{(void*)0,&g_407,&g_43[0],&g_407,(void*)0,&g_407,&g_43[0],&g_43[0]},{(void*)0,&g_407,&g_43[0],&g_43[0],&g_43[0],&g_407,(void*)0,&g_407},{&g_43[0],&g_407,&g_43[0],&g_407,&g_680,&g_407,&g_43[0],&g_407},{&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_680,&g_407,&g_680,&g_43[0]},{&g_43[0],&g_43[0],&g_43[0],&g_407,&g_43[0],&g_43[0],(void*)0,&g_43[0]}};
        int32_t l_888 = (-8L);
        const uint32_t * const * const *l_896 = (void*)0;
        uint32_t ****l_899 = &g_897;
        int32_t l_910 = 0x9BD63E0DL;
        uint16_t *l_912 = &g_811;
        int16_t *l_913[9] = {&g_119,&g_119,&g_119,&g_119,&g_119,&g_119,&g_119,&g_119,&g_119};
        int i, j;
        l_889 &= (l_888 = ((***g_469) && ((safe_rshift_func_int32_t_s_u((*g_233), 26)) , ((g_43[0] ^= ((void*)0 != l_879)) || ((**l_702) = (safe_lshift_func_uint64_t_u_s(g_246, ((safe_rshift_func_int64_t_s_s(2L, (l_888 && (18446744073709551608UL <= (1L || g_657[0]))))) < l_888))))))));
        g_178[0].f0 ^= (((safe_mod_func_int8_t_s_s(g_550[1], (g_407 |= ((safe_mod_func_uint16_t_u_u((*l_2), (safe_sub_func_uint8_t_u_u((((l_896 == ((*l_899) = g_897)) <= ((g_119 = ((*l_879) = (((safe_sub_func_uint16_t_u_u((g_680 <= 18446744073709551607UL), (safe_rshift_func_uint64_t_u_s(((safe_div_func_uint16_t_u_u(((*l_912) = ((safe_div_func_int16_t_s_s((safe_div_func_int16_t_s_s((l_910 , (g_246 || (!l_888))), (-9L))), g_761)) , l_888)), l_888)) && 1L), 5)))) & 0x0D94L) , 1L))) | (-2L))) , (**l_702)), g_290[1])))) , 9UL)))) , l_910) > 0xCC52AD2CL);
    }
    return (*g_347);
}


/* ------------------------------------------ */
/* 
 * reads : g_470 g_471 g_410 g_548 g_185 g_43 g_811 g_814
 * writes: g_3 g_178.f0
 */
static int32_t  func_10(int32_t  p_11, int64_t  p_12)
{ /* block id: 341 */
    int32_t l_802 = 0x47DA8BA4L;
    int16_t * const l_803 = &g_119;
    int16_t *l_804 = &g_119;
    uint32_t ** const l_805 = &g_471;
    const uint32_t *l_807 = (void*)0;
    const uint32_t **l_806 = &l_807;
    const uint32_t ***l_808 = &l_806;
    uint16_t *l_809[3];
    uint8_t l_810 = 0x95L;
    int32_t l_812 = 0xD077CC9BL;
    uint64_t *l_813 = &g_139;
    int i;
    for (i = 0; i < 3; i++)
        l_809[i] = &g_57.f1;
    (*g_814) = (safe_rshift_func_int32_t_s_s(((-1L) < (((safe_add_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u((((safe_sub_func_uint32_t_u_u(5UL, (**g_470))) , (safe_mod_func_int8_t_s_s((g_548 == (safe_sub_func_int8_t_s_s((safe_mul_func_int16_t_s_s(((l_810 = (safe_sub_func_int32_t_s_s((l_802 = ((*g_185) = p_12)), (((((l_803 != (l_804 = l_804)) <= (l_805 == ((*l_808) = l_806))) & p_12) | p_12) | 0x3CL)))) && g_43[0]), 0xFFACL)), 6UL))), p_11))) && g_811), l_812)), p_11)) , l_813) != &g_78)), 16));
    return l_802;
}


/* ------------------------------------------ */
/* 
 * reads : g_429 g_3 g_142 g_143 g_290 g_184 g_185 g_591 g_598 g_40 g_550 g_485 g_57 g_322 g_236 g_291 g_292 g_657 g_246 g_737 g_178.f0 g_323 g_250 g_471 g_43 g_119 g_107
 * writes: g_7 g_57.f1 g_321 g_107 g_548 g_185 g_549 g_3 g_486 g_57.f4 g_66 g_760 g_410 g_680
 */
static uint8_t  func_13(uint8_t  p_14)
{ /* block id: 307 */
    union U0 * volatile l_708 = &g_57;/* VOLATILE GLOBAL l_708 */
    int32_t *l_710 = &g_178[0].f0;
    const int32_t l_722[9][4][6] = {{{0x4A4A676DL,1L,0x6DC2CA32L,4L,0x6DC2CA32L,1L},{0x13244E09L,8L,0x6DC2CA32L,(-9L),0x9DB619A4L,0x8A184C39L},{0x98779B49L,(-1L),1L,1L,(-1L),(-1L)},{1L,(-1L),(-1L),0xACBC8474L,0x9DB619A4L,0x6DC2CA32L}},{{0xBEC77299L,8L,8L,0x4A4A676DL,0x6DC2CA32L,(-1L)},{0xBEC77299L,1L,8L,0xACBC8474L,0L,0L},{1L,0x9DB619A4L,0x9DB619A4L,1L,8L,0L},{0x98779B49L,0L,8L,(-9L),3L,(-1L)}},{{0x13244E09L,1L,8L,4L,3L,0x6DC2CA32L},{0x4A4A676DL,0L,(-1L),0x13244E09L,8L,(-1L)},{(-10L),0x9DB619A4L,1L,0x13244E09L,0L,0x8A184C39L},{0x4A4A676DL,1L,0x6DC2CA32L,4L,0x6DC2CA32L,1L}},{{0x13244E09L,8L,0x6DC2CA32L,(-9L),0x9DB619A4L,0x8A184C39L},{0x98779B49L,(-1L),1L,1L,(-1L),(-1L)},{1L,(-1L),(-1L),0xACBC8474L,0x9DB619A4L,0x6DC2CA32L},{0xBEC77299L,8L,8L,0x4A4A676DL,0x6DC2CA32L,(-1L)}},{{0xBEC77299L,1L,8L,0xACBC8474L,0L,0L},{1L,0x9DB619A4L,0x9DB619A4L,1L,8L,0L},{0x98779B49L,0L,8L,(-9L),3L,(-1L)},{0x13244E09L,1L,8L,4L,3L,0x6DC2CA32L}},{{0x4A4A676DL,0L,(-1L),0x13244E09L,8L,(-1L)},{(-10L),0x9DB619A4L,1L,0x13244E09L,0L,0x8A184C39L},{0x4A4A676DL,1L,0x6DC2CA32L,4L,0x6DC2CA32L,1L},{0x13244E09L,8L,0x6DC2CA32L,(-9L),0x9DB619A4L,0x8A184C39L}},{{0x98779B49L,(-1L),1L,1L,(-1L),(-1L)},{1L,(-1L),(-1L),0xACBC8474L,0x9DB619A4L,0x6DC2CA32L},{0xBEC77299L,8L,8L,0x4A4A676DL,0x6DC2CA32L,(-1L)},{0xBEC77299L,1L,8L,0xACBC8474L,0L,0L}},{{1L,0x9DB619A4L,0x9DB619A4L,1L,8L,0L},{0x98779B49L,0L,8L,(-9L),1L,8L},{(-1L),0x293A5183L,0x0CEB9DACL,8L,1L,0xFDDBEB87L},{1L,0x6357C6F3L,0xDB8DD2E7L,(-1L),0x0CEB9DACL,0xDB8DD2E7L}},{{0x8A184C39L,(-1L),6L,(-1L),0x6357C6F3L,(-8L)},{1L,6L,0xFDDBEB87L,8L,0xFDDBEB87L,6L},{(-1L),(-1L),0xFDDBEB87L,1L,(-1L),(-8L)},{8L,8L,6L,0x9DB619A4L,8L,0xDB8DD2E7L}}};
    int8_t *l_767 = (void*)0;
    int32_t **l_781 = &l_710;
    int i, j, k;
    if ((*g_429))
    { /* block id: 308 */
        int32_t *l_709 = &g_3;
        int16_t *l_716[3];
        int32_t *l_717 = &g_57.f4;
        int8_t *l_721 = &g_66;
        int32_t l_723 = 1L;
        union U0 ****l_734 = (void*)0;
        union U0 *l_754[5][4] = {{(void*)0,&g_57,&g_57,(void*)0},{&g_57,(void*)0,&g_57,&g_57},{(void*)0,(void*)0,&g_57,(void*)0},{(void*)0,&g_57,&g_57,(void*)0},{&g_57,(void*)0,&g_57,&g_57}};
        union U0 **l_753 = &l_754[3][1];
        int i, j;
        for (i = 0; i < 3; i++)
            l_716[i] = (void*)0;
lbl_707:
        for (g_7 = 0; g_7 < 2; g_7 += 1)
        {
            for (g_57.f1 = 0; g_57.f1 < 8; g_57.f1 += 1)
            {
                g_321[g_7][g_57.f1] = 0x2AB1EB5EL;
            }
        }
        for (g_107 = 0; (g_107 >= 23); g_107 = safe_add_func_uint8_t_u_u(g_107, 7))
        { /* block id: 312 */
            int32_t **l_711 = &l_710;
            if (g_3)
                goto lbl_707;
            l_708 = (*g_142);
            (*l_711) = func_21(g_290[7], l_709, l_710);
        }
        if ((((safe_mod_func_int64_t_s_s((safe_div_func_int8_t_s_s((((((((*l_709) = (g_549 = g_40[7][2][3])) | (g_550[1] == (((((*g_485) = l_716[1]) != l_716[2]) > (((*l_717) = (-1L)) , (safe_lshift_func_int32_t_s_s(((((*l_708) , (~((*l_721) = g_322))) , 0xBB41A095L) & ((-1L) > p_14)), 23)))) , g_236))) < (*g_291)) < 0L) & p_14) , 0xBBL), l_722[8][2][2])), 18446744073709551615UL)) ^ 0UL) | l_723))
        { /* block id: 322 */
            int64_t l_733 = 0xD7E88F6F11E19DC1LL;
            int32_t l_735 = 0xA463B8A5L;
            const int8_t * const l_736[8][6] = {{&g_66,&g_657[0],&g_66,&g_657[0],&g_66,&g_657[0]},{&g_657[0],&g_657[0],&g_657[0],&g_657[1],&g_66,&g_657[0]},{&g_657[0],(void*)0,&g_66,&g_657[0],&g_657[0],&g_657[0]},{&g_657[0],&g_657[1],&g_657[0],&g_657[0],&g_657[1],&g_657[0]},{&g_657[0],&g_66,&g_66,&g_66,&g_657[0],&g_657[1]},{&g_66,&g_66,&g_657[0],&g_657[0],&g_66,(void*)0},{&g_66,&g_657[1],&g_657[0],&g_66,&g_657[0],&g_657[1]},{&g_657[0],&g_657[0],&g_657[0],&g_657[0],&g_657[1],&g_66}};
            int i, j;
            l_735 = (safe_mul_func_int32_t_s_s(((((((*l_721) = (!(((((safe_mod_func_uint64_t_u_u((safe_mul_func_uint8_t_u_u(((g_549 = (safe_rshift_func_int16_t_s_s((g_657[0] & ((((((l_733 = (0xF470L && p_14)) , ((*g_185) ^= 1L)) , (l_734 == (((1L && g_246) < 1L) , &g_647))) != l_735) , l_736[7][1]) != (void*)0)), 0))) <= p_14), p_14)), 0x9086FAC8AF56D238LL)) >= p_14) | l_735) || 0xC558C8EDBC97B9E7LL) & g_737))) , l_733) <= 0x3DL) & 6UL) , (-3L)), g_178[0].f0));
        }
        else
        { /* block id: 328 */
            int32_t l_750 = 0L;
            int32_t *l_755 = &l_723;
            (*l_755) &= ((safe_add_func_uint32_t_u_u(p_14, ((safe_mod_func_uint16_t_u_u(((safe_add_func_int32_t_s_s((safe_mul_func_uint8_t_u_u(0x22L, (((*l_721) = p_14) < (safe_mod_func_int64_t_s_s(0xA22992F8204EE31ELL, (safe_add_func_int8_t_s_s((18446744073709551610UL || 0xAD7D2B312B0FA6DCLL), l_750))))))), ((safe_rshift_func_uint8_t_u_s((l_753 == (void*)0), 0)) && 1UL))) >= g_323), g_250)) , (*l_710)))) && 1L);
        }
    }
    else
    { /* block id: 332 */
        const int32_t *l_758 = &g_251;
        const int32_t **l_759[1][2];
        int32_t l_775 = 9L;
        uint8_t *l_778 = (void*)0;
        uint8_t *l_779[2][9] = {{(void*)0,(void*)0,&g_680,(void*)0,(void*)0,&g_680,(void*)0,(void*)0,&g_680},{(void*)0,(void*)0,&g_43[0],(void*)0,(void*)0,&g_43[0],(void*)0,(void*)0,&g_43[0]}};
        int32_t **l_780 = (void*)0;
        int i, j;
        for (i = 0; i < 1; i++)
        {
            for (j = 0; j < 2; j++)
                l_759[i][j] = &l_758;
        }
        (*g_185) |= (*l_710);
        (*g_591) = func_21(((safe_mod_func_uint64_t_u_u(((g_760 = l_758) != &g_251), ((safe_unary_minus_func_int64_t_s(((g_680 = (p_14 != (safe_sub_func_uint64_t_u_u((((safe_add_func_int64_t_s_s((l_767 != (void*)0), (safe_lshift_func_uint64_t_u_s((((!((safe_lshift_func_uint64_t_u_s((g_322 | (safe_div_func_uint16_t_u_u(((l_775 && ((*g_471) = (safe_sub_func_int8_t_s_s(p_14, (g_290[7] , 0x20L))))) || g_43[0]), l_775))), 8)) || l_775)) , 0x8491L) == l_775), g_119)))) <= 0xDD959B290ACB52B7LL) <= (*l_710)), (-9L))))) & p_14))) , 0xEE64D32BBDD19668LL))) , 0xEE551B63L), &g_3, l_710);
    }
    (*l_781) = (void*)0;
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_548 g_184 g_185 g_3 g_591 g_598
 * writes: g_548 g_185
 */
static int32_t * func_21(const int32_t  p_22, int32_t * p_23, int32_t * p_24)
{ /* block id: 297 */
    int32_t **l_701[3][6] = {{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185},{&g_185,&g_185,&g_185,&g_185,&g_185,&g_185}};
    int i, j;
    for (g_548 = 0; (g_548 != 43); g_548 = safe_add_func_uint8_t_u_u(g_548, 1))
    { /* block id: 300 */
        if ((**g_184))
            break;
    }
    (*g_598) = (*g_591);
    return (*g_184);
}


/* ------------------------------------------ */
/* 
 * reads : g_410 g_468 g_469 g_470 g_471 g_160 g_43 g_185 g_589 g_485 g_486 g_40 g_550
 * writes: g_410 g_549 g_680 g_236 g_3
 */
static const int32_t  func_25(uint32_t  p_26, uint8_t  p_27, uint32_t  p_28)
{ /* block id: 282 */
    union U0 l_663[3] = {{-1L},{-1L},{-1L}};
    union U0 **l_671 = (void*)0;
    union U0 *** const l_670 = &l_671;
    int16_t *l_677[1];
    int8_t *l_678 = (void*)0;
    int8_t *l_679[3][9] = {{(void*)0,&g_66,&g_66,(void*)0,&g_66,&g_66,&g_66,(void*)0,&g_66},{&g_66,&g_66,&g_657[1],&g_66,&g_657[1],&g_66,&g_657[1],&g_66,&g_66},{&g_66,(void*)0,&g_66,&g_66,&g_66,(void*)0,&g_66,&g_66,(void*)0}};
    uint32_t *l_681 = (void*)0;
    uint32_t *l_682 = (void*)0;
    uint32_t *l_683 = (void*)0;
    uint32_t *l_684 = &g_236;
    union U1 **l_695 = &g_182;
    union U1 ***l_696 = &l_695;
    uint32_t l_697 = 0xFC9F3712L;
    int32_t l_698 = 0x055626E7L;
    int i, j;
    for (i = 0; i < 1; i++)
        l_677[i] = &g_549;
    for (g_410 = 0; (g_410 != 29); g_410++)
    { /* block id: 285 */
        const uint32_t l_662 = 0x03FB6DB4L;
        return l_662;
    }
    (*g_185) = (l_663[0] , ((p_26 == ((*l_684) = ((g_680 = ((safe_lshift_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s(((((((safe_div_func_int64_t_s_s((0xC0800749L != ((void*)0 != l_670)), (~((((p_28 < ((****g_468) &= p_27)) && ((safe_mod_func_uint32_t_u_u((safe_rshift_func_int16_t_s_u((p_28 , (g_549 = g_160)), p_26)), 0xEC7EE54CL)) , 1UL)) && p_27) != 0xFA70L)))) & l_663[0].f0) == (-1L)) > p_28) | 0x779CL) , 5UL), g_160)), g_43[0])) < p_28)) | p_28))) && p_27));
    l_663[0].f2 = ((2L && (((((p_26 , ((+((p_28 || (l_698 ^= ((safe_lshift_func_uint64_t_u_s((((((((((0xBC5648F1L != (safe_rshift_func_uint32_t_u_s((((***g_589) && (safe_mul_func_uint32_t_u_u((+(p_27 , ((safe_lshift_func_uint16_t_u_u((g_550[3] == ((((*l_696) = l_695) == (void*)0) && (-3L))), 13)) == 0xF69EL))), l_663[0].f0))) ^ l_663[0].f0), 8))) != l_697) < (*g_471)) == p_26) > l_663[0].f0) , (***g_589)) && p_28) > 0x8456L) != 1UL), 39)) , l_663[0].f0))) < 1UL)) | (-1L))) , 0x3349A2C68EF3284ELL) <= p_27) & (-1L)) | l_663[0].f0)) == p_28);
    return l_697;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_43
 * writes: g_40 g_3 g_43
 */
static uint32_t  func_29(const uint8_t  p_30, uint32_t  p_31, uint16_t  p_32)
{ /* block id: 2 */
    int32_t l_38 = 0x66EF3B06L;
    uint16_t *l_39 = &g_40[7][2][3];
    int32_t *l_41[3][2] = {{&g_3,&g_3},{&g_3,&g_3},{&g_3,&g_3}};
    int32_t l_49 = 0x5104F36CL;
    uint8_t *l_53[8][3][10] = {{{&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],(void*)0},{&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0]},{&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0]}},{{(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0]},{&g_43[0],&g_43[0],&g_43[0],(void*)0,(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0]},{&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0]}},{{&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0]},{&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],(void*)0,(void*)0,&g_43[0]},{&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0]}},{{&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],(void*)0,&g_43[0]},{(void*)0,&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0]},{&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0]}},{{&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0]},{&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0]},{&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0]}},{{&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],(void*)0,&g_43[0]},{(void*)0,&g_43[0],(void*)0,&g_43[0],(void*)0,&g_43[0],(void*)0,(void*)0,&g_43[0],(void*)0},{&g_43[0],(void*)0,(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0]}},{{(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0]},{(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0]},{&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0}},{{&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0]},{&g_43[0],&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0]},{&g_43[0],(void*)0,&g_43[0],&g_43[0],&g_43[0],&g_43[0],(void*)0,&g_43[0],&g_43[0],(void*)0}}};
    uint16_t ***l_588 = (void*)0;
    const uint32_t l_590 = 4294967295UL;
    int32_t l_619 = 0xACB71096L;
    union U0 *l_645[7];
    union U0 **l_644[8][9] = {{&l_645[4],&l_645[1],(void*)0,&l_645[1],&l_645[4],&l_645[4],&l_645[1],&l_645[4],&l_645[4]},{&l_645[1],&l_645[0],(void*)0,&l_645[4],&l_645[0],&l_645[4],&l_645[0],&l_645[4],(void*)0},{&l_645[4],&l_645[4],&l_645[4],&l_645[4],&l_645[1],&l_645[4],&l_645[4],&l_645[1],(void*)0},{&l_645[5],&l_645[0],&l_645[4],&l_645[1],&l_645[1],&l_645[4],&l_645[0],&l_645[5],&l_645[4]},{&l_645[5],&l_645[1],&l_645[4],&l_645[5],&l_645[0],&l_645[4],&l_645[1],&l_645[1],&l_645[4]},{&l_645[4],&l_645[1],(void*)0,&l_645[1],&l_645[4],&l_645[4],&l_645[1],&l_645[4],&l_645[4]},{&l_645[1],&l_645[0],(void*)0,&l_645[4],&l_645[0],&l_645[4],&l_645[0],&l_645[4],(void*)0},{&l_645[4],&l_645[4],&l_645[4],&l_645[4],&l_645[1],&l_645[4],&l_645[4],&l_645[1],(void*)0}};
    union U0 ***l_643 = &l_644[7][3];
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_645[i] = &g_57;
    g_43[0] ^= func_33(p_30, ((*l_39) = l_38), l_41[2][1], &g_3);
    return p_30;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes: g_3
 */
static int32_t  func_33(const int8_t  p_34, uint16_t  p_35, int32_t * p_36, int32_t * p_37)
{ /* block id: 4 */
    const int32_t l_42 = 1L;
    (*p_37) = l_42;
    return (*p_37);
}


/* ------------------------------------------ */
/* 
 * reads : g_107 g_40 g_3 g_43 g_142 g_143 g_57 g_486
 * writes: g_107 g_3 g_139
 */
static uint16_t ** func_44(uint16_t * p_45, uint32_t  p_46, uint16_t ** const  p_47, uint16_t ** p_48)
{ /* block id: 228 */
    int32_t *l_573 = &g_3;
    int64_t *l_583 = &g_107;
    uint64_t *l_584 = &g_139;
    int32_t l_585 = (-10L);
    uint16_t **l_586[5][8][2] = {{{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486}},{{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486}},{{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486}},{{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486}},{{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486},{&g_486,&g_486}}};
    int i, j, k;
    for (g_107 = 9; (g_107 <= (-29)); g_107--)
    { /* block id: 231 */
        return &g_486;
    }
    (*l_573) &= ((**p_48) , 0xCCA1DE5EL);
    l_585 = (safe_mul_func_int16_t_s_s((safe_lshift_func_int64_t_s_s((~(safe_add_func_uint8_t_u_u(((safe_add_func_uint32_t_u_u(0UL, 0xF063EF62L)) & ((*l_573) = ((*l_573) >= (*l_573)))), (p_46 || (-1L))))), (g_43[0] != ((*l_584) = (((**g_142) , l_583) == l_583))))), (*g_486)));
    return l_586[0][1][0];
}


/* ------------------------------------------ */
/* 
 * reads : g_66 g_57 g_40 g_7 g_57.f0 g_3 g_43 g_97 g_97.f0 g_119 g_78 g_139 g_142 g_160 g_143 g_178 g_180 g_184 g_181 g_182 g_185 g_233 g_236 g_252 g_178.f0 g_286 g_291 g_292 g_306 g_310 g_251 g_323 g_290 g_346 g_321 g_309 g_410 g_413 g_107 g_407 g_429 g_57.f3 g_5 g_347 g_468 g_307 g_485 g_486 g_471 g_308 g_548 g_469 g_470
 * writes: g_78 g_3 g_107 g_119 g_139 g_43 g_160 g_66 g_185 g_40 g_178.f0 g_236 g_252 g_273 g_275 g_286 g_291 g_306 g_251 g_323 g_182 g_346 g_57.f3 g_407 g_410 g_480 g_485 g_548 g_549 g_550 g_181
 */
static uint32_t  func_50(uint8_t  p_51, uint16_t * p_52)
{ /* block id: 9 */
    const union U0 **l_54 = (void*)0;
    union U0 *l_56 = &g_57;
    union U0 **l_55 = &l_56;
    int8_t *l_65[8][1][8] = {{{&g_66,(void*)0,&g_66,&g_66,&g_66,&g_66,&g_66,&g_66}},{{(void*)0,&g_66,&g_66,&g_66,&g_66,&g_66,&g_66,&g_66}},{{(void*)0,(void*)0,&g_66,(void*)0,&g_66,(void*)0,(void*)0,&g_66}},{{&g_66,&g_66,&g_66,&g_66,&g_66,&g_66,&g_66,&g_66}},{{&g_66,&g_66,&g_66,(void*)0,&g_66,&g_66,&g_66,&g_66}},{{&g_66,&g_66,&g_66,&g_66,&g_66,&g_66,&g_66,&g_66}},{{&g_66,&g_66,&g_66,&g_66,(void*)0,&g_66,&g_66,(void*)0}},{{(void*)0,&g_66,&g_66,(void*)0,&g_66,&g_66,(void*)0,&g_66}}};
    int32_t l_67 = 1L;
    int32_t l_72 = 0L;
    uint64_t *l_77 = &g_78;
    int8_t l_448 = 0x95L;
    int32_t **l_449 = &g_185;
    uint32_t **l_453 = (void*)0;
    uint32_t ***l_452 = &l_453;
    int64_t *l_457[1][6];
    int64_t l_458[7][3][2] = {{{0xA859B20CB32DE50FLL,0x84C57A7CA7F859E7LL},{1L,0xCB66975232A7D651LL},{1L,0x84C57A7CA7F859E7LL}},{{0xA859B20CB32DE50FLL,0xC62E95EEE8872C66LL},{0x84C57A7CA7F859E7LL,0L},{(-6L),0L}},{{5L,0x25CABFE9561FEEB7LL},{0x25CABFE9561FEEB7LL,(-4L)},{0xA681FD754C5A717ALL,5L}},{{0xCB66975232A7D651LL,0x88A3AD5CFDD42086LL},{0L,0x88A3AD5CFDD42086LL},{0xCB66975232A7D651LL,5L}},{{0xA681FD754C5A717ALL,(-4L)},{0x25CABFE9561FEEB7LL,0x25CABFE9561FEEB7LL},{5L,0L}},{{(-6L),0L},{0x84C57A7CA7F859E7LL,0xC62E95EEE8872C66LL},{0xA859B20CB32DE50FLL,0x84C57A7CA7F859E7LL}},{{1L,0xCB66975232A7D651LL},{1L,0x84C57A7CA7F859E7LL},{0xA859B20CB32DE50FLL,0xC62E95EEE8872C66LL}}};
    uint64_t l_462[5] = {1UL,1UL,1UL,1UL,1UL};
    union U1 l_507 = {0x0ED7406FL};
    int32_t l_516 = 0x266EE760L;
    const uint8_t **l_518[6];
    const uint8_t ***l_517 = &l_518[2];
    int8_t l_551[5];
    union U1 *l_553[8];
    int32_t l_555 = 0x4AB0EB29L;
    int32_t l_556 = 0x0FB11AE6L;
    int8_t l_557 = 0x03L;
    int32_t l_558 = 0x724CF205L;
    int32_t l_559 = 6L;
    int32_t l_560 = 1L;
    int32_t l_561 = 0xA37083E0L;
    int64_t l_562 = 0L;
    int32_t l_563 = 0xC6697DB4L;
    int32_t l_564 = 0x845D305FL;
    int32_t l_565[4][8][4] = {{{0L,0L,(-1L),0xC273C0FDL},{0L,0x14889515L,(-1L),0x14889515L},{0x95F1D11CL,1L,1L,0xC75D04D6L},{0x3084ABC9L,0xA8213EF9L,0x1B67BD50L,0x9126FE76L},{0xC75D04D6L,7L,0x8ED8A38CL,(-1L)},{0xC75D04D6L,(-1L),0x1B67BD50L,0xAD10DB91L},{0x3084ABC9L,(-1L),1L,0x3084ABC9L},{0x95F1D11CL,0x98EA0348L,(-1L),1L}},{{0L,(-1L),(-1L),1L},{0L,7L,1L,(-1L)},{0x98EA0348L,0xAD10DB91L,0xA3386E6FL,1L},{(-1L),0xC273C0FDL,(-1L),8L},{1L,(-1L),3L,(-1L)},{1L,(-1L),0x82A684A2L,(-1L)},{0x14889515L,0x1B67BD50L,0xF5784E14L,7L},{(-1L),0xA8213EF9L,3L,3L}},{{2L,2L,3L,0x14889515L},{(-1L),0x80410E8AL,(-9L),0x98EA0348L},{0xC273C0FDL,0L,1L,(-9L)},{0x624227BEL,0L,(-1L),0x98EA0348L},{0L,0x80410E8AL,3L,1L},{0x09434700L,0L,0x1C3ACC7FL,(-1L)},{(-1L),0x9126FE76L,1L,(-1L)},{0x3084ABC9L,1L,(-1L),1L}},{{(-1L),0x9C2775E9L,1L,0xA3386E6FL},{(-1L),1L,2L,(-1L)},{(-1L),0x0E73A5D8L,3L,3L},{(-1L),(-9L),0x0CCB7C10L,0x82A684A2L},{0x9043603AL,(-1L),0x624227BEL,0xF5784E14L},{0x1B67BD50L,0xA3386E6FL,0x8ED8A38CL,3L},{6L,0x1B67BD50L,6L,3L},{0L,1L,8L,(-9L)}}};
    union U1 **l_570 = &g_182;
    int i, j, k;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 6; j++)
            l_457[i][j] = &g_57.f0;
    }
    for (i = 0; i < 6; i++)
        l_518[i] = &g_291;
    for (i = 0; i < 5; i++)
        l_551[i] = 0x60L;
    for (i = 0; i < 8; i++)
        l_553[i] = &g_178[0];
    (*l_55) = (void*)0;
    (*l_449) = (((func_58((safe_add_func_uint32_t_u_u(((((l_67 ^= p_51) | (g_66 < (safe_mul_func_uint8_t_u_u(((g_57 , (safe_lshift_func_int32_t_s_u((l_72 < ((safe_lshift_func_uint64_t_u_s(((*l_77) = ((safe_rshift_func_uint8_t_u_u(g_40[7][2][3], l_72)) == p_51)), ((safe_mul_func_uint64_t_u_u((g_7 , 0x9E5C5CB2EA737198LL), l_72)) | p_51))) && p_51)), g_57.f0))) || (-6L)), 0xB5L)))) >= l_72) , p_51), g_40[8][2][0])), l_65[4][0][2], &g_43[0], p_51) , l_448) || p_51) , &l_67);
    for (g_57.f3 = 0; (g_57.f3 > (-1)); g_57.f3--)
    { /* block id: 175 */
        uint32_t ****l_454 = &l_452;
        (*l_454) = l_452;
    }
    if (((safe_mul_func_int64_t_s_s((l_72 ^= (l_458[5][0][1] = (**l_449))), 0x67A6BB68870B58B7LL)) || ((g_5 == ((((safe_rshift_func_int16_t_s_s(1L, ((+g_57.f3) & g_290[2]))) , (**g_346)) , g_57.f3) & ((&p_51 == (void*)0) | (**l_449)))) > 1L)))
    { /* block id: 180 */
        int16_t l_487 = 0x2810L;
        (*l_449) = (*l_449);
        (*g_185) = l_462[4];
        if ((6L >= (-1L)))
        { /* block id: 183 */
            uint8_t *l_479 = (void*)0;
            uint8_t **l_478 = &l_479;
            union U1 l_508 = {-1L};
            for (g_139 = (-11); (g_139 > 9); g_139 = safe_add_func_uint8_t_u_u(g_139, 5))
            { /* block id: 186 */
                int8_t l_511[2];
                const uint8_t ****l_519 = &l_517;
                int i;
                for (i = 0; i < 2; i++)
                    l_511[i] = (-1L);
                (*g_185) &= (-9L);
                for (g_3 = (-21); (g_3 < (-6)); g_3 = safe_add_func_int64_t_s_s(g_3, 1))
                { /* block id: 190 */
                    uint32_t ****l_467 = &l_452;
                    uint16_t *l_484 = &g_40[5][2][7];
                    uint16_t **l_483 = &l_484;
                    int32_t *l_489 = &g_178[0].f0;
                    union U1 ***l_506[1][2][2];
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                    {
                        for (j = 0; j < 2; j++)
                        {
                            for (k = 0; k < 2; k++)
                                l_506[i][j][k] = &g_181;
                        }
                    }
                    (*g_185) = (l_467 == g_468);
                    (*l_489) = (safe_add_func_int8_t_s_s((safe_rshift_func_uint16_t_u_u((((safe_add_func_int64_t_s_s((((**g_310) == (g_480 = l_478)) || ((*g_185) |= (safe_div_func_uint16_t_u_u(((l_483 != (g_485 = g_485)) & ((p_51 ^ 0xA8L) != (g_410 < ((**l_483) = (*g_486))))), 0x87A6L)))), l_487)) && (**g_485)) == p_51), g_290[1])), 255UL));
                    for (l_72 = (-26); (l_72 <= (-19)); ++l_72)
                    { /* block id: 199 */
                        union U1 ***l_505 = &g_181;
                        union U1 ****l_504[10];
                        int i;
                        for (i = 0; i < 10; i++)
                            l_504[i] = &l_505;
                        (**l_449) = (l_516 |= (safe_mul_func_int64_t_s_s((safe_div_func_int32_t_s_s(p_51, (**l_449))), ((safe_lshift_func_int64_t_s_u((safe_mul_func_uint64_t_u_u(((safe_sub_func_uint32_t_u_u(((*g_471) = ((safe_mod_func_int16_t_s_s(((l_506[0][1][0] = &g_181) == ((l_508 = l_507) , &g_181)), (-4L))) && (safe_mod_func_int32_t_s_s(l_511[1], (safe_mod_func_uint32_t_u_u((**l_449), (safe_sub_func_int8_t_s_s(((g_160 < 0xD79B2379CF2031ABLL) ^ (*g_486)), 1L)))))))), p_51)) , g_407), 0L)), (*l_489))) ^ (**g_307)))));
                    }
                }
                (*l_519) = l_517;
            }
        }
        else
        { /* block id: 209 */
            return (*g_471);
        }
    }
    else
    { /* block id: 212 */
        int16_t l_534 = 0x116EL;
        int32_t *l_546[6][4][5] = {{{&g_3,&l_72,&l_516,&g_178[0].f0,(void*)0},{(void*)0,&l_516,&l_72,&l_72,&l_67},{&g_3,(void*)0,&g_178[0].f0,&l_67,&l_72},{&g_178[0].f0,&l_67,&g_3,&g_3,(void*)0}},{{&l_507.f0,&l_67,&g_3,&g_3,&g_3},{&l_72,(void*)0,&l_72,(void*)0,(void*)0},{(void*)0,&l_516,&l_516,&l_516,(void*)0},{&g_178[0].f0,&l_72,&l_507.f0,&l_72,&g_3}},{{&l_72,&g_3,&l_516,(void*)0,&l_507.f0},{&g_3,&l_72,&l_72,(void*)0,&l_67},{&g_178[0].f0,&l_516,&g_3,&l_67,&l_72},{&l_72,(void*)0,&g_3,&l_67,(void*)0}},{{&l_516,(void*)0,&g_178[0].f0,(void*)0,&l_516},{&l_507.f0,&l_516,&l_72,(void*)0,&g_3},{&l_67,&l_507.f0,&l_516,&l_72,&l_72},{(void*)0,(void*)0,&l_67,&l_516,&g_3}},{{&g_3,&l_72,&l_507.f0,(void*)0,&l_516},{&g_3,(void*)0,&l_72,&g_3,(void*)0},{&l_507.f0,&g_3,(void*)0,&g_3,&l_72},{&l_507.f0,&l_507.f0,&l_67,&l_67,&l_67}},{{&g_3,&g_3,&g_3,&l_72,&l_507.f0},{&g_3,&l_72,&g_3,&g_178[0].f0,&g_3},{(void*)0,&g_178[0].f0,(void*)0,&g_3,(void*)0},{&l_67,&l_72,&g_3,&l_507.f0,(void*)0}}};
        uint16_t *l_547 = &g_548;
        union U1 *l_552 = &l_507;
        int32_t l_554 = 0x95DF65F0L;
        uint8_t l_566 = 0x4FL;
        union U1 ***l_569 = &g_181;
        int i, j, k;
        l_551[3] &= (((p_51 <= (((((safe_sub_func_int8_t_s_s((g_550[3] = (safe_rshift_func_uint16_t_u_u((safe_div_func_int16_t_s_s(((safe_mod_func_uint16_t_u_u((g_549 = ((**g_485) = (safe_rshift_func_int16_t_s_s((safe_lshift_func_uint64_t_u_s((safe_sub_func_int8_t_s_s((g_66 = l_534), (((((*l_547) &= ((safe_div_func_uint16_t_u_u(((~(((g_57.f3 = (safe_mul_func_uint16_t_u_u((((**l_449) && (**l_449)) < (*g_413)), (safe_rshift_func_int16_t_s_u(0L, (safe_mul_func_int16_t_s_s((**l_449), (safe_mod_func_int32_t_s_s((g_3 = 1L), (**l_449)))))))))) <= g_78) && (*g_486))) || 0x40B4E46CL), (*g_486))) > 0xCCL)) < (**l_449)) , p_51) <= p_51))), 51)), p_51)))), 0x0C9DL)) == p_51), 0x0548L)), p_51))), (**l_449))) <= (**l_449)) >= (**l_449)) <= 0L) != 0x747CL)) > p_51) , 0x8EC43938L);
        l_553[5] = ((*g_181) = l_552);
        l_566--;
        l_570 = ((*l_569) = &l_553[7]);
    }
    return (****g_468);
}


/* ------------------------------------------ */
/* 
 * reads : g_40 g_3 g_43 g_97 g_57.f0 g_97.f0 g_119 g_78 g_139 g_142 g_160 g_143 g_66 g_178 g_180 g_184 g_181 g_182 g_185 g_233 g_236 g_252 g_178.f0 g_286 g_57 g_291 g_292 g_306 g_310 g_251 g_323 g_290 g_346 g_321 g_309 g_410 g_413 g_7 g_107 g_407 g_429
 * writes: g_3 g_107 g_78 g_119 g_139 g_43 g_160 g_66 g_185 g_40 g_178.f0 g_236 g_252 g_273 g_275 g_286 g_291 g_306 g_251 g_323 g_182 g_346 g_57.f3 g_407 g_410
 */
static uint8_t  func_58(uint16_t  p_59, uint8_t * const  p_60, uint8_t * p_61, uint64_t  p_62)
{ /* block id: 13 */
    int32_t *l_83 = &g_3;
    int8_t *l_112 = &g_66;
    int32_t l_137[4][4][3] = {{{0xA4E4CF6FL,0x907D73F8L,0xE6255739L},{0x01134933L,0xEC2A52D8L,0xA256EE45L},{2L,0x907D73F8L,(-4L)},{0x01134933L,0xA256EE45L,0xA256EE45L}},{{0xA4E4CF6FL,0x907D73F8L,0xE6255739L},{0x01134933L,0xEC2A52D8L,0xA256EE45L},{2L,0x907D73F8L,(-4L)},{0x01134933L,0xA256EE45L,0xA256EE45L}},{{0xA4E4CF6FL,0x2397AFB7L,7L},{0xEC2A52D8L,(-1L),0L},{(-4L),0x2397AFB7L,0x2E92E3B7L},{0xEC2A52D8L,0L,0L}},{{0xE6255739L,0x2397AFB7L,7L},{0xEC2A52D8L,(-1L),0L},{(-4L),0x2397AFB7L,0x2E92E3B7L},{0xEC2A52D8L,0L,0L}}};
    uint8_t l_176 = 0x73L;
    uint16_t *l_285 = &g_40[5][1][2];
    uint16_t **l_284[7];
    int32_t l_339 = 0L;
    union U0 *l_352 = &g_57;
    union U0 **l_351 = &l_352;
    uint16_t l_368 = 0x355EL;
    int64_t l_390 = 6L;
    uint32_t l_406 = 9UL;
    uint32_t *l_423 = &g_410;
    union U1 l_427 = {0xCAE0697DL};
    int16_t *l_428 = &g_119;
    uint64_t l_445[3][9] = {{0xCD6FC0DC3151456BLL,0x4E1D7CEBA578F800LL,0x5567A7518A81A473LL,0x132F7EAB35379CB4LL,0x54A35818E4E5C9E8LL,0x6F4D2E5CBDF15A0DLL,0x54A35818E4E5C9E8LL,0x132F7EAB35379CB4LL,0x5567A7518A81A473LL},{0x5567A7518A81A473LL,0x5567A7518A81A473LL,18446744073709551607UL,0x6D1E40F14374E920LL,0x935083D18B33212FLL,0x4E1D7CEBA578F800LL,0x6F4D2E5CBDF15A0DLL,0xCD6FC0DC3151456BLL,0x6F4D2E5CBDF15A0DLL},{0x5567A7518A81A473LL,0UL,0x4E1D7CEBA578F800LL,0x4E1D7CEBA578F800LL,0UL,0x5567A7518A81A473LL,0x6D1E40F14374E920LL,18446744073709551606UL,0x0600A618006F3F81LL}};
    int i, j, k;
    for (i = 0; i < 7; i++)
        l_284[i] = &l_285;
    if (((*l_83) = (safe_lshift_func_uint32_t_u_u(p_59, 19))))
    { /* block id: 15 */
        union U1 l_88 = {-3L};
        union U1 *l_89 = &l_88;
        const union U0 *l_90 = (void*)0;
        union U0 *l_91 = (void*)0;
        const int32_t l_96 = 0xE29F52E1L;
        int8_t *l_113 = &g_66;
        int16_t *l_163 = &g_119;
        int32_t l_243 = 0x2A8F979CL;
        int32_t l_248 = 0L;
        int32_t l_249[3][2] = {{0x9371184BL,(-1L)},{0x9371184BL,0x9371184BL},{(-1L),0x9371184BL}};
        int8_t **l_272 = &l_112;
        int64_t l_329 = (-1L);
        int i, j;
        (*l_83) |= (safe_rshift_func_int16_t_s_u(p_62, g_40[0][1][1]));
        if (((((safe_lshift_func_uint64_t_u_u((((*l_89) = l_88) , ((g_3 <= (l_90 != l_91)) , g_43[0])), p_59)) <= (safe_sub_func_int32_t_s_s((safe_sub_func_int8_t_s_s((*l_83), l_96)), l_96))) , (*l_83)) , g_40[7][2][3]))
        { /* block id: 18 */
            uint16_t l_105[6][9] = {{0x5F71L,0x6983L,65534UL,65533UL,4UL,65533UL,65534UL,0x6983L,0x5F71L},{0x87C2L,65533UL,0x3F91L,4UL,65535UL,65533UL,5UL,0x782EL,0x6983L},{65533UL,65533UL,0x5604L,65527UL,65527UL,0x5604L,65533UL,65533UL,0x1853L},{0x87C2L,65535UL,5UL,0x1B8DL,65527UL,0xFDDEL,0x3081L,4UL,4UL},{0x5F71L,0x3F91L,65535UL,65533UL,65535UL,0x3F91L,0x5F71L,0xFDDEL,0x1853L},{0xFDDEL,0x782EL,0x5F71L,65533UL,4UL,65527UL,0x6983L,65535UL,0x6983L}};
            int64_t *l_106 = &g_107;
            int8_t **l_114 = (void*)0;
            int8_t **l_115 = &l_113;
            int16_t *l_118[3][10] = {{&g_119,(void*)0,(void*)0,&g_119,&g_119,(void*)0,&g_119,(void*)0,&g_119,&g_119},{(void*)0,&g_119,(void*)0,&g_119,&g_119,(void*)0,(void*)0,&g_119,&g_119,(void*)0},{&g_119,&g_119,&g_119,&g_119,&g_119,&g_119,&g_119,&g_119,&g_119,&g_119}};
            int32_t l_120 = 1L;
            uint64_t *l_121 = &g_78;
            int32_t l_138[9][9][3] = {{{0x804477D5L,0x58BC828DL,0xC4819D74L},{0xA2BCA0CBL,0L,0x3662F39AL},{0xC4819D74L,0x804477D5L,0x24172394L},{0x9EFAF6FFL,0xCDDAFE07L,0x0CB638BEL},{0xC4819D74L,0xC4819D74L,0x2E8F47D9L},{0xA2BCA0CBL,0x2C2567F9L,0L},{0x804477D5L,0xC4819D74L,0x804477D5L},{0x3662F39AL,0xCDDAFE07L,1L},{0x58BC828DL,0x804477D5L,0x804477D5L}},{{1L,0L,0L},{(-6L),0x58BC828DL,0x2E8F47D9L},{1L,(-4L),0x0CB638BEL},{0x58BC828DL,(-6L),0x24172394L},{0x3662F39AL,(-4L),0x3662F39AL},{0x804477D5L,0x58BC828DL,0xC4819D74L},{0xA2BCA0CBL,0L,0x3662F39AL},{0xC4819D74L,0x804477D5L,0x2E8F47D9L},{0L,0L,1L}},{{0x5F298898L,0x5F298898L,0xC4819D74L},{0x3662F39AL,0x0DECC6E9L,0x0CB638BEL},{(-6L),0x5F298898L,(-6L)},{0x9EFAF6FFL,0L,0xD7A1B735L},{0x804477D5L,(-6L),(-6L)},{0xD7A1B735L,0x2C2567F9L,0x0CB638BEL},{0x24172394L,0x804477D5L,0xC4819D74L},{0xD7A1B735L,6L,1L},{0x804477D5L,0x24172394L,0x2E8F47D9L}},{{0x9EFAF6FFL,6L,0x9EFAF6FFL},{(-6L),0x804477D5L,0x5F298898L},{0x3662F39AL,0x2C2567F9L,0x9EFAF6FFL},{0x5F298898L,(-6L),0x2E8F47D9L},{0L,0L,1L},{0x5F298898L,0x5F298898L,0xC4819D74L},{0x3662F39AL,0x0DECC6E9L,0x0CB638BEL},{(-6L),0x5F298898L,(-6L)},{0x9EFAF6FFL,0L,0xD7A1B735L}},{{0x804477D5L,(-6L),(-6L)},{0xD7A1B735L,0x2C2567F9L,0x0CB638BEL},{0x24172394L,0x804477D5L,0xC4819D74L},{0xD7A1B735L,6L,1L},{0x804477D5L,0x24172394L,0x2E8F47D9L},{0x9EFAF6FFL,6L,0x9EFAF6FFL},{(-6L),0x804477D5L,0x5F298898L},{0x3662F39AL,0x2C2567F9L,0x9EFAF6FFL},{0x5F298898L,(-6L),0x2E8F47D9L}},{{0L,0L,1L},{0x5F298898L,0x5F298898L,0xC4819D74L},{0x3662F39AL,0x0DECC6E9L,0x0CB638BEL},{(-6L),0x5F298898L,(-6L)},{0x9EFAF6FFL,0L,0xD7A1B735L},{0x804477D5L,(-6L),(-6L)},{0xD7A1B735L,0x2C2567F9L,0x0CB638BEL},{0x24172394L,0x804477D5L,0xC4819D74L},{0xD7A1B735L,6L,1L}},{{0x804477D5L,0x24172394L,0x2E8F47D9L},{0x9EFAF6FFL,6L,0x9EFAF6FFL},{(-6L),0x804477D5L,0x5F298898L},{0x3662F39AL,0x2C2567F9L,0x9EFAF6FFL},{0x5F298898L,(-6L),0x2E8F47D9L},{0L,0L,1L},{0x5F298898L,0x5F298898L,0xC4819D74L},{0x3662F39AL,0x0DECC6E9L,0x0CB638BEL},{(-6L),0x5F298898L,(-6L)}},{{0x9EFAF6FFL,0L,0xD7A1B735L},{0x804477D5L,(-6L),(-6L)},{0xD7A1B735L,0x2C2567F9L,0x0CB638BEL},{0x24172394L,0x804477D5L,0xC4819D74L},{0xD7A1B735L,6L,1L},{0x804477D5L,0x24172394L,0x2E8F47D9L},{0x9EFAF6FFL,6L,0x9EFAF6FFL},{(-6L),0x804477D5L,0x5F298898L},{0x3662F39AL,0x2C2567F9L,0x9EFAF6FFL}},{{0x5F298898L,(-6L),0x2E8F47D9L},{0L,0L,1L},{0x5F298898L,0x5F298898L,0xC4819D74L},{0x3662F39AL,0x0DECC6E9L,0x0CB638BEL},{(-6L),0x5F298898L,(-6L)},{0x9EFAF6FFL,0L,0xD7A1B735L},{0x804477D5L,(-6L),(-6L)},{0xD7A1B735L,0x2C2567F9L,0x0CB638BEL},{0x24172394L,(-6L),0x5F298898L}}};
            union U0 **l_144 = &l_91;
            union U1 ***l_200 = &g_181;
            union U0 l_223[3][4][1] = {{{{0L}},{{1L}},{{0L}},{{0L}}},{{{1L}},{{0L}},{{0L}},{{1L}}},{{{0L}},{{0L}},{{1L}},{{0L}}}};
            int i, j, k;
            if (((((g_97[2][4] , ((((*l_121) = (((safe_rshift_func_uint64_t_u_u((((l_120 &= (!((g_43[0] , ((((safe_rshift_func_int8_t_s_s((g_57.f0 != 18446744073709551611UL), ((safe_div_func_int64_t_s_s(((*l_106) = l_105[1][2]), (safe_mul_func_int16_t_s_s((safe_div_func_int64_t_s_s((l_112 != ((*l_115) = l_113)), l_88.f0)), (safe_rshift_func_uint16_t_u_u((g_97[2][4].f0 | l_105[1][7]), 1)))))) != p_62))) < 0UL) <= (*l_83)) | l_105[5][1])) >= 0x15C6L))) < g_57.f0) < g_57.f0), g_119)) , (void*)0) != (void*)0)) == 18446744073709551615UL) && g_43[0])) || p_62) == g_57.f0) , 0x4A35B986L))
            { /* block id: 23 */
                union U0 l_157 = {0xE4C78807F30BC104LL};
                union U1 **l_166 = (void*)0;
                uint32_t l_177 = 4294967295UL;
                union U1 ***l_197 = &l_166;
                union U1 **l_198[8];
                int i;
                for (i = 0; i < 8; i++)
                    l_198[i] = &l_89;
                if (p_59)
                { /* block id: 24 */
                    int64_t l_124 = 0x28D9C3D7FAD0BDB4LL;
                    for (g_119 = 0; (g_119 <= 5); g_119 += 1)
                    { /* block id: 27 */
                        return g_97[2][4].f0;
                    }
                    if (g_119)
                        goto lbl_127;
                    if (l_88.f0)
                        goto lbl_125;
lbl_125:
                    for (g_119 = 0; (g_119 > 16); ++g_119)
                    { /* block id: 32 */
                        return l_124;
                    }
lbl_127:
                    for (g_78 = 0; (g_78 <= 3); g_78 += 1)
                    { /* block id: 38 */
                        int64_t l_126 = 1L;
                        return l_126;
                    }
                    for (l_88.f0 = 0; (l_88.f0 < (-10)); l_88.f0 = safe_sub_func_int16_t_s_s(l_88.f0, 6))
                    { /* block id: 44 */
                        uint32_t l_130 = 0UL;
                        (*l_83) &= l_130;
                    }
                }
                else
                { /* block id: 47 */
                    int32_t *l_131 = &l_120;
                    int32_t *l_132 = &l_120;
                    int32_t *l_133 = &l_88.f0;
                    int32_t *l_134 = &g_3;
                    int32_t *l_135 = &l_120;
                    int32_t *l_136[3][7] = {{&l_88.f0,&l_120,&l_120,&l_88.f0,&l_120,&l_120,&l_88.f0},{&l_120,&l_88.f0,&l_120,&l_120,&l_88.f0,&l_120,&l_120},{&l_88.f0,&l_88.f0,&l_120,&l_88.f0,&l_88.f0,&l_120,&l_88.f0}};
                    union U0 *l_173 = &l_157;
                    int32_t **l_196 = &l_134;
                    int i, j;
                    g_139++;
                    if ((g_142 != l_144))
                    { /* block id: 49 */
                        int16_t l_147 = (-8L);
                        union U1 **l_164[8][7] = {{&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89},{&l_89,(void*)0,&l_89,(void*)0,&l_89,(void*)0,&l_89},{&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89},{&l_89,(void*)0,&l_89,(void*)0,&l_89,(void*)0,&l_89},{&l_89,&l_89,&l_89,&l_89,&l_89,&l_89,&l_89},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
                        union U1 ***l_165[2][5][7] = {{{&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3]},{&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3]},{&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3]},{&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3]},{&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3]}},{{&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3]},{&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3]},{&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3]},{&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3]},{&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3],&l_164[5][3]}}};
                        int i, j, k;
                        (*l_83) = (safe_sub_func_int32_t_s_s(l_147, (safe_lshift_func_int8_t_s_s((-1L), (safe_mod_func_uint8_t_u_u((safe_unary_minus_func_int32_t_s((safe_mul_func_uint8_t_u_u(((*p_61)++), (l_157 , (g_160 &= (safe_lshift_func_uint8_t_u_u(g_139, 0)))))))), (safe_div_func_uint8_t_u_u(((void*)0 != l_163), 0x32L))))))));
                        l_166 = l_164[5][3];
                        if (l_157.f0)
                            goto lbl_179;
lbl_179:
                        l_120 ^= (safe_div_func_uint8_t_u_u(248UL, ((*l_113) = (safe_add_func_int32_t_s_s(((safe_mul_func_uint8_t_u_u(((*g_142) == l_173), p_62)) | ((((((safe_add_func_uint16_t_u_u(g_139, ((l_176 ^ l_177) >= ((g_119 = ((g_43[0] < ((*l_83) >= 0x3188522CE914191BLL)) ^ 0x2C52L)) <= g_66)))) != 0x36573A9DBB096D48LL) , g_178[0]) , (-2L)) <= 0x4EA2A6299ED92AE5LL) >= 0x22E02E4CL)), p_62)))));
                        (*l_132) = 0L;
                    }
                    else
                    { /* block id: 59 */
                        union U1 *l_193 = (void*)0;
                        (*l_133) &= (p_59 && ((void*)0 == g_180[5][0]));
                        (*g_184) = &g_3;
                        (**g_184) = ((*l_135) |= (safe_lshift_func_int8_t_s_s((safe_mul_func_int32_t_s_s((p_61 == (void*)0), (p_62 <= ((((*g_181) != ((safe_unary_minus_func_int32_t_s(p_59)) , l_193)) , 0xFF993564L) <= 0xDF329044L)))), 4)));
                    }
                    for (l_88.f0 = 2; (l_88.f0 >= 0); l_88.f0 -= 1)
                    { /* block id: 67 */
                        int32_t *l_194 = &l_120;
                        int32_t **l_195 = &l_133;
                        (*l_195) = l_194;
                    }
                    (*l_196) = (g_40[3][0][6] , (void*)0);
                }
                (*l_83) = (((*l_197) = &l_89) == l_198[5]);
            }
            else
            { /* block id: 74 */
                union U1 ****l_201 = &l_200;
                const int32_t l_212 = 0xC19F9507L;
                union U0 **l_225[2][3][1] = {{{&l_91},{&l_91},{&l_91}},{{&l_91},{&l_91},{&l_91}}};
                int32_t l_242 = (-10L);
                int32_t l_247 = 1L;
                uint16_t *l_282 = &l_105[1][2];
                uint16_t **l_281 = &l_282;
                uint64_t l_296 = 4UL;
                int32_t *l_328[10][1] = {{&l_137[0][3][2]},{&l_247},{&l_88.f0},{&l_88.f0},{&l_247},{&l_137[0][3][2]},{&l_247},{&l_88.f0},{&l_88.f0},{&l_247}};
                uint32_t l_330[3][1][5] = {{{0xA467A130L,4294967295UL,0xA467A130L,0xA467A130L,4294967295UL}},{{0UL,4294967295UL,4294967295UL,0UL,4294967295UL}},{{4294967295UL,4294967295UL,1UL,4294967295UL,0xA467A130L}}};
                int i, j, k;
                if (((((safe_unary_minus_func_int32_t_s((g_43[0] ^ ((((g_97[2][4].f0 , &g_181) != ((*l_201) = l_200)) , (**g_184)) && (((*l_83) & (safe_div_func_uint32_t_u_u(((((*l_106) = g_97[2][4].f0) != ((safe_rshift_func_uint32_t_u_u(((((g_43[0] >= (safe_rshift_func_int64_t_s_u((((safe_sub_func_uint64_t_u_u((safe_mod_func_int8_t_s_s(((p_62 && g_139) != p_59), g_43[0])), l_138[1][3][1])) , p_59) < (*p_61)), 40))) & g_66) < p_59) , l_96), 9)) | l_105[1][2])) <= p_59), l_212))) , (-5L)))))) > p_59) ^ p_62) | 0xA9FAL))
                { /* block id: 77 */
                    union U0 l_224 = {5L};
                    uint16_t *l_232 = &g_40[7][2][3];
                    int32_t l_241 = 6L;
                    int32_t l_244 = 0xD3B134FBL;
                    (*g_233) = ((safe_div_func_int64_t_s_s(9L, ((*l_121) = ((safe_mul_func_int16_t_s_s((g_119 = ((safe_mod_func_uint8_t_u_u((safe_div_func_uint16_t_u_u((((safe_mod_func_int64_t_s_s((((l_223[1][1][0] , l_224) , ((0x400AL && p_59) , l_225[1][2][0])) == (void*)0), (((*g_185) = (safe_add_func_uint8_t_u_u(((*p_61) == ((safe_rshift_func_int16_t_s_s((safe_lshift_func_uint16_t_u_s(((*l_232) = l_105[1][2]), 7)), 7)) || g_66)), p_62))) && g_160))) && (**g_184)) != g_160), p_59)), 0x6CL)) <= g_66)), 0L)) , g_3)))) > g_43[0]);
                    for (p_59 = 0; (p_59 <= 0); p_59 += 1)
                    { /* block id: 85 */
                        uint32_t *l_234 = &g_178[0].f1;
                        uint32_t *l_235[6][9] = {{&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236},{&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236},{&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236},{&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236},{&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236},{&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236,&g_236,&l_88.f1,&g_236}};
                        int32_t *l_237 = &l_137[0][1][0];
                        int32_t *l_238 = &l_120;
                        int32_t *l_239 = &l_120;
                        int32_t *l_240[9] = {&g_178[0].f0,&l_137[0][2][1],&g_178[0].f0,&g_178[0].f0,&l_137[0][2][1],&g_178[0].f0,&g_178[0].f0,&l_137[0][2][1],&g_178[0].f0};
                        int32_t l_245 = 1L;
                        int i, j;
                        (*g_185) |= (p_59 == (g_236 |= g_160));
                        g_252--;
                    }
                    (*g_185) = l_243;
                    (*g_185) |= (~((safe_lshift_func_int64_t_s_u(((*l_106) = (p_62 || (safe_rshift_func_int8_t_s_s(0L, g_40[7][2][3])))), 63)) && ((safe_lshift_func_int8_t_s_s((safe_lshift_func_uint8_t_u_u((*p_61), (p_62 < ((safe_mul_func_uint16_t_u_u(((safe_add_func_int32_t_s_s(((safe_rshift_func_uint32_t_u_s(((&g_181 != (*l_201)) ^ (safe_div_func_uint32_t_u_u(((g_160 = ((**g_181) , (((l_272 = (void*)0) != (void*)0) > l_138[6][3][2]))) == p_59), l_138[0][1][2]))), l_96)) , p_62), (*g_233))) >= l_96), 0x0B42L)) , (*p_61))))), 1)) & g_40[2][1][0])));
                }
                else
                { /* block id: 95 */
                    const int32_t *l_276 = &g_3;
                    int32_t *l_313 = &l_247;
                    int32_t *l_314 = &g_3;
                    int32_t *l_315 = (void*)0;
                    int32_t *l_316 = &g_178[0].f0;
                    int32_t *l_317 = &l_137[0][1][2];
                    int32_t *l_318 = (void*)0;
                    int32_t *l_319 = &l_137[2][3][1];
                    int32_t *l_320[10][5] = {{&l_249[2][1],&g_3,&l_120,&l_243,&g_3},{&l_88.f0,&l_248,&l_248,&l_88.f0,(void*)0},{&l_249[2][1],&l_138[2][5][0],&l_88.f0,&g_3,&g_3},{&l_248,&l_88.f0,&l_248,(void*)0,&l_88.f0},{&g_3,&l_120,&l_243,&g_3,&l_243},{(void*)0,(void*)0,&l_249[1][1],&l_88.f0,&g_178[0].f0},{&l_249[2][1],&l_249[2][1],&l_243,&l_243,&l_249[2][1]},{&g_178[0].f0,&l_248,&l_248,&g_178[0].f0,(void*)0},{&l_138[2][5][0],&l_249[2][1],&l_88.f0,&l_249[2][1],&l_138[2][5][0]},{&l_248,(void*)0,&l_248,(void*)0,(void*)0}};
                    int i, j;
                    if (p_59)
                    { /* block id: 96 */
                        const int32_t **l_274 = (void*)0;
                        uint16_t ***l_283 = &l_281;
                        uint16_t * const **l_287 = &g_286;
                        const uint8_t *l_289 = &g_290[0];
                        const uint8_t **l_288[4];
                        int32_t l_293 = 0L;
                        int i;
                        for (i = 0; i < 4; i++)
                            l_288[i] = &l_289;
                        l_276 = (g_275 = (g_273 = &l_249[2][0]));
                        (*g_185) = (*l_276);
                        (*l_83) = (safe_sub_func_uint32_t_u_u(l_242, ((l_212 != ((l_284[1] = ((*l_283) = l_281)) == ((*l_287) = g_286))) >= (((*l_163) = ((g_291 = &g_43[0]) != (void*)0)) != (l_293 &= (p_62 && (0x4BL <= 0x11L)))))));
                        (*g_185) |= (safe_rshift_func_int32_t_s_s(p_62, 31));
                    }
                    else
                    { /* block id: 109 */
                        int32_t *l_304 = (void*)0;
                        int32_t *l_305[8][9] = {{&l_138[2][5][0],&l_120,&l_120,&l_138[2][5][0],&l_120,&l_120,&l_138[2][5][0],&l_120,&l_120},{&l_88.f0,(void*)0,&g_178[0].f0,(void*)0,&g_178[0].f0,(void*)0,&l_88.f0,(void*)0,&g_178[0].f0},{&l_138[2][5][0],&l_120,&l_120,&l_138[2][5][0],&l_120,&l_120,&l_138[2][5][0],&l_120,&l_120},{&l_88.f0,(void*)0,&g_178[0].f0,(void*)0,&g_178[0].f0,(void*)0,&l_88.f0,(void*)0,&g_178[0].f0},{&l_138[2][5][0],&l_120,&l_120,&l_138[2][5][0],&l_120,&l_120,&l_138[2][5][0],&l_120,&l_120},{&l_88.f0,(void*)0,&g_178[0].f0,(void*)0,&g_178[0].f0,(void*)0,&l_88.f0,(void*)0,&g_178[0].f0},{&l_138[2][5][0],&l_120,&l_120,&l_138[2][5][0],&l_120,&l_120,&l_138[2][5][0],&l_120,&l_120},{&l_88.f0,(void*)0,&g_178[0].f0,(void*)0,&g_178[0].f0,(void*)0,&l_88.f0,(void*)0,&g_178[0].f0}};
                        int i, j;
                        l_120 = (((p_59 || l_296) && ((((+(safe_rshift_func_int32_t_s_u(((g_66 = ((*g_143) , g_119)) || (*g_291)), (0x253BE1FAAB5558DFLL > ((((safe_sub_func_uint16_t_u_u(((~(safe_unary_minus_func_uint32_t_u(((p_62 ^ (l_247 ^= ((*g_185) |= (-4L)))) != 3UL)))) ^ 0x5257L), p_62)) ^ g_78) == l_223[1][1][0].f0) != l_88.f0))))) == g_139) >= 0x61933900C7D32C07LL) && p_59)) , (*l_83));
                        (*g_310) = g_306;
                    }
                    for (g_251 = 11; (g_251 <= (-25)); g_251--)
                    { /* block id: 118 */
                        l_137[0][1][2] = ((*g_185) = ((*p_61) & l_120));
                    }
                    g_323--;
                    (*l_319) |= (g_290[9] >= ((**g_181) , (safe_div_func_int16_t_s_s(0x3559L, (*l_313)))));
                }
                ++l_330[2][0][1];
            }
            return l_248;
        }
        else
        { /* block id: 128 */
            union U1 *l_333 = &g_178[0];
            int32_t l_334 = 0xC7DBC72EL;
            int32_t **l_340 = &g_185;
            union U0 * const **l_348 = &g_346;
            union U0 * const *l_350[4][4][2] = {{{&g_347,&g_347},{&g_347,&g_347},{&g_347,&g_347},{&g_347,&g_347}},{{&g_347,&g_347},{&g_347,&g_347},{&g_347,&g_347},{&g_347,&g_347}},{{&g_347,&g_347},{&g_347,&g_347},{&g_347,&g_347},{&g_347,&g_347}},{{&g_347,&g_347},{&g_347,&g_347},{&g_347,&g_347},{&g_347,&g_347}}};
            union U0 * const **l_349 = &l_350[2][0][1];
            uint32_t **l_353 = (void*)0;
            uint32_t *l_355[5] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
            uint32_t **l_354 = &l_355[3];
            uint16_t ***l_358 = &l_284[1];
            int32_t *l_359 = &l_137[2][1][0];
            int32_t *l_360 = &l_243;
            int32_t *l_361 = &l_334;
            int32_t *l_362 = (void*)0;
            int32_t *l_363 = &l_137[1][3][2];
            int32_t *l_364 = (void*)0;
            int32_t *l_365 = &l_137[1][0][1];
            int32_t *l_366 = &g_3;
            int32_t *l_367[2];
            int i, j, k;
            for (i = 0; i < 2; i++)
                l_367[i] = &l_137[0][1][2];
            (*l_340) = (((p_62 & (((((((*g_181) = l_333) != &l_88) , ((l_334 | ((((safe_div_func_int32_t_s_s((((p_62 != (safe_lshift_func_uint8_t_u_u((*g_291), 7))) > l_334) > (1UL == (p_62 ^ g_119))), l_248)) || g_78) , l_163) == &g_119)) <= 0x439229954B307670LL)) , (*g_142)) != (void*)0) <= 255UL)) , l_339) , (void*)0);
            l_243 = (l_137[1][2][2] = (safe_mod_func_uint8_t_u_u(((safe_add_func_uint64_t_u_u(((((((*l_83) = p_62) != 0UL) && (safe_unary_minus_func_int64_t_s(((((*l_349) = ((*l_348) = g_346)) != (l_351 = l_351)) && ((&g_236 == ((*l_354) = &g_236)) == l_249[1][1]))))) , ((*p_61) & (safe_add_func_int32_t_s_s((l_358 == (void*)0), (*l_83))))) , g_321[1][6]), 0x96E35F7F73C63427LL)) , 0UL), (*g_291))));
            l_368++;
            if (p_59)
            { /* block id: 139 */
                (*l_83) = p_59;
            }
            else
            { /* block id: 141 */
                return (*l_83);
            }
        }
    }
    else
    { /* block id: 145 */
        uint64_t *l_373 = &g_139;
        uint32_t *l_383 = &g_236;
        uint16_t ** const l_389 = &l_285;
        int32_t l_393 = 1L;
        int64_t *l_404 = &g_57.f3;
        int16_t *l_405[4];
        int32_t l_408 = 1L;
        int32_t *l_409 = &l_137[2][1][2];
        int i;
        for (i = 0; i < 4; i++)
            l_405[i] = (void*)0;
        (*g_413) = (safe_mul_func_uint32_t_u_u((((*l_373)++) > (!((safe_mod_func_int16_t_s_s((safe_div_func_int8_t_s_s((safe_add_func_int16_t_s_s((g_410 ^= (((*l_383) |= 0x04A81537L) <= (+((((*l_409) &= (((-1L) >= ((safe_add_func_uint64_t_u_u(g_290[0], (safe_rshift_func_int32_t_s_u(((g_286 == l_389) != (((l_390 == (safe_div_func_int32_t_s_s(l_393, ((g_407 = (safe_mod_func_int16_t_s_s((g_119 &= (safe_add_func_int32_t_s_s(((*l_83) = 0x63F14597L), ((((safe_mul_func_int16_t_s_s(((safe_add_func_int32_t_s_s((safe_add_func_int64_t_s_s(((*l_404) = (g_323 & 18446744073709551614UL)), g_43[0])), 0x341E3514L)) , p_62), p_62)) != p_59) , g_309) , l_368)))), l_406))) , 2L)))) > 249UL) != 0UL)), 1)))) && (-6L))) != l_408)) <= p_59) | p_59)))), g_292)), (*p_61))), 7L)) == p_62))), p_62));
        l_83 = &l_393;
    }
    if (((safe_div_func_int64_t_s_s((safe_unary_minus_func_uint8_t_u((g_7 || 0xC0L))), (p_62 , ((*p_61) && (g_407 ^= ((safe_lshift_func_uint8_t_u_u((safe_mod_func_int32_t_s_s((safe_lshift_func_uint64_t_u_u(0xBABB2D718FBDC8BFLL, 3)), (++(*l_423)))), (g_43[0] &= (*g_291)))) > ((*l_428) ^= ((((+g_107) && (((*l_112) = g_290[3]) , (((l_427 , 0x6B9E0CDCL) >= p_59) || p_59))) , 3UL) <= p_62)))))))) != g_40[7][2][3]))
    { /* block id: 162 */
        uint32_t l_435 = 18446744073709551606UL;
        uint64_t *l_444 = &g_323;
        int32_t *l_446[4][8][8] = {{{&l_137[0][1][2],&l_137[0][1][1],&l_137[0][1][2],&g_178[0].f0,&g_178[0].f0,&l_137[1][3][1],&l_137[3][2][0],&l_137[1][0][1]},{&g_3,&l_137[0][1][2],&l_427.f0,&g_3,&l_427.f0,&g_3,&g_178[0].f0,&l_137[1][2][1]},{&g_3,&g_3,&l_137[0][1][2],&g_3,&g_178[0].f0,&g_3,&l_427.f0,&l_137[3][1][0]},{&l_137[0][1][2],&g_3,(void*)0,&l_427.f0,&g_178[0].f0,&l_137[1][2][1],&l_427.f0,&g_3},{&g_178[0].f0,&l_137[0][1][2],&l_427.f0,&l_427.f0,(void*)0,&l_137[0][1][2],&g_178[0].f0,&l_427.f0},{&g_178[0].f0,&l_137[1][0][1],&l_137[0][1][2],&l_427.f0,&l_427.f0,(void*)0,&g_3,&g_3},{(void*)0,&l_137[3][1][0],&l_137[3][2][0],&l_427.f0,&g_178[0].f0,&l_427.f0,&l_137[3][2][0],&l_137[3][1][0]},{&l_137[0][1][2],&l_137[0][1][2],(void*)0,&g_3,(void*)0,&g_178[0].f0,&l_427.f0,&l_137[1][2][1]}},{{&g_178[0].f0,&l_137[1][3][0],(void*)0,&g_3,&l_137[0][1][2],(void*)0,&l_427.f0,&l_137[1][0][1]},{&l_137[0][1][2],&g_3,(void*)0,&g_178[0].f0,(void*)0,&l_137[0][1][2],&l_137[3][2][0],&l_137[0][1][1]},{(void*)0,&l_137[0][1][2],&l_137[3][2][0],&l_137[0][1][1],&l_427.f0,&l_427.f0,&g_3,&l_137[1][2][1]},{&g_178[0].f0,&g_3,&l_137[0][1][2],&g_3,&g_3,&g_3,&g_178[0].f0,&l_427.f0},{&l_137[0][1][2],&g_3,&l_427.f0,&l_427.f0,&l_427.f0,&l_427.f0,&l_427.f0,&g_3},{&l_427.f0,&l_137[0][1][2],(void*)0,&l_137[1][3][0],(void*)0,&l_137[0][1][2],&l_427.f0,&l_427.f0},{&l_427.f0,&g_3,&l_137[0][1][2],&l_137[3][1][0],&g_178[0].f0,(void*)0,&g_178[0].f0,&g_3},{(void*)0,&l_137[1][3][0],&l_427.f0,&l_427.f0,&g_178[0].f0,&g_178[0].f0,&l_137[3][2][0],&l_137[1][3][0]}},{{&l_427.f0,&l_137[0][1][2],&l_137[0][1][2],&g_3,(void*)0,&l_427.f0,&g_178[0].f0,&l_137[1][2][1]},{&l_427.f0,&l_137[3][1][0],(void*)0,&l_137[1][0][1],&l_427.f0,(void*)0,&l_137[0][1][2],&g_3},{&l_137[0][1][2],&l_137[1][0][1],&l_427.f0,&g_178[0].f0,&g_3,&l_137[0][1][2],&l_137[3][2][0],&g_3},{&g_178[0].f0,&l_137[0][1][2],(void*)0,&l_137[1][0][1],&l_427.f0,&l_137[1][2][1],(void*)0,&g_3},{(void*)0,&g_178[0].f0,&g_178[0].f0,&g_178[0].f0,(void*)0,&l_137[1][3][0],&l_137[0][1][2],&l_427.f0},{(void*)0,&l_427.f0,&l_137[0][1][2],&l_427.f0,(void*)0,&l_427.f0,&l_137[0][1][2],&g_178[0].f0},{&l_137[0][1][2],&g_178[0].f0,&l_137[0][1][2],&g_3,&l_427.f0,&g_3,&l_137[0][1][2],&l_427.f0},{(void*)0,&l_137[1][3][1],&g_178[0].f0,&l_427.f0,(void*)0,&l_427.f0,(void*)0,&l_427.f0}},{{(void*)0,&l_137[1][2][1],(void*)0,&l_427.f0,&l_427.f0,&g_178[0].f0,&l_427.f0,&l_137[1][2][1]},{(void*)0,(void*)0,&l_427.f0,&l_427.f0,&l_427.f0,&g_178[0].f0,(void*)0,&g_3},{(void*)0,&l_137[1][2][1],&g_178[0].f0,&l_137[1][3][1],(void*)0,&l_427.f0,(void*)0,&l_137[1][3][1]},{(void*)0,&l_137[1][3][1],(void*)0,&l_137[2][0][1],&l_137[3][2][0],&g_3,&l_427.f0,&l_137[0][1][2]},{&l_427.f0,&g_178[0].f0,&l_137[0][1][2],&l_137[0][1][2],(void*)0,&l_427.f0,&l_137[3][2][0],&g_3},{&l_427.f0,&l_427.f0,&g_178[0].f0,&g_178[0].f0,&l_137[3][2][0],&l_137[1][3][0],&l_427.f0,&g_3},{(void*)0,&g_178[0].f0,&l_427.f0,&l_427.f0,(void*)0,&g_3,&l_137[0][1][2],&g_178[0].f0},{(void*)0,&g_178[0].f0,(void*)0,&l_137[1][2][1],&l_427.f0,(void*)0,(void*)0,&l_427.f0}}};
        int i, j, k;
        (*g_429) &= p_59;
        l_427.f0 |= (safe_rshift_func_uint16_t_u_u((safe_add_func_uint64_t_u_u((safe_unary_minus_func_uint8_t_u((l_435 == (safe_mul_func_int32_t_s_s(p_62, (((*l_112) = (-9L)) , (safe_div_func_int64_t_s_s(((((*l_423) &= g_43[0]) && ((void*)0 == &l_390)) || (safe_mul_func_int8_t_s_s(((safe_sub_func_uint32_t_u_u(l_435, (((((**g_181) , ((*l_444) = (1UL & p_59))) && l_435) >= (-1L)) , 0x512DB83CL))) && (*g_233)), l_445[2][4]))), p_59)))))))), g_292)), 5));
    }
    else
    { /* block id: 168 */
        union U1 *l_447 = &l_427;
        (*g_181) = l_447;
    }
    return l_137[0][1][2];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_5, "g_5", print_hash_value);
    transparent_crc(g_7, "g_7", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_40[i][j][k], "g_40[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_43[i], "g_43[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_66, "g_66", print_hash_value);
    transparent_crc(g_78, "g_78", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_97[i][j].f0, "g_97[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_107, "g_107", print_hash_value);
    transparent_crc(g_119, "g_119", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_160, "g_160", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_178[i].f0, "g_178[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_236, "g_236", print_hash_value);
    transparent_crc(g_246, "g_246", print_hash_value);
    transparent_crc(g_250, "g_250", print_hash_value);
    transparent_crc(g_251, "g_251", print_hash_value);
    transparent_crc(g_252, "g_252", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_290[i], "g_290[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_292, "g_292", print_hash_value);
    transparent_crc(g_309, "g_309", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_321[i][j], "g_321[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_322, "g_322", print_hash_value);
    transparent_crc(g_323, "g_323", print_hash_value);
    transparent_crc(g_407, "g_407", print_hash_value);
    transparent_crc(g_410, "g_410", print_hash_value);
    transparent_crc(g_548, "g_548", print_hash_value);
    transparent_crc(g_549, "g_549", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_550[i], "g_550[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_657[i], "g_657[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_680, "g_680", print_hash_value);
    transparent_crc(g_737, "g_737", print_hash_value);
    transparent_crc(g_761, "g_761", print_hash_value);
    transparent_crc(g_811, "g_811", print_hash_value);
    transparent_crc(g_872, "g_872", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_873[i][j][k], "g_873[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 197
XXX total union variables: 13

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 18
breakdown:
   indirect level: 0, occurrence: 5
   indirect level: 1, occurrence: 4
   indirect level: 2, occurrence: 6
   indirect level: 3, occurrence: 2
   indirect level: 4, occurrence: 1
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 12
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 6
XXX times a single bitfield on LHS: 1
XXX times a single bitfield on RHS: 0

XXX max expression depth: 40
breakdown:
   depth: 1, occurrence: 136
   depth: 2, occurrence: 28
   depth: 3, occurrence: 6
   depth: 4, occurrence: 2
   depth: 6, occurrence: 1
   depth: 10, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 2
   depth: 16, occurrence: 1
   depth: 18, occurrence: 1
   depth: 20, occurrence: 1
   depth: 21, occurrence: 5
   depth: 22, occurrence: 2
   depth: 25, occurrence: 2
   depth: 26, occurrence: 1
   depth: 27, occurrence: 2
   depth: 28, occurrence: 2
   depth: 29, occurrence: 3
   depth: 30, occurrence: 2
   depth: 31, occurrence: 1
   depth: 34, occurrence: 1
   depth: 35, occurrence: 1
   depth: 37, occurrence: 1
   depth: 40, occurrence: 1

XXX total number of pointers: 242

XXX times a variable address is taken: 594
XXX times a pointer is dereferenced on RHS: 102
breakdown:
   depth: 1, occurrence: 66
   depth: 2, occurrence: 29
   depth: 3, occurrence: 6
   depth: 4, occurrence: 1
XXX times a pointer is dereferenced on LHS: 121
breakdown:
   depth: 1, occurrence: 115
   depth: 2, occurrence: 5
   depth: 3, occurrence: 0
   depth: 4, occurrence: 1
XXX times a pointer is compared with null: 12
XXX times a pointer is compared with address of another variable: 2
XXX times a pointer is compared with another pointer: 5
XXX times a pointer is qualified to be dereferenced: 1766

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 328
   level: 2, occurrence: 72
   level: 3, occurrence: 17
   level: 4, occurrence: 10
XXX number of pointers point to pointers: 95
XXX number of pointers point to scalars: 129
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 30.2
XXX average alias set size: 1.38

XXX times a non-volatile is read: 678
XXX times a non-volatile is write: 343
XXX times a volatile is read: 58
XXX    times read thru a pointer: 12
XXX times a volatile is write: 19
XXX    times written thru a pointer: 2
XXX times a volatile is available for access: 356
XXX percentage of non-volatile access: 93

XXX forward jumps: 3
XXX backward jumps: 2

XXX stmts: 133
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 29
   depth: 2, occurrence: 15
   depth: 3, occurrence: 13
   depth: 4, occurrence: 21
   depth: 5, occurrence: 23

XXX percentage a fresh-made variable is used: 18.6
XXX percentage an existing variable is used: 81.4
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

