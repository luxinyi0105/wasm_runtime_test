/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      2306395551
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   const volatile unsigned f0 : 14;
};

/* --- GLOBAL VARIABLES --- */
static const volatile int64_t g_14[6] = {(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)};
static uint64_t g_16 = 6UL;
static int32_t g_75 = 1L;
static uint64_t g_82 = 6UL;
static uint32_t g_115 = 0x520CAD13L;
static uint32_t g_116 = 0xA104108FL;
static uint16_t g_118 = 0xC2ECL;
static int32_t *g_126 = &g_75;
static int32_t g_139 = 0x386FE3A8L;
static int8_t g_141 = 1L;
static uint32_t g_142 = 0x084A157FL;
static uint64_t g_159 = 0xFFDF03653FF11A6DLL;
static uint8_t g_163 = 254UL;
static int16_t g_165[2][2][4] = {{{(-7L),(-7L),(-7L),(-7L)},{(-7L),(-7L),(-7L),(-7L)}},{{(-7L),(-7L),(-7L),(-7L)},{(-7L),(-7L),(-7L),(-7L)}}};
static int64_t g_200 = (-1L);
static uint32_t g_209 = 1UL;
static int32_t g_212 = 0x1D326F63L;
static uint8_t g_217 = 0xC8L;
static uint32_t g_245 = 0UL;
static volatile int64_t g_282[2][6] = {{0x2C0690983454C05BLL,0x4D1D3ED8F5056CABLL,0x4D1D3ED8F5056CABLL,0x2C0690983454C05BLL,0x92BBAF6A02321D8DLL,0x2C0690983454C05BLL},{0x2C0690983454C05BLL,0x92BBAF6A02321D8DLL,0x2C0690983454C05BLL,0x4D1D3ED8F5056CABLL,0x4D1D3ED8F5056CABLL,0x2C0690983454C05BLL}};
static volatile int64_t *g_281 = &g_282[1][5];
static volatile int64_t **g_280[8] = {&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281,&g_281};
static int32_t g_312[6] = {0xB0FE6DB1L,0x287BE3B7L,0xB0FE6DB1L,0xB0FE6DB1L,0xB0FE6DB1L,0x940EEDF8L};
static uint64_t g_322 = 0UL;
static uint8_t *g_411 = (void*)0;
static uint8_t **g_410 = &g_411;
static volatile uint32_t g_419 = 0xF299F02CL;/* VOLATILE GLOBAL g_419 */
static volatile uint32_t g_420 = 4294967295UL;/* VOLATILE GLOBAL g_420 */
static volatile uint32_t g_421 = 0xE7F5A0BEL;/* VOLATILE GLOBAL g_421 */
static volatile uint32_t *g_418[8] = {&g_420,&g_421,&g_420,&g_420,&g_421,&g_420,&g_420,&g_421};
static volatile uint32_t **g_417[4] = {&g_418[5],&g_418[5],&g_418[5],&g_418[5]};
static int32_t ** volatile *g_447 = (void*)0;
static int32_t ** volatile **g_446 = &g_447;
static int32_t g_467 = 3L;
static uint32_t g_506 = 4294967289UL;
static uint32_t * const g_505 = &g_506;
static uint32_t * const *g_504[7] = {&g_505,&g_505,&g_505,&g_505,&g_505,&g_505,&g_505};
static uint32_t * const **g_503 = &g_504[2];
static uint64_t g_513 = 18446744073709551615UL;
static uint32_t g_545 = 0x43EE5101L;
static uint16_t *g_554 = &g_118;
static uint16_t **g_553 = &g_554;
static uint64_t g_602 = 1UL;
static uint64_t g_665 = 0xB6EC8DE29CE48A01LL;
static uint16_t g_692 = 0xEEE4L;
static int8_t g_694 = 8L;
static uint64_t *g_730 = &g_513;
static uint32_t *g_754[1][1][7] = {{{&g_545,&g_545,&g_545,&g_545,&g_545,&g_545,&g_545}}};
static uint32_t **g_753 = &g_754[0][0][6];
static int8_t ***g_807 = (void*)0;
static struct S0 g_818 = {3};/* VOLATILE GLOBAL g_818 */
static const struct S0 g_819 = {82};/* VOLATILE GLOBAL g_819 */
static const uint64_t g_867 = 0x9FEB1E5E5D7BFA74LL;
static uint32_t g_890 = 7UL;
static uint8_t g_925[10] = {0UL,1UL,1UL,0UL,1UL,1UL,0UL,1UL,1UL,0UL};
static const int8_t *g_963 = (void*)0;
static const int8_t * const *g_962[6][1][8] = {{{(void*)0,&g_963,&g_963,(void*)0,&g_963,&g_963,&g_963,&g_963}},{{(void*)0,&g_963,&g_963,(void*)0,&g_963,&g_963,(void*)0,&g_963}},{{&g_963,&g_963,&g_963,&g_963,&g_963,&g_963,&g_963,&g_963}},{{&g_963,&g_963,&g_963,&g_963,&g_963,&g_963,&g_963,&g_963}},{{&g_963,&g_963,&g_963,&g_963,&g_963,&g_963,&g_963,&g_963}},{{&g_963,&g_963,&g_963,&g_963,(void*)0,&g_963,(void*)0,&g_963}}};
static const int8_t * const **g_961 = &g_962[2][0][2];
static uint64_t g_973 = 0x8C13B8019219DFEFLL;
static const volatile uint32_t g_979 = 5UL;/* VOLATILE GLOBAL g_979 */
static const volatile uint32_t * const g_978 = &g_979;
static const volatile uint32_t * const *g_977[6] = {&g_978,&g_978,&g_978,&g_978,&g_978,&g_978};
static const volatile uint32_t * const * volatile *g_976[3][10] = {{&g_977[1],&g_977[1],&g_977[1],(void*)0,(void*)0,&g_977[1],&g_977[1],&g_977[1],(void*)0,(void*)0},{&g_977[1],&g_977[1],&g_977[1],(void*)0,(void*)0,&g_977[1],&g_977[1],&g_977[1],(void*)0,(void*)0},{&g_977[1],&g_977[1],&g_977[1],(void*)0,(void*)0,&g_977[1],&g_977[1],&g_977[1],(void*)0,(void*)0}};
static const volatile uint32_t * const * volatile * volatile *g_975 = &g_976[1][6];
static const volatile uint32_t * const * volatile * volatile * volatile * const g_974[1] = {&g_975};
static uint8_t g_992 = 0x6CL;
static volatile struct S0 g_1024[1] = {{104}};
static volatile struct S0 * const g_1023 = &g_1024[0];
static struct S0 g_1026 = {89};/* VOLATILE GLOBAL g_1026 */
static const int16_t g_1039 = 0x7C32L;
static struct S0 g_1046 = {95};/* VOLATILE GLOBAL g_1046 */
static struct S0 g_1050 = {64};/* VOLATILE GLOBAL g_1050 */
static struct S0 *g_1049 = &g_1050;
static struct S0 **g_1048 = &g_1049;
static uint16_t g_1052 = 0x7267L;
static int64_t g_1053[10] = {0xBFBB9510A757D8C3LL,0xBFBB9510A757D8C3LL,0xBFBB9510A757D8C3LL,0xBFBB9510A757D8C3LL,0xBFBB9510A757D8C3LL,0xBFBB9510A757D8C3LL,0xBFBB9510A757D8C3LL,0xBFBB9510A757D8C3LL,0xBFBB9510A757D8C3LL,0xBFBB9510A757D8C3LL};
static uint16_t ** volatile *g_1068 = &g_553;
static uint16_t ** volatile ** const g_1067 = &g_1068;
static uint16_t ** volatile **g_1069[8][5][6] = {{{(void*)0,&g_1068,(void*)0,&g_1068,&g_1068,(void*)0},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,(void*)0,&g_1068,&g_1068,(void*)0},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,(void*)0,&g_1068,&g_1068,(void*)0},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,(void*)0,&g_1068,(void*)0,&g_1068}},{{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0},{(void*)0,(void*)0,&g_1068,&g_1068,(void*)0,&g_1068},{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0},{(void*)0,(void*)0,&g_1068,&g_1068,(void*)0,&g_1068}},{{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0},{(void*)0,(void*)0,&g_1068,&g_1068,(void*)0,&g_1068},{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0}},{{(void*)0,(void*)0,&g_1068,&g_1068,(void*)0,&g_1068},{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0},{(void*)0,(void*)0,&g_1068,&g_1068,(void*)0,&g_1068},{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068}},{{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0},{(void*)0,(void*)0,&g_1068,&g_1068,(void*)0,&g_1068},{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0},{(void*)0,(void*)0,&g_1068,&g_1068,(void*)0,&g_1068}},{{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0},{(void*)0,(void*)0,&g_1068,&g_1068,(void*)0,&g_1068},{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0}},{{(void*)0,(void*)0,&g_1068,&g_1068,(void*)0,&g_1068},{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068},{(void*)0,&g_1068,&g_1068,&g_1068,&g_1068,(void*)0},{(void*)0,(void*)0,&g_1068,&g_1068,(void*)0,&g_1068},{(void*)0,(void*)0,(void*)0,&g_1068,(void*)0,&g_1068}}};
static struct S0 g_1108 = {108};/* VOLATILE GLOBAL g_1108 */
static struct S0 ** const *g_1118 = (void*)0;
static int8_t ** const *g_1158 = (void*)0;
static volatile struct S0 g_1161 = {35};/* VOLATILE GLOBAL g_1161 */
static volatile int8_t ** volatile * volatile * volatile g_1171 = (void*)0;/* VOLATILE GLOBAL g_1171 */
static volatile int8_t ** volatile * volatile * volatile * const  volatile g_1170 = &g_1171;/* VOLATILE GLOBAL g_1170 */
static int8_t g_1206 = 6L;
static volatile int8_t g_1212 = 0x5EL;/* VOLATILE GLOBAL g_1212 */
static volatile int8_t g_1213 = 0x3CL;/* VOLATILE GLOBAL g_1213 */
static volatile int8_t * volatile g_1211[10] = {&g_1212,&g_1212,&g_1212,&g_1212,&g_1212,&g_1212,&g_1212,&g_1212,&g_1212,&g_1212};
static volatile int8_t * volatile *g_1210[4] = {&g_1211[6],&g_1211[6],&g_1211[6],&g_1211[6]};
static volatile int8_t * volatile **g_1209 = &g_1210[2];
static volatile int8_t * volatile ***g_1208 = &g_1209;
static volatile int8_t * volatile ****g_1207 = &g_1208;
static volatile struct S0 g_1228 = {84};/* VOLATILE GLOBAL g_1228 */
static volatile struct S0 g_1256 = {66};/* VOLATILE GLOBAL g_1256 */
static struct S0 ** volatile g_1258 = &g_1049;/* VOLATILE GLOBAL g_1258 */
static volatile uint32_t g_1260 = 18446744073709551615UL;/* VOLATILE GLOBAL g_1260 */
static volatile int8_t g_1312 = (-1L);/* VOLATILE GLOBAL g_1312 */
static int16_t *g_1326 = &g_165[0][0][1];
static int16_t **g_1395 = &g_1326;
static int16_t *** volatile g_1394 = &g_1395;/* VOLATILE GLOBAL g_1394 */
static int64_t *g_1419 = &g_1053[7];
static int64_t **g_1418 = &g_1419;
static int32_t *g_1526[7][9] = {{&g_312[5],&g_139,&g_139,&g_312[5],&g_212,(void*)0,&g_212,&g_312[5],&g_139},{&g_467,&g_139,(void*)0,&g_212,&g_212,&g_212,(void*)0,&g_139,&g_467},{&g_139,&g_312[5],&g_212,(void*)0,&g_212,&g_312[5],&g_139,&g_139,&g_312[5]},{&g_139,(void*)0,(void*)0,(void*)0,&g_139,&g_139,&g_212,&g_212,&g_212},{&g_139,&g_212,&g_139,&g_312[0],&g_212,&g_212,&g_312[0],&g_139,&g_212},{&g_467,&g_139,&g_212,&g_312[3],(void*)0,&g_139,(void*)0,&g_139,(void*)0},{&g_312[5],(void*)0,&g_312[0],&g_312[0],(void*)0,&g_312[5],&g_212,&g_312[5],(void*)0}};
static uint32_t g_1587 = 0x883E429DL;
static int32_t ** volatile g_1597 = (void*)0;/* VOLATILE GLOBAL g_1597 */
static volatile uint32_t *g_1607 = &g_1260;
static volatile uint32_t * volatile *g_1606 = &g_1607;
static int8_t g_1611[4][8] = {{0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L},{0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L},{0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L},{0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L,0xC0L}};
static uint32_t g_1752 = 3UL;
static int8_t g_1762[2][1] = {{(-2L)},{(-2L)}};
static uint32_t ***g_1787 = &g_753;
static uint32_t ****g_1786 = &g_1787;
static uint16_t g_1789 = 0xEAD6L;
static int8_t *g_1806 = &g_1611[0][2];
static int8_t **g_1805 = &g_1806;
static int16_t g_1822 = 0L;
static const uint64_t g_1856 = 0xA154DB0730572F57LL;
static volatile struct S0 g_1876 = {54};/* VOLATILE GLOBAL g_1876 */
static int16_t ** volatile * const  volatile g_1893 = &g_1395;/* VOLATILE GLOBAL g_1893 */
static int16_t ** volatile * const  volatile * const g_1892 = &g_1893;
static volatile struct S0 g_1924 = {76};/* VOLATILE GLOBAL g_1924 */
static volatile int64_t g_1932 = 0x82AA599DB2426F9FLL;/* VOLATILE GLOBAL g_1932 */
static volatile uint64_t g_1941 = 18446744073709551612UL;/* VOLATILE GLOBAL g_1941 */
static uint32_t g_1971 = 0x7F6F6A1DL;
static int16_t ** volatile g_1973 = &g_1326;/* VOLATILE GLOBAL g_1973 */
static int16_t g_1996[4] = {(-7L),(-7L),(-7L),(-7L)};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t  func_2(uint32_t  p_3, const uint64_t  p_4, int64_t  p_5, int8_t  p_6);
static uint32_t  func_7(uint32_t  p_8, int8_t  p_9, uint8_t  p_10, int64_t  p_11, int64_t  p_12);
static uint64_t  func_19(int32_t  p_20, uint8_t  p_21, int64_t  p_22);
static uint8_t  func_25(const uint16_t  p_26, int64_t  p_27, int8_t  p_28);
static int8_t  func_41(uint32_t  p_42, int32_t  p_43);
static uint16_t  func_48(int64_t  p_49, uint32_t  p_50, int8_t  p_51, uint32_t  p_52);
static int8_t  func_55(int32_t  p_56, uint32_t  p_57, uint16_t  p_58, int32_t  p_59, uint8_t  p_60);
static int32_t  func_61(int32_t  p_62);
static const uint16_t  func_63(uint32_t  p_64);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_14 g_16 g_75 g_82 g_115 g_116 g_126 g_142 g_118 g_139 g_159 g_165 g_163 g_141 g_217 g_545 g_245 g_212 g_200 g_506 g_505 g_467 g_312 g_554 g_730 g_513 g_692 g_867 g_503 g_504 g_890 g_753 g_754 g_209 g_925 g_553 g_961 g_973 g_974 g_807 g_992 g_1023 g_1039 g_1052 g_1053 g_322 g_1067 g_1395 g_1326 g_1208 g_1209 g_1210 g_1211 g_1213 g_1212 g_421 g_1394 g_1587 g_1419 g_1068 g_1606 g_1611 g_281 g_282 g_694 g_1206 g_1418 g_1258 g_1049 g_1024 g_1607 g_1752 g_1526 g_419 g_1161.f0 g_1170 g_1171 g_1789 g_1805 g_1822 g_1856 g_602 g_1786 g_1787 g_1876 g_1892 g_1893 g_1924 g_1941 g_1806 g_818.f0 g_1973 g_1971 g_1996 g_978 g_979
 * writes: g_82 g_116 g_75 g_126 g_139 g_142 g_159 g_163 g_165 g_200 g_209 g_212 g_118 g_141 g_467 g_217 g_665 g_506 g_545 g_554 g_312 g_961 g_992 g_513 g_115 g_1048 g_1052 g_1053 g_694 g_504 g_1069 g_1526 g_1587 g_925 g_553 g_1611 g_1206 g_1752 g_1786 g_1789 g_245 g_602 g_16 g_1787 g_1971 g_692 g_1597
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int16_t l_13 = 0x4781L;
    uint32_t l_145 = 18446744073709551615UL;
    uint16_t *l_1054 = &g_118;
    uint32_t l_1528[9][4][5] = {{{0UL,0UL,0x508D0BA7L,0UL,0UL},{0x900B1625L,0UL,0x900B1625L,0x900B1625L,0UL},{0UL,0x900B1625L,0x900B1625L,0UL,0x900B1625L},{0UL,0UL,0x508D0BA7L,0UL,0UL}},{{0x900B1625L,0UL,0x900B1625L,0x900B1625L,0UL},{0UL,0x900B1625L,0x900B1625L,0UL,0x900B1625L},{0UL,0UL,0x508D0BA7L,0UL,0UL},{0x900B1625L,0UL,0x900B1625L,0x900B1625L,0UL}},{{0UL,0x900B1625L,0x900B1625L,0UL,0x900B1625L},{0UL,0UL,0x508D0BA7L,0UL,0UL},{0x900B1625L,0UL,0x900B1625L,0x900B1625L,0UL},{0UL,0x900B1625L,0x900B1625L,0UL,0x900B1625L}},{{0UL,0UL,0x508D0BA7L,0UL,0UL},{0x900B1625L,0UL,0x900B1625L,0x900B1625L,0UL},{0UL,0x900B1625L,0x900B1625L,0UL,0x900B1625L},{0UL,0UL,0x508D0BA7L,0UL,0UL}},{{0x900B1625L,0UL,0x900B1625L,0x508D0BA7L,0x900B1625L},{0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L,0x508D0BA7L},{0x900B1625L,0x900B1625L,0UL,0x900B1625L,0x900B1625L},{0x508D0BA7L,0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L}},{{0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L,0x508D0BA7L},{0x900B1625L,0x900B1625L,0UL,0x900B1625L,0x900B1625L},{0x508D0BA7L,0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L},{0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L,0x508D0BA7L}},{{0x900B1625L,0x900B1625L,0UL,0x900B1625L,0x900B1625L},{0x508D0BA7L,0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L},{0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L,0x508D0BA7L},{0x900B1625L,0x900B1625L,0UL,0x900B1625L,0x900B1625L}},{{0x508D0BA7L,0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L},{0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L,0x508D0BA7L},{0x900B1625L,0x900B1625L,0UL,0x900B1625L,0x900B1625L},{0x508D0BA7L,0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L}},{{0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L,0x508D0BA7L},{0x900B1625L,0x900B1625L,0UL,0x900B1625L,0x900B1625L},{0x508D0BA7L,0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L},{0x900B1625L,0x508D0BA7L,0x508D0BA7L,0x900B1625L,0x508D0BA7L}}};
    uint8_t **l_1545 = &g_411;
    int16_t l_1549 = (-1L);
    int32_t l_1559 = 0x7E4E0034L;
    int32_t l_1560 = 1L;
    int32_t **l_1610 = &g_1526[2][2];
    int32_t ***l_1609 = &l_1610;
    int32_t ****l_1608[7] = {&l_1609,&l_1609,&l_1609,&l_1609,&l_1609,&l_1609,&l_1609};
    int32_t l_1642[3][7] = {{1L,0x63BA138FL,0x63BA138FL,1L,0x63BA138FL,0x63BA138FL,1L},{(-9L),2L,(-9L),(-9L),2L,(-9L),(-9L)},{1L,1L,0L,1L,1L,0L,1L}};
    struct S0 *l_1712 = &g_1108;
    int8_t ****l_1721 = &g_807;
    int8_t *****l_1720 = &l_1721;
    uint32_t l_1758 = 0x02674F37L;
    int16_t l_1760 = 0x062DL;
    uint32_t l_1763 = 0x4282C7A2L;
    uint16_t l_1766 = 0x088DL;
    uint32_t l_1768 = 0x3CD72008L;
    int8_t **l_1807 = &g_1806;
    uint32_t **l_1820 = &g_754[0][0][6];
    int8_t **l_1824[4][4] = {{&g_1806,&g_1806,&g_1806,&g_1806},{&g_1806,&g_1806,&g_1806,&g_1806},{(void*)0,&g_1806,&g_1806,&g_1806},{&g_1806,&g_1806,&g_1806,&g_1806}};
    int32_t l_1858 = (-1L);
    int16_t l_1867[6][5][1] = {{{1L},{0xA6CBL},{0xC2F5L},{1L},{9L}},{{0xC2F5L},{1L},{0xC2F5L},{9L},{1L}},{{0xC2F5L},{0xA6CBL},{1L},{9L},{9L}},{{1L},{0xA6CBL},{0xC2F5L},{1L},{9L}},{{0xC2F5L},{1L},{0xC2F5L},{9L},{1L}},{{0xC2F5L},{0xA6CBL},{1L},{9L},{9L}}};
    uint64_t *l_1868 = &g_513;
    uint16_t l_1968 = 0x8AABL;
    const uint16_t l_1984 = 0xB641L;
    int32_t l_2041 = 0x257CFEDAL;
    uint32_t ****l_2048 = &g_1787;
    int i, j, k;
    if (func_2(func_7(l_13, (((g_14[0] != ((safe_unary_minus_func_uint32_t_u((g_16 > ((safe_div_func_uint64_t_u_u(func_19(l_13, ((safe_div_func_uint64_t_u_u(((g_16 , ((func_25(((*l_1054) = ((g_694 = (((g_16 & (safe_rshift_func_int32_t_s_s((g_1053[3] ^= (safe_add_func_int64_t_s_s((((safe_rshift_func_uint64_t_u_u(((*g_730) = ((safe_lshift_func_uint32_t_u_u(((safe_div_func_int8_t_s_s((safe_div_func_uint32_t_u_u(4294967295UL, (g_1052 &= (func_41((safe_div_func_int8_t_s_s((0x2F55126EL == (safe_add_func_uint16_t_u_u(func_48((safe_add_func_int8_t_s_s(func_55(g_16, g_16, l_13, g_16, l_13), l_145)), g_118, l_145, g_115), (-5L)))), g_890)), g_692) <= l_13)))), 0x35L)) , l_145), l_145)) > l_13)), 25)) <= (-10L)) & 0x0041L), l_13))), 27))) || (*g_730)) , 0x72L)) | 0xF6L)), l_145, l_13) , l_145) & g_322)) ^ 0L), g_925[6])) , l_13), g_890), 18446744073709551615UL)) < 0x094AL)))) , 1UL)) , (*g_730)) >= l_145), l_13, g_692, l_145), l_13, l_1528[1][0][0], l_145))
    { /* block id: 646 */
        int16_t ***l_1547[4][6] = {{&g_1395,&g_1395,&g_1395,&g_1395,&g_1395,&g_1395},{(void*)0,&g_1395,(void*)0,&g_1395,(void*)0,&g_1395},{&g_1395,&g_1395,&g_1395,&g_1395,&g_1395,&g_1395},{(void*)0,&g_1395,(void*)0,&g_1395,(void*)0,&g_1395}};
        int16_t ****l_1546 = &l_1547[1][2];
        int32_t l_1548 = (-1L);
        uint64_t l_1551 = 0xE3FA7293E86BF141LL;
        int32_t l_1558[10][7][3] = {{{1L,0x5E315788L,1L},{5L,0xAAB437A3L,0xCD7D1552L},{0xB4EEB05FL,0x5E315788L,(-3L)},{(-1L),(-1L),0xCD7D1552L},{1L,1L,1L},{(-1L),0xAAB437A3L,0xAAB437A3L},{0xB4EEB05FL,1L,(-3L)}},{{5L,(-1L),0xAAB437A3L},{1L,0x5E315788L,1L},{5L,0xAAB437A3L,0xCD7D1552L},{0xB4EEB05FL,0x5E315788L,(-3L)},{(-1L),(-1L),0xCD7D1552L},{1L,1L,1L},{(-1L),0xAAB437A3L,0xAAB437A3L}},{{0xB4EEB05FL,1L,(-3L)},{5L,(-1L),0xAAB437A3L},{1L,0x5E315788L,1L},{5L,0xAAB437A3L,0xCD7D1552L},{0xB4EEB05FL,0x5E315788L,(-3L)},{(-1L),(-1L),0xCD7D1552L},{1L,1L,1L}},{{(-1L),0xAAB437A3L,0xAAB437A3L},{0xB4EEB05FL,1L,(-3L)},{5L,(-1L),0xAAB437A3L},{1L,0x5E315788L,1L},{5L,0xAAB437A3L,0xCD7D1552L},{0xB4EEB05FL,0x5E315788L,(-3L)},{(-1L),(-1L),0xCD7D1552L}},{{1L,1L,1L},{(-1L),0xAAB437A3L,0xAAB437A3L},{0xB4EEB05FL,1L,(-3L)},{5L,(-1L),0xAAB437A3L},{1L,0x5E315788L,1L},{5L,0xAAB437A3L,0xCD7D1552L},{0xB4EEB05FL,0x5E315788L,(-3L)}},{{(-1L),(-1L),0xCD7D1552L},{1L,1L,1L},{(-1L),0xAAB437A3L,0xAAB437A3L},{0xB4EEB05FL,1L,(-3L)},{5L,(-1L),0xAAB437A3L},{1L,0x5E315788L,1L},{5L,0xAAB437A3L,0xCD7D1552L}},{{0xB4EEB05FL,0x5E315788L,(-3L)},{(-1L),(-1L),0xCD7D1552L},{1L,1L,1L},{(-1L),0xAAB437A3L,0xAAB437A3L},{0xB4EEB05FL,1L,(-3L)},{5L,(-1L),0xAAB437A3L},{1L,0x5E315788L,1L}},{{5L,0xAAB437A3L,0xCD7D1552L},{0xB4EEB05FL,0x5E315788L,(-3L)},{(-1L),(-1L),0xCD7D1552L},{1L,1L,1L},{(-1L),0xAAB437A3L,0xAAB437A3L},{0xB4EEB05FL,1L,(-3L)},{5L,(-1L),0xAAB437A3L}},{{1L,0x5E315788L,1L},{5L,0xAAB437A3L,0xCD7D1552L},{0xB4EEB05FL,0x5E315788L,(-3L)},{(-1L),(-1L),0xCD7D1552L},{1L,1L,1L},{(-1L),0xAAB437A3L,0xAAB437A3L},{0xB4EEB05FL,1L,(-3L)}},{{5L,(-1L),0xAAB437A3L},{1L,0x5E315788L,1L},{5L,0xAAB437A3L,0xCD7D1552L},{0xB4EEB05FL,0x5E315788L,(-3L)},{(-1L),(-1L),0xCD7D1552L},{1L,1L,1L},{(-1L),0xAAB437A3L,0xAAB437A3L}}};
        uint8_t l_1615[8];
        uint32_t l_1683 = 1UL;
        int32_t l_1684[1];
        int8_t l_1701 = 0x13L;
        int32_t l_1744 = 0xA1D44877L;
        int64_t l_1771 = (-5L);
        uint32_t l_1772[4] = {0xA081A11AL,0xA081A11AL,0xA081A11AL,0xA081A11AL};
        uint32_t ***l_1785 = (void*)0;
        uint32_t ****l_1784 = &l_1785;
        int32_t *l_1788[9][10] = {{&l_1744,&l_1744,(void*)0,&l_1642[2][1],(void*)0,(void*)0,(void*)0,&l_1642[2][1],(void*)0,&l_1744},{(void*)0,&l_1642[2][1],&l_1744,(void*)0,&l_1642[2][1],&l_1642[2][1],(void*)0,&l_1744,&l_1642[2][1],(void*)0},{&l_1744,&l_1744,&l_1642[2][1],&l_1642[2][1],&l_1744,&l_1642[2][1],&l_1642[2][1],&l_1744,&l_1744,&l_1744},{(void*)0,&l_1642[2][1],(void*)0,&l_1744,&l_1744,(void*)0,&l_1642[2][1],(void*)0,(void*)0,(void*)0},{&l_1744,&l_1642[2][1],&l_1642[2][1],&l_1744,&l_1642[2][1],&l_1642[2][1],&l_1744,&l_1744,&l_1744,&l_1744},{&l_1744,(void*)0,&l_1642[2][1],&l_1642[2][1],(void*)0,&l_1744,&l_1642[2][1],(void*)0,&l_1642[2][1],&l_1744},{&l_1642[2][1],(void*)0,(void*)0,(void*)0,&l_1642[2][1],(void*)0,&l_1744,&l_1744,(void*)0,&l_1642[2][1]},{&l_1642[2][1],&l_1642[2][1],&l_1642[2][1],&l_1642[2][1],&l_1642[2][1],&l_1744,&l_1642[2][1],&l_1744,&l_1642[2][1],&l_1642[2][1]},{&l_1744,&l_1642[2][1],&l_1744,&l_1642[2][1],&l_1642[2][1],&l_1642[2][1],&l_1642[2][1],&l_1642[2][1],&l_1642[2][1],&l_1744}};
        int i, j, k;
        for (i = 0; i < 8; i++)
            l_1615[i] = 0x13L;
        for (i = 0; i < 1; i++)
            l_1684[i] = 6L;
        if ((safe_mul_func_uint8_t_u_u(0UL, (safe_mul_func_uint64_t_u_u(0x60A7212D5BDDD4D4LL, (!((((*g_505) |= ((**g_753) = (safe_sub_func_int8_t_s_s(0xD5L, (((safe_mul_func_uint16_t_u_u((safe_mul_func_uint16_t_u_u((safe_rshift_func_int64_t_s_u((((&g_411 != l_1545) >= ((0x9A35L ^ ((**g_1395) = (&g_1395 == ((*l_1546) = &g_1395)))) > l_1528[1][0][0])) && 4294967292UL), 17)), l_1548)), l_13)) | (****g_1208)) >= 0UL))))) != l_1549) <= l_1548)))))))
        { /* block id: 651 */
            int32_t *l_1550 = &l_1548;
            int32_t **l_1554 = &g_1526[2][2];
            ++l_1551;
            (*l_1554) = (void*)0;
            return g_421;
        }
        else
        { /* block id: 655 */
            int32_t *l_1555 = &g_467;
            int32_t *l_1556 = &l_1548;
            int32_t *l_1557[9][4] = {{&g_312[2],&g_312[5],&g_312[5],&g_312[2]},{&g_139,&g_312[5],&g_212,&g_312[5]},{&g_312[5],&g_212,&g_212,&g_212},{&g_139,&g_139,&g_312[5],&g_212},{&g_312[2],&g_212,&g_312[2],&g_312[5]},{&g_312[2],&g_312[5],&g_312[5],&g_312[2]},{&g_139,&g_312[5],&g_212,&g_312[5]},{&g_312[5],&g_212,&g_212,&g_212},{&g_139,&g_139,&g_312[5],&g_212}};
            uint32_t l_1561 = 0xF0F56DC1L;
            int16_t *l_1582 = &l_13;
            int16_t **l_1581 = &l_1582;
            uint16_t l_1593 = 65534UL;
            int16_t l_1595 = (-1L);
            int8_t l_1653 = 8L;
            uint32_t l_1681[2][8] = {{0x5A640FB2L,0x5A640FB2L,3UL,0x5A640FB2L,0x5A640FB2L,3UL,0x5A640FB2L,0x5A640FB2L},{5UL,0x5A640FB2L,5UL,5UL,0x5A640FB2L,5UL,5UL,0x5A640FB2L}};
            uint8_t l_1710 = 1UL;
            uint64_t l_1711 = 0x4C0D85CF9BD38D7ALL;
            int32_t l_1761 = 0L;
            int i, j;
            l_1561--;
            for (l_1548 = 19; (l_1548 != 19); l_1548 = safe_add_func_int8_t_s_s(l_1548, 8))
            { /* block id: 659 */
                int16_t l_1570[9][10] = {{(-1L),(-8L),0x0EA3L,(-7L),0xE169L,(-1L),0xE169L,(-7L),0x0EA3L,(-8L)},{0xE169L,(-8L),0x3B24L,0x9138L,0x1477L,0x51C5L,0x0EA3L,0x7B02L,0x0EA3L,0x51C5L},{3L,(-8L),0xE169L,(-8L),0x3B24L,0x9138L,0x1477L,0x51C5L,0x0EA3L,0x7B02L},{0x15D1L,0xAF2BL,0xE169L,0x51C5L,(-1L),0x51C5L,0xE169L,0xAF2BL,0x15D1L,0x7B02L},{0x0EA3L,0x51C5L,0x1477L,0x9138L,0x3B24L,(-8L),0xE169L,(-8L),0x3B24L,0x9138L},{3L,0xAF2BL,3L,0x9138L,0xE169L,0x7B02L,0x1477L,(-1L),0x15D1L,(-1L)},{3L,(-8L),0x15D1L,0x51C5L,0x15D1L,(-8L),3L,(-1L),0x0EA3L,0xAF2BL},{0x0EA3L,(-1L),3L,(-8L),0x15D1L,0x51C5L,0x15D1L,(-8L),3L,(-1L)},{0x15D1L,(-1L),0x1477L,0x7B02L,0xE169L,0x9138L,3L,0xAF2BL,3L,0x9138L}};
                int32_t l_1612 = 0x70766CF6L;
                int64_t l_1613[9][5] = {{0x856871E5C660B4CCLL,1L,1L,0x856871E5C660B4CCLL,(-1L)},{0x6C1E3735FCFB227DLL,0L,1L,7L,4L},{7L,0x1D9C53A9D365DD22LL,0xC2CD42A958E6F29ALL,5L,1L},{(-1L),0x6C1E3735FCFB227DLL,7L,7L,0x6C1E3735FCFB227DLL},{(-1L),9L,1L,0x856871E5C660B4CCLL,0x6C1E3735FCFB227DLL},{0x1D9C53A9D365DD22LL,0xDF70227D9E4BF346LL,0L,5L,1L},{9L,5L,(-1L),4L,4L},{0x1D9C53A9D365DD22LL,1L,0x1D9C53A9D365DD22LL,(-1L),(-1L)},{(-1L),1L,5L,9L,0xDF70227D9E4BF346LL}};
                int32_t l_1614[4][7] = {{1L,0L,0x8FD3EFFDL,(-1L),1L,0x5976B279L,0x5976B279L},{0x8FD3EFFDL,0L,1L,0L,0x8FD3EFFDL,(-1L),1L},{(-10L),(-9L),0L,(-1L),0x726EA29FL,(-1L),0L},{1L,1L,0xBAF0FF95L,1L,(-9L),0x5976B279L,(-10L)}};
                int i, j;
                for (g_163 = 0; (g_163 < 58); g_163 = safe_add_func_uint8_t_u_u(g_163, 2))
                { /* block id: 662 */
                    uint32_t l_1592[1];
                    int32_t *l_1596[10][5][2] = {{{&l_1548,&l_1560},{(void*)0,&g_75},{(void*)0,(void*)0},{&l_1548,&g_212},{&g_212,(void*)0}},{{&l_1558[6][5][2],&l_1558[6][5][2]},{&g_212,&g_139},{&g_75,&g_312[2]},{&g_312[2],&l_1558[9][2][0]},{&l_1558[6][5][2],&g_312[2]}},{{&g_139,&g_212},{&g_139,&g_312[2]},{&l_1558[6][5][2],&l_1558[9][2][0]},{&g_312[2],&g_312[2]},{&g_75,&g_139}},{{&g_212,&l_1558[6][5][2]},{&l_1558[6][5][2],(void*)0},{&g_212,&g_212},{&l_1548,(void*)0},{(void*)0,&g_75}},{{(void*)0,&l_1560},{&l_1548,(void*)0},{&g_139,(void*)0},{(void*)0,&l_1548},{&l_1560,&g_212}},{{&g_312[2],&l_1560},{&g_312[3],&g_312[2]},{&l_1558[6][5][2],(void*)0},{&l_1548,&l_1560},{(void*)0,&l_1560}},{{&l_1548,(void*)0},{&l_1558[6][5][2],&g_312[2]},{&g_312[3],&l_1560},{&g_312[2],&g_212},{(void*)0,(void*)0}},{{&l_1560,&l_1558[5][6][2]},{(void*)0,(void*)0},{(void*)0,&g_212},{&g_212,(void*)0},{(void*)0,&g_139}},{{(void*)0,&g_312[2]},{&l_1560,&l_1558[6][5][2]},{&l_1548,&l_1548},{&l_1558[9][2][0],(void*)0},{(void*)0,&g_312[2]}},{{(void*)0,(void*)0},{&g_312[2],(void*)0},{&l_1548,&l_1560},{&l_1548,(void*)0},{&g_312[2],(void*)0}}};
                    uint64_t *l_1601 = &l_1551;
                    int i, j, k;
                    for (i = 0; i < 1; i++)
                        l_1592[i] = 18446744073709551609UL;
                    for (l_1560 = 0; (l_1560 >= (-13)); l_1560 = safe_sub_func_int32_t_s_s(l_1560, 5))
                    { /* block id: 665 */
                        int16_t **l_1580 = &g_1326;
                        int32_t l_1590[4][9] = {{0xCD2511BFL,0xCD2511BFL,0xE0698403L,0xE51EAF95L,0x6C6B46DDL,0xE0698403L,0x6C6B46DDL,0xE51EAF95L,0xE0698403L},{0xCD2511BFL,0xCD2511BFL,0xE0698403L,0xE51EAF95L,0x6C6B46DDL,0xE0698403L,0x6C6B46DDL,0xE51EAF95L,0xE0698403L},{0xCD2511BFL,0xCD2511BFL,0xE0698403L,0xE51EAF95L,0x6C6B46DDL,0xE0698403L,0x6C6B46DDL,0xE51EAF95L,0xE0698403L},{0xCD2511BFL,0xCD2511BFL,0xE0698403L,0xE51EAF95L,0x6C6B46DDL,0xE0698403L,0x6C6B46DDL,0xE51EAF95L,0xE0698403L}};
                        int32_t l_1591 = (-1L);
                        int64_t *l_1594 = &g_200;
                        int32_t **l_1598 = &l_1596[4][4][0];
                        int i, j;
                        if (l_1570[5][4])
                            break;
                        (*l_1598) = (((~((l_1559 |= (***g_1394)) <= ((*l_1582) = (((safe_div_func_uint64_t_u_u((safe_rshift_func_int8_t_s_s((((18446744073709551615UL == ((*g_1419) = ((*l_1594) |= ((l_1558[5][1][0] = (((((l_1558[7][6][0] & ((((safe_sub_func_int32_t_s_s(0x440DC349L, (l_1591 = (safe_sub_func_int16_t_s_s(((l_1580 != (l_1581 = (void*)0)) | (((((safe_div_func_int16_t_s_s((g_1587 &= (safe_div_func_int16_t_s_s(0xE8DAL, (**g_1395)))), (((((safe_sub_func_uint8_t_u_u((l_1590[0][5] = ((l_1570[0][8] && 1L) & l_1590[2][4])), l_1591)) <= 0x8EAAA1CCECCA200ELL) >= 0x64L) < 0x493E38D8DB5D16C7LL) , (**g_1395)))) , 18446744073709551615UL) >= l_1592[0]) != (*l_1555)) ^ (*g_1419))), (****g_1067)))))) | 0xC3L) | 0x36L) >= (*g_730))) ^ 0x0DL) > 0x209F1CC0L) , l_1593) | (*g_730))) & 0xEBL)))) , &g_975) != &g_975), l_1570[5][4])), g_925[8])) , (*l_1555)) , l_1558[6][5][2])))) ^ l_1595) , l_1596[4][4][0]);
                        return l_1559;
                    }
                    (*l_1555) = (safe_mul_func_uint8_t_u_u(253UL, ((((*l_1601) &= (*g_730)) ^ ((((safe_rshift_func_uint32_t_u_s((((l_1570[4][2] , (safe_add_func_int32_t_s_s(8L, l_1570[5][4]))) && (g_1606 == &g_1607)) != (****g_1067)), (l_1608[5] == (void*)0))) != 0x1C08495F1D67E07FLL) , (**g_553)) == l_1558[2][2][2])) , g_1611[0][3])));
                    --l_1615[7];
                }
            }
            if (l_1615[6])
            { /* block id: 684 */
                uint32_t l_1625 = 1UL;
                const uint8_t l_1680 = 0UL;
                int32_t l_1682 = 0L;
                for (l_13 = 18; (l_13 > (-20)); --l_13)
                { /* block id: 687 */
                    uint16_t l_1624[2][7] = {{65535UL,65535UL,0x52BBL,65535UL,65535UL,0x52BBL,65535UL},{0x3589L,65534UL,65534UL,0x3589L,65534UL,65534UL,0x3589L}};
                    int16_t l_1641 = 0L;
                    uint8_t *l_1654[4][9][7] = {{{&g_992,&g_217,&g_925[6],&g_217,&l_1615[2],&g_217,&g_925[6]},{&g_217,&g_217,&g_925[6],&g_925[6],&g_992,&g_925[3],(void*)0},{&l_1615[7],&g_925[6],&g_925[6],&g_992,&g_217,(void*)0,&g_217},{&l_1615[4],(void*)0,&g_217,&g_925[6],&g_992,(void*)0,(void*)0},{&g_925[6],&l_1615[2],&g_992,&g_992,&l_1615[2],&g_925[6],(void*)0},{(void*)0,&g_992,&g_925[6],&g_217,(void*)0,&l_1615[4],&g_217},{(void*)0,&g_217,&g_992,&g_925[6],&g_925[6],&l_1615[7],(void*)0},{&g_925[3],&g_992,&g_925[6],&g_925[6],&g_217,&g_217,&g_925[6]},{&g_217,&l_1615[2],&g_217,&g_925[6],&g_217,&g_992,&l_1615[2]}},{{&g_925[6],(void*)0,&l_1615[7],&g_925[6],&g_925[6],&g_925[6],&g_163},{&g_163,&g_925[6],&g_217,&g_217,&g_163,&g_992,&g_992},{(void*)0,&g_217,(void*)0,&g_992,(void*)0,&g_217,(void*)0},{(void*)0,&g_217,&g_925[3],&g_925[6],&g_217,&l_1615[7],&g_217},{&g_925[6],(void*)0,&g_925[6],&g_992,&g_163,&g_992,(void*)0},{&g_163,&g_925[3],&g_925[6],(void*)0,(void*)0,&g_163,(void*)0},{&g_925[6],&g_217,&g_217,&g_925[6],(void*)0,&g_925[3],&l_1615[4]},{(void*)0,&g_925[6],(void*)0,&g_163,&g_163,&g_925[6],&g_217},{&g_925[6],&g_163,&g_163,(void*)0,&g_925[6],(void*)0,&l_1615[4]}},{{&g_925[3],(void*)0,&g_925[6],&g_217,&g_217,&g_925[6],(void*)0},{&g_163,(void*)0,(void*)0,&g_925[6],&g_925[3],&g_163,(void*)0},{&g_992,&g_163,&g_992,&g_925[6],(void*)0,&g_925[6],&g_217},{&g_992,&g_925[6],&l_1615[4],&g_925[6],(void*)0,&g_217,&g_217},{&g_925[6],&g_217,&l_1615[2],&g_217,&g_925[6],&g_217,&g_992},{&l_1615[7],&g_925[3],&g_925[6],(void*)0,&l_1615[4],&g_925[6],&g_925[3]},{&g_163,(void*)0,&g_217,&g_163,&l_1615[7],&g_163,&g_217},{&l_1615[7],(void*)0,&g_163,&g_925[6],&g_217,&g_925[6],&g_163},{&g_925[6],&g_925[6],&g_163,(void*)0,&g_992,(void*)0,&g_217}},{{&g_992,&l_1615[4],&g_217,&g_992,&g_925[6],&g_925[6],(void*)0},{&g_992,&l_1615[7],&g_925[6],&l_1615[4],&g_992,&g_925[3],&l_1615[7]},{&g_163,&g_217,&l_1615[2],&l_1615[2],&g_217,&g_163,&l_1615[7]},{&g_925[3],&g_992,&l_1615[4],&g_925[6],&l_1615[7],&g_992,(void*)0},{&g_925[6],&g_925[6],&g_992,&g_217,&l_1615[4],&g_992,&g_217},{(void*)0,&g_992,(void*)0,&g_163,&g_925[6],&g_925[6],&g_163},{&g_925[6],&g_217,&g_925[6],&g_163,(void*)0,&l_1615[7],&g_217},{&g_163,&l_1615[7],&g_163,&g_217,(void*)0,&g_163,&g_925[3]},{&g_925[6],&l_1615[4],(void*)0,&g_925[6],&g_925[3],&l_1615[7],&g_992}}};
                    uint16_t ***l_1679 = &g_553;
                    int i, j, k;
                    for (g_545 = 24; (g_545 >= 19); --g_545)
                    { /* block id: 690 */
                        int32_t l_1637 = (-4L);
                        uint8_t *l_1638 = &g_992;
                        (*l_1555) = ((((((safe_div_func_int64_t_s_s((((l_1624[1][6] & ((((l_1625 > ((0x88116825310630E0LL != (!((safe_div_func_uint16_t_u_u(((safe_sub_func_uint8_t_u_u(((safe_sub_func_uint32_t_u_u(((safe_div_func_int16_t_s_s(((safe_lshift_func_uint8_t_u_s((g_217 |= ((*l_1638) &= ((l_1637 , l_1624[0][5]) > 0x6AEFBA1DL))), 2)) ^ ((((*g_730) > ((((safe_add_func_uint64_t_u_u(l_1637, (l_1625 ^ 1UL))) || l_1641) , l_1637) == (*g_554))) | (*g_281)) >= l_1641)), 1L)) , 4294967295UL), l_1637)) ^ 0xACE9FB90L), 4L)) >= l_1625), (**g_1395))) , l_1642[2][1]))) , l_1625)) && (-1L)) ^ (*g_1326)) ^ 0UL)) | (*g_730)) < (*l_1555)), l_1637)) , (*g_281)) && (*g_281)) | (****g_1067)) <= 0x27L) , l_1551);
                        (*l_1546) = (*l_1546);
                    }
                    l_1684[0] |= (((safe_rshift_func_uint64_t_u_s((((safe_mul_func_int16_t_s_s(((safe_lshift_func_int32_t_s_u(l_1615[7], 10)) || l_1641), (*g_554))) == (((safe_mod_func_uint16_t_u_u((l_1682 = (safe_mul_func_int16_t_s_s(((((l_1653 < (++g_925[4])) >= (((***g_1394) | (safe_add_func_int32_t_s_s((safe_lshift_func_int32_t_s_u(l_1558[2][3][0], 21)), (safe_mul_func_int64_t_s_s(((safe_rshift_func_int32_t_s_s((l_1558[5][4][0] , (safe_sub_func_uint16_t_u_u((safe_sub_func_int32_t_s_s(((*l_1556) = ((*l_1555) = ((((safe_mul_func_uint64_t_u_u((safe_add_func_int32_t_s_s((safe_lshift_func_int32_t_s_s((safe_div_func_int64_t_s_s(((*g_1419) |= (l_1641 <= (safe_div_func_uint16_t_u_u((((*l_1679) = &g_554) != &g_554), 0xD306L)))), l_1641)), l_1680)), 1UL)), l_1641)) , (***g_1068)) && (**g_1395)) | (*l_1555)))), l_1680)), l_1551))), l_1681[1][1])) > l_1625), l_1624[0][6]))))) & l_1615[7])) ^ (*g_554)) | g_322), 0x934FL))), l_1624[1][3])) | 0xFB62L) <= 65535UL)) , 0x477D42B6A0E0CE8ELL), 29)) <= l_1624[1][6]) == l_1683);
                }
            }
            else
            { /* block id: 704 */
                int8_t *l_1690 = (void*)0;
                int8_t *l_1691 = &g_694;
                uint8_t l_1706 = 0UL;
                int8_t *l_1709[9] = {&l_1653,&l_1653,&l_1653,&l_1653,&l_1653,&l_1653,&l_1653,&l_1653,&l_1653};
                uint8_t ***l_1726 = &g_410;
                uint8_t ****l_1725[7][8][2] = {{{&l_1726,&l_1726},{(void*)0,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726},{(void*)0,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726}},{{&l_1726,&l_1726},{&l_1726,(void*)0},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,(void*)0},{&l_1726,(void*)0},{&l_1726,&l_1726}},{{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,(void*)0},{(void*)0,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726},{(void*)0,(void*)0},{&l_1726,&l_1726}},{{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,(void*)0},{&l_1726,(void*)0},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,(void*)0}},{{(void*)0,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726},{(void*)0,(void*)0},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,(void*)0}},{{&l_1726,(void*)0},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,(void*)0},{(void*)0,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726}},{{(void*)0,(void*)0},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,&l_1726},{&l_1726,(void*)0},{&l_1726,(void*)0},{&l_1726,&l_1726},{&l_1726,&l_1726}}};
                uint8_t *****l_1724 = &l_1725[1][7][1];
                int32_t l_1731 = 0xD537D54DL;
                int32_t l_1732 = 1L;
                uint32_t *l_1745 = &l_1528[5][1][0];
                int i, j, k;
                if ((safe_mod_func_int64_t_s_s(((+(((((safe_div_func_uint64_t_u_u(4UL, ((**g_1418) = (((((((*l_1691) |= l_1558[6][3][0]) != (g_1611[0][3] = 3L)) > ((((g_1206 &= ((safe_lshift_func_int16_t_s_s((safe_div_func_int64_t_s_s((+l_1551), (safe_mul_func_int64_t_s_s((((safe_add_func_int32_t_s_s(l_1701, (((***g_1209) >= (safe_div_func_uint32_t_u_u(l_1706, l_1706))) | ((safe_add_func_int8_t_s_s(l_1706, 0L)) < (*g_1326))))) | (*g_505)) >= (-4L)), l_1706)))), 4)) <= l_1706)) >= 0x3DL) != 0xA49393BAB72CC9C9LL) | 0x922DBDEB05B29FF0LL)) | 0xC18E34B81771B970LL) , l_1710) || (-1L))))) == l_1558[9][6][1]) | 0x61323E7FC45B0AB8LL) | (-7L)) | 0xE1L)) > l_1706), l_1711)))
                { /* block id: 709 */
                    struct S0 **l_1713 = &l_1712;
                    uint8_t *****l_1727 = &l_1725[1][7][1];
                    int32_t l_1728 = 8L;
                    if (((((*l_1713) = l_1712) != (*g_1258)) , ((((*g_554) &= (safe_sub_func_uint64_t_u_u(0x9546C2F95BD5EE77LL, ((safe_add_func_int32_t_s_s((((safe_add_func_int16_t_s_s((((0xCCD15DD423F08C9ELL != (*g_730)) | ((void*)0 != l_1720)) < ((safe_mul_func_uint8_t_u_u((((**g_1418) ^= (((l_1727 = l_1724) == (void*)0) < 0xDFC16F26DDCCACA4LL)) || l_1728), 246UL)) , 255UL)), 65535UL)) == l_1728) & 1UL), (**g_753))) && 3L)))) <= l_1728) & (**g_1395))))
                    { /* block id: 714 */
                        return g_245;
                    }
                    else
                    { /* block id: 716 */
                        l_1557[3][1] = (void*)0;
                        return (*l_1555);
                    }
                }
                else
                { /* block id: 720 */
                    uint8_t l_1733 = 0UL;
                    int32_t l_1747 = 0x484CE94BL;
                    int32_t l_1748 = 0xCDBFAA2DL;
                    int32_t l_1750 = 0xBDE0C99AL;
                    int16_t **l_1759 = &g_1326;
                    for (g_467 = 0; (g_467 > 8); ++g_467)
                    { /* block id: 723 */
                        l_1733--;
                        if (l_1733)
                            continue;
                        return l_1733;
                    }
                    if ((((*l_1581) = (*l_1581)) == (**g_1394)))
                    { /* block id: 729 */
                        uint8_t **l_1738[10][4] = {{&g_411,&g_411,&g_411,&g_411},{(void*)0,&g_411,&g_411,(void*)0},{&g_411,(void*)0,&g_411,&g_411},{&g_411,&g_411,&g_411,(void*)0},{&g_411,&g_411,&g_411,&g_411},{(void*)0,&g_411,&g_411,(void*)0},{&g_411,(void*)0,&g_411,&g_411},{(void*)0,&g_411,&g_411,&g_411},{(void*)0,(void*)0,(void*)0,(void*)0},{&g_411,&g_411,&g_411,&g_411}};
                        uint64_t *l_1743[6][8] = {{(void*)0,&l_1551,&g_602,(void*)0,&g_602,&l_1551,(void*)0,&g_513},{&g_159,&l_1711,&g_159,(void*)0,(void*)0,&g_159,&l_1711,&g_159},{&g_513,(void*)0,&l_1551,&g_602,(void*)0,&g_602,&l_1551,(void*)0},{&g_159,&l_1551,&g_513,&g_159,&g_602,&g_602,&g_159,&g_513},{(void*)0,(void*)0,&g_159,&l_1711,&g_159,&g_159,&g_159,&l_1711},{&g_513,&l_1711,&g_513,&g_602,&l_1711,&l_1551,&l_1551,&l_1711}};
                        int32_t l_1746 = 0x615A5D2DL;
                        int32_t l_1749 = 0L;
                        int32_t l_1751 = 2L;
                        int i, j;
                        l_1684[0] = (((((****g_1067) , (safe_lshift_func_uint32_t_u_s((***g_503), (l_1738[8][1] == &g_411)))) , l_1558[3][5][0]) > (((l_1733 || (((l_1747 = (safe_div_func_uint32_t_u_u(((safe_sub_func_uint64_t_u_u(((*g_730) = (l_1744 |= (*g_730))), (((*g_1023) , (*g_1606)) != l_1745))) <= 0x474A8842L), l_1746))) && l_1731) != 1UL)) | l_1748) >= (**g_1418))) && 0x4AF1L);
                        --g_1752;
                    }
                    else
                    { /* block id: 735 */
                        uint32_t ** const *l_1756 = (void*)0;
                        uint32_t ** const **l_1755 = &l_1756;
                        (*l_1556) = (l_1732 |= (l_1755 != ((~l_1758) , (void*)0)));
                        l_1759 = (*g_1394);
                        (*l_1555) |= 0x1E60FD2BL;
                    }
                }
                (**l_1609) = (**l_1609);
                return g_419;
            }
            l_1763++;
        }
        if (l_1766)
        { /* block id: 747 */
            int64_t l_1767 = 0x98DC4362E61295B2LL;
            l_1768--;
        }
        else
        { /* block id: 749 */
            (**l_1609) = &l_1684[0];
        }
        l_1772[1]--;
        l_1558[6][5][2] = (((safe_mul_func_uint32_t_u_u(((***g_503) = (safe_lshift_func_uint8_t_u_u((safe_unary_minus_func_int64_t_s((safe_mod_func_uint16_t_u_u((g_1161.f0 , ((g_1789 = ((0x7BL & ((((((*l_1720) = &g_807) == (*g_1170)) & ((0x59L || (-1L)) < 0x5DD15A4F0A0A5774LL)) , (safe_rshift_func_uint8_t_u_u(((g_1786 = l_1784) == (((((((*l_1609) != (*l_1609)) , 0x8339AC4F3C30353CLL) <= l_1551) == 0UL) < 0xC6CDCF6CL) , &l_1785)), 1))) , 0xFBL)) , g_163)) , 1UL)), 0xEBF7L)))), 7))), 0xFC666A20L)) , 0xD954EC07L) ^ l_1684[0]);
    }
    else
    { /* block id: 758 */
        int16_t l_1797 = (-1L);
        struct S0 *l_1799[8] = {&g_1026,&g_1026,&g_1026,&g_1026,&g_1026,&g_1026,&g_1026,&g_1026};
        const uint16_t *l_1812 = &g_118;
        const uint16_t **l_1811 = &l_1812;
        const uint16_t ***l_1810 = &l_1811;
        const uint16_t ****l_1813 = (void*)0;
        const uint16_t ****l_1814 = &l_1810;
        uint32_t * const *l_1819 = &g_505;
        int32_t l_1821 = 0xCE9575B3L;
        uint8_t l_1823 = 0UL;
        uint8_t l_1857[6] = {0x9DL,0x9DL,0x9DL,0x9DL,0x9DL,0x9DL};
        uint8_t l_1861 = 1UL;
        int16_t l_1869 = 0xE5D4L;
        int32_t l_1881 = 8L;
        uint8_t *** const l_1887[9][2] = {{&l_1545,&l_1545},{&l_1545,&l_1545},{&l_1545,&l_1545},{&l_1545,&l_1545},{&l_1545,&l_1545},{&l_1545,&l_1545},{&l_1545,&l_1545},{&l_1545,&l_1545},{&l_1545,&l_1545}};
        int8_t l_1914 = 0xF7L;
        uint16_t l_1938 = 0xA169L;
        uint64_t l_1980 = 6UL;
        int32_t l_2013 = 0xAAE9C929L;
        int i, j;
        for (g_1789 = (-21); (g_1789 > 13); g_1789++)
        { /* block id: 761 */
            uint16_t l_1794[3][3];
            int32_t l_1798 = 0xE5D3742BL;
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                    l_1794[i][j] = 65531UL;
            }
            for (g_82 = 0; (g_82 < 48); g_82 = safe_add_func_uint8_t_u_u(g_82, 6))
            { /* block id: 764 */
                return l_1794[2][2];
            }
            l_1798 |= (safe_lshift_func_uint16_t_u_s(l_1797, 2));
            for (g_694 = 0; (g_694 <= 2); g_694 += 1)
            { /* block id: 770 */
                struct S0 **l_1800 = (void*)0;
                struct S0 **l_1801 = &l_1712;
                int8_t l_1804 = (-2L);
                int i, j;
                if (l_1642[g_694][(g_694 + 1)])
                    break;
                (*l_1801) = l_1799[7];
                for (l_13 = 0; (l_13 <= 3); l_13 += 1)
                { /* block id: 775 */
                    if ((&g_730 == &g_730))
                    { /* block id: 776 */
                        int i, j;
                        g_1526[(g_694 + 3)][(l_13 + 4)] = g_1526[(g_694 + 3)][(l_13 + 4)];
                    }
                    else
                    { /* block id: 778 */
                        int i, j, k;
                        l_1798 = (l_1804 |= (safe_mod_func_uint32_t_u_u(((**g_753) = l_1528[(l_13 + 3)][(g_694 + 1)][g_694]), 1L)));
                    }
                }
                return l_1642[g_694][(g_694 + 1)];
            }
        }
        if (((l_1807 = g_1805) != ((((safe_add_func_uint16_t_u_u((((*g_1023) , (*g_1067)) != ((*l_1814) = l_1810)), ((**g_1395) < 0x0E1DL))) < (safe_sub_func_uint64_t_u_u((l_1797 , (safe_lshift_func_uint16_t_u_u(0xB1BEL, (((((l_1819 == l_1820) >= (****g_1067)) , (***g_503)) > l_1821) , g_1822)))), (*g_1419)))) , l_1823) , l_1824[3][0])))
        { /* block id: 789 */
            uint64_t l_1838[9][1] = {{0x701CB2945F4B2211LL},{0x9261227B8BFDA0C2LL},{0x701CB2945F4B2211LL},{0x9261227B8BFDA0C2LL},{0x701CB2945F4B2211LL},{0x9261227B8BFDA0C2LL},{0x701CB2945F4B2211LL},{0x9261227B8BFDA0C2LL},{0x701CB2945F4B2211LL}};
            uint8_t l_1860 = 0x3CL;
            int32_t l_1871 = 0x3F2A8652L;
            int i, j;
            for (g_245 = 0; (g_245 < 6); g_245 = safe_add_func_uint64_t_u_u(g_245, 3))
            { /* block id: 792 */
                int64_t l_1827 = 0x7C9CCE396142CE4FLL;
                int32_t l_1859 = 0L;
                const int32_t l_1864 = (-1L);
                l_1861 ^= ((((((*g_554) < ((l_1827 && ((+(((((safe_lshift_func_uint32_t_u_s(((safe_rshift_func_int64_t_s_s((((((~3L) , ((safe_add_func_int16_t_s_s(((**g_1395) = 0x44FAL), ((((safe_div_func_int32_t_s_s((l_1821 = l_1838[5][0]), l_1838[1][0])) >= (safe_div_func_int8_t_s_s((safe_add_func_int64_t_s_s((((safe_div_func_uint16_t_u_u((safe_div_func_int64_t_s_s((+(((safe_mul_func_int64_t_s_s((((**g_553) || (***g_1068)) && (safe_mul_func_uint8_t_u_u((safe_add_func_int16_t_s_s(((safe_sub_func_uint64_t_u_u(((*g_730) | (*g_281)), 18446744073709551614UL)) >= 0x7491C51325FA3A98LL), (****g_1067))), l_1827))), (*g_1419))) < l_1797) == 2UL)), g_1856)), (*g_554))) & l_1857[3]) ^ l_1838[5][0]), l_1857[4])), 255UL))) , l_1858) >= l_1838[5][0]))) > (-8L))) == 0xD210L) || l_1827) && (****g_1067)), l_1827)) <= l_1827), 10)) != l_1859) , l_1827) ^ l_1860) <= l_1860)) == (*g_554))) >= (**g_1418))) < l_1838[5][0]) , (*g_730)) == l_1838[1][0]) || 0UL);
                for (g_602 = 24; (g_602 != 49); ++g_602)
                { /* block id: 798 */
                    l_1859 &= l_1864;
                    for (l_13 = 0; (l_13 <= 0); l_13 += 1)
                    { /* block id: 802 */
                        uint32_t l_1870 = 0xA1BA9CEEL;
                        int i, j, k;
                        l_1871 = ((l_1528[(l_13 + 3)][(l_13 + 3)][(l_13 + 3)] && (safe_mul_func_uint32_t_u_u(4294967295UL, (l_1838[1][0] , (l_1867[1][2][0] , ((****g_1786) ^= l_1838[4][0])))))) >= ((l_1868 == &l_1838[8][0]) , ((l_1869 != (l_1870 && l_1827)) > 0x5B77L)));
                    }
                }
            }
        }
        else
        { /* block id: 808 */
            uint32_t l_1885 = 0x8FC5158EL;
            int32_t l_1886 = 0xD14E0E3EL;
            uint8_t *** const l_1888 = (void*)0;
            uint16_t ***l_1890 = &g_553;
            uint16_t ****l_1889 = &l_1890;
            uint16_t l_1921 = 65535UL;
            int16_t *l_1925 = &l_13;
            int16_t l_1997 = 5L;
            int32_t l_2033[5];
            int i;
            for (i = 0; i < 5; i++)
                l_2033[i] = (-10L);
            if ((safe_sub_func_uint32_t_u_u(((l_1886 |= (safe_mul_func_uint32_t_u_u((g_1876 , (*g_505)), (((safe_rshift_func_uint64_t_u_s(((safe_mul_func_int8_t_s_s(0L, (0L > l_1821))) == (1UL & ((l_1881 , (((!(safe_sub_func_uint32_t_u_u(((l_1885 , 0xF0701B8CL) , l_1869), 0UL))) >= (-5L)) ^ l_1885)) & (**g_1395)))), 17)) , 0UL) && 4294967286UL)))) ^ l_1885), (-1L))))
            { /* block id: 810 */
                const int16_t **** const l_1891 = (void*)0;
                l_1886 ^= ((((*g_1326) = ((l_1887[3][1] != l_1888) | ((((void*)0 == l_1889) , (*g_1258)) != (void*)0))) , l_1891) != g_1892);
            }
            else
            { /* block id: 813 */
                int16_t ***l_1913 = &g_1395;
                int16_t ****l_1912 = &l_1913;
                int32_t l_1919 = 0L;
                uint64_t *l_1920[4][9][3] = {{{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665},{(void*)0,(void*)0,&g_513},{&g_973,&g_602,&g_665},{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665},{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665},{(void*)0,(void*)0,&g_513}},{{&g_973,&g_602,&g_665},{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665},{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665},{(void*)0,(void*)0,&g_513},{&g_973,&g_602,&g_665},{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665}},{{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665},{(void*)0,(void*)0,&g_513},{&g_973,&g_602,&g_665},{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665},{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665},{(void*)0,(void*)0,&g_513}},{{&g_973,&g_602,&g_665},{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665},{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665},{(void*)0,(void*)0,&g_513},{&g_973,&g_602,&g_665},{&g_82,&g_82,&g_513},{&g_322,&g_322,&g_665}}};
                int32_t l_1934 = 0xB014C24CL;
                uint8_t *l_1949 = &g_925[5];
                uint32_t ***l_1965 = (void*)0;
                int i, j, k;
                if (((safe_add_func_int16_t_s_s(((((safe_sub_func_uint8_t_u_u((((safe_lshift_func_uint32_t_u_u(((safe_div_func_uint32_t_u_u((safe_mul_func_uint16_t_u_u((safe_rshift_func_int16_t_s_s((***g_1893), (safe_rshift_func_uint64_t_u_s((g_16 &= (l_1823 || (((((*l_1912) = &g_1395) == &g_1395) < ((((*g_730) < (l_1914 || (safe_sub_func_int16_t_s_s(l_1861, (safe_div_func_int32_t_s_s(0x51054C98L, l_1919)))))) , 0x8BL) >= 0x09L)) > 0x44L))), 36)))), 0x5ADCL)), 0x6F8536A4L)) >= l_1914), 14)) == 0x92L) && (*g_1326)), l_1921)) | l_1885) > 0UL) | 0x88L), 0xB2F0L)) <= l_1919))
                { /* block id: 816 */
                    const uint32_t l_1930 = 0x808549BCL;
                    uint32_t l_1931 = 0xBAE0ADD5L;
                    int32_t l_1933[4][10] = {{0x91FC48EEL,0x91FC48EEL,0x86190DCEL,0x91FC48EEL,0x91FC48EEL,0x86190DCEL,0x91FC48EEL,0x91FC48EEL,0x86190DCEL,0x91FC48EEL},{0x91FC48EEL,0x55032B46L,0x55032B46L,0x91FC48EEL,0x55032B46L,0x55032B46L,0x91FC48EEL,0x55032B46L,0x55032B46L,0x91FC48EEL},{0x55032B46L,0x91FC48EEL,0x55032B46L,0x55032B46L,0x91FC48EEL,0x55032B46L,0x55032B46L,0x91FC48EEL,0x55032B46L,0x55032B46L},{0x91FC48EEL,0x91FC48EEL,0x86190DCEL,0x91FC48EEL,0x91FC48EEL,0x86190DCEL,0x91FC48EEL,0x91FC48EEL,0x86190DCEL,0x91FC48EEL}};
                    uint32_t l_1935 = 0xD8367FDBL;
                    int32_t *l_1944 = (void*)0;
                    uint32_t l_1950 = 4294967295UL;
                    int8_t *** const *l_1955 = (void*)0;
                    int i, j;
                    l_1886 = (safe_lshift_func_uint8_t_u_u((((0xBAE470559490FAC2LL ^ l_1857[3]) <= ((((*g_505) = (0xD5CA555D11033657LL == (g_1924 , (l_1925 != (***g_1892))))) & (safe_rshift_func_int32_t_s_s((1UL != (safe_mod_func_int64_t_s_s(((*g_1419) &= 1L), (((l_1886 || l_1930) || l_1919) || l_1857[3])))), l_1931))) & 1UL)) , 0UL), l_1921));
lbl_1943:
                    ++l_1935;
                    l_1938--;
                    if (g_1941)
                    { /* block id: 822 */
                        uint32_t l_1942[9][10][2] = {{{4294967294UL,7UL},{4294967295UL,4294967295UL},{0UL,0xBB301531L},{7UL,0xBB301531L},{0UL,4294967295UL},{4294967295UL,7UL},{0xE0AFF57BL,0x4B71FC19L},{0UL,4294967294UL},{0x25E8D8F5L,0xA4422847L},{0xC07083B7L,0xC07083B7L}},{{7UL,0UL},{0xCF50A6A8L,0xBB301531L},{4294967294UL,4294967294UL},{4294967289UL,4294967294UL},{0x4B71FC19L,1UL},{0x4B71FC19L,4294967294UL},{4294967289UL,4294967294UL},{4294967294UL,0xBB301531L},{0xCF50A6A8L,0UL},{7UL,0xC07083B7L}},{{0xC07083B7L,0xA4422847L},{0x25E8D8F5L,4294967294UL},{0UL,0x4B71FC19L},{0xE0AFF57BL,4294967295UL},{0UL,0x70CD6A12L},{0xA4422847L,0xC1E48182L},{4294967295UL,0xC1E48182L},{0xA4422847L,0x70CD6A12L},{0UL,4294967295UL},{0xE0AFF57BL,0x4B71FC19L}},{{0UL,4294967294UL},{0x25E8D8F5L,0xA4422847L},{0xC07083B7L,0xC07083B7L},{7UL,0UL},{0xCF50A6A8L,0xBB301531L},{4294967294UL,4294967294UL},{4294967289UL,4294967294UL},{0x4B71FC19L,1UL},{0x4B71FC19L,4294967294UL},{4294967289UL,4294967294UL}},{{4294967294UL,0xBB301531L},{0xCF50A6A8L,0UL},{7UL,0xC07083B7L},{0xC07083B7L,0xA4422847L},{0x25E8D8F5L,4294967294UL},{0UL,0x4B71FC19L},{0xE0AFF57BL,4294967295UL},{0UL,0x70CD6A12L},{0xA4422847L,0xC1E48182L},{4294967295UL,0xC1E48182L}},{{0xA4422847L,0x70CD6A12L},{0UL,4294967295UL},{0xE0AFF57BL,0x4B71FC19L},{0UL,4294967294UL},{0x25E8D8F5L,0xA4422847L},{0xC07083B7L,0xC07083B7L},{7UL,0UL},{0xCF50A6A8L,0xBB301531L},{4294967294UL,4294967294UL},{4294967289UL,4294967294UL}},{{0x4B71FC19L,1UL},{0x4B71FC19L,4294967294UL},{4294967289UL,4294967294UL},{4294967294UL,0xBB301531L},{0xCF50A6A8L,0UL},{7UL,0xC07083B7L},{0xC07083B7L,0xA4422847L},{0x25E8D8F5L,4294967294UL},{0UL,0x4B71FC19L},{0xE0AFF57BL,4294967295UL}},{{0UL,0x70CD6A12L},{0xA4422847L,0xC1E48182L},{4294967295UL,0xC1E48182L},{0xA4422847L,0x70CD6A12L},{0UL,4294967295UL},{0xE0AFF57BL,0x4B71FC19L},{0UL,4294967294UL},{0x25E8D8F5L,0xA4422847L},{0xC07083B7L,0xC07083B7L},{7UL,0UL}},{{0xCF50A6A8L,0xBB301531L},{4294967294UL,4294967294UL},{4294967289UL,4294967294UL},{0x4B71FC19L,1UL},{0x4B71FC19L,4294967294UL},{4294967289UL,4294967294UL},{4294967294UL,0xBB301531L},{0xCF50A6A8L,0UL},{7UL,0xC07083B7L},{0xC07083B7L,0xA4422847L}}};
                        int i, j, k;
                        l_1942[5][1][0] = 0xC54ABC1AL;
                        (*l_1610) = (void*)0;
                        if (l_1549)
                            goto lbl_1943;
                        l_1944 = &l_1821;
                    }
                    else
                    { /* block id: 827 */
                        int8_t l_1956 = 0x4AL;
                        (**l_1609) = (void*)0;
                        l_1886 |= ((((safe_rshift_func_int16_t_s_u((l_1949 != (void*)0), (l_1950 , (--(***g_1068))))) , ((****g_1067) & 1L)) < ((65532UL & ((((safe_rshift_func_int8_t_s_u(((void*)0 != l_1955), 3)) ^ l_1956) , (*g_1806)) < l_1857[4])) < l_1857[2])) >= 9UL);
                    }
                }
                else
                { /* block id: 832 */
                    if (l_1934)
                    { /* block id: 833 */
                        uint32_t l_1962 = 0x03E9F197L;
                        uint8_t l_1969[6][4][2] = {{{5UL,1UL},{5UL,1UL},{1UL,1UL},{1UL,1UL}},{{5UL,1UL},{5UL,1UL},{1UL,1UL},{1UL,1UL}},{{5UL,1UL},{5UL,1UL},{1UL,1UL},{1UL,1UL}},{{5UL,1UL},{5UL,1UL},{1UL,1UL},{1UL,1UL}},{{5UL,1UL},{5UL,1UL},{1UL,1UL},{1UL,1UL}},{{5UL,1UL},{5UL,1UL},{1UL,1UL},{1UL,1UL}}};
                        int32_t l_1970 = 0xE29722FDL;
                        int i, j, k;
                        g_1971 = (safe_add_func_uint64_t_u_u((((((((*g_730) = (l_1970 = ((safe_sub_func_int16_t_s_s(((~l_1934) <= ((l_1962 &= ((void*)0 != &l_1949)) >= ((*l_1925) = ((***l_1913) = (safe_mul_func_int8_t_s_s(l_1934, (l_1869 <= ((&l_1820 == ((*g_1786) = l_1965)) == (safe_lshift_func_int64_t_s_u((l_1921 >= ((-8L) ^ 65535UL)), l_1968)))))))))), 0xDABDL)) , l_1969[2][2][0]))) ^ g_322) , l_1919) & (*g_554)) & l_1969[5][3][0]) ^ l_1919), 0x22004CDF0C5EF0F6LL));
                        return l_1886;
                    }
                    else
                    { /* block id: 842 */
                        return g_818.f0;
                    }
                }
                if (l_1914)
                { /* block id: 846 */
                    (*l_1610) = &l_1886;
                }
                else
                { /* block id: 848 */
                    if (l_1919)
                    { /* block id: 849 */
                        uint16_t l_1972 = 0xAF37L;
                        int32_t ****l_1974[7][8][4] = {{{&l_1609,(void*)0,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{(void*)0,(void*)0,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{(void*)0,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,(void*)0,&l_1609},{&l_1609,(void*)0,&l_1609,&l_1609}},{{&l_1609,&l_1609,&l_1609,&l_1609},{(void*)0,(void*)0,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{(void*)0,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,(void*)0,&l_1609},{&l_1609,(void*)0,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609}},{{(void*)0,(void*)0,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{(void*)0,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,(void*)0,&l_1609},{&l_1609,(void*)0,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{(void*)0,(void*)0,&l_1609,&l_1609}},{{&l_1609,&l_1609,&l_1609,&l_1609},{(void*)0,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,(void*)0,&l_1609},{&l_1609,(void*)0,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{(void*)0,(void*)0,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609}},{{(void*)0,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,(void*)0,&l_1609},{&l_1609,(void*)0,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{(void*)0,(void*)0,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{(void*)0,&l_1609,&l_1609,&l_1609}},{{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,(void*)0,&l_1609},{&l_1609,&l_1609,(void*)0,&l_1609},{&l_1609,&l_1609,&l_1609,(void*)0},{&l_1609,&l_1609,&l_1609,&l_1609}},{{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,(void*)0,&l_1609},{&l_1609,&l_1609,(void*)0,&l_1609},{&l_1609,&l_1609,&l_1609,(void*)0},{&l_1609,&l_1609,&l_1609,&l_1609},{&l_1609,&l_1609,&l_1609,&l_1609}}};
                        int i, j, k;
                        l_1821 &= (((((l_1885 > (((l_1972 >= l_1972) , (g_1973 == (void*)0)) , ((((void*)0 != l_1974[6][0][2]) ^ l_1921) != (!(l_1797 == (*g_730)))))) == (*g_1419)) , (-3L)) <= (*g_1326)) < 0x6C3E8C0CL);
                        return l_1938;
                    }
                    else
                    { /* block id: 852 */
                        uint32_t *l_1978[1][3];
                        int32_t l_1979[2];
                        int i, j;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 3; j++)
                                l_1978[i][j] = (void*)0;
                        }
                        for (i = 0; i < 2; i++)
                            l_1979[i] = 0x6305E483L;
                        l_1886 = (l_1979[0] = (safe_lshift_func_int32_t_s_u(((*g_1419) <= 0x6BD5CF56933F0409LL), ((l_1978[0][2] == (g_1924.f0 , &l_1885)) > ((**g_1395) ^ ((*l_1925) = (**g_1395)))))));
                        return l_1886;
                    }
                }
                l_1980--;
            }
            for (g_1971 = 0; (g_1971 <= 9); g_1971 += 1)
            { /* block id: 863 */
                int32_t l_1985 = 0x6D0B5106L;
                int32_t l_1986 = 1L;
                int8_t l_2007 = 0x82L;
                uint32_t l_2017 = 4294967291UL;
                for (l_1768 = 0; (l_1768 <= 1); l_1768 += 1)
                { /* block id: 866 */
                    for (l_1869 = 0; (l_1869 <= 9); l_1869 += 1)
                    { /* block id: 869 */
                        int32_t l_1983 = (-1L);
                        int i;
                        l_1881 &= (l_1983 = g_925[g_1971]);
                    }
                }
                if (l_1984)
                    break;
                l_1986 = l_1985;
                for (g_212 = 7; (g_212 >= 0); g_212 -= 1)
                { /* block id: 878 */
                    int32_t *l_1995 = (void*)0;
                    uint16_t l_1998 = 65535UL;
                    for (l_1861 = 0; (l_1861 <= 1); l_1861 += 1)
                    { /* block id: 881 */
                        int64_t l_1993 = 8L;
                        uint64_t l_1994 = 1UL;
                        int i, j;
                        l_1994 = (safe_lshift_func_uint16_t_u_u((0x79B0ECA3L == (safe_div_func_uint64_t_u_u(g_282[l_1861][(l_1861 + 1)], ((safe_lshift_func_int64_t_s_u((*g_1419), 13)) , l_1993)))), 1));
                        (**l_1609) = l_1995;
                        if (g_282[l_1861][(l_1861 + 1)])
                            break;
                        l_1821 |= (l_1881 = g_1996[0]);
                    }
                    (*l_1610) = &l_1886;
                    l_1886 |= l_1997;
                    l_1998 ^= l_1997;
                }
                for (l_1886 = 0; (l_1886 <= 9); l_1886 += 1)
                { /* block id: 894 */
                    uint16_t l_1999[4] = {65535UL,65535UL,65535UL,65535UL};
                    uint8_t l_2000 = 0x7EL;
                    uint16_t * const *l_2012 = &g_554;
                    int32_t l_2014 = 0xE104606DL;
                    int8_t l_2032 = 7L;
                    int i;
                    l_1999[2] = 1L;
                    for (g_692 = 3; (g_692 <= 9); g_692 += 1)
                    { /* block id: 898 */
                        if (l_1986)
                            break;
                        --l_2000;
                    }
                    l_2014 = (l_1881 = (safe_sub_func_int32_t_s_s(((((*g_1806) = ((safe_rshift_func_uint16_t_u_s(0xD5B7L, 14)) & ((*g_730) | ((l_2007 ^ (((((**g_1067) != ((l_1986 > (safe_div_func_uint32_t_u_u((safe_add_func_int64_t_s_s(l_1886, (*g_730))), ((****g_1786) &= ((l_2000 & (((-3L) != l_2000) , (***g_1893))) <= l_1857[2]))))) , l_2012)) == 0xBA5A761CL) , 0L) || 0x5830F6695D53BD48LL)) ^ 7L)))) <= l_2013) , l_2000), l_1997)));
                    l_1986 = (safe_add_func_uint8_t_u_u((((l_2033[3] ^= ((l_2017 ^ 255UL) , (safe_lshift_func_uint16_t_u_u(((safe_mul_func_uint16_t_u_u(((safe_sub_func_uint32_t_u_u((*g_978), (!(2L > (safe_add_func_int32_t_s_s(((*g_730) & ((l_2014 | l_1914) ^ (safe_mul_func_int16_t_s_s((~((**g_753) = (((((safe_div_func_uint32_t_u_u(0x6D734349L, l_1869)) <= 0L) , 2L) , (*g_1419)) | l_2014))), l_2000)))), l_2007)))))) || 0xB2L), l_2014)) && 0xFF9EL), l_2032)))) >= 1UL) , 0xA4L), 246UL));
                }
            }
            l_2033[3] ^= (l_2013 = l_1821);
        }
        l_2013 = l_1857[3];
    }
    (*g_503) = (*g_1787);
    for (l_1968 = 22; (l_1968 <= 36); ++l_1968)
    { /* block id: 919 */
        uint32_t *l_2036 = &l_145;
        int32_t l_2046 = 0x35F25488L;
        int32_t l_2047[4][1];
        int i, j;
        for (i = 0; i < 4; i++)
        {
            for (j = 0; j < 1; j++)
                l_2047[i][j] = 0x590AB2ACL;
        }
        l_2046 = ((l_2036 != &l_145) && (((**g_1418) = ((safe_sub_func_int16_t_s_s((((***g_503)++) , (l_2041 >= (safe_rshift_func_int64_t_s_u(((((((**g_553) |= (safe_add_func_int32_t_s_s((l_2047[1][0] ^= l_2046), ((l_2046 && ((void*)0 != l_2048)) & ((l_2046 >= l_2046) <= l_2046))))) || l_2047[1][0]) < l_2046) && l_2047[0][0]) , l_2046), l_2046)))), l_2046)) <= 0xFC2293DBL)) & l_2046));
        l_2047[2][0] = (18446744073709551613UL < (safe_mod_func_uint32_t_u_u((safe_mod_func_int8_t_s_s((0L != l_2047[3][0]), l_2046)), (safe_lshift_func_int16_t_s_u((**g_1395), 3)))));
    }
    g_1597 = &g_126;
    return g_1752;
}


/* ------------------------------------------ */
/* 
 * reads : g_467
 * writes: g_467
 */
static int32_t  func_2(uint32_t  p_3, const uint64_t  p_4, int64_t  p_5, int8_t  p_6)
{ /* block id: 638 */
    uint32_t l_1529 = 0x5EC87E16L;
    for (g_467 = 4; (g_467 >= 0); g_467 -= 1)
    { /* block id: 641 */
        return p_4;
    }
    l_1529--;
    return p_5;
}


/* ------------------------------------------ */
/* 
 * reads : g_1067
 * writes: g_1069
 */
static uint32_t  func_7(uint32_t  p_8, int8_t  p_9, uint8_t  p_10, int64_t  p_11, int64_t  p_12)
{ /* block id: 428 */
    uint8_t *l_1081 = &g_925[0];
    int32_t **l_1083[8];
    int32_t ***l_1082 = &l_1083[2];
    int64_t l_1105 = (-5L);
    uint8_t l_1146 = 2UL;
    int8_t * const l_1205 = &g_1206;
    int8_t * const *l_1204 = &l_1205;
    int8_t * const **l_1203[2];
    int8_t * const ***l_1202 = &l_1203[0];
    int8_t * const ****l_1201 = &l_1202;
    uint32_t *l_1309[1][7][3] = {{{(void*)0,&g_142,&g_142},{&g_890,&g_142,&g_142},{&g_142,&g_142,&g_142},{(void*)0,&g_142,&g_142},{&g_890,&g_142,&g_142},{&g_142,&g_142,&g_142},{(void*)0,&g_142,&g_142}}};
    uint32_t ***l_1376 = &g_753;
    uint32_t ****l_1375 = &l_1376;
    uint32_t l_1378 = 0x8CFD2B7EL;
    uint8_t ***l_1386[9][4] = {{(void*)0,&g_410,(void*)0,&g_410},{(void*)0,&g_410,(void*)0,&g_410},{(void*)0,&g_410,(void*)0,&g_410},{(void*)0,&g_410,(void*)0,&g_410},{(void*)0,&g_410,(void*)0,&g_410},{(void*)0,&g_410,(void*)0,&g_410},{(void*)0,&g_410,(void*)0,&g_410},{(void*)0,&g_410,(void*)0,&g_410},{(void*)0,&g_410,(void*)0,&g_410}};
    uint8_t ****l_1385[9] = {&l_1386[3][1],&l_1386[8][1],&l_1386[3][1],&l_1386[8][1],&l_1386[3][1],&l_1386[8][1],&l_1386[3][1],&l_1386[8][1],&l_1386[3][1]};
    struct S0 *l_1390 = &g_1046;
    int8_t l_1478 = 0xC3L;
    struct S0 *l_1525[1][8][10] = {{{&g_1046,(void*)0,(void*)0,&g_1046,&g_1050,&g_1046,(void*)0,&g_1050,(void*)0,&g_1046},{&g_1046,&g_818,&g_1046,(void*)0,&g_1046,&g_818,(void*)0,(void*)0,(void*)0,(void*)0},{&g_1046,&g_1050,&g_1050,&g_1046,&g_1050,&g_1050,&g_1046,&g_1026,&g_1050,&g_1108},{&g_818,(void*)0,&g_818,&g_1046,&g_1046,&g_1108,&g_1050,&g_818,(void*)0,&g_1026},{&g_1050,(void*)0,&g_1108,&g_1046,&g_1046,&g_1046,&g_1046,&g_1108,(void*)0,&g_1050},{&g_1050,&g_1050,&g_1046,&g_818,&g_818,&g_1046,(void*)0,&g_1046,&g_1050,&g_1046},{&g_1046,&g_818,&g_1050,(void*)0,&g_1026,&g_1108,&g_1046,&g_1108,&g_1026,(void*)0},{&g_1026,&g_818,&g_1026,(void*)0,&g_1050,&g_1046,(void*)0,&g_1050,(void*)0,&g_1046}}};
    int32_t l_1527 = 0xC1B304E9L;
    int i, j, k;
    for (i = 0; i < 8; i++)
        l_1083[i] = &g_126;
    for (i = 0; i < 2; i++)
        l_1203[i] = &l_1204;
    g_1069[0][3][5] = g_1067;
    return l_1527;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint64_t  func_19(int32_t  p_20, uint8_t  p_21, int64_t  p_22)
{ /* block id: 425 */
    int32_t *l_1061 = &g_75;
    int32_t l_1062[10] = {0x39EBE672L,0x39EBE672L,0xBAC7DC83L,0x39EBE672L,0x39EBE672L,0xBAC7DC83L,0x39EBE672L,0x39EBE672L,0xBAC7DC83L,0x39EBE672L};
    int32_t *l_1063[10][9] = {{&l_1062[2],&g_139,&l_1062[0],(void*)0,&g_312[3],&g_212,&g_312[2],&g_212,&g_212},{&g_467,&l_1062[2],(void*)0,&g_139,(void*)0,&l_1062[2],&g_467,&g_139,&g_467},{&l_1062[2],&g_312[3],&g_312[2],&g_139,(void*)0,&g_212,&l_1062[0],&l_1062[0],&g_212},{(void*)0,&g_212,&g_212,&g_212,(void*)0,&g_139,&g_212,&g_139,(void*)0},{&g_312[3],&g_312[2],&g_139,(void*)0,&g_212,&l_1062[0],&l_1062[0],&g_212,(void*)0},{(void*)0,&g_139,(void*)0,&l_1062[2],&g_467,&g_139,&g_467,&l_1062[2],(void*)0},{(void*)0,&g_312[3],&g_212,&g_312[2],&g_212,&g_212,&g_312[2],&g_212,&g_312[3]},{(void*)0,&l_1062[2],(void*)0,&l_1062[2],(void*)0,&l_1062[2],(void*)0,&l_1062[2],(void*)0},{&g_212,&g_139,&g_212,(void*)0,(void*)0,&g_212,&g_139,&g_212,&l_1062[2]},{&g_467,&l_1062[2],(void*)0,&g_212,(void*)0,&l_1062[2],&g_467,&g_212,&g_467}};
    uint64_t l_1064 = 0x57C496BEEAE995CDLL;
    int i, j;
    ++l_1064;
    return p_22;
}


/* ------------------------------------------ */
/* 
 * reads : g_503 g_504
 * writes: g_504
 */
static uint8_t  func_25(const uint16_t  p_26, int64_t  p_27, int8_t  p_28)
{ /* block id: 416 */
    int8_t l_1060[9] = {0x6EL,0x6EL,0x6EL,0x6EL,0x6EL,0x6EL,0x6EL,0x6EL,0x6EL};
    int i;
    for (p_27 = 0; (p_27 >= 20); ++p_27)
    { /* block id: 419 */
        int16_t *l_1058 = &g_165[1][0][3];
        int16_t **l_1057 = &l_1058;
        int16_t ***l_1059 = &l_1057;
        (*l_1059) = l_1057;
        if (l_1060[5])
            break;
    }
    (*g_503) = (*g_503);
    return l_1060[5];
}


/* ------------------------------------------ */
/* 
 * reads : g_139 g_753 g_754 g_545 g_503 g_504 g_505 g_730 g_513 g_159 g_209 g_925 g_553 g_506 g_312 g_961 g_973 g_974 g_807 g_467 g_992 g_1023 g_75 g_1039 g_165 g_554 g_118
 * writes: g_545 g_506 g_209 g_554 g_312 g_200 g_139 g_165 g_961 g_467 g_992 g_513 g_115 g_212 g_75 g_1048
 */
static int8_t  func_41(uint32_t  p_42, int32_t  p_43)
{ /* block id: 345 */
    const uint8_t *l_891[2];
    uint64_t l_892 = 1UL;
    int32_t l_893 = 0x49180306L;
    int32_t l_899[6][1][6] = {{{(-9L),(-4L),0x754425FFL,0L,0x0A98E491L,0x754425FFL}},{{0x9F6C5D0EL,1L,0x0A98E491L,(-8L),0x0A98E491L,1L}},{{0L,(-4L),(-8L),(-8L),(-4L),0x0A98E491L}},{{0x9F6C5D0EL,0x0A98E491L,(-8L),0L,1L,1L}},{{(-9L),0x0A98E491L,0x0A98E491L,(-9L),(-4L),0x754425FFL}},{{(-9L),(-4L),0x754425FFL,0L,0x0A98E491L,0x754425FFL}}};
    int32_t l_900 = 0xC647D42EL;
    int64_t l_901 = 0x348976BDE6651E4DLL;
    int32_t l_902[1][8][4] = {{{3L,(-1L),(-1L),3L},{(-1L),3L,(-1L),(-1L)},{3L,3L,0x144D13CFL,3L},{3L,(-1L),(-1L),3L},{(-1L),3L,(-1L),(-1L)},{3L,3L,0x144D13CFL,3L},{3L,(-1L),(-1L),3L},{0x144D13CFL,(-1L),0x144D13CFL,0x144D13CFL}}};
    int8_t *l_911 = &g_141;
    int8_t ** const l_910[9] = {&l_911,&l_911,&l_911,&l_911,&l_911,&l_911,&l_911,&l_911,&l_911};
    int8_t ****l_935 = &g_807;
    int8_t *****l_934 = &l_935;
    uint32_t l_965[5] = {4294967292UL,4294967292UL,4294967292UL,4294967292UL,4294967292UL};
    const uint64_t l_972 = 18446744073709551612UL;
    int64_t l_981[10] = {5L,4L,5L,4L,5L,4L,5L,4L,5L,4L};
    int64_t l_1006 = 0xF53364E9764EB6EBLL;
    int32_t l_1014 = (-1L);
    int32_t *l_1036 = &l_1014;
    struct S0 * const l_1043 = (void*)0;
    struct S0 * const *l_1042 = &l_1043;
    struct S0 *l_1045 = &g_1046;
    struct S0 **l_1044 = &l_1045;
    struct S0 ***l_1047[1][2][9] = {{{&l_1044,&l_1044,&l_1044,&l_1044,&l_1044,&l_1044,&l_1044,&l_1044,&l_1044},{(void*)0,(void*)0,&l_1044,(void*)0,(void*)0,&l_1044,(void*)0,(void*)0,&l_1044}}};
    int32_t *l_1051 = &l_899[4][0][2];
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_891[i] = &g_217;
    p_43 &= ((void*)0 == l_891[1]);
    if (l_892)
    { /* block id: 347 */
        int32_t *l_894 = &g_312[2];
        int32_t *l_895 = (void*)0;
        int32_t *l_896 = &g_467;
        int32_t *l_897 = &g_139;
        int32_t *l_898[5];
        uint32_t l_903[7] = {0xCE393DBEL,0xCE393DBEL,0x2DBCFE07L,0xCE393DBEL,0xCE393DBEL,0x2DBCFE07L,0xCE393DBEL};
        uint32_t *** const l_912 = &g_753;
        uint32_t l_913 = 0x881C1638L;
        int64_t *l_918[7];
        uint16_t ** const l_926 = (void*)0;
        int8_t **l_960 = (void*)0;
        int8_t ***l_959 = &l_960;
        const int8_t * const ***l_964 = &g_961;
        int32_t l_980 = 0x92F1AA31L;
        int i;
        for (i = 0; i < 5; i++)
            l_898[i] = &g_312[3];
        for (i = 0; i < 7; i++)
            l_918[i] = (void*)0;
        l_903[4]++;
        if ((((safe_div_func_int16_t_s_s((safe_rshift_func_uint8_t_u_u((l_910[1] != &l_911), (((l_893 = (((((&g_504[2] != l_912) == l_913) , (((((***g_503) = (safe_sub_func_uint32_t_u_u(((((safe_mod_func_uint16_t_u_u(p_43, (*l_897))) <= 4294967295UL) >= ((**g_753) |= 4294967295UL)) , 4294967295UL), p_42))) , (void*)0) != (void*)0) != 65530UL)) != 7L) != p_42)) , 0x9774FF12C24BBB7FLL) , 255UL))), p_42)) & (*g_730)) ^ g_159))
        { /* block id: 352 */
            uint16_t *l_930 = &g_118;
            int32_t l_946 = 0xAF71B056L;
            for (g_209 = 16; (g_209 >= 28); ++g_209)
            { /* block id: 355 */
                uint16_t * const l_929 = &g_692;
                int8_t *****l_933 = (void*)0;
                int32_t l_936 = (-10L);
                uint16_t l_937 = 0UL;
                int16_t *l_940 = (void*)0;
                int16_t *l_941 = &g_165[0][1][0];
                int32_t l_947 = 1L;
                uint8_t *l_948[2][7][8] = {{{(void*)0,&g_163,&g_925[6],&g_163,(void*)0,&g_163,&g_163,(void*)0},{&g_163,(void*)0,(void*)0,&g_163,&g_163,(void*)0,&g_163,&g_163},{(void*)0,&g_163,(void*)0,&g_163,&g_925[6],&g_925[6],&g_163,(void*)0},{&g_163,&g_163,&g_925[6],(void*)0,&g_925[7],(void*)0,&g_925[6],&g_163},{&g_163,(void*)0,&g_163,&g_925[6],&g_925[6],&g_163,(void*)0,&g_163},{(void*)0,&g_163,&g_163,(void*)0,&g_163,&g_163,(void*)0,(void*)0},{&g_163,(void*)0,&g_163,&g_163,(void*)0,&g_163,&g_925[6],&g_163}},{{(void*)0,&g_163,&g_925[6],&g_163,(void*)0,&g_163,&g_163,(void*)0},{&g_163,(void*)0,(void*)0,&g_163,&g_163,(void*)0,&g_163,&g_163},{(void*)0,&g_163,(void*)0,&g_163,&g_925[6],&g_925[6],&g_163,(void*)0},{&g_163,&g_163,&g_925[6],(void*)0,&g_925[7],(void*)0,&g_925[6],&g_163},{&g_163,(void*)0,&g_163,&g_925[6],&g_925[6],&g_163,(void*)0,&g_163},{(void*)0,&g_163,&g_163,(void*)0,&g_163,&g_163,(void*)0,(void*)0},{&g_163,(void*)0,&g_163,&g_163,(void*)0,&g_163,&g_925[6],&g_163}}};
                int i, j, k;
                (*l_894) ^= (((safe_unary_minus_func_uint8_t_u(((safe_mod_func_int8_t_s_s(((!(l_936 = ((((p_43 | ((l_899[0][0][3] = (0UL <= ((g_925[6] & ((((void*)0 != l_926) != (safe_add_func_int32_t_s_s((l_929 == ((*g_553) = l_930)), ((*g_505) > ((l_933 = l_933) == l_934))))) != (*g_730))) >= 0x4022B9CDL))) <= 0xCAL)) > 0xE5L) , p_43) | 1L))) , g_209), p_42)) && l_937))) & 5UL) >= l_900);
                (*l_894) &= (0x27L != (l_899[3][0][2] &= (((*l_941) = (safe_add_func_int64_t_s_s((g_200 = (0xD90AL & ((*g_730) < (p_42 , p_43)))), (((*l_897) &= 0xFFFEAF6FL) == (*g_505))))) != ((0xBD49A2B6D7DDF550LL >= ((l_947 ^= ((safe_add_func_int32_t_s_s((safe_mod_func_uint8_t_u_u(l_902[0][4][3], l_946)), 0x2B497A49L)) | l_936)) , (-1L))) , l_902[0][3][0]))));
            }
        }
        else
        { /* block id: 368 */
            for (l_892 = (-17); (l_892 < 41); l_892 = safe_add_func_int8_t_s_s(l_892, 1))
            { /* block id: 371 */
                int32_t **l_951 = &l_895;
                (*l_951) = &p_43;
            }
        }
        (*l_896) &= ((safe_add_func_uint16_t_u_u((0xA1D4020CBD54F8FFLL ^ (+((l_899[3][0][2] &= (((safe_mod_func_uint32_t_u_u(((safe_lshift_func_int64_t_s_u(l_902[0][1][2], (((p_42 , l_959) == ((*l_964) = g_961)) == l_965[4]))) ^ (((((safe_rshift_func_uint16_t_u_s((safe_lshift_func_int32_t_s_s(((safe_div_func_int64_t_s_s(l_972, g_973)) , ((*g_505) >= (-1L))), 14)), g_159)) , g_974[0]) != &g_975) , (void*)0) == (**l_934))), l_972)) | l_980) , 0xA5921FC8AFF32D2DLL)) && (-1L)))), l_981[5])) <= (*l_897));
    }
    else
    { /* block id: 378 */
        int32_t *l_982 = (void*)0;
        int32_t *l_983 = (void*)0;
        int32_t *l_984 = &l_893;
        int32_t *l_985 = &g_467;
        int32_t *l_986 = &g_467;
        int32_t *l_987 = (void*)0;
        int32_t *l_988 = &g_312[2];
        int32_t *l_989 = &g_212;
        int32_t *l_990 = &l_902[0][1][3];
        int32_t *l_991[2][1][3] = {{{(void*)0,(void*)0,(void*)0}},{{&l_902[0][1][2],&l_902[0][1][2],&l_902[0][1][2]}}};
        uint32_t *l_1005 = &g_115;
        uint32_t ***l_1010 = &g_753;
        uint32_t ****l_1009 = &l_1010;
        uint8_t *l_1035 = (void*)0;
        int i, j, k;
        ++g_992;
        if ((l_981[5] == (4294967295UL >= (safe_add_func_uint32_t_u_u((safe_mod_func_uint16_t_u_u((((*l_1005) = (p_43 & (safe_rshift_func_uint64_t_u_s((++(*g_730)), (safe_mod_func_int32_t_s_s(9L, p_43)))))) , (((l_1006 || (safe_lshift_func_int8_t_s_u(p_43, 7))) , l_1009) != (((+((((((void*)0 != &g_165[0][0][1]) , &g_962[2][0][2]) == (void*)0) , 1UL) | l_899[5][0][2])) || p_43) , (void*)0))), l_893)), (*l_986))))))
        { /* block id: 382 */
            for (l_892 = (-27); (l_892 == 18); l_892++)
            { /* block id: 385 */
                if (l_1014)
                    break;
                (*l_984) &= 0x55E02944L;
            }
        }
        else
        { /* block id: 389 */
            uint32_t * const **l_1017 = (void*)0;
            int32_t l_1018[4];
            struct S0 *l_1025 = &g_1026;
            uint64_t *l_1027[8][1] = {{&g_159},{&g_973},{&g_973},{&g_159},{&g_973},{&g_973},{&g_159},{&g_973}};
            int32_t l_1028 = 0xC21B7BA3L;
            int i, j;
            for (i = 0; i < 4; i++)
                l_1018[i] = (-9L);
            (*l_989) = (((((safe_add_func_int16_t_s_s((((*l_1009) = (*l_1009)) == l_1017), (l_1018[2] , (!p_42)))) | (safe_mul_func_uint64_t_u_u(p_42, (l_1028 = ((+((((((*g_730) = 5UL) >= 0xE74FF042D64CC069LL) && p_42) , g_1023) != l_1025)) , l_981[1]))))) < 7UL) & l_1018[2]) | p_42);
        }
        for (g_75 = 0; (g_75 == (-17)); g_75--)
        { /* block id: 397 */
            for (p_43 = 0; (p_43 >= (-26)); --p_43)
            { /* block id: 400 */
                const volatile uint32_t * const **l_1034 = &g_977[1];
                const volatile uint32_t * const ***l_1033 = &l_1034;
                (*l_1033) = &g_977[1];
            }
            (*l_984) = (l_1035 != (void*)0);
            l_983 = l_1036;
        }
    }
    (*l_1051) ^= (safe_mod_func_uint32_t_u_u(g_1039, (p_42 || ((safe_lshift_func_uint64_t_u_u(9UL, ((((*g_730) = (*g_730)) ^ (((l_1042 == (g_1048 = l_1044)) , 0x46CFL) ^ g_165[0][0][0])) > (((*g_554) && (*l_1036)) <= 4L)))) , (*g_505)))));
    return p_42;
}


/* ------------------------------------------ */
/* 
 * reads : g_82 g_139 g_126 g_75 g_116 g_159 g_165 g_163 g_118 g_141 g_115 g_217 g_545 g_245 g_212 g_200 g_506 g_505 g_467 g_312 g_554 g_730 g_513 g_692 g_867 g_503 g_504
 * writes: g_82 g_139 g_75 g_116 g_159 g_163 g_165 g_200 g_209 g_212 g_118 g_141 g_467 g_217 g_665 g_126 g_506
 */
static uint16_t  func_48(int64_t  p_49, uint32_t  p_50, int8_t  p_51, uint32_t  p_52)
{ /* block id: 27 */
    int32_t l_152[8] = {5L,5L,5L,5L,5L,5L,5L,5L};
    uint16_t *l_177 = &g_118;
    int32_t l_203[3];
    uint8_t *l_299 = &g_217;
    uint64_t *l_348 = &g_159;
    uint32_t *l_444[4][2] = {{&g_209,&g_209},{&g_245,&g_245},{&g_245,&g_209},{&g_245,&g_245}};
    uint64_t l_445 = 3UL;
    int64_t l_600 = (-1L);
    int32_t *l_609 = &l_152[2];
    int8_t l_695[4][6][2] = {{{0L,(-1L)},{1L,1L},{1L,(-1L)},{0L,0x1CL},{(-1L),0x1CL},{0L,(-1L)}},{{1L,1L},{1L,(-1L)},{0L,0x1CL},{(-1L),0x1CL},{0L,(-1L)},{1L,1L}},{{1L,(-1L)},{0L,0x1CL},{(-1L),0x1CL},{0L,(-1L)},{1L,1L},{1L,(-1L)}},{{0L,0x1CL},{(-1L),0x1CL},{0L,(-1L)},{1L,1L},{1L,(-1L)},{0L,0x1CL}}};
    uint32_t l_881 = 0UL;
    int32_t **l_889 = &g_126;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_203[i] = 0x528EE746L;
    for (g_82 = 0; (g_82 >= 6); ++g_82)
    { /* block id: 30 */
        uint32_t l_174[3];
        uint16_t l_220 = 65531UL;
        int32_t l_238[2];
        int32_t l_320 = 0x973A6B71L;
        int8_t *l_392 = &g_141;
        int32_t **l_395 = &g_126;
        uint32_t * const *l_501 = &l_444[1][1];
        uint32_t * const **l_500 = &l_501;
        int8_t **l_544 = &l_392;
        int32_t *l_546 = &l_152[6];
        int16_t l_547 = 0xE106L;
        uint64_t l_548[8] = {2UL,0xEB5696C67D3F3AF6LL,2UL,2UL,0xEB5696C67D3F3AF6LL,2UL,2UL,0xEB5696C67D3F3AF6LL};
        int8_t l_574 = 0L;
        uint64_t l_576 = 18446744073709551612UL;
        uint16_t l_670 = 0x3CDEL;
        uint8_t l_737 = 8UL;
        uint64_t l_739[2];
        int i;
        for (i = 0; i < 3; i++)
            l_174[i] = 0xCD0BF8E1L;
        for (i = 0; i < 2; i++)
            l_238[i] = 0L;
        for (i = 0; i < 2; i++)
            l_739[i] = 1UL;
        for (g_139 = 0; (g_139 == 8); g_139++)
        { /* block id: 33 */
            int32_t l_151 = 0L;
            uint8_t l_204 = 1UL;
            const uint16_t *l_208[6][7] = {{(void*)0,(void*)0,&g_118,&g_118,(void*)0,(void*)0,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118},{(void*)0,&g_118,&g_118,(void*)0,(void*)0,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118},{(void*)0,(void*)0,&g_118,&g_118,(void*)0,(void*)0,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118,&g_118,&g_118}};
            const uint16_t **l_207 = &l_208[1][0];
            int32_t l_315 = 0xFD082DB4L;
            int32_t l_319[5];
            int64_t *l_352 = (void*)0;
            int64_t **l_351 = &l_352;
            uint32_t *l_415[7][4] = {{&g_209,&g_209,&g_209,&g_209},{&g_209,&g_209,&g_209,&g_209},{&g_209,&g_209,&g_209,&g_209},{&g_209,&g_209,&g_209,&g_209},{&g_209,&g_209,&g_209,&g_209},{&g_209,&g_209,&g_209,&g_209},{&g_209,&g_209,&g_209,&g_209}};
            uint32_t **l_414 = &l_415[2][0];
            int32_t *l_439 = &g_212;
            int32_t **l_438 = &l_439;
            int i, j;
            for (i = 0; i < 5; i++)
                l_319[i] = (-1L);
            (*g_126) ^= (~l_151);
            for (g_116 = 0; (g_116 <= 7); g_116 += 1)
            { /* block id: 37 */
                int32_t *l_153 = &l_151;
                int32_t *l_154 = &l_152[3];
                int32_t *l_155 = &l_151;
                int32_t *l_156 = &l_152[6];
                int32_t *l_157 = &g_75;
                int32_t *l_158 = &l_151;
                uint8_t *l_162 = &g_163;
                int16_t *l_164 = &g_165[0][0][1];
                uint16_t *l_176 = &g_118;
                uint16_t **l_175 = &l_176;
                int32_t l_198 = 0L;
                int32_t l_216 = 0L;
                uint8_t l_223[6][9][4] = {{{0x04L,0xA8L,0xCFL,0xD2L},{0xA8L,0xFAL,0x75L,0x09L},{0x8DL,0xFCL,1UL,1UL},{0x78L,0UL,0x3BL,0UL},{255UL,1UL,0xA3L,0x29L},{253UL,1UL,253UL,0xD3L},{0x16L,0x19L,253UL,1UL},{0x07L,0x7DL,255UL,0x03L},{0x75L,0x06L,0x6DL,0x82L}},{{4UL,0x29L,0xCEL,255UL},{252UL,0x8FL,0x66L,1UL},{0x19L,0xD2L,1UL,4UL},{1UL,6UL,0UL,1UL},{0x19L,0xB5L,0x8DL,0UL},{1UL,0x82L,252UL,0x03L},{253UL,0xCFL,0x96L,252UL},{0x8DL,0x66L,0xFAL,0UL},{255UL,0x25L,0xFCL,0x25L}},{{1UL,0xA8L,6UL,4UL},{0x8FL,9UL,7UL,0x04L},{0x75L,0xFCL,0x09L,0UL},{0x75L,255UL,7UL,0x03L},{0x8FL,0UL,6UL,0xA3L},{1UL,0x82L,0xFCL,0x53L},{255UL,0x78L,0xFAL,0xB5L},{0x8DL,3UL,0x96L,0x02L},{253UL,0UL,0x96L,255UL}},{{0x02L,255UL,0xD2L,0x78L},{0UL,253UL,0x53L,0xD2L},{250UL,1UL,0x02L,0x19L},{252UL,0x29L,0xA3L,1UL},{0xFAL,0x09L,1UL,0xA8L},{1UL,0x53L,0x25L,0xFEL},{0xA1L,0x88L,0x06L,0xD2L},{0x03L,0xD3L,0xB5L,0xD2L},{0x09L,0x10L,0x8DL,249UL}},{{0xB5L,1UL,255UL,0x66L},{1UL,1UL,253UL,0x10L},{255UL,0xF2L,0xF2L,255UL},{0xD2L,0x7DL,0xA1L,0xFCL},{6UL,1UL,0x9DL,255UL},{1UL,0xFAL,0UL,255UL},{0x06L,1UL,253UL,0xFCL},{0x88L,0x7DL,6UL,255UL},{0x16L,0xF2L,0xCFL,0x10L}},{{0x82L,1UL,1UL,0x66L},{0x96L,1UL,0UL,249UL},{0x82L,0x10L,0x07L,0xD2L},{0xCEL,0xD3L,249UL,0xD2L},{0x29L,0x88L,0x3DL,0xFEL},{0xFEL,0x53L,0x7DL,0xA8L},{0x19L,0x09L,0xCEL,1UL},{0x98L,0x29L,250UL,0x19L},{0xFAL,1UL,0x16L,0xD2L}}};
                int i, j, k;
                g_159++;
                (*g_126) = (((*l_164) = (l_152[g_116] > (((*l_162) = 1UL) , p_50))) || ((((*l_175) = ((((0x74L && g_165[0][0][1]) < ((safe_sub_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s(g_163, (g_82 , (safe_mul_func_int32_t_s_s((*g_126), ((safe_add_func_uint16_t_u_u((0xBB07CFFEL | l_174[2]), p_49)) <= g_118)))))), l_151)) > 18446744073709551607UL)) != l_174[1]) , (void*)0)) != l_177) >= g_75));
                for (l_151 = 2; (l_151 >= 0); l_151 -= 1)
                { /* block id: 45 */
                    int8_t l_178 = 1L;
                    if ((*l_157))
                    { /* block id: 46 */
                        return l_178;
                    }
                    else
                    { /* block id: 48 */
                        int64_t *l_199[6][4] = {{&g_200,&g_200,&g_200,&g_200},{&g_200,&g_200,&g_200,&g_200},{&g_200,&g_200,&g_200,&g_200},{&g_200,&g_200,&g_200,&g_200},{&g_200,&g_200,&g_200,&g_200},{&g_200,&g_200,&g_200,&g_200}};
                        uint64_t *l_205[8][2] = {{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0}};
                        int32_t l_206 = 2L;
                        int32_t *l_210 = (void*)0;
                        int32_t *l_211 = &g_212;
                        int32_t l_215 = 0x56885D1BL;
                        int i, j;
                        (*l_156) = ((0x2F837EA6L == (safe_mod_func_int64_t_s_s((safe_mod_func_uint16_t_u_u((safe_rshift_func_uint8_t_u_u((&l_152[g_116] != (((*g_126) > (*g_126)) , &g_139)), (safe_mul_func_int16_t_s_s((safe_mul_func_uint16_t_u_u((safe_sub_func_int64_t_s_s(((safe_mul_func_uint32_t_u_u((*l_156), (safe_mul_func_uint32_t_u_u((((((*l_211) = (g_209 = (((((g_200 = (!((safe_rshift_func_int64_t_s_s(4L, 38)) > l_198))) , (l_206 = (((l_203[2] = (safe_add_func_uint16_t_u_u((l_151 > l_174[2]), p_49))) , l_204) ^ (*l_156)))) <= g_75) , (void*)0) == l_207))) <= 0L) != p_51) , p_50), p_50)))) >= p_49), l_174[2])), 0xECADL)), g_141)))), l_204)), g_115))) | l_152[4]);
                        l_223[2][5][0] &= (safe_div_func_uint32_t_u_u((p_51 & (0L < (l_215 <= p_50))), (((l_216 & (g_217 >= (safe_sub_func_uint16_t_u_u(l_220, ((((safe_add_func_int16_t_s_s(0x9DE8L, l_152[3])) | 0L) < 5L) == p_52))))) < p_50) || 1UL)));
                        if (p_49)
                            continue;
                    }
                }
            }
            for (l_220 = 0; (l_220 >= 36); l_220++)
            { /* block id: 62 */
                uint64_t l_231 = 4UL;
                int32_t *l_246 = &l_151;
                int32_t l_311[10][9][1] = {{{(-1L)},{0x8AACF54AL},{(-1L)},{0x0E8EB7F1L},{0L},{0x8AACF54AL},{0L},{0x0E8EB7F1L},{(-1L)}},{{0x8AACF54AL},{(-1L)},{0x0E8EB7F1L},{0L},{0x8AACF54AL},{0L},{0x0E8EB7F1L},{(-1L)},{0x8AACF54AL}},{{(-1L)},{0x0E8EB7F1L},{0L},{0x8AACF54AL},{0L},{0x0E8EB7F1L},{(-1L)},{0x8AACF54AL},{(-1L)}},{{0x0E8EB7F1L},{0L},{0x8AACF54AL},{0L},{0x0E8EB7F1L},{(-1L)},{0x8AACF54AL},{(-1L)},{0x0E8EB7F1L}},{{0L},{0x8AACF54AL},{0L},{0x0E8EB7F1L},{(-1L)},{0x8AACF54AL},{(-1L)},{0x0E8EB7F1L},{0L}},{{0x8AACF54AL},{0L},{0x0E8EB7F1L},{(-1L)},{0x8AACF54AL},{(-1L)},{0x0E8EB7F1L},{0L},{0x8AACF54AL}},{{0L},{0x0E8EB7F1L},{(-1L)},{0x8AACF54AL},{(-1L)},{0x0E8EB7F1L},{0L},{0x8AACF54AL},{0L}},{{0x0E8EB7F1L},{(-1L)},{0x8AACF54AL},{(-1L)},{0x0E8EB7F1L},{0L},{0x8AACF54AL},{0L},{0x0E8EB7F1L}},{{(-1L)},{0x8AACF54AL},{(-1L)},{0x0E8EB7F1L},{0L},{0x8AACF54AL},{0L},{0x0E8EB7F1L},{(-1L)}},{{0x8AACF54AL},{(-1L)},{0x0E8EB7F1L},{0L},{0x8AACF54AL},{0L},{0x0E8EB7F1L},{(-1L)},{0x8AACF54AL}}};
                int64_t *l_384[1];
                uint8_t l_429 = 255UL;
                uint8_t l_464 = 0x87L;
                uint8_t l_494 = 0x39L;
                uint32_t ***l_496 = (void*)0;
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_384[i] = (void*)0;
            }
        }
        l_203[2] = (safe_mod_func_uint32_t_u_u(((safe_add_func_uint64_t_u_u(((*l_348) ^= g_217), (**l_395))) , (((((safe_mod_func_uint64_t_u_u((safe_mul_func_int64_t_s_s(((((((**l_395) , ((l_203[2] != (safe_add_func_uint32_t_u_u((((((*l_392) = (((safe_add_func_int64_t_s_s((safe_add_func_uint8_t_u_u(((**l_395) & ((*l_546) = (safe_sub_func_uint8_t_u_u(0x97L, ((((*l_177) = (((((l_544 == ((*g_126) , (void*)0)) == g_545) == g_217) , 4L) , l_152[4])) == p_51) <= p_49))))), p_51)), g_245)) <= (*g_126)) , 1L)) , l_547) != (-6L)) >= (-9L)), 0x64726F9AL))) == g_212)) > l_203[2]) , p_51) <= (**l_395)) , l_548[0]), g_200)), p_50)) , g_506) <= p_51) ^ 0x0232EAA1L) , p_51)), (*g_505)));
        for (l_320 = 0; (l_320 < (-12)); l_320 = safe_sub_func_int64_t_s_s(l_320, 5))
        { /* block id: 181 */
            uint16_t ***l_555 = &g_553;
            uint64_t *l_556[9] = {&g_159,&g_159,&g_159,&g_159,&g_159,&g_159,&g_159,&g_159,&g_159};
            int32_t l_564[9] = {(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L),(-10L)};
            uint64_t l_565 = 0x3A9A04E8F80D4D5CLL;
            int64_t l_598 = 0xEE156B07EC2138A6LL;
            uint8_t *l_655 = &g_217;
            int16_t l_668 = 0xCB94L;
            int64_t l_669 = 0x0C85AB6E29D5E47FLL;
            uint32_t ***l_685 = (void*)0;
            uint32_t ****l_684[3];
            const int8_t *l_703 = &l_574;
            const int8_t ** const l_702 = &l_703;
            const int8_t ** const *l_701 = &l_702;
            const int8_t ** const **l_700[3][5][1] = {{{(void*)0},{&l_701},{&l_701},{&l_701},{(void*)0}},{{&l_701},{(void*)0},{&l_701},{&l_701},{&l_701}},{{(void*)0},{&l_701},{(void*)0},{&l_701},{&l_701}}};
            int32_t l_759 = 0xE3315345L;
            uint16_t l_788 = 65535UL;
            uint64_t l_791 = 1UL;
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_684[i] = &l_685;
        }
        if ((*l_546))
            break;
    }
    for (g_467 = 1; (g_467 <= 7); g_467 += 1)
    { /* block id: 303 */
        int16_t *l_798 = &g_165[1][0][3];
        int16_t **l_799 = &l_798;
        int8_t *l_800 = &l_695[0][3][1];
        int8_t **l_806[6] = {&l_800,&l_800,(void*)0,&l_800,&l_800,(void*)0};
        int8_t ***l_805 = &l_806[1];
        int32_t l_814[10] = {1L,1L,(-1L),1L,1L,(-1L),1L,1L,(-1L),1L};
        int32_t l_815 = (-10L);
        int16_t ***l_821[6][7][1] = {{{&l_799},{(void*)0},{(void*)0},{(void*)0},{&l_799},{&l_799},{(void*)0}},{{(void*)0},{(void*)0},{&l_799},{&l_799},{(void*)0},{(void*)0},{(void*)0}},{{&l_799},{&l_799},{(void*)0},{(void*)0},{(void*)0},{&l_799},{&l_799}},{{(void*)0},{(void*)0},{(void*)0},{&l_799},{&l_799},{(void*)0},{(void*)0}},{{(void*)0},{&l_799},{&l_799},{(void*)0},{(void*)0},{(void*)0},{&l_799}},{{&l_799},{(void*)0},{(void*)0},{(void*)0},{&l_799},{&l_799},{(void*)0}}};
        int i, j, k;
        (*l_609) = ((((*l_299) ^= (l_152[g_467] , (0x3410L >= (safe_rshift_func_uint8_t_u_s(((+p_51) < (*l_609)), 3))))) && l_152[g_467]) || ((*l_800) = ((((((safe_add_func_int64_t_s_s(g_312[4], (((*l_799) = l_798) == ((g_165[1][0][0] || (((*g_554) < (*g_554)) , (*g_554))) , &g_165[1][0][0])))) <= g_165[0][0][1]) , 0x0AE3L) , (*g_730)) > (*g_730)) ^ g_692)));
        for (g_217 = 0; (g_217 >= 26); ++g_217)
        { /* block id: 310 */
            int8_t ****l_808 = &g_807;
            int32_t l_813 = 0x176BA18AL;
            int32_t l_841 = (-1L);
            int32_t l_843 = 0xB0AA13EFL;
            int32_t l_844 = 1L;
            int32_t l_846 = 0x76D1130FL;
            int32_t l_847 = (-1L);
            int32_t l_848[1][8] = {{0xAD24F580L,0xAD24F580L,0xAD24F580L,0xAD24F580L,0xAD24F580L,0xAD24F580L,0xAD24F580L,0xAD24F580L}};
            int i, j;
        }
        if (l_152[g_467])
            continue;
        for (g_665 = 0; (g_665 == 36); ++g_665)
        { /* block id: 329 */
            int32_t *l_854 = &l_152[g_467];
            int32_t *l_855 = &g_75;
            int32_t *l_856 = &l_203[2];
            int32_t *l_857[10];
            uint8_t l_858 = 252UL;
            int64_t *l_883 = &l_600;
            int64_t **l_882 = &l_883;
            int64_t *l_888[7][3] = {{&g_200,&l_600,(void*)0},{&g_200,(void*)0,&g_200},{&g_200,&g_200,(void*)0},{&g_200,&g_200,&g_200},{(void*)0,&g_200,(void*)0},{&l_600,&g_200,&l_600},{(void*)0,(void*)0,&l_600}};
            int i, j;
            for (i = 0; i < 10; i++)
                l_857[i] = &g_312[2];
            g_126 = l_854;
            if ((*l_609))
                continue;
            l_858--;
            (*l_609) = (safe_div_func_uint64_t_u_u((safe_sub_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_u(g_867, 5)), ((*l_856) |= ((((((g_200 &= (((0x88E9DDF8L & (((safe_mul_func_int64_t_s_s((p_49 = ((safe_mod_func_int16_t_s_s((0x48DEEFEBL < (p_50 >= (((safe_unary_minus_func_uint32_t_u(((***g_503) ^= (safe_rshift_func_uint32_t_u_u((safe_rshift_func_uint16_t_u_s((((l_881 ^= l_152[g_467]) != p_50) > (((*l_882) = &g_200) == &l_600)), 1)), ((safe_div_func_uint16_t_u_u(((((((safe_sub_func_uint16_t_u_u((p_51 ^ (*l_609)), 1L)) || g_165[1][1][1]) >= (*g_126)) || p_50) , 0x1547ACD4L) , (*g_554)), 0xFCCAL)) <= l_152[g_467])))))) || p_51) >= p_51))), p_49)) > (*l_609))), 0L)) , 1UL) ^ (*g_554))) | l_814[1]) && 0UL)) <= p_51) , p_51) == l_815) || 0x397FL) ^ (-9L))))), 0xA278106CEAEA4B2FLL));
        }
    }
    l_609 = ((*l_889) = &l_152[5]);
    return p_50;
}


/* ------------------------------------------ */
/* 
 * reads : g_16 g_75 g_82 g_115 g_116 g_126 g_142
 * writes: g_82 g_116 g_75 g_126 g_139 g_142
 */
static int8_t  func_55(int32_t  p_56, uint32_t  p_57, uint16_t  p_58, int32_t  p_59, uint8_t  p_60)
{ /* block id: 1 */
    int32_t l_73[8][4][7] = {{{(-4L),0L,0x1EAE5249L,0xE38B13F4L,(-4L),8L,0xB91EE328L},{1L,0L,0x60871E8EL,1L,7L,0xFB88B70EL,7L},{(-1L),(-6L),(-6L),(-1L),0L,(-1L),0L},{(-10L),1L,0x523F84E0L,0x716659E0L,(-5L),0x461A3ECBL,0L}},{{(-4L),(-4L),(-1L),(-1L),0x55018227L,0xE785E8A7L,0L},{0xF497EEE4L,0x58CD180CL,7L,4L,0x016D172EL,4L,7L},{0x55018227L,0xA3421904L,0xE38B13F4L,1L,0x7F34FA62L,(-1L),0xB91EE328L},{0x70979B5CL,0x3CA5AAD5L,(-5L),0L,5L,0x461A3ECBL,(-3L)}},{{0x201886A6L,8L,0xA3421904L,(-1L),0x7F34FA62L,(-1L),0x8CCAA7A7L},{8L,0xFB88B70EL,0x016D172EL,0x3CA5AAD5L,0x016D172EL,0xFB88B70EL,8L},{1L,(-1L),0x9B6F3608L,(-4L),0x55018227L,0xC8167BA9L,(-6L)},{(-3L),0x461A3ECBL,5L,0L,(-5L),0x3CA5AAD5L,0x70979B5CL}},{{(-4L),0xE785E8A7L,0x9B6F3608L,0x8CCAA7A7L,0L,0x55018227L,0xA3421904L},{7L,4L,0x016D172EL,4L,7L,0x58CD180CL,0xF497EEE4L},{0L,(-1L),0xA3421904L,(-1L),(-4L),0xB91EE328L,(-1L)},{0L,0x461A3ECBL,(-5L),0x716659E0L,0x523F84E0L,1L,(-10L)}},{{0L,(-1L),0xE38B13F4L,(-6L),0x201886A6L,0x201886A6L,(-6L)},{7L,0xFB88B70EL,7L,1L,0x60871E8EL,0L,1L},{(-4L),0xC8167BA9L,(-1L),0L,(-1L),0xE38B13F4L,(-1L)},{(-3L),0x3CA5AAD5L,0x523F84E0L,1L,0xC438F874L,0L,(-10L)}},{{1L,0x55018227L,(-6L),(-1L),0xE785E8A7L,0x201886A6L,0xA3421904L},{8L,0x58CD180CL,0x60871E8EL,0x3923BFA4L,(-1L),1L,1L},{0x201886A6L,0xB91EE328L,0x1EAE5249L,0x55018227L,(-1L),0xB91EE328L,(-6L)},{0x70979B5CL,1L,0xC438F874L,0x3923BFA4L,(-3L),0xCAF8A8FFL,0L}},{{0L,(-1L),(-6L),(-6L),(-1L),0L,(-1L)},{1L,0x461A3ECBL,0x016D172EL,1L,0xF497EEE4L,4L,0xD241D88CL},{0xE785E8A7L,0xB91EE328L,0L,(-4L),0xE785E8A7L,0x9B6F3608L,0x8CCAA7A7L},{7L,0x461A3ECBL,0x523F84E0L,0x58CD180CL,5L,1L,5L}},{{0x55018227L,(-1L),(-6L),0xA3421904L,(-4L),8L,(-1L)},{7L,0x58CD180CL,0xF497EEE4L,0x3CA5AAD5L,0x3BBC7615L,0x716659E0L,0x60871E8EL},{0xE785E8A7L,0x8CCAA7A7L,(-1L),8L,0L,(-6L),(-1L)},{0x70979B5CL,0xCAF8A8FFL,5L,0xFB88B70EL,(-10L),0xFB88B70EL,5L}}};
    int32_t *l_74[8][6][3] = {{{&g_75,&g_75,&g_75},{&g_75,&g_75,&g_75},{(void*)0,&g_75,&g_75},{&g_75,&g_75,&g_75},{&g_75,(void*)0,&g_75},{&g_75,(void*)0,(void*)0}},{{&g_75,&g_75,(void*)0},{&g_75,(void*)0,&g_75},{(void*)0,&g_75,(void*)0},{&g_75,(void*)0,&g_75},{&g_75,(void*)0,(void*)0},{&g_75,&g_75,&g_75}},{{&g_75,&g_75,(void*)0},{&g_75,&g_75,(void*)0},{&g_75,&g_75,&g_75},{&g_75,&g_75,&g_75},{(void*)0,&g_75,&g_75},{&g_75,&g_75,&g_75}},{{&g_75,(void*)0,&g_75},{&g_75,(void*)0,(void*)0},{&g_75,&g_75,(void*)0},{&g_75,(void*)0,&g_75},{(void*)0,&g_75,(void*)0},{&g_75,(void*)0,&g_75}},{{&g_75,(void*)0,(void*)0},{&g_75,&g_75,&g_75},{&g_75,&g_75,(void*)0},{&g_75,&g_75,(void*)0},{&g_75,&g_75,&g_75},{&g_75,&g_75,&g_75}},{{(void*)0,&g_75,&g_75},{&g_75,&g_75,&g_75},{&g_75,(void*)0,&g_75},{&g_75,(void*)0,(void*)0},{&g_75,&g_75,(void*)0},{&g_75,(void*)0,&g_75}},{{(void*)0,&g_75,(void*)0},{&g_75,(void*)0,&g_75},{&g_75,(void*)0,(void*)0},{&g_75,&g_75,&g_75},{&g_75,&g_75,(void*)0},{&g_75,&g_75,(void*)0}},{{&g_75,&g_75,&g_75},{&g_75,&g_75,&g_75},{(void*)0,(void*)0,&g_75},{&g_75,(void*)0,&g_75},{&g_75,&g_75,(void*)0},{&g_75,&g_75,&g_75}}};
    int64_t l_80 = (-1L);
    uint64_t *l_81 = &g_82;
    int16_t l_140 = 0x6240L;
    int i, j, k;
    g_139 = (func_61((func_63((g_16 >= (safe_mul_func_int8_t_s_s(g_16, (safe_rshift_func_int64_t_s_u((safe_add_func_uint64_t_u_u(((*l_81) &= (((((safe_lshift_func_int32_t_s_s(((p_59 |= l_73[7][1][2]) || ((l_74[1][2][1] == ((((5L ^ ((g_75 , (safe_add_func_uint64_t_u_u((safe_lshift_func_int64_t_s_u(g_16, (p_58 == 0xA5L))), p_60))) & 0xBFABL)) <= g_75) , p_56) , (void*)0)) != g_16)), p_58)) != p_56) >= l_80) == p_57) , p_58)), g_16)), 6)))))) && g_82)) > g_115);
    --g_142;
    return g_82;
}


/* ------------------------------------------ */
/* 
 * reads : g_82 g_75 g_116 g_126
 * writes: g_126 g_75
 */
static int32_t  func_61(int32_t  p_62)
{ /* block id: 12 */
    int32_t *l_124 = &g_75;
    int32_t **l_125[4][7][2] = {{{(void*)0,&l_124},{&l_124,&l_124},{(void*)0,&l_124},{&l_124,&l_124},{(void*)0,(void*)0},{&l_124,(void*)0},{&l_124,(void*)0}},{{&l_124,(void*)0},{&l_124,(void*)0},{(void*)0,&l_124},{&l_124,&l_124},{(void*)0,&l_124},{&l_124,&l_124},{(void*)0,&l_124}},{{&l_124,&l_124},{(void*)0,(void*)0},{&l_124,(void*)0},{&l_124,(void*)0},{&l_124,(void*)0},{&l_124,(void*)0},{(void*)0,&l_124}},{{&l_124,&l_124},{(void*)0,&l_124},{&l_124,&l_124},{(void*)0,&l_124},{&l_124,&l_124},{(void*)0,(void*)0},{&l_124,(void*)0}}};
    int i, j, k;
    if (((((g_82 , (+(safe_sub_func_uint64_t_u_u(((g_126 = l_124) == (void*)0), (*l_124))))) < (*l_124)) <= (g_75 , ((*l_124) != (safe_mod_func_int8_t_s_s((((((((void*)0 == &g_118) & 18446744073709551615UL) != (*l_124)) || 0L) <= g_116) < p_62), p_62))))) >= 0xAD1B9823F5DDD1E6LL))
    { /* block id: 14 */
        uint64_t l_133 = 1UL;
        for (g_75 = (-9); (g_75 < 27); g_75++)
        { /* block id: 17 */
            l_133++;
        }
    }
    else
    { /* block id: 20 */
        uint8_t l_136[9][10] = {{255UL,0xF9L,0x5BL,6UL,0x5BL,0xF9L,255UL,0xC9L,0x0BL,0xDFL},{1UL,0xFBL,0xF9L,255UL,6UL,0x17L,0UL,0x88L,248UL,0xC9L},{255UL,0xFBL,0x3AL,4UL,1UL,1UL,255UL,0xDFL,0x0DL,0x0DL},{0x75L,0xF9L,6UL,0x85L,0x85L,6UL,0xF9L,0x75L,0xC0L,0xFBL},{0x3AL,0xC0L,6UL,0x5BL,0xE6L,1UL,0x17L,0xA9L,255UL,0x85L},{0x0BL,246UL,6UL,0xE6L,6UL,0xA9L,1UL,0x75L,0x88L,0x17L},{0x52L,0xDFL,6UL,0xFBL,0x8CL,0xFBL,6UL,0xDFL,0x52L,0UL},{0x17L,255UL,0x3AL,0UL,0UL,0x75L,1UL,0x88L,6UL,0x52L},{0x88L,0UL,0xF9L,0UL,255UL,0UL,0xA9L,0xC9L,0x52L,0x75L}};
        int i, j;
        --l_136[3][3];
    }
    return (*g_126);
}


/* ------------------------------------------ */
/* 
 * reads : g_75 g_16 g_115 g_82
 * writes: g_116 g_75
 */
static const uint16_t  func_63(uint32_t  p_64)
{ /* block id: 4 */
    int64_t l_89 = 0x3DE27ED8A746704BLL;
    int32_t l_90 = 0xD8ABD3BCL;
    uint64_t l_95 = 18446744073709551615UL;
    const int32_t *l_98 = &g_75;
    int32_t *l_99 = (void*)0;
    int32_t **l_100 = &l_99;
    uint16_t *l_117[10][5][5] = {{{(void*)0,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,(void*)0,(void*)0},{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,(void*)0,&g_118,&g_118}},{{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,(void*)0,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118},{(void*)0,(void*)0,&g_118,(void*)0,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118}},{{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,(void*)0,&g_118},{&g_118,&g_118,(void*)0,&g_118,(void*)0},{&g_118,(void*)0,&g_118,&g_118,&g_118},{(void*)0,&g_118,&g_118,&g_118,&g_118}},{{&g_118,(void*)0,(void*)0,&g_118,&g_118},{&g_118,&g_118,(void*)0,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,(void*)0},{(void*)0,&g_118,&g_118,&g_118,&g_118}},{{&g_118,(void*)0,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,(void*)0,(void*)0,&g_118,(void*)0},{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,(void*)0,&g_118,&g_118}},{{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,(void*)0,&g_118},{&g_118,(void*)0,&g_118,&g_118,(void*)0},{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118}},{{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,(void*)0,&g_118,&g_118},{&g_118,(void*)0,&g_118,(void*)0,(void*)0},{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118}},{{(void*)0,&g_118,&g_118,&g_118,&g_118},{(void*)0,&g_118,&g_118,&g_118,(void*)0},{(void*)0,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118}},{{&g_118,(void*)0,&g_118,&g_118,&g_118},{&g_118,(void*)0,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,(void*)0},{(void*)0,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,(void*)0,&g_118,&g_118}},{{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,(void*)0,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,&g_118,&g_118},{&g_118,&g_118,&g_118,(void*)0,&g_118}}};
    int32_t l_119 = (-1L);
    int32_t *l_120[10];
    int i, j, k;
    for (i = 0; i < 10; i++)
        l_120[i] = (void*)0;
    g_75 = ((safe_rshift_func_uint8_t_u_s((p_64 && (safe_sub_func_int32_t_s_s((((safe_mod_func_int16_t_s_s((l_90 = l_89), (l_119 = (safe_add_func_int32_t_s_s((safe_sub_func_uint8_t_u_u(0xBAL, (((l_95 , (safe_mul_func_uint64_t_u_u((l_98 == ((*l_100) = l_99)), ((safe_sub_func_int32_t_s_s((safe_rshift_func_int32_t_s_u(4L, (((((g_116 = (safe_lshift_func_uint32_t_u_u(g_75, ((((safe_add_func_int64_t_s_s((safe_rshift_func_uint32_t_u_u(((((safe_mul_func_int8_t_s_s((safe_mod_func_int64_t_s_s(((g_16 == 0L) <= (-1L)), 0xD4F1ACCADAFA0740LL)), (*l_98))) == (*l_98)) , (*l_98)) > (*l_98)), p_64)), g_115)) <= 0xF171379FL) , p_64) == g_82)))) , 0xB5L) ^ p_64) || (-4L)) != 0xA355C284D4494882LL))), g_82)) == g_16)))) , &l_95) == &l_95))), g_75))))) <= g_16) , 0xB0DE5594L), p_64))), 2)) == g_75);
    (*l_100) = (*l_100);
    return p_64;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_14[i], "g_14[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_16, "g_16", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    transparent_crc(g_82, "g_82", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_116, "g_116", print_hash_value);
    transparent_crc(g_118, "g_118", print_hash_value);
    transparent_crc(g_139, "g_139", print_hash_value);
    transparent_crc(g_141, "g_141", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_159, "g_159", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_165[i][j][k], "g_165[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_200, "g_200", print_hash_value);
    transparent_crc(g_209, "g_209", print_hash_value);
    transparent_crc(g_212, "g_212", print_hash_value);
    transparent_crc(g_217, "g_217", print_hash_value);
    transparent_crc(g_245, "g_245", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_282[i][j], "g_282[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_312[i], "g_312[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_322, "g_322", print_hash_value);
    transparent_crc(g_419, "g_419", print_hash_value);
    transparent_crc(g_420, "g_420", print_hash_value);
    transparent_crc(g_421, "g_421", print_hash_value);
    transparent_crc(g_467, "g_467", print_hash_value);
    transparent_crc(g_506, "g_506", print_hash_value);
    transparent_crc(g_513, "g_513", print_hash_value);
    transparent_crc(g_545, "g_545", print_hash_value);
    transparent_crc(g_602, "g_602", print_hash_value);
    transparent_crc(g_665, "g_665", print_hash_value);
    transparent_crc(g_692, "g_692", print_hash_value);
    transparent_crc(g_694, "g_694", print_hash_value);
    transparent_crc(g_818.f0, "g_818.f0", print_hash_value);
    transparent_crc(g_819.f0, "g_819.f0", print_hash_value);
    transparent_crc(g_867, "g_867", print_hash_value);
    transparent_crc(g_890, "g_890", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_925[i], "g_925[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_973, "g_973", print_hash_value);
    transparent_crc(g_979, "g_979", print_hash_value);
    transparent_crc(g_992, "g_992", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1024[i].f0, "g_1024[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1026.f0, "g_1026.f0", print_hash_value);
    transparent_crc(g_1039, "g_1039", print_hash_value);
    transparent_crc(g_1046.f0, "g_1046.f0", print_hash_value);
    transparent_crc(g_1050.f0, "g_1050.f0", print_hash_value);
    transparent_crc(g_1052, "g_1052", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_1053[i], "g_1053[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1108.f0, "g_1108.f0", print_hash_value);
    transparent_crc(g_1161.f0, "g_1161.f0", print_hash_value);
    transparent_crc(g_1206, "g_1206", print_hash_value);
    transparent_crc(g_1212, "g_1212", print_hash_value);
    transparent_crc(g_1213, "g_1213", print_hash_value);
    transparent_crc(g_1228.f0, "g_1228.f0", print_hash_value);
    transparent_crc(g_1256.f0, "g_1256.f0", print_hash_value);
    transparent_crc(g_1260, "g_1260", print_hash_value);
    transparent_crc(g_1312, "g_1312", print_hash_value);
    transparent_crc(g_1587, "g_1587", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1611[i][j], "g_1611[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1752, "g_1752", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 1; j++)
        {
            transparent_crc(g_1762[i][j], "g_1762[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1789, "g_1789", print_hash_value);
    transparent_crc(g_1822, "g_1822", print_hash_value);
    transparent_crc(g_1856, "g_1856", print_hash_value);
    transparent_crc(g_1876.f0, "g_1876.f0", print_hash_value);
    transparent_crc(g_1924.f0, "g_1924.f0", print_hash_value);
    transparent_crc(g_1932, "g_1932", print_hash_value);
    transparent_crc(g_1941, "g_1941", print_hash_value);
    transparent_crc(g_1971, "g_1971", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_1996[i], "g_1996[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 494
   depth: 1, occurrence: 6
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 22
breakdown:
   indirect level: 0, occurrence: 6
   indirect level: 1, occurrence: 10
   indirect level: 2, occurrence: 4
   indirect level: 3, occurrence: 2
XXX full-bitfields structs in the program: 6
breakdown:
   indirect level: 0, occurrence: 6
XXX times a bitfields struct's address is taken: 32
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 6
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 3

XXX max expression depth: 64
breakdown:
   depth: 1, occurrence: 196
   depth: 2, occurrence: 46
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 6, occurrence: 2
   depth: 9, occurrence: 2
   depth: 12, occurrence: 1
   depth: 14, occurrence: 3
   depth: 15, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 2
   depth: 18, occurrence: 1
   depth: 19, occurrence: 2
   depth: 20, occurrence: 2
   depth: 21, occurrence: 3
   depth: 22, occurrence: 1
   depth: 23, occurrence: 1
   depth: 24, occurrence: 5
   depth: 25, occurrence: 2
   depth: 27, occurrence: 1
   depth: 28, occurrence: 2
   depth: 32, occurrence: 1
   depth: 33, occurrence: 1
   depth: 38, occurrence: 1
   depth: 39, occurrence: 2
   depth: 41, occurrence: 1
   depth: 43, occurrence: 1
   depth: 44, occurrence: 1
   depth: 46, occurrence: 1
   depth: 64, occurrence: 1

XXX total number of pointers: 438

XXX times a variable address is taken: 1178
XXX times a pointer is dereferenced on RHS: 272
breakdown:
   depth: 1, occurrence: 200
   depth: 2, occurrence: 46
   depth: 3, occurrence: 13
   depth: 4, occurrence: 13
XXX times a pointer is dereferenced on LHS: 221
breakdown:
   depth: 1, occurrence: 179
   depth: 2, occurrence: 32
   depth: 3, occurrence: 8
   depth: 4, occurrence: 2
XXX times a pointer is compared with null: 37
XXX times a pointer is compared with address of another variable: 10
XXX times a pointer is compared with another pointer: 11
XXX times a pointer is qualified to be dereferenced: 6330

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 645
   level: 2, occurrence: 264
   level: 3, occurrence: 142
   level: 4, occurrence: 110
   level: 5, occurrence: 3
XXX number of pointers point to pointers: 224
XXX number of pointers point to scalars: 200
XXX number of pointers point to structs: 14
XXX percent of pointers has null in alias set: 28.1
XXX average alias set size: 1.41

XXX times a non-volatile is read: 1758
XXX times a non-volatile is write: 785
XXX times a volatile is read: 65
XXX    times read thru a pointer: 38
XXX times a volatile is write: 7
XXX    times written thru a pointer: 2
XXX times a volatile is available for access: 592
XXX percentage of non-volatile access: 97.2

XXX forward jumps: 0
XXX backward jumps: 5

XXX stmts: 191
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 28
   depth: 2, occurrence: 31
   depth: 3, occurrence: 30
   depth: 4, occurrence: 28
   depth: 5, occurrence: 43

XXX percentage a fresh-made variable is used: 16.5
XXX percentage an existing variable is used: 83.5
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

