/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      1739194209
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
#pragma pack(push)
#pragma pack(1)
struct S0 {
   const uint32_t  f0;
   signed f1 : 4;
   int32_t  f2;
   uint32_t  f3;
   uint64_t  f4;
   uint16_t  f5;
};
#pragma pack(pop)

union U1 {
   volatile uint64_t  f0;
   const int32_t  f1;
   unsigned f2 : 3;
};

/* --- GLOBAL VARIABLES --- */
static volatile int32_t g_2 = 0x1836CCB0L;/* VOLATILE GLOBAL g_2 */
static int32_t g_3 = (-8L);
static volatile union U1 g_68 = {0x4CD027BAED967AACLL};/* VOLATILE GLOBAL g_68 */
static volatile int32_t *g_75 = (void*)0;
static volatile int32_t ** volatile g_74 = &g_75;/* VOLATILE GLOBAL g_74 */
static int32_t g_79 = 0x190218FCL;
static volatile int32_t g_95[3][3][7] = {{{0x01F6F3B3L,4L,1L,(-3L),(-3L),1L,4L},{1L,0x3ED3529AL,0xF7A535ACL,0x3ED3529AL,1L,0x3ED3529AL,0xF7A535ACL},{(-3L),(-3L),1L,4L,0x01F6F3B3L,0x01F6F3B3L,4L}},{{(-5L),0xFAD3287BL,(-5L),0x3ED3529AL,(-5L),0xFAD3287BL,(-5L)},{(-3L),4L,4L,(-3L),0x01F6F3B3L,1L,1L},{1L,0xFAD3287BL,0xF7A535ACL,0xFAD3287BL,1L,0xFAD3287BL,0xF7A535ACL}},{{0x01F6F3B3L,(-3L),4L,4L,(-3L),0x01F6F3B3L,1L},{(-5L),0x3ED3529AL,(-5L),0xFAD3287BL,(-5L),0x3ED3529AL,(-5L)},{0x01F6F3B3L,4L,1L,(-3L),(-3L),1L,4L}}};
static volatile int8_t g_96 = 0x85L;/* VOLATILE GLOBAL g_96 */
static volatile uint32_t g_97 = 0UL;/* VOLATILE GLOBAL g_97 */
static int32_t **g_105 = (void*)0;
static int16_t g_110[6][6][7] = {{{0x60B9L,1L,(-1L),1L,0xA8E0L,4L,0x0D86L},{0x7171L,0xC8BEL,0xF435L,0x1BAAL,(-1L),0xC071L,2L},{0L,0x6956L,0x64F7L,0x2BCEL,0L,0x25CAL,0L},{(-9L),(-1L),1L,0x0E8CL,(-1L),0x86B6L,7L},{2L,(-1L),0x823BL,(-9L),7L,0xD6B8L,0xFB63L},{0L,0L,0x8AE8L,1L,7L,1L,0x7708L}},{{(-5L),(-1L),0xDB65L,0xC284L,(-1L),0xDFCFL,(-1L)},{0x64F7L,(-1L),(-5L),0L,0L,(-1L),0x57AAL},{2L,0xA8E0L,0x1603L,0xDF3AL,(-1L),0x3581L,0xBF87L},{(-4L),7L,(-10L),(-1L),0xA8E0L,0xE691L,0x7F38L},{1L,0x81D6L,0xDEE7L,0xF2DDL,0L,0x4289L,(-1L)},{0x1587L,9L,0L,(-7L),1L,1L,(-7L)}},{{(-9L),0xC8BEL,(-9L),1L,0x6C19L,0xD9FCL,1L},{0L,(-10L),0xD9FCL,7L,0L,0x25CAL,0x1603L},{0x25CAL,0x2BB1L,(-9L),0xE064L,1L,0xD9FCL,0x24CFL},{0xE070L,(-4L),0x823BL,1L,(-9L),1L,0x2BCEL},{(-1L),1L,0xC330L,0xA77CL,(-5L),0x4289L,0x7708L},{1L,0x6583L,0x86B6L,0x3581L,0x24CFL,0xE691L,1L}},{{0xD9FCL,(-1L),0x17FCL,0L,0xC071L,0x3581L,(-4L)},{0x7F38L,1L,0x6583L,0L,(-7L),(-1L),0L},{(-4L),0xDA7DL,9L,0x17FCL,0xD6B8L,0xDFCFL,1L},{(-9L),0x7FEFL,0x6D35L,0xE070L,0L,1L,0x4F03L},{0L,0xF2DDL,(-1L),0x6C19L,1L,0xD6B8L,0x4F03L},{0xF435L,0xC8BEL,0x7171L,0x4356L,0x4F03L,0x86B6L,1L}},{{0xBF87L,2L,1L,0xFB63L,0x86B6L,0x25CAL,0xEDDCL},{1L,0x6D35L,(-5L),1L,1L,0x0C79L,0xE691L},{7L,1L,0xDFCFL,(-1L),0x2BB1L,0x1587L,0L},{(-6L),0xDB65L,0x7171L,0x2BB1L,0xC284L,0xF435L,0L},{0x3581L,(-6L),0x0C79L,1L,0x1BAAL,(-1L),(-1L)},{0x8AE8L,0xEDDCL,0xC284L,0xEDDCL,0x8AE8L,2L,(-1L)}},{{0xF435L,0x1587L,0xEDDCL,2L,0xF6B5L,0x6D35L,(-3L)},{0xE691L,0x1BAAL,0xDA7DL,0x3581L,0xD9FCL,0L,(-5L)},{0xF435L,2L,(-1L),0xDA7DL,(-10L),0x4438L,5L},{0x8AE8L,(-1L),(-6L),4L,0x1587L,0x86B6L,1L},{0x3581L,(-7L),0x2BB1L,0xBF87L,4L,0x8AE8L,0x17FCL},{(-6L),7L,0x7F38L,0L,(-4L),(-1L),0x2579L}}};
static uint32_t g_120[1][7] = {{0x5BEA926FL,4294967287UL,0x5BEA926FL,0x5BEA926FL,4294967287UL,0x5BEA926FL,0x5BEA926FL}};
static uint32_t g_122[10][5] = {{0x143A6694L,0x143A6694L,0x143A6694L,0x143A6694L,0x143A6694L},{4294967287UL,0x8A694094L,4294967287UL,0x8A694094L,4294967287UL},{0x143A6694L,0x143A6694L,0x143A6694L,0x143A6694L,0x143A6694L},{4294967287UL,0x8A694094L,4294967287UL,0x8A694094L,4294967287UL},{0x143A6694L,0x143A6694L,0x143A6694L,0x143A6694L,0x143A6694L},{4294967287UL,0x8A694094L,4294967287UL,0x8A694094L,4294967287UL},{0x143A6694L,0x143A6694L,0x143A6694L,0x143A6694L,0x143A6694L},{4294967287UL,0x8A694094L,4294967287UL,0x8A694094L,4294967287UL},{0x143A6694L,0x143A6694L,0x143A6694L,0x143A6694L,0x143A6694L},{4294967287UL,0x8A694094L,4294967287UL,0x8A694094L,4294967287UL}};
static int8_t g_127 = (-1L);
static uint8_t g_140 = 0UL;
static int64_t g_161 = 0x2FDBCC2C37AD7940LL;
static uint8_t g_163 = 1UL;
static int32_t g_165 = 0x1C2D1908L;
static int16_t *** volatile g_168[3] = {(void*)0,(void*)0,(void*)0};
static int32_t *g_221 = &g_165;
static int32_t g_228 = (-1L);
static uint64_t g_236 = 0xAB6034B83A5DF858LL;
static uint8_t *g_243 = &g_140;
static uint8_t **g_242 = &g_243;
static int32_t ** volatile g_244 = &g_221;/* VOLATILE GLOBAL g_244 */
static const uint64_t g_262 = 0x25A8C6FE17D3D015LL;
static int16_t g_338 = 8L;
static uint32_t g_346[9][10] = {{0xD3C9604AL,0xB62B178CL,0xB62B178CL,0xD3C9604AL,0xC03593D4L,0xC44B2EB3L,0x2178109CL,18446744073709551612UL,1UL,0x21E0DFF4L},{0xD0C3387CL,0x69420ABCL,1UL,0x2178109CL,0xB62B178CL,1UL,0xB62B178CL,0x2178109CL,1UL,0x69420ABCL},{1UL,18446744073709551606UL,0UL,0xD3C9604AL,0xFBDD38DDL,0x7ADD0CA8L,0xC44B2EB3L,1UL,0xC03593D4L,0xC03593D4L},{18446744073709551606UL,0x21E0DFF4L,0x7ADD0CA8L,1UL,1UL,0x7ADD0CA8L,0x21E0DFF4L,18446744073709551606UL,0xD3C9604AL,0xC44B2EB3L},{1UL,0UL,0x2178109CL,18446744073709551606UL,18446744073709551615UL,1UL,18446744073709551612UL,0xC44B2EB3L,18446744073709551612UL,1UL},{0xD0C3387CL,18446744073709551615UL,18446744073709551606UL,0xC44B2EB3L,0x69420ABCL,0x2178109CL,1UL,0xD3C9604AL,18446744073709551612UL,0xFBDD38DDL},{1UL,0xB62B178CL,0xFBDD38DDL,0x2178109CL,1UL,0UL,0UL,1UL,0x2178109CL,0xFBDD38DDL},{0x2178109CL,0x2178109CL,0x21E0DFF4L,0xFBDD38DDL,0x69420ABCL,0xC03593D4L,1UL,18446744073709551606UL,1UL,0xD0C3387CL},{18446744073709551606UL,18446744073709551615UL,1UL,18446744073709551612UL,0xC44B2EB3L,18446744073709551612UL,1UL,18446744073709551615UL,18446744073709551606UL,0x2178109CL}};
static int8_t g_347 = 0xF5L;
static volatile int32_t ** volatile g_378 = &g_75;/* VOLATILE GLOBAL g_378 */
static const int16_t g_392 = (-7L);
static int32_t * volatile g_401 = &g_228;/* VOLATILE GLOBAL g_401 */
static int32_t * volatile * const g_400 = &g_401;
static int32_t * volatile *g_403 = (void*)0;
static int32_t * volatile ** volatile g_402[2] = {&g_403,&g_403};
static int32_t * volatile ** volatile g_404 = &g_403;/* VOLATILE GLOBAL g_404 */
static struct S0 g_440 = {0x3DEE22F1L,2,1L,1UL,18446744073709551614UL,0x1C18L};
static union U1 g_486 = {0UL};/* VOLATILE GLOBAL g_486 */
static int32_t ** volatile g_513[6][7] = {{&g_221,&g_221,&g_221,&g_221,&g_221,&g_221,&g_221},{(void*)0,&g_221,&g_221,&g_221,&g_221,(void*)0,&g_221},{&g_221,&g_221,&g_221,&g_221,&g_221,&g_221,&g_221},{(void*)0,&g_221,&g_221,&g_221,&g_221,&g_221,&g_221},{&g_221,&g_221,&g_221,&g_221,&g_221,&g_221,&g_221},{&g_221,&g_221,&g_221,&g_221,(void*)0,(void*)0,&g_221}};
static union U1 *g_647 = &g_486;
static union U1 ** volatile g_646[8] = {&g_647,&g_647,&g_647,&g_647,&g_647,&g_647,&g_647,&g_647};
static union U1 ** volatile g_648 = (void*)0;/* VOLATILE GLOBAL g_648 */
static union U1 g_650 = {0xEDC40BC8F8AE80B7LL};/* VOLATILE GLOBAL g_650 */
static int64_t g_675 = 0x63429ABF6AF04A26LL;
static union U1 g_685[6] = {{1UL},{1UL},{1UL},{1UL},{1UL},{1UL}};
static uint16_t g_697 = 65528UL;
static struct S0 g_854 = {2UL,-3,0x4F3B0785L,0x3C889FECL,18446744073709551615UL,0x7B0CL};
static struct S0 *g_853[4] = {&g_854,&g_854,&g_854,&g_854};
static volatile int64_t g_860[3] = {(-10L),(-10L),(-10L)};
static const volatile int64_t *g_859 = &g_860[2];
static const volatile int64_t **g_858 = &g_859;
static const volatile int64_t ***g_857 = &g_858;
static const volatile int64_t ****g_879 = &g_857;
static const volatile int64_t ***** volatile g_878 = &g_879;/* VOLATILE GLOBAL g_878 */
static union U1 g_918[5][8] = {{{0x30A7A2D796259289LL},{0xDD1449D78F1EAFB1LL},{0xDD1449D78F1EAFB1LL},{0x30A7A2D796259289LL},{0xDD1449D78F1EAFB1LL},{0xDD1449D78F1EAFB1LL},{0x30A7A2D796259289LL},{0xDD1449D78F1EAFB1LL}},{{0x30A7A2D796259289LL},{0x30A7A2D796259289LL},{0x5B313E9A9C79AA2FLL},{0x30A7A2D796259289LL},{0x30A7A2D796259289LL},{0x5B313E9A9C79AA2FLL},{0x30A7A2D796259289LL},{0x30A7A2D796259289LL}},{{0xDD1449D78F1EAFB1LL},{0x30A7A2D796259289LL},{0xDD1449D78F1EAFB1LL},{0xDD1449D78F1EAFB1LL},{0x30A7A2D796259289LL},{0xDD1449D78F1EAFB1LL},{0xDD1449D78F1EAFB1LL},{0x30A7A2D796259289LL}},{{0x30A7A2D796259289LL},{0xDD1449D78F1EAFB1LL},{0xDD1449D78F1EAFB1LL},{0x30A7A2D796259289LL},{0xDD1449D78F1EAFB1LL},{0xDD1449D78F1EAFB1LL},{0x30A7A2D796259289LL},{0xDD1449D78F1EAFB1LL}},{{0x30A7A2D796259289LL},{0x30A7A2D796259289LL},{0x5B313E9A9C79AA2FLL},{0x30A7A2D796259289LL},{0x30A7A2D796259289LL},{0x5B313E9A9C79AA2FLL},{0x30A7A2D796259289LL},{0x30A7A2D796259289LL}}};
static uint64_t *g_939 = &g_440.f4;
static uint64_t **g_938 = &g_939;
static uint64_t *** const  volatile g_937[4] = {&g_938,&g_938,&g_938,&g_938};
static union U1 g_985 = {0UL};/* VOLATILE GLOBAL g_985 */
static const uint32_t g_1003[1][1][4] = {{{0x520934C7L,0x520934C7L,0x520934C7L,0x520934C7L}}};
static const uint32_t *g_1002 = &g_1003[0][0][1];
static const int32_t *g_1011 = (void*)0;
static const int32_t ** volatile g_1010 = &g_1011;/* VOLATILE GLOBAL g_1010 */
static volatile union U1 g_1014 = {0x51CAA6A239872DC2LL};/* VOLATILE GLOBAL g_1014 */
static volatile union U1 g_1029[7] = {{0xD2FFBFD50834793ELL},{0xD2FFBFD50834793ELL},{0xD2FFBFD50834793ELL},{0xD2FFBFD50834793ELL},{0xD2FFBFD50834793ELL},{0xD2FFBFD50834793ELL},{0xD2FFBFD50834793ELL}};
static volatile int16_t g_1033[6][5][8] = {{{0x9695L,0xBF2BL,(-1L),5L,0x0684L,(-1L),0x377BL,8L},{(-1L),0xB026L,(-3L),0L,0x5E87L,0x17E5L,0x3416L,3L},{0x3E3BL,0x5E87L,0xF688L,(-1L),4L,0x4D17L,0L,0xCD19L},{0x59A3L,1L,0x5B40L,0x5C62L,(-1L),(-6L),1L,0L},{(-1L),(-1L),0xF85FL,8L,6L,1L,(-6L),0xD4A5L}},{{1L,(-9L),0xCBCCL,0x377BL,0xA373L,0xC29FL,4L,0x0684L},{0xFFEFL,0x1EAFL,0xD711L,3L,0xA0F2L,1L,6L,0x5C62L},{(-3L),0xC29FL,0xC5FCL,(-1L),0x5B40L,0x5B40L,(-1L),0xC5FCL},{0xC3E9L,0xC3E9L,0xD4A5L,0x92C8L,0x17E5L,0L,(-1L),1L},{0x555DL,0xF85FL,4L,5L,0x712FL,8L,(-6L),1L}},{{0xF85FL,1L,0xF4D2L,0x92C8L,0x8F23L,0xBBABL,0x02D2L,0xC5FCL},{4L,0x5F8BL,1L,(-1L),4L,(-7L),0x8F23L,0x5C62L},{0x9695L,(-6L),0x5CB9L,3L,0L,0xC3E9L,1L,0x0684L},{0L,0x5E87L,(-1L),0x377BL,(-6L),0xBB39L,(-3L),0xD4A5L},{0x555DL,(-3L),1L,8L,1L,(-1L),3L,(-1L)}},{{(-1L),0x712FL,0xB026L,0xC5FCL,(-6L),0x7921L,0xA373L,0x6EB3L},{0xCD19L,0x5F8BL,0x555DL,0x17E5L,0xA0F2L,0xCD19L,0x4D17L,0xFFEFL},{0x5B40L,0xD4A5L,0L,(-1L),0x5E87L,(-1L),0xBBABL,0x3416L},{0L,0L,(-1L),(-1L),(-1L),0L,0L,0x49E1L},{0xF688L,(-1L),(-6L),0x555DL,(-4L),0xFFEFL,0x7921L,(-3L)}},{{(-1L),0x02D2L,0x92C8L,0xC5FCL,(-4L),(-1L),0x02D2L,(-1L)},{0xF688L,0x1EAFL,0x8FF1L,(-3L),(-1L),1L,0x712FL,0xD711L},{0L,0xBBABL,0xCBCCL,0xC29FL,0x5E87L,(-1L),4L,0x0684L},{0x5B40L,1L,0xD4A5L,(-1L),0xA0F2L,0xC4DFL,0xC3E9L,4L},{0xCD19L,0xC29FL,1L,(-1L),(-6L),0xFFEFL,(-1L),1L}},{{(-1L),6L,7L,0x92C8L,1L,0xF85FL,4L,0L},{0x555DL,(-2L),0x5C62L,1L,(-6L),8L,0x712FL,5L},{0L,0xD4A5L,0xF4D2L,(-1L),0L,(-3L),0xC29FL,0xC5FCL},{0x49E1L,(-6L),0xF688L,0x59A3L,8L,0xD4A5L,0xD4A5L,8L},{0xA3E0L,0x5C62L,0x5C62L,0xA3E0L,0xBB39L,0L,0x633BL,8L}}};
static volatile int16_t * volatile g_1032 = &g_1033[5][1][4];/* VOLATILE GLOBAL g_1032 */
static volatile int16_t g_1035 = 0xFB0AL;/* VOLATILE GLOBAL g_1035 */
static volatile int16_t *g_1034[1] = {&g_1035};
static volatile int16_t * volatile *g_1031[5][10] = {{&g_1034[0],&g_1034[0],&g_1034[0],&g_1034[0],&g_1034[0],&g_1034[0],(void*)0,&g_1034[0],&g_1034[0],&g_1034[0]},{&g_1034[0],(void*)0,&g_1034[0],&g_1034[0],&g_1034[0],&g_1034[0],&g_1034[0],&g_1034[0],&g_1034[0],&g_1034[0]},{&g_1034[0],(void*)0,&g_1034[0],&g_1034[0],(void*)0,&g_1034[0],&g_1034[0],&g_1034[0],&g_1034[0],&g_1034[0]},{(void*)0,&g_1034[0],&g_1034[0],&g_1032,&g_1034[0],&g_1032,&g_1034[0],&g_1034[0],(void*)0,&g_1034[0]},{(void*)0,&g_1034[0],&g_1034[0],&g_1034[0],&g_1032,&g_1034[0],&g_1034[0],&g_1032,&g_1034[0],&g_1034[0]}};
static volatile int16_t * volatile ** const g_1030 = &g_1031[3][7];
static volatile int8_t g_1117 = 0x34L;/* VOLATILE GLOBAL g_1117 */
static struct S0 ** volatile g_1137 = (void*)0;/* VOLATILE GLOBAL g_1137 */
static struct S0 ** volatile g_1138 = &g_853[1];/* VOLATILE GLOBAL g_1138 */
static uint32_t * volatile *g_1142 = (void*)0;
static int64_t *g_1155 = &g_161;
static int64_t **g_1154 = &g_1155;
static int64_t ***g_1153[8] = {(void*)0,&g_1154,(void*)0,(void*)0,&g_1154,(void*)0,(void*)0,&g_1154};
static union U1 g_1172 = {18446744073709551614UL};/* VOLATILE GLOBAL g_1172 */
static int32_t g_1179 = 0x61899579L;
static int32_t * const g_1178 = &g_1179;
static int32_t * const *g_1177 = &g_1178;
static union U1 g_1188[5] = {{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}};
static uint32_t *g_1193 = &g_854.f3;
static union U1 g_1235 = {0x42FAB52B21BDD587LL};/* VOLATILE GLOBAL g_1235 */
static union U1 g_1240 = {7UL};/* VOLATILE GLOBAL g_1240 */
static int32_t ** volatile g_1245 = (void*)0;/* VOLATILE GLOBAL g_1245 */
static int32_t ** volatile g_1246 = &g_221;/* VOLATILE GLOBAL g_1246 */
static uint64_t ***g_1281 = &g_938;
static uint64_t **** volatile g_1280 = &g_1281;/* VOLATILE GLOBAL g_1280 */
static volatile union U1 g_1339 = {18446744073709551615UL};/* VOLATILE GLOBAL g_1339 */
static uint32_t g_1358[9][6][4] = {{{0xD4DFFB26L,0x649E36ADL,4UL,0xE879CCC0L},{4294967286UL,0xA3AEE396L,0xD4DFFB26L,4294967295UL},{4294967288UL,5UL,4294967294UL,0x649E36ADL},{4294967291UL,5UL,4294967291UL,4294967295UL},{0xE5FEABDBL,0xA3AEE396L,0xACBABCCDL,0xE879CCC0L},{0x8393AE72L,0x649E36ADL,4294967288UL,0xA3AEE396L}},{{9UL,0UL,4294967288UL,6UL},{0x8393AE72L,4294967295UL,0xACBABCCDL,4294967294UL},{0xE5FEABDBL,4294967295UL,4294967291UL,0xAA1170A0L},{4294967291UL,0xAA1170A0L,4294967294UL,0xAA1170A0L},{4294967288UL,4294967295UL,0xD4DFFB26L,4294967294UL},{4294967286UL,4294967295UL,4UL,6UL}},{{0xD4DFFB26L,0UL,0x5002EB11L,0xA3AEE396L},{0xD4DFFB26L,0x649E36ADL,4UL,0xE879CCC0L},{4294967286UL,0xA3AEE396L,0xD4DFFB26L,4294967295UL},{4294967288UL,5UL,4294967294UL,0x649E36ADL},{4294967291UL,5UL,4294967291UL,4294967295UL},{0xE5FEABDBL,0xA3AEE396L,0xACBABCCDL,0xE879CCC0L}},{{0x8393AE72L,0x649E36ADL,4294967288UL,0xA3AEE396L},{9UL,0UL,4294967288UL,6UL},{0x8393AE72L,4294967295UL,0xACBABCCDL,4294967294UL},{0xE5FEABDBL,4294967295UL,4294967291UL,0xAA1170A0L},{4294967291UL,0xAA1170A0L,4294967294UL,0xAA1170A0L},{4294967288UL,4294967295UL,0xD4DFFB26L,4294967294UL}},{{4294967286UL,4294967295UL,4UL,6UL},{0xD4DFFB26L,0UL,0x5002EB11L,0xA3AEE396L},{0xD4DFFB26L,0x649E36ADL,4UL,0xE879CCC0L},{4294967286UL,0xA3AEE396L,0xD4DFFB26L,4294967295UL},{9UL,0xE879CCC0L,4294967286UL,0xAA1170A0L},{0x5002EB11L,0xE879CCC0L,0x5002EB11L,4294967295UL}},{{0x8393AE72L,0UL,4294967294UL,4294967295UL},{0xA82F7CF4L,0xAA1170A0L,9UL,0UL},{0xD4DFFB26L,6UL,9UL,0x649E36ADL},{0xA82F7CF4L,4294967295UL,4294967294UL,0xA3AEE396L},{0x8393AE72L,0x79D24514L,0x5002EB11L,5UL},{0x5002EB11L,5UL,4294967286UL,5UL}},{{9UL,0x79D24514L,4UL,0xA3AEE396L},{4294967291UL,4294967295UL,0xE5FEABDBL,0x649E36ADL},{4UL,6UL,4294967288UL,0UL},{4UL,0xAA1170A0L,0xE5FEABDBL,4294967295UL},{4294967291UL,0UL,4UL,4294967295UL},{9UL,0xE879CCC0L,4294967286UL,0xAA1170A0L}},{{0x5002EB11L,0xE879CCC0L,0x5002EB11L,4294967295UL},{0x8393AE72L,0UL,4294967294UL,4294967295UL},{0xA82F7CF4L,0xAA1170A0L,9UL,0UL},{0xD4DFFB26L,6UL,9UL,0x649E36ADL},{0xA82F7CF4L,4294967295UL,4294967294UL,0xA3AEE396L},{0x8393AE72L,0x79D24514L,0x5002EB11L,5UL}},{{0x5002EB11L,5UL,4294967286UL,5UL},{9UL,0x79D24514L,4UL,0xA3AEE396L},{4294967291UL,4294967295UL,0xE5FEABDBL,0x649E36ADL},{4UL,6UL,4294967288UL,0UL},{4UL,0xAA1170A0L,0xE5FEABDBL,4294967295UL},{4294967291UL,0UL,4UL,4294967295UL}}};
static int16_t ***** volatile g_1380 = (void*)0;/* VOLATILE GLOBAL g_1380 */
static int32_t * volatile *g_1401 = &g_221;
static int32_t * volatile * volatile *g_1400 = &g_1401;
static int32_t * volatile * volatile ** volatile g_1399 = &g_1400;/* VOLATILE GLOBAL g_1399 */
static volatile int64_t g_1433 = 0x1961B5F57222DA2FLL;/* VOLATILE GLOBAL g_1433 */
static volatile uint32_t g_1465 = 4294967293UL;/* VOLATILE GLOBAL g_1465 */
static volatile int8_t g_1491[7] = {0x06L,0x06L,0x06L,0x06L,0x06L,0x06L,0x06L};
static volatile int8_t *g_1490 = &g_1491[4];
static volatile int8_t * volatile *g_1489 = &g_1490;
static int64_t ****g_1530 = &g_1153[3];
static int64_t *****g_1529 = &g_1530;
static int64_t *****g_1531 = (void*)0;
static int64_t *****g_1532 = &g_1530;
static volatile int32_t ** volatile g_1619 = (void*)0;/* VOLATILE GLOBAL g_1619 */
static volatile int32_t ** volatile g_1620 = &g_75;/* VOLATILE GLOBAL g_1620 */
static struct S0 g_1678 = {0UL,-0,0xD62B1334L,0x443E2D06L,0x72887232814F4515LL,0UL};
static volatile int16_t g_1713 = 0x4B59L;/* VOLATILE GLOBAL g_1713 */
static volatile int64_t g_1758 = 0x4ED28340DE99990ALL;/* VOLATILE GLOBAL g_1758 */
static volatile union U1 g_1788 = {0x6AFA990FFD283EA7LL};/* VOLATILE GLOBAL g_1788 */
static union U1 g_1801 = {1UL};/* VOLATILE GLOBAL g_1801 */
static const int32_t g_1815 = 0xBE1D4971L;
static const int32_t ** volatile g_1816[5][1][6] = {{{&g_1011,&g_1011,&g_1011,&g_1011,&g_1011,&g_1011}},{{&g_1011,&g_1011,&g_1011,&g_1011,&g_1011,&g_1011}},{{&g_1011,&g_1011,&g_1011,&g_1011,&g_1011,&g_1011}},{{&g_1011,&g_1011,&g_1011,&g_1011,&g_1011,&g_1011}},{{&g_1011,&g_1011,&g_1011,&g_1011,&g_1011,&g_1011}}};
static const int32_t ** volatile g_1817 = &g_1011;/* VOLATILE GLOBAL g_1817 */
static volatile union U1 g_1852 = {1UL};/* VOLATILE GLOBAL g_1852 */
static int32_t * volatile **g_1855[10] = {&g_1401,&g_1401,&g_1401,&g_1401,&g_1401,&g_1401,&g_1401,&g_1401,&g_1401,&g_1401};
static int32_t * volatile ** volatile * volatile g_1854 = &g_1855[8];/* VOLATILE GLOBAL g_1854 */
static int32_t * volatile ** volatile * volatile *g_1853[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static union U1 g_1865 = {7UL};/* VOLATILE GLOBAL g_1865 */
static int32_t ** volatile g_1868 = &g_221;/* VOLATILE GLOBAL g_1868 */
static const struct S0 g_1924 = {3UL,-1,0xFB325170L,0x3AC1E1D0L,0UL,6UL};
static const struct S0 *g_1923 = &g_1924;
static volatile uint32_t g_1988 = 0x67D69FF2L;/* VOLATILE GLOBAL g_1988 */
static volatile union U1 g_2002 = {18446744073709551615UL};/* VOLATILE GLOBAL g_2002 */
static union U1 g_2003 = {18446744073709551615UL};/* VOLATILE GLOBAL g_2003 */
static union U1 g_2020 = {0x77F7629D89DE0EBBLL};/* VOLATILE GLOBAL g_2020 */
static union U1 ** volatile g_2044[6] = {&g_647,&g_647,&g_647,&g_647,&g_647,&g_647};
static union U1 ** volatile g_2045 = &g_647;/* VOLATILE GLOBAL g_2045 */
static int32_t ***g_2056 = &g_105;
static int32_t ****g_2055 = &g_2056;
static uint32_t g_2078 = 1UL;
static const struct S0 ** volatile g_2080 = &g_1923;/* VOLATILE GLOBAL g_2080 */
static int32_t ** volatile g_2098 = &g_221;/* VOLATILE GLOBAL g_2098 */
static const int32_t ** volatile g_2109 = &g_1011;/* VOLATILE GLOBAL g_2109 */
static int16_t g_2188[4][5][8] = {{{0xCE7AL,1L,(-1L),(-4L),0x9BD1L,3L,0x65F0L,0L},{1L,0x9BD1L,0x59B2L,0xCE7AL,(-1L),8L,0x8FE1L,0L},{0x4E99L,4L,0xCDA3L,0L,6L,0xECCEL,0x6F6FL,(-6L)},{1L,0x69F1L,1L,(-6L),(-8L),0xB0FFL,0x9BD1L,(-1L)},{8L,4L,1L,(-1L),0L,0xC9A2L,0L,(-1L)}},{{0x6F6FL,(-8L),0x6F6FL,3L,(-1L),0xECCEL,0x17EBL,9L},{4L,0L,0x59B2L,1L,0xCE7AL,3L,(-1L),0xCB47L},{4L,0x2A9AL,0L,(-6L),(-1L),(-1L),3L,8L},{0x6F6FL,1L,0xABFBL,8L,0L,0xCE7AL,5L,3L},{8L,0x6F6FL,0x8C68L,0xECCEL,(-8L),0x69F1L,(-3L),1L}},{{(-1L),1L,0xCE7AL,0xCDA3L,0L,0x59B2L,(-1L),(-8L)},{(-1L),(-6L),0x9BD1L,0L,0L,0x9BD1L,(-6L),(-1L)},{0xABFBL,0xC9A2L,(-1L),0x8FE1L,0xECCEL,0x65F0L,0xA3E0L,0L},{(-1L),(-4L),8L,3L,0x8FE1L,0x65F0L,0x6152L,0x4E99L},{6L,0xC9A2L,0x1489L,0L,(-6L),0x9BD1L,0L,1L}},{{0x4E99L,(-6L),0xECCEL,0x6152L,0x17EBL,0x59B2L,1L,(-3L)},{0x8FE1L,1L,0x17EBL,5L,0L,0x69F1L,0xCE7AL,8L},{0L,0x6F6FL,3L,0xA3E0L,6L,0xCE7AL,0xC5D3L,0xCE7AL},{(-3L),1L,8L,1L,(-3L),(-1L),0x69F1L,9L},{(-8L),0x2A9AL,0L,1L,(-1L),3L,1L,1L}}};
static uint32_t **g_2233 = (void*)0;
static uint32_t *** volatile g_2232 = &g_2233;/* VOLATILE GLOBAL g_2232 */
static int32_t ** volatile g_2246 = &g_221;/* VOLATILE GLOBAL g_2246 */
static union U1 g_2270 = {0x75AFC6D1D02A907ELL};/* VOLATILE GLOBAL g_2270 */
static const uint32_t g_2290 = 0x76570244L;
static const int32_t ** volatile g_2458[4][6] = {{&g_1011,(void*)0,&g_1011,(void*)0,&g_1011,(void*)0},{&g_1011,(void*)0,&g_1011,(void*)0,&g_1011,(void*)0},{&g_1011,(void*)0,&g_1011,(void*)0,&g_1011,(void*)0},{&g_1011,(void*)0,&g_1011,(void*)0,&g_1011,(void*)0}};
static const int32_t ** volatile g_2459[3][7][4] = {{{(void*)0,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,(void*)0,&g_1011,(void*)0},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,(void*)0,&g_1011,&g_1011},{(void*)0,(void*)0,&g_1011,&g_1011},{(void*)0,&g_1011,&g_1011,&g_1011}},{{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011}},{{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011},{&g_1011,&g_1011,&g_1011,&g_1011}}};
static const int32_t ** volatile g_2460 = &g_1011;/* VOLATILE GLOBAL g_2460 */
static union U1 ** volatile *g_2480 = &g_648;
static union U1 ** volatile ** volatile g_2479 = &g_2480;/* VOLATILE GLOBAL g_2479 */
static union U1 ** volatile ** volatile * volatile g_2481 = &g_2479;/* VOLATILE GLOBAL g_2481 */
static uint8_t g_2515 = 0x99L;
static volatile union U1 g_2526 = {0xA19ADB30A8829C22LL};/* VOLATILE GLOBAL g_2526 */
static union U1 g_2551 = {0xD5A6DD64F156DC98LL};/* VOLATILE GLOBAL g_2551 */
static union U1 g_2561 = {18446744073709551615UL};/* VOLATILE GLOBAL g_2561 */
static const int32_t ** volatile g_2634[4] = {&g_1011,&g_1011,&g_1011,&g_1011};
static int16_t g_2685 = 0x6F1CL;
static volatile union U1 g_2732 = {0xC47B6D14BA47BDACLL};/* VOLATILE GLOBAL g_2732 */
static union U1 g_2733[1] = {{0xB70E39FE4C7AF61ALL}};
static uint32_t g_2929 = 0x5BBCAFE0L;
static struct S0 g_2936 = {4294967295UL,-0,0xC05D77FBL,0x968B25F3L,0x4CA40CE2810F32B3LL,65535UL};
static struct S0 ***g_2954 = (void*)0;
static struct S0 ****g_2953 = &g_2954;
static int64_t ** const *g_2992[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static int64_t ** const **g_2991 = &g_2992[0];
static union U1 ** volatile g_3017[8] = {&g_647,&g_647,&g_647,&g_647,&g_647,&g_647,&g_647,&g_647};
static union U1 ** volatile g_3018 = &g_647;/* VOLATILE GLOBAL g_3018 */
static int32_t g_3066 = 0xBAD241ADL;
static uint64_t ****g_3077 = (void*)0;
static uint64_t *****g_3076 = &g_3077;
static int8_t g_3140 = 1L;
static volatile union U1 g_3239[10][8][3] = {{{{0x1BFC1A1292B4607FLL},{6UL},{18446744073709551610UL}},{{18446744073709551613UL},{18446744073709551615UL},{0UL}},{{6UL},{1UL},{18446744073709551608UL}},{{0x92C647BFD7818A70LL},{0x29CC8E8D0A8F3DFFLL},{1UL}},{{18446744073709551610UL},{0xAD92F08EB7700250LL},{18446744073709551615UL}},{{0x246A247C9A880FEELL},{0xF95C4CFB841C3E52LL},{18446744073709551615UL}},{{18446744073709551607UL},{0x6BD4C8374038B126LL},{1UL}},{{1UL},{0xDDF71997ED263EF8LL},{18446744073709551608UL}}},{{{0x1366A4CF73EBC2DELL},{4UL},{0UL}},{{0xEA6F0EBE1E596BDALL},{0x5E39DFBEBC8A879FLL},{18446744073709551610UL}},{{0xE5C307993967BED4LL},{0UL},{18446744073709551613UL}},{{0xBA6411B1BEB63645LL},{0x92C647BFD7818A70LL},{0xE5C307993967BED4LL}},{{0xA218162D52237072LL},{0x97112929F1907EDELL},{1UL}},{{6UL},{0x472B0617FF24FE42LL},{9UL}},{{0x66E9A8B554EF63AFLL},{0UL},{0x246A247C9A880FEELL}},{{18446744073709551607UL},{18446744073709551613UL},{0xC9C625CF74167A0DLL}}},{{{1UL},{0xC9C625CF74167A0DLL},{2UL}},{{6UL},{0xB3D2A52C90290646LL},{1UL}},{{0xA8FAAC4B83CA26FELL},{6UL},{0x0B14043957AE947FLL}},{{18446744073709551615UL},{0x595C8CFEE6FC3B99LL},{18446744073709551615UL}},{{18446744073709551614UL},{18446744073709551615UL},{0x176BD2981828B32DLL}},{{18446744073709551615UL},{1UL},{0x6BD4C8374038B126LL}},{{18446744073709551612UL},{0x15D0EE769718067FLL},{18446744073709551610UL}},{{1UL},{18446744073709551613UL},{0xF95C4CFB841C3E52LL}}},{{{18446744073709551612UL},{18446744073709551615UL},{0x92C647BFD7818A70LL}},{{18446744073709551615UL},{0x3B8225F8B3AE66D7LL},{1UL}},{{18446744073709551614UL},{18446744073709551611UL},{0UL}},{{18446744073709551615UL},{18446744073709551615UL},{0x3D665F37F2547F6DLL}},{{0xA8FAAC4B83CA26FELL},{0x606FA391E7350C4CLL},{0xBA6411B1BEB63645LL}},{{6UL},{0xBDBFB532D7A2DD76LL},{0xC11EF70520AF5408LL}},{{1UL},{7UL},{1UL}},{{18446744073709551607UL},{0xEF07BE6B2D6B2EECLL},{0x29CC8E8D0A8F3DFFLL}}},{{{0x66E9A8B554EF63AFLL},{18446744073709551615UL},{0x45D56CA661B0745ALL}},{{6UL},{0xA218162D52237072LL},{0x9D5FE7A987422FE0LL}},{{0xA218162D52237072LL},{1UL},{0x34E7A27262954AD3LL}},{{0xBA6411B1BEB63645LL},{0x0B14043957AE947FLL},{0x5E39DFBEBC8A879FLL}},{{0xE5C307993967BED4LL},{0xC11EF70520AF5408LL},{1UL}},{{0xEA6F0EBE1E596BDALL},{0xE4FA11A2DF3BB5CALL},{0xAD92F08EB7700250LL}},{{0x1366A4CF73EBC2DELL},{0xF291E16D1F3C5101LL},{0x472B0617FF24FE42LL}},{{1UL},{0x5332436072E2490ELL},{18446744073709551615UL}}},{{{18446744073709551607UL},{0UL},{1UL}},{{0x9D5FE7A987422FE0LL},{18446744073709551607UL},{0xF95C4CFB841C3E52LL}},{{6UL},{18446744073709551610UL},{1UL}},{{0xD342F9A3D66E1B45LL},{7UL},{0x5FB8144F809384C0LL}},{{6UL},{18446744073709551613UL},{0x247E935E7F271FADLL}},{{0x894E83A67A2916D8LL},{0x397964947E284179LL},{1UL}},{{5UL},{7UL},{0x246A247C9A880FEELL}},{{0xA218162D52237072LL},{0x29CC8E8D0A8F3DFFLL},{1UL}}},{{{0x3074A86AC9C30557LL},{0x5E39DFBEBC8A879FLL},{18446744073709551608UL}},{{0x606FA391E7350C4CLL},{0x246A247C9A880FEELL},{1UL}},{{0UL},{0x97112929F1907EDELL},{18446744073709551615UL}},{{1UL},{0xF95C4CFB841C3E52LL},{18446744073709551615UL}},{{0UL},{0x3074A86AC9C30557LL},{0x56D23721FBC1DD27LL}},{{1UL},{1UL},{0x3D665F37F2547F6DLL}},{{0x6BD4C8374038B126LL},{0xAD92F08EB7700250LL},{0xEA6F0EBE1E596BDALL}},{{0x34E7A27262954AD3LL},{0x34E7A27262954AD3LL},{0xB3D2A52C90290646LL}}},{{{0x595C8CFEE6FC3B99LL},{18446744073709551607UL},{0xE4FA11A2DF3BB5CALL}},{{1UL},{0UL},{5UL}},{{0x97112929F1907EDELL},{0xC9C625CF74167A0DLL},{18446744073709551613UL}},{{9UL},{1UL},{5UL}},{{0x397964947E284179LL},{18446744073709551615UL},{0xE4FA11A2DF3BB5CALL}},{{18446744073709551608UL},{18446744073709551615UL},{0xB3D2A52C90290646LL}},{{18446744073709551615UL},{0x472B0617FF24FE42LL},{0xEA6F0EBE1E596BDALL}},{{18446744073709551607UL},{18446744073709551614UL},{0x3D665F37F2547F6DLL}}},{{{1UL},{0x247E935E7F271FADLL},{0x56D23721FBC1DD27LL}},{{0xA8FAAC4B83CA26FELL},{18446744073709551615UL},{18446744073709551615UL}},{{0x246A247C9A880FEELL},{0x176BD2981828B32DLL},{18446744073709551615UL}},{{0xBDBFB532D7A2DD76LL},{0x3D665F37F2547F6DLL},{1UL}},{{0x472B0617FF24FE42LL},{2UL},{18446744073709551608UL}},{{18446744073709551613UL},{0x1BFC1A1292B4607FLL},{1UL}},{{1UL},{0xD342F9A3D66E1B45LL},{0x246A247C9A880FEELL}},{{18446744073709551615UL},{18446744073709551610UL},{1UL}}},{{{18446744073709551615UL},{0x5332436072E2490ELL},{0x247E935E7F271FADLL}},{{1UL},{18446744073709551615UL},{0x5FB8144F809384C0LL}},{{0xAD92F08EB7700250LL},{0xBDBFB532D7A2DD76LL},{1UL}},{{0x56D23721FBC1DD27LL},{4UL},{0xF95C4CFB841C3E52LL}},{{1UL},{0xA218162D52237072LL},{1UL}},{{1UL},{0x15D0EE769718067FLL},{0xAD92F08EB7700250LL}},{{0x56D23721FBC1DD27LL},{0xCCB50686C7ED1684LL},{2UL}},{{0xAD92F08EB7700250LL},{1UL},{0x15D0EE769718067FLL}}}};
static int32_t g_3253 = 0xB1C8CFC4L;
static int16_t ***g_3273[1] = {(void*)0};
static int16_t ****g_3272 = &g_3273[0];
static int16_t ***** volatile g_3271 = &g_3272;/* VOLATILE GLOBAL g_3271 */
static const union U1 *g_3301 = &g_2003;
static const union U1 **g_3300[4] = {&g_3301,&g_3301,&g_3301,&g_3301};
static const union U1 ***g_3299 = &g_3300[1];
static const union U1 ****g_3298[7][9][4] = {{{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,&g_3299,&g_3299,&g_3299},{(void*)0,&g_3299,&g_3299,&g_3299},{(void*)0,(void*)0,&g_3299,&g_3299},{&g_3299,(void*)0,&g_3299,&g_3299},{(void*)0,&g_3299,&g_3299,&g_3299},{&g_3299,&g_3299,(void*)0,&g_3299},{(void*)0,&g_3299,&g_3299,(void*)0},{(void*)0,&g_3299,(void*)0,(void*)0}},{{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,(void*)0,&g_3299,(void*)0},{(void*)0,&g_3299,&g_3299,(void*)0},{(void*)0,&g_3299,&g_3299,&g_3299},{(void*)0,&g_3299,&g_3299,&g_3299},{&g_3299,&g_3299,&g_3299,(void*)0},{&g_3299,(void*)0,(void*)0,&g_3299},{(void*)0,&g_3299,&g_3299,&g_3299},{(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,(void*)0,(void*)0,&g_3299},{&g_3299,(void*)0,&g_3299,&g_3299},{&g_3299,(void*)0,(void*)0,&g_3299},{&g_3299,&g_3299,&g_3299,(void*)0},{&g_3299,(void*)0,&g_3299,&g_3299},{&g_3299,(void*)0,(void*)0,&g_3299},{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,(void*)0,&g_3299,&g_3299}},{{(void*)0,(void*)0,&g_3299,&g_3299},{(void*)0,&g_3299,(void*)0,(void*)0},{(void*)0,&g_3299,&g_3299,&g_3299},{(void*)0,(void*)0,&g_3299,&g_3299},{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,&g_3299,(void*)0,&g_3299},{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,&g_3299,(void*)0,&g_3299}},{{&g_3299,&g_3299,&g_3299,(void*)0},{&g_3299,&g_3299,(void*)0,&g_3299},{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,&g_3299,(void*)0,&g_3299},{(void*)0,&g_3299,&g_3299,&g_3299},{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,(void*)0,&g_3299,&g_3299},{&g_3299,&g_3299,&g_3299,(void*)0}},{{(void*)0,&g_3299,&g_3299,&g_3299},{&g_3299,(void*)0,&g_3299,&g_3299},{&g_3299,(void*)0,&g_3299,&g_3299},{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,(void*)0,&g_3299,&g_3299},{(void*)0,(void*)0,(void*)0,(void*)0},{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,(void*)0,(void*)0,&g_3299},{&g_3299,(void*)0,&g_3299,&g_3299}},{{&g_3299,(void*)0,(void*)0,&g_3299},{&g_3299,&g_3299,&g_3299,(void*)0},{&g_3299,(void*)0,&g_3299,&g_3299},{&g_3299,(void*)0,(void*)0,&g_3299},{&g_3299,&g_3299,&g_3299,&g_3299},{&g_3299,(void*)0,&g_3299,&g_3299},{(void*)0,(void*)0,&g_3299,&g_3299},{(void*)0,&g_3299,(void*)0,(void*)0},{(void*)0,&g_3299,&g_3299,&g_3299}}};
static const union U1 *****g_3297 = &g_3298[5][3][3];
static const union U1 g_3386 = {0x5A70A1E4BF36D3FCLL};/* VOLATILE GLOBAL g_3386 */
static uint32_t * volatile * volatile *g_3394 = &g_1142;
static uint32_t * volatile * volatile **g_3393 = &g_3394;
static struct S0 g_3408 = {0x4906E438L,1,-1L,6UL,0xB77B6E57DB14B867LL,0x8008L};
static uint16_t g_3427[3] = {65529UL,65529UL,65529UL};
static union U1 g_3448 = {0x309ADD2C3544079ALL};/* VOLATILE GLOBAL g_3448 */
static volatile union U1 g_3464 = {1UL};/* VOLATILE GLOBAL g_3464 */
static int32_t g_3466[6] = {0xA1187A93L,0xA1187A93L,0xA1187A93L,0xA1187A93L,0xA1187A93L,0xA1187A93L};
static struct S0 ** volatile g_3471[8] = {&g_853[1],&g_853[1],&g_853[1],&g_853[1],&g_853[1],&g_853[1],&g_853[1],&g_853[1]};
static struct S0 ** volatile g_3472 = &g_853[2];/* VOLATILE GLOBAL g_3472 */
static uint32_t g_3475 = 9UL;
static uint8_t g_3487 = 0x15L;
static volatile int64_t g_3521 = 0x3E3F8D66C481CD3DLL;/* VOLATILE GLOBAL g_3521 */
static int16_t g_3547 = 0xEFC4L;
static struct S0 g_3558 = {0x22AF55FEL,3,0L,0xDE7A1BD6L,1UL,65528UL};
static const union U1 g_3594 = {18446744073709551615UL};/* VOLATILE GLOBAL g_3594 */
static union U1 g_3614 = {0x6A038055CA9F88FDLL};/* VOLATILE GLOBAL g_3614 */
static int32_t *g_3621 = &g_3466[0];
static int32_t **g_3620 = &g_3621;
static int32_t ***g_3619 = &g_3620;
static int8_t g_3668 = 0x9EL;
static struct S0 g_3686 = {1UL,-1,-1L,1UL,1UL,7UL};
static int32_t g_3819 = 0xCB0CB268L;
static int16_t *g_3838 = &g_3547;
static int16_t **g_3837 = &g_3838;
static int16_t *** volatile g_3836 = &g_3837;/* VOLATILE GLOBAL g_3836 */
static struct S0 g_3840[3][4] = {{{4294967295UL,-2,0xF984C670L,0x12C9E6C9L,1UL,0xD42DL},{0x6BE001A4L,3,0x9CA5BEE6L,4294967295UL,1UL,0x1C45L},{0x6BE001A4L,3,0x9CA5BEE6L,4294967295UL,1UL,0x1C45L},{4294967295UL,-2,0xF984C670L,0x12C9E6C9L,1UL,0xD42DL}},{{0x6BE001A4L,3,0x9CA5BEE6L,4294967295UL,1UL,0x1C45L},{4294967295UL,-2,0xF984C670L,0x12C9E6C9L,1UL,0xD42DL},{0x6BE001A4L,3,0x9CA5BEE6L,4294967295UL,1UL,0x1C45L},{0x6BE001A4L,3,0x9CA5BEE6L,4294967295UL,1UL,0x1C45L}},{{4294967295UL,-2,0xF984C670L,0x12C9E6C9L,1UL,0xD42DL},{4294967295UL,-2,0xF984C670L,0x12C9E6C9L,1UL,0xD42DL},{0UL,2,0xDB5161ABL,4294967287UL,0xCFBB34D6C46A7A48LL,0x7046L},{4294967295UL,-2,0xF984C670L,0x12C9E6C9L,1UL,0xD42DL}}};
static uint32_t *g_3849 = &g_2078;
static uint32_t * volatile * volatile g_3848[5][2][5] = {{{&g_3849,&g_3849,&g_3849,&g_3849,&g_3849},{&g_3849,&g_3849,(void*)0,&g_3849,&g_3849}},{{&g_3849,&g_3849,&g_3849,&g_3849,&g_3849},{&g_3849,&g_3849,&g_3849,&g_3849,&g_3849}},{{&g_3849,&g_3849,&g_3849,&g_3849,&g_3849},{&g_3849,&g_3849,&g_3849,&g_3849,&g_3849}},{{&g_3849,&g_3849,&g_3849,&g_3849,&g_3849},{&g_3849,&g_3849,&g_3849,&g_3849,&g_3849}},{{&g_3849,&g_3849,&g_3849,&g_3849,&g_3849},{&g_3849,&g_3849,&g_3849,&g_3849,&g_3849}}};
static uint32_t * volatile * volatile * volatile g_3847 = &g_3848[1][0][0];/* VOLATILE GLOBAL g_3847 */
static uint32_t g_3887[10] = {4294967291UL,4294967291UL,4294967291UL,4294967291UL,4294967291UL,4294967291UL,4294967291UL,4294967291UL,4294967291UL,4294967291UL};
static uint32_t g_3911 = 0xAFC35BD4L;
static uint32_t ***g_3985 = &g_2233;
static uint32_t ****g_3984 = &g_3985;
static const int64_t *g_3989[8][10] = {{&g_161,&g_675,&g_675,&g_161,&g_161,&g_675,&g_675,&g_161,&g_161,&g_675},{&g_161,&g_161,&g_675,&g_675,&g_161,&g_161,&g_675,&g_675,&g_161,&g_161},{&g_161,&g_675,&g_675,&g_161,&g_161,&g_675,&g_675,&g_161,&g_161,&g_675},{&g_161,&g_161,&g_675,&g_675,&g_161,&g_161,&g_675,&g_675,&g_161,&g_161},{&g_161,&g_675,&g_675,&g_161,&g_161,&g_675,&g_675,&g_161,&g_161,&g_675},{&g_161,&g_161,&g_675,&g_675,&g_161,&g_161,&g_675,&g_675,&g_161,&g_161},{&g_161,&g_675,&g_675,&g_161,&g_161,&g_675,&g_675,&g_161,&g_161,&g_675},{&g_161,&g_161,&g_675,&g_675,&g_161,&g_161,&g_675,&g_675,&g_161,&g_161}};
static const int64_t **g_3988[8][10] = {{(void*)0,&g_3989[4][7],(void*)0,(void*)0,&g_3989[3][5],&g_3989[3][5],&g_3989[7][1],&g_3989[3][5],&g_3989[3][5],(void*)0},{&g_3989[3][5],&g_3989[3][5],&g_3989[3][5],&g_3989[4][1],&g_3989[2][9],&g_3989[3][5],&g_3989[6][6],(void*)0,&g_3989[3][5],&g_3989[3][5]},{&g_3989[3][5],&g_3989[2][9],&g_3989[7][1],(void*)0,&g_3989[6][6],&g_3989[4][2],&g_3989[3][5],(void*)0,&g_3989[4][5],&g_3989[2][9]},{&g_3989[3][5],&g_3989[7][1],&g_3989[3][5],&g_3989[3][5],&g_3989[7][1],&g_3989[3][5],&g_3989[4][5],&g_3989[3][5],&g_3989[6][6],&g_3989[3][5]},{&g_3989[3][5],&g_3989[4][7],&g_3989[4][5],&g_3989[3][5],(void*)0,&g_3989[7][1],(void*)0,&g_3989[4][4],&g_3989[7][7],&g_3989[4][1]},{&g_3989[3][5],&g_3989[2][9],&g_3989[4][1],&g_3989[3][5],&g_3989[3][5],&g_3989[3][5],&g_3989[4][1],&g_3989[2][9],&g_3989[3][5],&g_3989[6][6]},{&g_3989[3][5],&g_3989[4][1],&g_3989[2][9],&g_3989[3][5],&g_3989[6][6],(void*)0,&g_3989[3][5],&g_3989[3][5],&g_3989[3][5],&g_3989[4][4]},{&g_3989[3][5],&g_3989[4][5],&g_3989[4][7],&g_3989[3][5],&g_3989[3][5],(void*)0,(void*)0,&g_3989[3][5],&g_3989[3][5],&g_3989[4][7]}};
static const int64_t *** volatile g_3987[2] = {&g_3988[7][7],&g_3988[7][7]};
static int16_t *****g_4008[5] = {&g_3272,&g_3272,&g_3272,&g_3272,&g_3272};
static int32_t *** const *g_4046 = &g_2056;
static int32_t *** const **g_4045 = &g_4046;
static int16_t g_4054 = 9L;


/* --- FORWARD DECLARATIONS --- */
static uint16_t  func_1(void);
static uint32_t  func_14(uint8_t  p_15);
static uint64_t  func_25(int32_t ** const  p_26, int8_t  p_27, int8_t  p_28, int32_t * p_29);
static int16_t  func_34(int32_t * const * p_35, struct S0  p_36, int32_t * const * p_37, int32_t ** p_38, const struct S0  p_39);
static struct S0  func_40(int32_t ** p_41, uint32_t  p_42, uint16_t  p_43);
static int32_t ** func_44(int64_t  p_45, struct S0  p_46, int32_t * p_47);
static struct S0  func_48(int32_t  p_49);
static const uint32_t  func_50(int8_t  p_51, uint16_t  p_52, int32_t  p_53, int32_t * p_54);
static uint16_t  func_57(int32_t ** p_58, int64_t  p_59, int32_t  p_60);
static int64_t  func_63(uint32_t  p_64, int32_t  p_65, int32_t * p_66, int32_t  p_67);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_3 g_3837 g_3838 g_3819 g_3887 g_1154 g_1155 g_161 g_1281 g_938 g_939 g_440.f4 g_1138 g_2936.f0 g_242 g_243 g_140 g_859 g_860 g_1401 g_221 g_165 g_1865.f0 g_1400 g_854.f0 g_1489 g_1490 g_1491 g_2551.f0 g_854.f5 g_2685 g_4045 g_3427 g_985.f0
 * writes: g_3 g_3668 g_3547 g_161 g_4008 g_853 g_165 g_3253 g_3408.f4 g_2936.f4 g_221
 */
static uint16_t  func_1(void)
{ /* block id: 0 */
    int16_t l_16 = 0xD333L;
    int32_t l_3994 = 0x56847EA7L;
    uint64_t l_3995 = 2UL;
    uint32_t l_4042 = 0UL;
    int32_t *** const **l_4047[2];
    struct S0 *l_4048 = &g_3408;
    int64_t l_4052[8];
    int64_t l_4053 = (-7L);
    int16_t l_4055 = 0xFEF2L;
    uint32_t l_4056 = 0UL;
    int i;
    for (i = 0; i < 2; i++)
        l_4047[i] = &g_4046;
    for (i = 0; i < 8; i++)
        l_4052[i] = 0x58C19BD63B5CD605LL;
    for (g_3 = 6; (g_3 < (-25)); g_3 = safe_sub_func_int32_t_s_s(g_3, 4))
    { /* block id: 3 */
        int8_t *l_3991 = &g_3668;
        int32_t l_3992 = 9L;
        int16_t *l_3993[4][2][2] = {{{&g_338,&g_338},{&g_338,&g_338}},{{&g_338,&g_338},{&g_338,&g_338}},{{&g_338,&g_338},{&g_338,&g_338}},{{&g_338,&g_338},{&g_338,&g_338}}};
        int i, j, k;
        if (((safe_div_func_int64_t_s_s(((safe_lshift_func_int16_t_s_s(((safe_add_func_int16_t_s_s(0x8932L, ((g_3 >= (safe_mod_func_int8_t_s_s(((l_3994 = (((*l_3991) = (func_14(l_16) >= 4294967289UL)) , ((**g_3837) = l_3992))) || (l_3994 = g_3819)), l_3995))) <= l_16))) > l_3992), 1)) != g_3887[1]), l_16)) == 0xF24F5052L))
        { /* block id: 2008 */
            uint64_t l_4000 = 0x822A46EFAE3D6BA9LL;
            uint32_t l_4003 = 0x6974DE5BL;
            (*g_1138) = ((((safe_add_func_int64_t_s_s((0x19AFE324470004A2LL && ((safe_sub_func_int16_t_s_s((-3L), (l_4000 | l_3992))) , ((**g_1154) ^= l_16))), ((g_4008[4] = (((safe_mul_func_int32_t_s_s(l_4003, (((*g_3837) != (void*)0) < (safe_add_func_int16_t_s_s((safe_add_func_uint64_t_u_u((***g_1281), l_3995)), l_16))))) , 0x1529L) , &g_3272)) == &g_3272))) == l_3992) > l_3992) , (void*)0);
            (**g_1401) |= (safe_mod_func_uint16_t_u_u(g_2936.f0, (((l_3994 = 0x7FL) | (safe_mod_func_int64_t_s_s((0x82DEL & ((-6L) < (**g_242))), (*g_859)))) ^ (((((((l_3992 ^ (*g_243)) , (0L ^ 0x9EL)) || l_4000) , (**g_1154)) , 1UL) && 9L) , 7UL))));
        }
        else
        { /* block id: 2014 */
            int32_t l_4026 = 0x7E155FB7L;
            for (g_3253 = 0; (g_3253 > (-21)); g_3253 = safe_sub_func_uint64_t_u_u(g_3253, 4))
            { /* block id: 2017 */
                int64_t l_4019 = 0L;
                for (g_3408.f4 = 0; (g_3408.f4 >= 36); g_3408.f4++)
                { /* block id: 2020 */
                    for (g_2936.f4 = 0; (g_2936.f4 <= 47); ++g_2936.f4)
                    { /* block id: 2023 */
                        return g_1865.f0;
                    }
                }
                (**g_1400) = &l_3994;
                l_4026 &= (((4UL != l_4019) && ((safe_mul_func_uint16_t_u_u(g_854.f0, ((**g_3837) = (0x497801AAL < ((safe_mul_func_uint8_t_u_u((**g_242), (**g_1489))) , ((*g_221) = (safe_rshift_func_uint64_t_u_u((((l_4019 , g_2551.f0) && l_3994) , l_16), l_4019)))))))) ^ g_854.f5)) < l_4019);
            }
            if ((safe_lshift_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((6L != (l_3992 = 0x8FC92F4DL)), ((**g_242) && 0x28L))), 0)))
            { /* block id: 2033 */
                int32_t *l_4031 = &l_4026;
                int32_t l_4033 = (-2L);
                int32_t l_4034 = 0x45E2904AL;
                int32_t l_4039 = 0x4F4C59FDL;
                int64_t l_4040 = (-1L);
                int32_t l_4041 = 0x298A6E6EL;
                if ((**g_1401))
                { /* block id: 2034 */
                    int8_t l_4032 = 1L;
                    (*g_1401) = l_4031;
                    (*g_1401) = (void*)0;
                    return l_4032;
                }
                else
                { /* block id: 2038 */
                    int32_t *l_4035 = &g_3558.f2;
                    int32_t *l_4036 = &g_2936.f2;
                    int32_t *l_4037 = &g_3558.f2;
                    int32_t *l_4038[8] = {&g_3408.f2,&g_3408.f2,&g_3408.f2,&g_3408.f2,&g_3408.f2,&g_3408.f2,&g_3408.f2,&g_3408.f2};
                    int i;
                    ++l_4042;
                }
                if ((*g_221))
                    break;
            }
            else
            { /* block id: 2042 */
                return l_3995;
            }
            return g_2685;
        }
    }
    if (l_16)
    { /* block id: 2048 */
        struct S0 **l_4049 = &g_853[2];
        (***g_1400) = ((l_4047[1] = g_4045) == &g_2055);
        (*l_4049) = l_4048;
    }
    else
    { /* block id: 2052 */
        int16_t l_4050 = (-1L);
        int32_t l_4051[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
        int i;
        l_4056--;
        return g_3427[0];
    }
    return g_985.f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_3
 * writes:
 */
static uint32_t  func_14(uint8_t  p_15)
{ /* block id: 4 */
    int32_t *l_17 = &g_3;
    int32_t **l_18 = &l_17;
    int32_t l_3672 = 0x33CA68C0L;
    int32_t l_3673[10][10] = {{0x28939AE2L,0xDD133627L,(-1L),0xCB24DCFAL,0xD9CD0B05L,6L,(-5L),0L,0L,(-5L)},{0L,0xD9CD0B05L,0xDD133627L,0xDD133627L,0xD9CD0B05L,0L,6L,(-1L),0x28939AE2L,0xCB24DCFAL},{0xD9CD0B05L,(-5L),0xDD133627L,0xCB24DCFAL,0L,(-1L),(-1L),0L,0xCB24DCFAL,0xDD133627L},{0xD9CD0B05L,0xD9CD0B05L,(-1L),(-5L),0x28939AE2L,0L,0xDD133627L,6L,0xCB24DCFAL,0xCB24DCFAL},{0L,0xDD133627L,6L,0xCB24DCFAL,0xCB24DCFAL,6L,0xDD133627L,0L,0x28939AE2L,(-5L)},{0x28939AE2L,0xD9CD0B05L,(-5L),0xDD133627L,0xCB24DCFAL,0L,(-1L),(-1L),0L,0xCB24DCFAL},{0xCB24DCFAL,(-5L),(-5L),0xCB24DCFAL,0x28939AE2L,(-1L),6L,0L,0xD9CD0B05L,0xDD133627L},{0xCB24DCFAL,0xD9CD0B05L,6L,(-5L),0L,0L,(-5L),6L,0xD9CD0B05L,0xCB24DCFAL},{0x28939AE2L,0xDD133627L,(-1L),0xCB24DCFAL,0xD9CD0B05L,6L,(-5L),0L,0L,(-5L)},{0L,0xD9CD0B05L,0xDD133627L,0xDD133627L,0xD9CD0B05L,0L,6L,(-1L),0x28939AE2L,0xCB24DCFAL}};
    struct S0 *l_3684 = &g_3408;
    int64_t ***l_3690[4][5][6] = {{{(void*)0,&g_1154,&g_1154,&g_1154,&g_1154,&g_1154},{(void*)0,&g_1154,&g_1154,(void*)0,&g_1154,&g_1154},{&g_1154,(void*)0,&g_1154,(void*)0,&g_1154,&g_1154},{(void*)0,&g_1154,&g_1154,&g_1154,&g_1154,(void*)0},{&g_1154,(void*)0,&g_1154,&g_1154,&g_1154,(void*)0}},{{&g_1154,&g_1154,&g_1154,&g_1154,&g_1154,&g_1154},{&g_1154,&g_1154,&g_1154,&g_1154,&g_1154,&g_1154},{&g_1154,&g_1154,&g_1154,&g_1154,&g_1154,&g_1154},{(void*)0,&g_1154,&g_1154,(void*)0,&g_1154,&g_1154},{&g_1154,(void*)0,&g_1154,(void*)0,&g_1154,&g_1154}},{{(void*)0,&g_1154,&g_1154,&g_1154,&g_1154,(void*)0},{&g_1154,(void*)0,&g_1154,&g_1154,&g_1154,(void*)0},{&g_1154,&g_1154,&g_1154,&g_1154,&g_1154,&g_1154},{&g_1154,&g_1154,&g_1154,&g_1154,&g_1154,&g_1154},{&g_1154,&g_1154,&g_1154,&g_1154,&g_1154,&g_1154}},{{(void*)0,&g_1154,&g_1154,(void*)0,&g_1154,&g_1154},{&g_1154,(void*)0,&g_1154,(void*)0,&g_1154,&g_1154},{(void*)0,&g_1154,&g_1154,&g_1154,&g_1154,(void*)0},{&g_1154,(void*)0,&g_1154,&g_1154,&g_1154,(void*)0},{&g_1154,&g_1154,&g_1154,&g_1154,&g_1154,&g_1154}}};
    const uint64_t *l_3708[10][8] = {{&g_3408.f4,&g_2936.f4,&g_2936.f4,&g_3408.f4,&g_2936.f4,(void*)0,&g_262,&g_3686.f4},{(void*)0,&g_2936.f4,&g_3558.f4,&g_3408.f4,&g_3686.f4,(void*)0,(void*)0,&g_3686.f4},{&g_3408.f4,&g_2936.f4,&g_2936.f4,&g_3408.f4,&g_2936.f4,(void*)0,&g_262,&g_3686.f4},{(void*)0,&g_2936.f4,&g_3558.f4,&g_3408.f4,&g_3686.f4,(void*)0,(void*)0,&g_3686.f4},{&g_3408.f4,&g_2936.f4,&g_2936.f4,&g_3408.f4,&g_2936.f4,(void*)0,&g_262,&g_3686.f4},{(void*)0,&g_2936.f4,&g_3558.f4,&g_3408.f4,&g_3686.f4,(void*)0,(void*)0,&g_3686.f4},{&g_3408.f4,&g_2936.f4,&g_2936.f4,&g_3408.f4,&g_2936.f4,(void*)0,&g_262,&g_3686.f4},{(void*)0,&g_2936.f4,&g_3558.f4,&g_3408.f4,&g_3686.f4,(void*)0,(void*)0,&g_3686.f4},{&g_3408.f4,&g_2936.f4,&g_2936.f4,&g_3408.f4,&g_2936.f4,(void*)0,&g_262,&g_3686.f4},{(void*)0,&g_2936.f4,&g_3558.f4,&g_3408.f4,&g_3686.f4,(void*)0,(void*)0,&g_3686.f4}};
    const uint64_t **l_3707 = &l_3708[5][1];
    const uint64_t ***l_3706 = &l_3707;
    const uint64_t ****l_3705 = &l_3706;
    const uint64_t **** const *l_3704 = &l_3705;
    int64_t *** const *l_3710 = (void*)0;
    int64_t *** const **l_3709[1][8][7] = {{{&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710},{(void*)0,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710},{&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710},{(void*)0,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710},{&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710},{(void*)0,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710},{&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710},{(void*)0,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710,&l_3710}}};
    uint16_t l_3775 = 0x533EL;
    int32_t ****l_3815[5][8] = {{&g_3619,&g_3619,&g_3619,&g_3619,&g_3619,&g_3619,&g_3619,&g_3619},{(void*)0,&g_3619,&g_3619,&g_3619,(void*)0,(void*)0,&g_3619,&g_3619},{(void*)0,(void*)0,&g_3619,&g_3619,&g_3619,(void*)0,(void*)0,&g_3619},{&g_3619,&g_3619,&g_3619,&g_3619,&g_3619,&g_3619,&g_3619,&g_3619},{&g_3619,&g_3619,&g_3619,&g_3619,&g_3619,&g_3619,&g_3619,&g_3619}};
    uint32_t l_3902 = 2UL;
    int64_t l_3973 = 0xCED30E64E39320AELL;
    int i, j, k;
    (*l_18) = l_17;
    for (p_15 = (-30); (p_15 != 9); p_15 = safe_add_func_uint64_t_u_u(p_15, 1))
    { /* block id: 8 */
        int32_t *l_1679 = &g_79;
        const struct S0 l_1930 = {0xCDD143B3L,3,0x2F3689CDL,0xBEC51615L,0xD3E26CAA35D3490CLL,65531UL};
        int32_t *l_2652 = &g_1678.f2;
        int32_t l_3674 = 0xB0C051DEL;
        int32_t l_3675 = (-10L);
        int32_t l_3676 = (-1L);
        int64_t l_3677[3][7][10] = {{{3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L},{0xDAD96431786CF747LL,0xDAD96431786CF747LL,0xD63EAFC8BE72428BLL,0xDAD96431786CF747LL,0xDAD96431786CF747LL,0xD63EAFC8BE72428BLL,0xDAD96431786CF747LL,0xDAD96431786CF747LL,0xD63EAFC8BE72428BLL,0xDAD96431786CF747LL},{0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL},{3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L},{0xDAD96431786CF747LL,0xDAD96431786CF747LL,0xD63EAFC8BE72428BLL,0xDAD96431786CF747LL,0xDAD96431786CF747LL,0xD63EAFC8BE72428BLL,0xDAD96431786CF747LL,0xDAD96431786CF747LL,0xD63EAFC8BE72428BLL,0xDAD96431786CF747LL},{0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL},{3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L}},{{0xDAD96431786CF747LL,0xDAD96431786CF747LL,0xD63EAFC8BE72428BLL,0xDAD96431786CF747LL,0xDAD96431786CF747LL,0xD63EAFC8BE72428BLL,0xDAD96431786CF747LL,0xDAD96431786CF747LL,0xD63EAFC8BE72428BLL,0xDAD96431786CF747LL},{0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,0xD63EAFC8BE72428BLL,3L},{0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL},{3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L},{3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L},{0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL},{3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L}},{{3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L},{0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL},{3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L},{3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L},{0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL},{3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L,3L,0xDAD96431786CF747LL,3L},{3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L,0xD63EAFC8BE72428BLL,0xD63EAFC8BE72428BLL,3L}}};
        int32_t l_3678[2];
        int64_t l_3679 = 0L;
        uint32_t l_3681 = 0xC788D5DBL;
        int32_t l_3889 = 0x50174BE9L;
        uint16_t l_3890 = 65529UL;
        uint32_t l_3948[2];
        uint64_t l_3977 = 0x8394637944BBC877LL;
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_3678[i] = (-1L);
        for (i = 0; i < 2; i++)
            l_3948[i] = 0xB7E739DCL;
    }
    return (**l_18);
}


/* ------------------------------------------ */
/* 
 * reads : g_939 g_440.f4
 * writes:
 */
static uint64_t  func_25(int32_t ** const  p_26, int8_t  p_27, int8_t  p_28, int32_t * p_29)
{ /* block id: 1259 */
    int16_t l_2662 = 0x7593L;
    uint64_t **l_2678 = &g_939;
    const int32_t l_2681 = 0xD8045B99L;
    uint8_t **l_2702 = &g_243;
    union U1 **l_2741 = &g_647;
    union U1 ***l_2740 = &l_2741;
    union U1 *** const *l_2739 = &l_2740;
    union U1 *** const **l_2738 = &l_2739;
    int32_t *l_2769 = &g_165;
    uint8_t *l_2783 = &g_140;
    int64_t *****l_2800[8] = {&g_1530,&g_1530,&g_1530,&g_1530,&g_1530,&g_1530,&g_1530,&g_1530};
    int8_t l_2813 = 0xB7L;
    struct S0 l_2825 = {1UL,0,-10L,7UL,1UL,0x2749L};
    int32_t l_2925 = 0xC3CC0D75L;
    struct S0 *l_2934 = &g_1678;
    int16_t l_2939[7] = {5L,0x85C6L,0x85C6L,5L,0x85C6L,0x85C6L,5L};
    int32_t l_2940 = 0x3C826A29L;
    const uint64_t *l_3006[10] = {(void*)0,&g_1924.f4,(void*)0,(void*)0,&g_1924.f4,(void*)0,(void*)0,&g_1924.f4,(void*)0,(void*)0};
    const uint64_t **l_3005 = &l_3006[1];
    const uint64_t ***l_3004 = &l_3005;
    const uint64_t ****l_3003[8][10] = {{&l_3004,&l_3004,&l_3004,&l_3004,(void*)0,&l_3004,(void*)0,&l_3004,&l_3004,&l_3004},{&l_3004,&l_3004,&l_3004,&l_3004,&l_3004,&l_3004,&l_3004,(void*)0,&l_3004,&l_3004},{(void*)0,&l_3004,(void*)0,&l_3004,&l_3004,&l_3004,&l_3004,(void*)0,&l_3004,(void*)0},{&l_3004,&l_3004,&l_3004,&l_3004,&l_3004,&l_3004,&l_3004,&l_3004,&l_3004,&l_3004},{&l_3004,&l_3004,&l_3004,&l_3004,(void*)0,&l_3004,&l_3004,(void*)0,(void*)0,&l_3004},{(void*)0,&l_3004,&l_3004,&l_3004,&l_3004,(void*)0,&l_3004,(void*)0,&l_3004,&l_3004},{&l_3004,&l_3004,&l_3004,&l_3004,(void*)0,&l_3004,&l_3004,&l_3004,&l_3004,(void*)0},{&l_3004,&l_3004,&l_3004,&l_3004,&l_3004,(void*)0,(void*)0,&l_3004,&l_3004,&l_3004}};
    int32_t l_3026[7][3] = {{0x95B0D5C7L,(-8L),0x95B0D5C7L},{4L,4L,4L},{0x95B0D5C7L,(-8L),0x95B0D5C7L},{4L,4L,4L},{0x95B0D5C7L,(-8L),0x95B0D5C7L},{4L,4L,4L},{0x95B0D5C7L,(-8L),0x95B0D5C7L}};
    uint64_t **** const l_3073 = &g_1281;
    uint64_t **** const *l_3072 = &l_3073;
    uint16_t *l_3082 = &g_854.f5;
    int16_t l_3163 = 0x8CD3L;
    uint32_t ** const *l_3174 = &g_2233;
    int32_t **l_3215 = &g_221;
    int32_t l_3237 = (-1L);
    int32_t l_3254 = (-1L);
    uint64_t *****l_3264 = &g_3077;
    const uint32_t l_3285 = 18446744073709551612UL;
    int32_t **l_3319 = (void*)0;
    int16_t l_3370 = 0x2DB2L;
    int8_t *l_3412 = &g_127;
    int8_t **l_3411[4][10][6] = {{{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,(void*)0},{(void*)0,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,(void*)0,(void*)0,&l_3412,&l_3412,&l_3412},{(void*)0,(void*)0,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412}},{{&l_3412,&l_3412,&l_3412,&l_3412,(void*)0,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,(void*)0,(void*)0},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,(void*)0,&l_3412,&l_3412,&l_3412,(void*)0},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,(void*)0},{&l_3412,(void*)0,(void*)0,(void*)0,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,(void*)0,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,(void*)0,&l_3412,(void*)0,&l_3412}},{{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,(void*)0,&l_3412,&l_3412},{&l_3412,(void*)0,&l_3412,(void*)0,&l_3412,&l_3412},{(void*)0,&l_3412,&l_3412,&l_3412,&l_3412,(void*)0},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,(void*)0},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,(void*)0,&l_3412,&l_3412},{(void*)0,&l_3412,&l_3412,(void*)0,&l_3412,&l_3412},{&l_3412,&l_3412,(void*)0,&l_3412,&l_3412,&l_3412}},{{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,(void*)0},{&l_3412,&l_3412,&l_3412,&l_3412,(void*)0,&l_3412},{&l_3412,(void*)0,&l_3412,&l_3412,&l_3412,(void*)0},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,(void*)0},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,(void*)0,&l_3412,&l_3412,&l_3412},{&l_3412,&l_3412,&l_3412,&l_3412,&l_3412,&l_3412}}};
    int32_t *l_3421 = (void*)0;
    uint32_t l_3444 = 1UL;
    int16_t l_3508 = (-1L);
    int32_t l_3510 = 0x4734EC78L;
    uint16_t l_3531 = 8UL;
    int8_t l_3609 = (-7L);
    int i, j, k;
    return (*g_939);
}


/* ------------------------------------------ */
/* 
 * reads : g_858 g_859 g_860 g_1281 g_938 g_939 g_440.f4 g_3 g_2246 g_79 g_1490 g_1491 g_1154 g_1155 g_2515 g_1400 g_1401 g_2526 g_242 g_243 g_140 g_2551 g_1030 g_1031 g_675 g_2188 g_854.f4 g_1179 g_440.f1 g_161 g_1280 g_1003 g_1193 g_854.f3 g_854.f2 g_165 g_347 g_854.f5
 * writes: g_1179 g_165 g_79 g_221 g_347 g_854.f4 g_161 g_675 g_2515 g_854.f5 g_140 g_440.f4 g_647 g_854.f3 g_854.f2
 */
static int16_t  func_34(int32_t * const * p_35, struct S0  p_36, int32_t * const * p_37, int32_t ** p_38, const struct S0  p_39)
{ /* block id: 913 */
    int32_t l_1941 = 0x8498952FL;
    uint8_t *l_1957[6][1];
    int32_t l_1967 = 0xD0007534L;
    int32_t l_1972 = 7L;
    int32_t l_1974 = 0xD23E14E3L;
    int32_t l_1976 = 9L;
    int32_t l_1977 = 0L;
    int32_t l_1978 = 0xF18B1FAEL;
    int8_t l_1982 = 0xF0L;
    const int16_t *l_2004 = &g_338;
    uint64_t *l_2086 = &g_854.f4;
    int32_t *l_2094 = &g_1179;
    int32_t **l_2093 = &l_2094;
    uint32_t l_2104 = 0x5137B758L;
    int32_t l_2182 = (-1L);
    int32_t l_2183 = 0x3ECBFDC7L;
    int32_t l_2184 = 0x9AAC5CC9L;
    int32_t l_2186 = 0x00F2D241L;
    int32_t l_2187[4][2][4] = {{{(-1L),7L,0xB72A0534L,0L},{0x95C08F0AL,0x2451C88AL,(-5L),1L}},{{0xB72A0534L,(-1L),(-1L),(-1L)},{0xB72A0534L,0xB72A0534L,(-5L),0x97CAEF1BL}},{{0x95C08F0AL,(-1L),0xB72A0534L,0x2451C88AL},{(-1L),0xF7ED837BL,0xCDB3AC7DL,0xB72A0534L}},{{0L,0xF7ED837BL,0L,0x2451C88AL},{0xF7ED837BL,(-1L),1L,0x97CAEF1BL}}};
    int32_t l_2189 = (-1L);
    int64_t l_2205 = 0x4B4ECBA49B7CDD45LL;
    union U1 **l_2269 = &g_647;
    int16_t *****l_2297 = (void*)0;
    struct S0 ** const l_2320 = &g_853[1];
    uint8_t l_2386 = 0x49L;
    int16_t *l_2420 = (void*)0;
    int16_t **l_2419[1][7][9] = {{{&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420},{&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,(void*)0,&l_2420},{&l_2420,&l_2420,&l_2420,&l_2420,(void*)0,&l_2420,&l_2420,&l_2420,&l_2420},{&l_2420,&l_2420,&l_2420,(void*)0,&l_2420,&l_2420,&l_2420,(void*)0,&l_2420},{&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420},{&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420},{&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420,&l_2420}}};
    int16_t ***l_2418[8];
    int16_t ****l_2417 = &l_2418[3];
    int32_t *l_2431 = &l_2187[2][0][2];
    int16_t l_2461 = (-8L);
    int64_t *l_2500 = (void*)0;
    int64_t *l_2501 = (void*)0;
    int64_t *l_2502 = (void*)0;
    int64_t *l_2503 = &g_675;
    int32_t l_2514[7] = {(-5L),0L,0L,(-5L),0L,0L,(-5L)};
    int32_t l_2536 = (-1L);
    uint32_t l_2606[8] = {0x22574072L,4294967292UL,0x22574072L,0x22574072L,4294967292UL,0x22574072L,0x22574072L,4294967292UL};
    uint32_t l_2632 = 0xD1AD1E78L;
    const int32_t *l_2636 = &l_1977;
    int i, j, k;
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 1; j++)
            l_1957[i][j] = &g_163;
    }
    for (i = 0; i < 8; i++)
        l_2418[i] = &l_2419[0][6][5];
lbl_2556:
    for (g_1179 = 3; (g_1179 >= 0); g_1179 -= 1)
    { /* block id: 916 */
        uint64_t l_1932 = 6UL;
        int16_t *l_1950 = &g_338;
        int16_t ** const l_1949[4] = {&l_1950,&l_1950,&l_1950,&l_1950};
        int16_t ** const *l_1948 = &l_1949[2];
        int16_t ** const **l_1947 = &l_1948;
        int16_t ** const ***l_1946 = &l_1947;
        uint32_t *l_1960 = &g_122[9][3];
        int32_t l_1965 = 0xDC37158FL;
        int32_t l_1968 = 0xF3025138L;
        int32_t l_1971 = 0L;
        int32_t l_1975 = 0x62D156D6L;
        int32_t l_1979 = 0xD21D4876L;
        int32_t l_1981 = (-1L);
        int32_t l_1987 = 0x4C564B46L;
        uint8_t l_2035 = 9UL;
        union U1 *l_2043[1][8][9] = {{{&g_918[2][5],&g_918[2][5],&g_1865,&g_1865,&g_918[2][5],&g_918[2][5],&g_1865,&g_1865,&g_918[2][5]},{&g_1188[1],&g_1801,&g_1188[1],&g_1801,&g_1188[1],&g_1801,&g_1188[1],&g_1801,&g_1188[1]},{&g_918[2][5],&g_1865,&g_1865,&g_918[2][5],&g_918[2][5],&g_1865,&g_1865,&g_918[2][5],&g_918[2][5]},{&g_918[0][2],&g_1801,&g_918[0][2],&g_1801,&g_918[0][2],&g_1801,&g_918[0][2],&g_1801,&g_918[0][2]},{&g_918[2][5],&g_918[2][5],&g_1865,&g_1865,&g_918[2][5],&g_918[2][5],&g_1865,&g_1865,&g_918[2][5]},{&g_1188[1],&g_1801,&g_1188[1],&g_1801,&g_1188[1],&g_1801,&g_1188[1],&g_1801,&g_1188[1]},{&g_918[2][5],&g_1865,&g_1865,&g_918[2][5],&g_918[2][5],&g_1865,&g_1865,&g_918[2][5],&g_918[2][5]},{&g_918[0][2],&g_1801,&g_918[0][2],&g_1801,&g_918[0][2],&g_1801,&g_918[0][2],&g_1801,&g_918[0][2]}}};
        int32_t ***l_2054[4][7] = {{(void*)0,&g_105,(void*)0,(void*)0,&g_105,(void*)0,&g_105},{(void*)0,&g_105,&g_105,(void*)0,&g_105,(void*)0,&g_105},{&g_105,&g_105,(void*)0,(void*)0,(void*)0,&g_105,&g_105},{&g_105,&g_105,&g_105,&g_105,&g_105,&g_105,&g_105}};
        int32_t ****l_2053 = &l_2054[0][3];
        uint64_t *** const l_2139[1][9] = {{&g_938,&g_938,&g_938,&g_938,&g_938,&g_938,&g_938,&g_938,&g_938}};
        int32_t l_2141 = 0x28EF8127L;
        int16_t l_2172 = 0L;
        struct S0 **l_2177 = &g_853[1];
        struct S0 ** const *l_2176[2];
        int32_t l_2206 = (-1L);
        int64_t l_2223 = 0x8109D654DF8E254ELL;
        int64_t l_2357 = 1L;
        uint32_t *l_2435[1];
        uint32_t **l_2434 = &l_2435[0];
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_2176[i] = &l_2177;
        for (i = 0; i < 1; i++)
            l_2435[i] = &g_346[4][0];
        for (g_165 = 3; (g_165 >= 0); g_165 -= 1)
        { /* block id: 919 */
            uint64_t l_1931 = 18446744073709551615UL;
            int8_t l_1958 = 0xB6L;
            int32_t *l_1959 = &g_1678.f2;
            union U1 *l_1962 = &g_1188[2];
            int32_t l_1973[9] = {0x679EC2ACL,0x679EC2ACL,0xCA8F75F6L,0x679EC2ACL,0x679EC2ACL,0xCA8F75F6L,0x679EC2ACL,0x679EC2ACL,0xCA8F75F6L};
            int16_t *****l_2036 = (void*)0;
            uint32_t l_2038 = 0xF4A7C409L;
            int32_t **l_2092 = (void*)0;
            int i;
            if (l_1931)
                break;
        }
        l_1974 ^= ((((safe_mul_func_int16_t_s_s((1UL | (safe_rshift_func_uint32_t_u_s((p_39 , l_1941), ((void*)0 != &g_1490)))), l_1977)) == (safe_rshift_func_int32_t_s_s(((**p_37) = ((safe_lshift_func_uint64_t_u_s(((p_36.f0 | ((l_1978 &= (l_2183 ^= p_39.f0)) , 0x94L)) , p_39.f1), (**g_858))) | (***g_1281))), (**p_35)))) , l_1941) ^ (**p_35));
        (*g_2246) = (*p_35);
        for (g_347 = 0; (g_347 <= 3); g_347 += 1)
        { /* block id: 1094 */
            int32_t **l_2249 = &l_2094;
            int32_t l_2268 = 3L;
            uint32_t ***l_2317 = &g_2233;
            uint32_t l_2318 = 0x68FC2816L;
            struct S0 l_2336 = {4294967286UL,-2,4L,0x19135816L,1UL,0x396AL};
            int32_t l_2358 = 0x08AFAD9DL;
            int8_t l_2376 = 0x85L;
            uint8_t l_2427 = 255UL;
            uint8_t l_2454 = 7UL;
            int16_t l_2457 = 0x0D5DL;
            if ((**p_35))
                break;
        }
    }
    if ((0x99266408L || ((~(p_36.f0 , p_39.f2)) & (p_39.f1 <= (((~(safe_unary_minus_func_int32_t_s((((safe_sub_func_uint16_t_u_u((!(*g_939)), ((((*l_2503) = ((**g_1154) = ((**p_38) < (safe_lshift_func_uint32_t_u_s((safe_lshift_func_int64_t_s_u((*l_2431), ((*l_2086) = ((safe_unary_minus_func_uint64_t_u((safe_rshift_func_uint8_t_u_s((~(((p_39.f5 ^ (+((((p_39.f3 || (-4L)) || p_36.f2) != (*l_2431)) ^ (*l_2431)))) , p_36.f2) == 1L)), (*g_1490))))) , 0x60C9FB339EC43061LL)))), 3))))) || p_36.f3) <= p_39.f5))) | (*l_2431)) <= 0x7E36L)))) , (**p_37)) <= 0x720EA907L)))))
    { /* block id: 1189 */
        int32_t *l_2504 = &l_2184;
        int32_t *l_2505 = (void*)0;
        int32_t *l_2506 = &l_2187[1][1][3];
        int32_t *l_2507 = &l_1967;
        int32_t *l_2508 = &l_1977;
        int32_t l_2509 = (-1L);
        int32_t *l_2510 = &l_2187[2][0][0];
        int32_t *l_2511 = &l_1967;
        int32_t *l_2512 = &l_1974;
        int32_t *l_2513[6] = {&l_1972,&l_1972,&l_2184,&l_1972,&l_1972,&l_2184};
        int i;
        ++g_2515;
        (*p_38) = &l_2509;
        (**g_1400) = (void*)0;
    }
    else
    { /* block id: 1193 */
        struct S0 *l_2527 = &g_854;
        int32_t l_2528 = 1L;
        int32_t l_2530 = 0x4E794401L;
        int32_t l_2545 = 0xB0982D63L;
        uint64_t l_2546[3];
        uint64_t **** const l_2552 = &g_1281;
        union U1 ***l_2580 = (void*)0;
        uint8_t l_2587 = 0xB6L;
        int32_t l_2599 = 1L;
        int8_t l_2601 = 0x7CL;
        int32_t l_2602[5][3][3];
        int16_t l_2604[7][1];
        int32_t l_2605 = (-1L);
        uint32_t l_2631 = 0x98DB7E6CL;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2546[i] = 8UL;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 3; j++)
            {
                for (k = 0; k < 3; k++)
                    l_2602[i][j][k] = (-3L);
            }
        }
        for (i = 0; i < 7; i++)
        {
            for (j = 0; j < 1; j++)
                l_2604[i][j] = 0L;
        }
        for (l_2182 = 0; (l_2182 <= (-5)); l_2182 = safe_sub_func_int64_t_s_s(l_2182, 2))
        { /* block id: 1196 */
            int16_t ****l_2529 = &l_2418[3];
            const int32_t l_2531 = 7L;
            int32_t l_2538 = 0x3DA5EF5FL;
            int32_t l_2541 = 0x63B1B981L;
            uint16_t l_2594 = 5UL;
            int32_t l_2598 = 1L;
            int32_t l_2600[8][3][8] = {{{0xC4BA0DC9L,0xC4036EF0L,(-9L),0L,1L,0xC4BA0DC9L,(-6L),0x4C74275FL},{0xC4036EF0L,0x1AC7AB0DL,0x30BBB3BFL,1L,1L,(-9L),0L,(-1L)},{0xC4BA0DC9L,0x6B57FC60L,(-1L),0x4C74275FL,(-1L),0x12E33F7AL,7L,0xC4BA0DC9L}},{{6L,(-1L),(-1L),(-9L),(-10L),(-10L),(-9L),(-1L)},{0xA0F8C372L,0xA0F8C372L,(-6L),(-1L),0x9B51EB5CL,(-9L),(-1L),(-9L)},{0x65395D11L,0x12E33F7AL,8L,3L,0xA0F8C372L,0x30BBB3BFL,0x12E33F7AL,(-9L)}},{{0x12E33F7AL,6L,0x61FF6260L,0L,(-1L),(-1L),0xF0F91792L,1L},{(-1L),1L,0x30BBB3BFL,8L,0L,(-1L),0xA0F8C372L,(-1L)},{(-9L),(-1L),7L,(-1L),(-9L),(-6L),8L,0L}},{{7L,0xC4036EF0L,0x12E33F7AL,0x6B57FC60L,(-9L),(-9L),0x9B51EB5CL,(-1L)},{(-1L),(-9L),0x12E33F7AL,0x30BBB3BFL,0xA0F8C372L,3L,8L,0x12E33F7AL},{(-9L),(-1L),7L,0L,0x4E3D05E3L,0L,0xA0F8C372L,0x61FF6260L}},{{0x65395D11L,0xF0F91792L,0x30BBB3BFL,0xCAAC760AL,0xCAAC760AL,0x30BBB3BFL,0xF0F91792L,0x65395D11L},{0xC4036EF0L,(-1L),0x61FF6260L,0L,0x9B51EB5CL,7L,0x12E33F7AL,1L},{7L,(-9L),8L,0x46B94E04L,0L,7L,(-1L),(-1L)}},{{0xABF22511L,(-1L),0xCAAC760AL,(-1L),1L,0x30BBB3BFL,8L,0L},{(-1L),0xF0F91792L,1L,0x6B57FC60L,(-1L),0L,(-1L),0x6B57FC60L},{(-1L),(-1L),(-1L),8L,0xCAAC760AL,3L,(-10L),(-1L)}},{{0x9B51EB5CL,(-9L),7L,0L,0x4C74275FL,(-9L),0xCAAC760AL,0x61FF6260L},{0x9B51EB5CL,0xC4036EF0L,8L,7L,0xCAAC760AL,(-6L),0xC4036EF0L,(-9L)},{(-1L),(-1L),(-9L),0xABF22511L,(-1L),(-1L),0x12E33F7AL,0x12E33F7AL}},{{(-1L),1L,0x46B94E04L,0x46B94E04L,1L,(-1L),0xA0F8C372L,0x6B57FC60L},{0xABF22511L,6L,3L,(-1L),0L,0x30BBB3BFL,(-10L),0xABF22511L},{7L,0x12E33F7AL,1L,(-1L),0x9B51EB5CL,(-9L),(-9L),0x6B57FC60L}}};
            int i, j, k;
            for (g_854.f5 = 0; (g_854.f5 > 33); g_854.f5++)
            { /* block id: 1199 */
                int32_t l_2537 = 0x859830C1L;
                int32_t l_2540 = 0xED1FF27FL;
                int32_t l_2544 = 0xB912DD5AL;
                uint16_t l_2571 = 0x3674L;
                union U1 ***l_2582 = &l_2269;
                int32_t l_2603[3];
                const int32_t *l_2633 = (void*)0;
                int i;
                for (i = 0; i < 3; i++)
                    l_2603[i] = 0xA7D7BA46L;
                (*l_2431) = ((**p_38) = 0x39877F82L);
                if ((((p_39.f5 && 8UL) , (safe_mul_func_uint16_t_u_u((((*l_2431) != (l_2528 = ((**g_1154) = ((g_2526 , l_2527) == l_2527)))) , (l_2529 == (void*)0)), l_2530))) || l_2531))
                { /* block id: 1204 */
                    int8_t l_2539 = 0xCBL;
                    int32_t l_2542 = 0xF2AAD057L;
                    int32_t l_2543 = 1L;
                    union U1 *l_2560[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_2560[i] = &g_2561;
                    if ((((**g_938) = ((!(p_36.f0 < (-10L))) > (((**g_242)--) , p_36.f3))) < (**g_858)))
                    { /* block id: 1207 */
                        int32_t *l_2535[5][9][4] = {{{&g_440.f2,&l_1977,&l_2184,&l_2184},{&g_440.f2,&g_440.f2,&l_2182,(void*)0},{&l_2184,&l_1978,&g_3,(void*)0},{&g_165,&l_2187[0][0][1],&l_2187[2][0][0],&g_3},{&l_1976,&l_2187[0][0][1],&l_2187[0][0][0],(void*)0},{&l_2187[0][0][1],&l_1978,&g_79,(void*)0},{&g_440.f2,&g_440.f2,&l_1976,&l_2184},{&g_440.f2,&l_1977,&g_165,&g_440.f2},{&g_854.f2,&l_2187[0][0][0],&g_440.f2,&l_1978}},{{(void*)0,&g_1678.f2,&l_2182,(void*)0},{&g_165,&g_440.f2,(void*)0,&l_2530},{&g_440.f2,&l_2528,&l_2186,&l_1977},{&g_1678.f2,&g_165,&g_3,&l_1976},{&g_440.f2,&l_1976,&l_2186,&l_2187[2][0][0]},{&l_2182,&l_1976,&g_165,(void*)0},{&l_2187[2][0][0],&l_1978,&l_2187[2][0][0],&l_1972},{&g_440.f2,&g_79,&l_1978,&g_440.f2},{(void*)0,&l_1978,(void*)0,&l_2182}},{{&l_1972,&l_1978,&g_3,(void*)0},{&l_1977,&g_1678.f2,&l_1977,&l_2187[2][0][0]},{&g_440.f2,(void*)0,&g_440.f2,&g_3},{&l_1978,&l_1977,&l_2183,(void*)0},{&l_2184,&l_1978,&l_2183,&l_1976},{&l_1978,&l_2186,&g_440.f2,&l_2528},{&g_440.f2,&g_854.f2,&l_1977,(void*)0},{&l_1977,(void*)0,&g_3,&l_2182},{&l_1972,(void*)0,(void*)0,&g_440.f2}},{{(void*)0,&l_2187[2][0][0],&l_1978,&l_1972},{&g_440.f2,&l_2182,&l_2187[2][0][0],&g_165},{&l_2187[2][0][0],(void*)0,&g_165,&l_2184},{&l_2182,&l_1974,&l_2186,&l_1972},{&g_440.f2,(void*)0,&g_3,&l_2187[0][0][1]},{&g_1678.f2,&l_2183,&l_2186,&l_1978},{&g_440.f2,&l_2182,(void*)0,&l_1974},{&g_165,&l_2183,&l_2182,&l_2183},{(void*)0,&l_2186,&g_440.f2,&g_3}},{{(void*)0,&l_2530,&l_2530,&l_2186},{&l_2183,(void*)0,(void*)0,&l_2183},{&l_2184,&l_2187[0][0][0],&l_1978,&l_2186},{&g_440.f2,&l_1972,&l_1972,&l_2184},{&l_1974,&g_3,&l_2528,&l_2184},{&g_165,&l_1972,&g_1678.f2,&l_2186},{&l_1972,&l_2187[0][0][0],&g_79,&l_2183},{&l_2183,(void*)0,&g_1678.f2,&l_2186},{&l_1967,&l_2530,&g_165,&g_3}}};
                        int16_t **l_2553[1];
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                            l_2553[i] = &l_2420;
                        l_2546[0]++;
                        (**p_37) = (((safe_rshift_func_uint32_t_u_u(((&g_937[1] == (g_2551 , l_2552)) <= (p_36.f2 , (l_2553[0] == (*g_1030)))), 4)) > (p_36.f4 = (((*l_2086) &= (safe_sub_func_int64_t_s_s(((*l_2503) |= ((*l_2431) = ((*g_1155) = 7L))), ((*g_939) = (g_2188[1][4][0] > (0x39746C3FL <= l_2541)))))) , p_39.f5))) <= (**p_35));
                    }
                    else
                    { /* block id: 1216 */
                        union U1 **l_2557 = (void*)0;
                        union U1 *l_2559 = &g_685[1];
                        union U1 **l_2558[9] = {&l_2559,&l_2559,&l_2559,&l_2559,&l_2559,&l_2559,&l_2559,&l_2559,&l_2559};
                        int i;
                        if (g_1179)
                            goto lbl_2556;
                        l_2560[2] = ((*l_2269) = (void*)0);
                        return p_36.f2;
                    }
                    for (p_36.f2 = (-5); (p_36.f2 < 23); p_36.f2 = safe_add_func_uint16_t_u_u(p_36.f2, 3))
                    { /* block id: 1224 */
                        int32_t *l_2564 = &l_2528;
                        int32_t *l_2565 = &l_1978;
                        int32_t *l_2566 = &g_165;
                        int32_t *l_2567 = &l_2187[2][0][0];
                        int32_t *l_2568 = &g_440.f2;
                        int32_t *l_2569 = (void*)0;
                        int32_t *l_2570[9][4] = {{&l_2187[2][0][0],&l_1977,&l_2187[0][0][2],&l_2187[0][0][2]},{&l_2187[2][0][0],&l_2187[2][0][0],&l_2182,(void*)0},{&g_79,&l_2187[0][0][2],&l_2187[2][0][0],&l_1972},{&l_1977,&l_2528,&l_2186,&l_2187[2][0][0]},{&l_1978,&l_2528,&l_1978,&l_1972},{&l_2528,&l_2187[0][0][2],&l_1978,(void*)0},{(void*)0,&l_2187[2][0][0],&l_1977,&l_2187[0][0][2]},{(void*)0,&l_1977,&l_1977,(void*)0},{(void*)0,&l_1972,&l_1978,&l_1978}};
                        int i, j;
                        l_2571--;
                        if (l_2546[2])
                            break;
                    }
                    (**p_37) |= (((((**g_938) && l_2571) , (1L & (0x482B05BCL >= p_39.f3))) < (safe_sub_func_int16_t_s_s(0xDD71L, g_440.f1))) == l_2542);
                }
                else
                { /* block id: 1229 */
                    int8_t l_2581 = 0x6FL;
                    int32_t l_2588 = (-8L);
                    int32_t *l_2597[7][10] = {{&l_1972,(void*)0,(void*)0,(void*)0,&g_3,(void*)0,(void*)0,(void*)0,(void*)0,&g_3},{&g_3,&l_2545,&l_2545,&g_3,&l_1977,&l_2187[1][1][3],&g_3,&l_2187[1][1][3],&l_1977,&g_3},{&l_2187[1][1][3],&g_3,&l_2187[1][1][3],&l_1977,&g_3,&l_2545,&l_2545,&g_3,&l_1977,&l_2187[1][1][3]},{(void*)0,(void*)0,(void*)0,&g_3,(void*)0,(void*)0,(void*)0,&g_3,(void*)0,(void*)0},{(void*)0,&l_2545,&l_2187[1][1][3],(void*)0,&l_1977,&l_1977,(void*)0,&l_2187[1][1][3],&l_2545,(void*)0},{&l_2187[1][1][3],(void*)0,&l_2545,&l_1977,(void*)0,&l_1977,&l_2545,(void*)0,&l_2187[1][1][3],&l_2187[1][1][3]},{(void*)0,&g_3,(void*)0,(void*)0,(void*)0,(void*)0,&g_3,(void*)0,(void*)0,(void*)0}};
                    int i, j;
                    if ((l_2537 > ((safe_sub_func_int32_t_s_s((**p_35), ((**g_1154) <= 0xAE306D4112DECE07LL))) ^ l_2545)))
                    { /* block id: 1230 */
                        l_2588 |= (l_2587 = ((*l_2431) |= (safe_sub_func_uint8_t_u_u((((void*)0 == &g_937[1]) <= (l_2580 == (l_2582 = (l_2581 , &l_2269)))), ((((**p_38) = (-1L)) || l_2581) || (safe_lshift_func_uint32_t_u_s(((safe_div_func_int64_t_s_s((l_2530 || 0x3DL), p_36.f3)) || 0x6F7A0816L), 11)))))));
                        (**l_2582) = (void*)0;
                    }
                    else
                    { /* block id: 1237 */
                        int32_t l_2589 = 1L;
                        int32_t *l_2590 = &l_2528;
                        int32_t *l_2591 = &l_1967;
                        int32_t *l_2592 = (void*)0;
                        int32_t *l_2593[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_2593[i] = &l_2545;
                        ++l_2594;
                        (**p_37) |= (**p_35);
                    }
                    l_2606[3]++;
                    if (((**p_37) = (safe_mod_func_int16_t_s_s(l_2603[0], 0x7F31L))))
                    { /* block id: 1243 */
                        int8_t l_2613[9][6] = {{0x5CL,0x5CL,0x13L,0x56L,0x13L,0x5CL},{0x13L,0xA2L,0x56L,0x56L,0xA2L,0x13L},{0x5CL,0x13L,0x56L,0x13L,0x5CL,0x5CL},{0xD0L,0x13L,0x13L,0xD0L,0xA2L,0xD0L},{0xD0L,0xA2L,0xD0L,0x13L,0x13L,0xD0L},{0x5CL,0x5CL,0x13L,0x56L,0x13L,0x5CL},{0x13L,0xA2L,0x56L,0x56L,0xA2L,0x13L},{0x5CL,0x13L,0x56L,0x13L,0x5CL,0x5CL},{0xD0L,0x13L,0x13L,0xD0L,0xA2L,0xD0L}};
                        int8_t *l_2616 = &l_1982;
                        int i, j;
                        (*l_2431) = ((safe_lshift_func_int32_t_s_u(l_2613[4][5], ((l_2632 = ((((**p_35) , ((*l_2616) = l_2603[0])) & ((safe_div_func_uint32_t_u_u(0xA498BDA5L, p_39.f4)) <= ((safe_add_func_int32_t_s_s(((safe_unary_minus_func_int32_t_s((((((safe_add_func_int16_t_s_s(((safe_add_func_int32_t_s_s(((!(l_2604[6][0] , ((*g_939) < (((*g_1155) = (safe_rshift_func_int64_t_s_u((-1L), 11))) >= ((((safe_mod_func_uint32_t_u_u(((**g_242) | l_2613[0][5]), (*l_2431))) && (**p_38)) == (**p_38)) && p_36.f1))))) | p_39.f1), l_2603[0])) , l_2631), p_39.f2)) , (****g_1280)) , g_2188[1][4][0]) | g_1003[0][0][1]) || (*l_2431)))) > 0L), (*g_1193))) || p_39.f3))) != p_36.f5)) , l_2603[1]))) && 0xCC60L);
                    }
                    else
                    { /* block id: 1248 */
                        const int32_t **l_2635[8][5] = {{(void*)0,&g_1011,&l_2633,(void*)0,&l_2633},{&l_2633,&l_2633,&l_2633,&g_1011,&g_1011},{&g_1011,&g_1011,&l_2633,&l_2633,&g_1011},{&g_1011,(void*)0,(void*)0,&g_1011,&g_1011},{&l_2633,&g_1011,&l_2633,&g_1011,&l_2633},{(void*)0,&l_2633,(void*)0,&g_1011,&l_2633},{&l_2633,&g_1011,&g_1011,&l_2633,&l_2633},{&g_1011,&g_1011,&l_2633,&l_2633,&l_2633}};
                        int i, j;
                        l_2636 = l_2633;
                    }
                }
            }
            (*l_2431) = ((((**p_38) = (safe_mul_func_int64_t_s_s((7UL > (safe_lshift_func_uint64_t_u_u(((safe_lshift_func_int32_t_s_s((&l_2386 == (*g_242)), (safe_add_func_uint8_t_u_u((safe_div_func_int64_t_s_s(((((void*)0 == (**l_2529)) < (safe_unary_minus_func_uint8_t_u((safe_sub_func_uint32_t_u_u((p_36.f4 ^ 18446744073709551609UL), (--(*g_1193))))))) == ((*l_2431) >= (p_39.f0 <= 0x3B22L))), (**g_938))), (**g_242))))) == 0x2EA006A98C3A4854LL), 9))), 7UL))) < (-3L)) >= l_2546[1]);
        }
    }
    return p_39.f2;
}


/* ------------------------------------------ */
/* 
 * reads : g_161 g_1491 g_1138 g_853 g_854 g_1035 g_1155 g_1758 g_1154 g_1678.f5 g_697 g_110 g_243 g_140 g_346 g_1193 g_1358 g_378 g_75 g_1620 g_1788 g_242 g_1801 g_347 g_1817 g_1489 g_1490 g_120 g_1852 g_939 g_440.f4 g_1853 g_938 g_1868 g_1532 g_1530 g_1032 g_1033 g_1281
 * writes: g_161 g_854.f2 g_1678.f5 g_697 g_75 g_140 g_854.f5 g_1193 g_163 g_1011 g_347 g_120 g_221 g_854.f3 g_1153 g_440.f4 g_1923
 */
static struct S0  func_40(int32_t ** p_41, uint32_t  p_42, uint16_t  p_43)
{ /* block id: 835 */
    const int32_t l_1741 = 0x41F33F59L;
    int32_t l_1746 = 0x05018278L;
    int32_t l_1748 = 0L;
    int32_t l_1751[6][8][5] = {{{5L,(-1L),0x7194CFA9L,(-1L),0x424DFB9AL},{0L,6L,(-9L),0xB1C4165FL,0x39441509L},{0x4707B6DDL,0xC45C34C3L,0x2FCBB30BL,(-1L),1L},{0x7194CFA9L,0x22F3DE89L,(-1L),0xA2882150L,0L},{0L,(-8L),1L,0xE08DB254L,0x7194CFA9L},{0x393B85C0L,0xCFB2FE2FL,(-7L),0x7194CFA9L,0x96CFD52AL},{(-1L),1L,1L,0x549BB0B2L,0x6D100758L},{5L,1L,0x082CFD01L,0xA3775D76L,0x9449F79BL}},{{0xA3775D76L,0x8190B1EFL,0L,0xA3AC0C92L,5L},{0L,6L,(-1L),6L,0x53E8346CL},{0xA3AC0C92L,6L,(-1L),(-9L),0x03E183EEL},{1L,(-8L),0L,1L,1L},{0xC6FE0E5BL,0L,0x082CFD01L,0x0EFEDDF2L,1L},{(-1L),6L,1L,0x39441509L,5L},{0x7194CFA9L,0xABC455D0L,0x412202AEL,0x20360379L,1L},{0x9449F79BL,(-10L),6L,0xE18ECE74L,0x39441509L}},{{0L,0x2FCBB30BL,0x4D3979A4L,(-9L),(-3L)},{0xABC455D0L,0x49C70BE4L,6L,(-1L),0xFE475D3AL},{0x146DC680L,0x39441509L,0x7E6FAEE0L,0x7E6FAEE0L,0x39441509L},{0x96CFD52AL,0x7E6FAEE0L,0xA45650E1L,0xA3775D76L,0xE18ECE74L},{(-1L),0x846938FFL,0xCFB2FE2FL,(-1L),0xA2882150L},{8L,0x2B60D072L,0L,(-1L),1L},{(-1L),0x0EFEDDF2L,(-3L),0x2B60D072L,0x3829FB44L},{0x96CFD52AL,0x6D100758L,(-1L),5L,0L}},{{0x146DC680L,0L,8L,5L,0x53E8346CL},{0xABC455D0L,0x4D3979A4L,(-2L),5L,0x082CFD01L},{0L,0x6D100758L,0x56F60CBEL,(-5L),0x49C70BE4L},{0x9449F79BL,0x20360379L,(-1L),0L,0x6D100758L},{0x7194CFA9L,0L,0xF9AD01E5L,0L,0x076C7D84L},{(-1L),0x846938FFL,0x94EB1254L,0x6D100758L,0xB38EE45AL},{0xC6FE0E5BL,0xA3AC0C92L,0x03E183EEL,0x2FCBB30BL,0L},{1L,(-1L),(-2L),1L,0x495BDF15L}},{{0xA3AC0C92L,0x49C70BE4L,(-1L),1L,(-1L)},{0L,0xF9572F3FL,0x146DC680L,0x2FCBB30BL,(-10L)},{0xA3775D76L,0L,(-3L),0x6D100758L,(-2L)},{5L,0xABC455D0L,0xDF3B4AA7L,0L,0x2B60D072L},{(-1L),(-1L),0x6DBC5BDDL,0L,0x8190B1EFL},{(-1L),0x03E183EEL,0xA45650E1L,(-5L),0L},{0x8190B1EFL,(-8L),(-1L),5L,(-1L)},{0xA45650E1L,0xB9DE2186L,0x85DAF351L,5L,(-4L)}},{{0xB38EE45AL,0xD1CC8849L,0x4D3979A4L,5L,0x4D3979A4L},{0x8190B1EFL,0x8190B1EFL,0xCBF05463L,0x2B60D072L,0xB38EE45AL},{0x549BB0B2L,(-1L),5L,(-1L),0x96CFD52AL},{1L,0xE18ECE74L,1L,0x3829FB44L,(-8L)},{1L,(-4L),(-1L),8L,0x2FCBB30BL},{(-1L),0x146DC680L,(-1L),0xC45C34C3L,0x549BB0B2L},{(-1L),0L,0xBF943A0DL,0x4D3979A4L,0x393B85C0L},{0xE18ECE74L,0xF9AD01E5L,0xB38EE45AL,0x7E6FAEE0L,0x076C7D84L}}};
    uint16_t l_1753 = 0xDF20L;
    int32_t l_1832 = 0x06C48D44L;
    uint32_t **l_1873 = &g_1193;
    uint32_t ***l_1872 = &l_1873;
    int64_t ***l_1920 = (void*)0;
    struct S0 l_1929[5] = {{0xE9DF48F7L,-1,0xD14EE579L,3UL,0x2EEEF5C9F17EC81ELL,0x0BFCL},{0xE9DF48F7L,-1,0xD14EE579L,3UL,0x2EEEF5C9F17EC81ELL,0x0BFCL},{0xE9DF48F7L,-1,0xD14EE579L,3UL,0x2EEEF5C9F17EC81ELL,0x0BFCL},{0xE9DF48F7L,-1,0xD14EE579L,3UL,0x2EEEF5C9F17EC81ELL,0x0BFCL},{0xE9DF48F7L,-1,0xD14EE579L,3UL,0x2EEEF5C9F17EC81ELL,0x0BFCL}};
    int i, j, k;
    for (p_43 = 2; (p_43 <= 6); p_43 += 1)
    { /* block id: 838 */
        int16_t l_1734 = 0xFBA8L;
        uint64_t l_1742 = 1UL;
        int32_t l_1743[7][9][3] = {{{0L,0x3ECB32D7L,0x3ECB32D7L},{0x231ACB6BL,(-1L),0L},{0xD2C13AD8L,1L,0xEC4D3756L},{0xE40B53B4L,(-3L),6L},{0x539ED5BAL,0x9BF8AD89L,7L},{0x7774C7A2L,(-3L),1L},{1L,1L,0L},{(-1L),(-1L),(-3L)},{7L,0x3ECB32D7L,0L}},{{0xBE9CFC3CL,0x197DEFCDL,0xBD97D037L},{0L,(-10L),1L},{0x4F3AF8F7L,0xBE9CFC3CL,0xBD97D037L},{0xB58004C8L,1L,0L},{(-3L),0x40214A9EL,(-3L)},{0xBE6EB284L,(-10L),0L},{0x9CF2B35DL,1L,1L},{(-10L),1L,7L},{0x219E27E7L,1L,6L}},{{(-10L),1L,0xEC4D3756L},{0x9CF2B35DL,0L,0L},{0xBE6EB284L,7L,0x3ECB32D7L},{(-3L),0x219E27E7L,0x584943E7L},{0xB58004C8L,0xD2C13AD8L,(-2L)},{0x4F3AF8F7L,0x0C555D4FL,(-1L)},{0L,0xD2C13AD8L,(-10L)},{0xBE9CFC3CL,0x219E27E7L,0x9CF2B35DL},{7L,7L,0xD2C13AD8L}},{{(-1L),0L,0x7774C7A2L},{1L,1L,(-10L)},{0x7774C7A2L,1L,0xBE9CFC3CL},{0x539ED5BAL,1L,(-10L)},{0xE40B53B4L,1L,0x7774C7A2L},{0xD2C13AD8L,(-10L),0xD2C13AD8L},{0x231ACB6BL,0x40214A9EL,0x9CF2B35DL},{0L,1L,(-10L)},{0x40214A9EL,0xBE9CFC3CL,(-1L)}},{{1L,(-10L),(-2L)},{0x40214A9EL,0x197DEFCDL,0x584943E7L},{0L,0x3ECB32D7L,0x3ECB32D7L},{0x231ACB6BL,(-1L),0L},{0xD2C13AD8L,1L,0xEC4D3756L},{0xE40B53B4L,(-3L),6L},{0x539ED5BAL,0x9BF8AD89L,7L},{0x7774C7A2L,(-3L),1L},{1L,1L,0L}},{{(-1L),(-1L),(-3L)},{7L,0x3ECB32D7L,0L},{0xBE9CFC3CL,0x197DEFCDL,0xBD97D037L},{0L,(-10L),1L},{0x4F3AF8F7L,0xBE9CFC3CL,0xBD97D037L},{0xB58004C8L,1L,0L},{(-3L),0x40214A9EL,(-3L)},{0xBE6EB284L,(-10L),0L},{0x9CF2B35DL,1L,1L}},{{(-10L),1L,0x539ED5BAL},{0L,0xE40B53B4L,0x7774C7A2L},{(-10L),0xEC4D3756L,1L},{(-3L),(-1L),(-1L)},{1L,0x539ED5BAL,7L},{0x231ACB6BL,0L,0xBE9CFC3CL},{(-2L),0xBE6EB284L,0L},{0x75740CEDL,0xBD97D037L,0x4F3AF8F7L},{0L,0xBE6EB284L,0xB58004C8L}}};
        struct S0 l_1787 = {0x4A711F0EL,3,-8L,0xD3CC6A7BL,0xE7C64AF8B2F099BBLL,1UL};
        uint32_t *l_1829 = &g_120[0][5];
        const uint32_t * const l_1877 = &g_440.f0;
        const uint32_t * const *l_1876 = &l_1877;
        const uint32_t * const **l_1875 = &l_1876;
        int16_t l_1903 = 8L;
        int64_t ***l_1917 = (void*)0;
        int64_t ***l_1921 = (void*)0;
        int i, j, k;
        for (g_161 = 0; (g_161 >= 0); g_161 -= 1)
        { /* block id: 841 */
            int32_t *l_1721 = &g_854.f2;
            int32_t l_1747 = 1L;
            int32_t l_1749 = (-1L);
            int32_t l_1750 = 1L;
            int32_t l_1752 = 0x177E71A5L;
            const uint16_t l_1779 = 0x3414L;
            uint8_t l_1798 = 0x9FL;
            const int32_t *l_1814 = &g_1815;
            uint16_t l_1826 = 0xC415L;
            uint64_t l_1843 = 0x443C8E70E783E036LL;
            union U1 *l_1862 = (void*)0;
            union U1 *l_1864 = &g_1865;
            const struct S0 l_1871 = {0UL,-3,1L,0x8D994ED0L,18446744073709551607UL,65535UL};
            union U1 **l_1928 = &g_647;
            int i;
            if (g_1491[p_43])
                break;
            if (((l_1721 != (void*)0) == (safe_rshift_func_int32_t_s_s((((safe_mul_func_int8_t_s_s(1L, (((safe_rshift_func_uint16_t_u_u(((**g_1138) , ((safe_div_func_uint8_t_u_u((safe_lshift_func_uint64_t_u_u(p_42, ((((((safe_rshift_func_uint8_t_u_s(l_1734, ((safe_div_func_uint64_t_u_u(p_43, 0x4D35342969CE620CLL)) > (safe_lshift_func_uint32_t_u_s((safe_rshift_func_int16_t_s_u(((l_1741 , 0x63L) != 0UL), 10)), (*l_1721)))))) && g_1035) & 0x01C2C6B3B2F313FALL) >= (*g_1155)) >= 4L) < l_1741))), 0x98L)) < l_1734)), 13)) && p_42) > 1UL))) < l_1742) && 0x32E48E95L), l_1741))))
            { /* block id: 843 */
                int32_t *l_1744 = &g_1678.f2;
                int32_t *l_1745[2];
                int i;
                for (i = 0; i < 2; i++)
                    l_1745[i] = &g_1678.f2;
                --l_1753;
                (*l_1721) ^= (65526UL || p_42);
            }
            else
            { /* block id: 846 */
                int8_t l_1770 = 5L;
                int64_t l_1780[5][9] = {{0x17118B5C220DB3EBLL,(-9L),(-9L),0x17118B5C220DB3EBLL,(-6L),0x309FAE4E658FCAC9LL,0xEDB7D11A1ADC20E0LL,(-9L),0x309FAE4E658FCAC9LL},{(-1L),(-9L),0L,0xEDB7D11A1ADC20E0LL,(-1L),(-1L),0xEDB7D11A1ADC20E0LL,0L,(-9L)},{0xEDB7D11A1ADC20E0LL,(-6L),0L,0x6DD5D60F9B7536E7LL,(-6L),(-9L),0L,0L,0L},{(-1L),(-1L),(-9L),0x6DD5D60F9B7536E7LL,(-9L),(-1L),(-1L),(-9L),0L},{0x17118B5C220DB3EBLL,(-6L),0x309FAE4E658FCAC9LL,0xEDB7D11A1ADC20E0LL,(-9L),0x309FAE4E658FCAC9LL,0L,0x309FAE4E658FCAC9LL,(-9L)}};
                uint64_t ****l_1782 = (void*)0;
                int32_t **l_1789 = (void*)0;
                uint16_t *l_1794 = &g_854.f5;
                int32_t l_1795 = 0x505B464FL;
                uint32_t **l_1802 = &g_1193;
                int32_t l_1818[7][10][3] = {{{4L,0xA3B14723L,0x926A1146L},{0x26AB487CL,0xC7EBDDECL,0x8F52AAC5L},{0L,0x56CBD134L,0xA3B14723L},{0x3C8D7159L,0xBB676D4DL,1L},{1L,0x56CBD134L,1L},{(-1L),0xC7EBDDECL,1L},{0xCE9D66F4L,0xA3B14723L,0L},{0L,0xC7EBDDECL,(-3L)},{0x89E8B33AL,0x56CBD134L,0x56CBD134L},{0x38BA4E99L,0xBB676D4DL,0x405B5E6CL}},{{0xA09D4F75L,0x56CBD134L,0x6A3E5873L},{(-1L),0xC7EBDDECL,0xBB676D4DL},{0xE4099ABBL,0xA3B14723L,(-4L)},{0x5D1F6D0FL,0xC7EBDDECL,0x099081C2L},{1L,0x56CBD134L,0x4174FEECL},{0x27878AF2L,0xBB676D4DL,0xC7571A52L},{0xBF6604C8L,0x56CBD134L,0xE8589AEEL},{0x5202109BL,0xC7EBDDECL,0xC7EBDDECL},{4L,0xA3B14723L,0x926A1146L},{0x26AB487CL,0xC7EBDDECL,0x8F52AAC5L}},{{0L,0x56CBD134L,0xA3B14723L},{0x3C8D7159L,0xBB676D4DL,1L},{1L,0x56CBD134L,1L},{(-1L),0xC7EBDDECL,1L},{0xCE9D66F4L,0xA3B14723L,0L},{0L,0xC7EBDDECL,(-3L)},{0x89E8B33AL,0x56CBD134L,0x56CBD134L},{0x38BA4E99L,0xBB676D4DL,0x405B5E6CL},{0xA09D4F75L,0x56CBD134L,0x6A3E5873L},{(-1L),0xC7EBDDECL,0xBB676D4DL}},{{0xE4099ABBL,0xA3B14723L,(-4L)},{0x5D1F6D0FL,0xC7EBDDECL,0x099081C2L},{1L,0x56CBD134L,0x4174FEECL},{0x27878AF2L,0xBB676D4DL,0xC7571A52L},{0xBF6604C8L,0x56CBD134L,0xE8589AEEL},{0x5202109BL,0xC7EBDDECL,0xC7EBDDECL},{4L,0xA3B14723L,0x926A1146L},{0x26AB487CL,0xC7EBDDECL,0x8F52AAC5L},{0L,0x56CBD134L,0xA3B14723L},{0x3C8D7159L,0xBB676D4DL,1L}},{{1L,8L,0L},{0xC7EBDDECL,(-1L),0x457DD02AL},{0x6A3E5873L,0L,0xA37373EBL},{1L,(-1L),0xEDAD5E0BL},{0x4174FEECL,8L,8L},{(-3L),(-1L),0xA11634C1L},{0x926A1146L,8L,0x76C6EB4AL},{0xBB676D4DL,(-1L),(-1L)},{1L,0L,1L},{0xC7571A52L,(-1L),0xA899C2FAL}},{{0x56CBD134L,8L,9L},{0x8F52AAC5L,(-1L),0x7E23AACBL},{(-4L),8L,0x1939C5CEL},{1L,(-1L),(-1L)},{0xE8589AEEL,0L,0L},{0x405B5E6CL,(-1L),0x40DC0107L},{0xA3B14723L,8L,0L},{0x099081C2L,(-1L),3L},{0L,8L,0L},{0xC7EBDDECL,(-1L),0x457DD02AL}},{{0x6A3E5873L,0L,0xA37373EBL},{1L,(-1L),0xEDAD5E0BL},{0x4174FEECL,8L,8L},{(-3L),(-1L),0xA11634C1L},{0x926A1146L,8L,0x76C6EB4AL},{0xBB676D4DL,(-1L),(-1L)},{1L,0L,1L},{0xC7571A52L,(-1L),0xA899C2FAL},{0x56CBD134L,8L,9L},{0x8F52AAC5L,(-1L),0x7E23AACBL}}};
                uint8_t l_1822[7];
                const struct S0 *l_1922 = &l_1871;
                int i, j, k;
                for (i = 0; i < 7; i++)
                    l_1822[i] = 0UL;
                for (p_42 = 0; (p_42 <= 1); p_42 += 1)
                { /* block id: 849 */
                    uint16_t *l_1777 = &g_1678.f5;
                    uint16_t *l_1778 = &g_697;
                    int8_t *l_1781[3][3][10] = {{{&g_127,&g_347,(void*)0,&l_1770,&l_1770,&g_347,&g_347,&l_1770,&l_1770,(void*)0},{&l_1770,&l_1770,&g_127,&g_347,&g_127,&l_1770,&l_1770,&g_347,(void*)0,&l_1770},{&g_347,&g_127,(void*)0,(void*)0,(void*)0,&l_1770,&l_1770,&g_347,&g_347,&g_347}},{{&g_347,&l_1770,(void*)0,&l_1770,&l_1770,&g_127,&g_347,&g_347,&l_1770,&g_127},{&g_127,&g_347,&l_1770,&g_347,(void*)0,(void*)0,&l_1770,&g_127,&l_1770,(void*)0},{&g_347,(void*)0,&g_127,(void*)0,&g_347,&g_347,&g_127,(void*)0,(void*)0,&g_347}},{{&g_127,(void*)0,&g_127,&l_1770,&g_347,&l_1770,(void*)0,&g_127,&l_1770,&g_347},{(void*)0,&l_1770,&l_1770,&g_127,&g_347,(void*)0,&l_1770,&g_347,&g_347,(void*)0},{&l_1770,&l_1770,&g_347,&g_347,(void*)0,&l_1770,&g_347,(void*)0,&g_127,&g_127}}};
                    int i, j, k;
                    l_1751[2][3][2] &= ((safe_lshift_func_int8_t_s_s(g_1758, (l_1746 = ((0x59902896B0E25942LL >= (safe_sub_func_int32_t_s_s(((1UL >= (safe_rshift_func_int16_t_s_s((safe_mul_func_int64_t_s_s(((safe_mod_func_int8_t_s_s((+(((safe_rshift_func_uint8_t_u_s(((((*l_1778) |= ((*l_1777) ^= ((0x55B54A7F55444550LL < (((p_42 , 4L) > l_1770) <= (p_43 || (safe_div_func_uint64_t_u_u(((((safe_lshift_func_uint8_t_u_s((safe_div_func_int64_t_s_s(p_43, 1L)), 0)) >= (*l_1721)) || 0L) > 1UL), (**g_1154)))))) > 0x6EA4ABA6964C73EFLL))) <= g_110[0][4][5]) ^ (*g_243)), g_346[4][0])) > p_42) ^ l_1779)), (*g_243))) && p_43), p_43)), l_1780[4][2]))) && (*g_1193)), 0x8411AA63L))) , g_1358[3][2][1])))) < p_42);
                    (*g_1620) = (*g_378);
                }
                (*l_1721) = (((void*)0 == l_1782) || (safe_mul_func_uint64_t_u_u((safe_lshift_func_int8_t_s_s((((((*g_243) ^= (l_1787 , ((g_1788 , l_1789) != &g_1178))) < (!0x9C8A0D8AL)) ^ 0xA2L) <= (l_1795 = (safe_div_func_uint16_t_u_u(((*l_1794) = (+(l_1780[4][2] , (*l_1721)))), p_42)))), l_1787.f5)), 0x5DAACCB95783B027LL)));
                if (((safe_sub_func_int64_t_s_s(l_1798, (safe_div_func_int8_t_s_s(((((((**g_242) || (&p_42 == (g_1801 , ((*l_1802) = l_1721)))) ^ (safe_mod_func_int8_t_s_s(((safe_mul_func_uint32_t_u_u(p_42, (safe_mul_func_int8_t_s_s((p_42 | ((((safe_div_func_uint8_t_u_u((safe_sub_func_uint8_t_u_u((*l_1721), (l_1743[1][7][2] > p_43))), (**g_242))) == 0xB7CF0C8AL) && p_43) , g_854.f4)), l_1795)))) || g_347), (**g_242)))) || (-1L)) | p_43) >= p_42), l_1787.f5)))) <= l_1795))
                { /* block id: 861 */
                    const int32_t *l_1813 = &g_854.f2;
                    int8_t *l_1844 = &g_347;
                    for (g_163 = 0; (g_163 <= 0); g_163 += 1)
                    { /* block id: 864 */
                        (*g_1817) = (l_1814 = l_1813);
                    }
                    if (l_1818[0][8][2])
                        break;
                    (*l_1721) = (safe_lshift_func_uint16_t_u_u((!((p_43 == l_1822[1]) >= ((((safe_lshift_func_uint32_t_u_u((((~l_1826) ^ (p_43 , (-2L))) == (safe_mod_func_int64_t_s_s(((((l_1829 == (void*)0) > 0x73L) < (safe_mod_func_int16_t_s_s(((p_43 ^ 0x332F5A28L) , p_42), l_1832))) >= l_1748), 0x707637AFE81D6F74LL))), 10)) && p_42) | (**g_242)) >= p_42))), g_1035));
                    l_1795 = (safe_lshift_func_int64_t_s_u(((void*)0 == &g_1031[3][7]), ((safe_add_func_uint64_t_u_u((~p_42), p_42)) && (safe_mul_func_uint8_t_u_u((+(((*l_1844) = (((p_42 , l_1734) < (safe_mod_func_int32_t_s_s((p_42 != ((p_42 > (8UL & 0x193EA588E03B6A8CLL)) ^ l_1787.f5)), (*l_1721)))) | l_1843)) < (**g_1489))), g_140)))));
                }
                else
                { /* block id: 872 */
                    const int8_t l_1851 = 0x89L;
                    int32_t l_1866 = 0xB8BC016CL;
                    uint32_t ****l_1874 = &l_1872;
                    const uint32_t * const ***l_1878 = (void*)0;
                    const uint32_t * const ***l_1879 = &l_1875;
                    const uint32_t * const **l_1881[10][4] = {{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}};
                    const uint32_t * const ***l_1880 = &l_1881[2][0];
                    int i, j;
                    for (l_1787.f4 = 0; (l_1787.f4 <= 0); l_1787.f4 += 1)
                    { /* block id: 875 */
                        int32_t ***l_1861[10][1] = {{&g_105},{(void*)0},{&g_105},{(void*)0},{&g_105},{(void*)0},{&g_105},{(void*)0},{&g_105},{(void*)0}};
                        int32_t ****l_1860 = &l_1861[0][0];
                        int32_t *****l_1859[1][1][1];
                        union U1 **l_1863 = &l_1862;
                        int32_t * const l_1867[7][8] = {{&g_1678.f2,&l_1787.f2,&g_1678.f2,&g_165,&g_165,&g_165,&g_165,&g_1678.f2},{&l_1787.f2,&l_1787.f2,&g_165,&l_1750,(void*)0,&l_1750,&g_165,&l_1787.f2},{&l_1787.f2,&g_1678.f2,&g_165,&g_165,&g_165,&g_165,&g_1678.f2,&l_1787.f2},{&g_1678.f2,&l_1751[3][6][3],&l_1787.f2,&l_1750,&l_1787.f2,&l_1751[3][6][3],&g_1678.f2,&g_1678.f2},{&l_1751[3][6][3],&l_1750,&g_165,&g_165,&l_1750,&l_1751[3][6][3],&g_165,&l_1751[3][6][3]},{&l_1750,&l_1751[3][6][3],&g_165,&l_1751[3][6][3],&l_1750,&g_165,&g_165,&l_1750},{&l_1751[3][6][3],&g_1678.f2,&g_1678.f2,&l_1751[3][6][3],&l_1787.f2,&l_1750,&l_1787.f2,&l_1751[3][6][3]}};
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                        {
                            for (j = 0; j < 1; j++)
                            {
                                for (k = 0; k < 1; k++)
                                    l_1859[i][j][k] = &l_1860;
                            }
                        }
                        l_1866 = (((*l_1863) = (((safe_div_func_uint64_t_u_u((((--g_120[l_1787.f4][(l_1787.f4 + 1)]) , (p_42 == ((((safe_mod_func_uint8_t_u_u((**g_242), (l_1851 || (g_1852 , 0xA4L)))) == 18446744073709551609UL) ^ ((*g_939) & ((g_1853[1] == (l_1859[0][0][0] = ((safe_rshift_func_uint16_t_u_s((safe_unary_minus_func_int16_t_s(0xA1E9L)), 15)) , (void*)0))) || (**g_938)))) , l_1787.f2))) > 9UL), l_1780[4][2])) || 0x4768DB79L) , l_1862)) == l_1864);
                        (*g_1868) = l_1867[1][6];
                    }
                    if ((safe_lshift_func_int8_t_s_u((-8L), ((l_1871 , (((*l_1874) = l_1872) == ((*l_1880) = ((*l_1879) = l_1875)))) | (safe_sub_func_int16_t_s_s((safe_lshift_func_int16_t_s_u(((((--(**g_242)) != ((l_1832 >= l_1795) < ((l_1750 &= ((safe_lshift_func_uint32_t_u_s(((safe_lshift_func_uint8_t_u_s(p_43, 2)) ^ ((p_43 & ((safe_mul_func_uint32_t_u_u(((*l_1829) = ((*g_1193)--)), (~(safe_sub_func_int8_t_s_s(0x3DL, l_1866))))) <= l_1866)) == (*g_1490))), 5)) == l_1866)) & l_1903))) < 0x7EBE68B5L) & p_43), 5)), p_42))))))
                    { /* block id: 889 */
                        uint32_t l_1910 = 0x4AA3D09CL;
                        int64_t ***l_1919 = &g_1154;
                        int64_t ****l_1918[4][5] = {{&l_1919,&l_1919,&l_1919,&l_1919,&l_1919},{&l_1919,(void*)0,(void*)0,&l_1919,(void*)0},{&l_1919,&l_1919,(void*)0,&l_1919,&l_1919},{(void*)0,&l_1919,(void*)0,(void*)0,&l_1919}};
                        int i, j;
                        l_1866 ^= (safe_add_func_uint64_t_u_u(((safe_mod_func_int32_t_s_s(l_1851, (safe_mod_func_int16_t_s_s((((***g_1281) ^= (p_42 ^ (l_1910 > (safe_rshift_func_uint64_t_u_s(18446744073709551615UL, ((++(*l_1794)) ^ ((safe_rshift_func_int16_t_s_u(l_1851, ((((0x71A083B2L ^ l_1795) && (((**g_1532) = l_1917) != (l_1921 = (l_1920 = l_1917)))) , 0x345A3846348B754BLL) | p_43))) || (*g_1032)))))))) != p_42), p_42)))) >= g_110[3][2][4]), 0xE0E6BF7BFB765622LL));
                        if (l_1910)
                            continue;
                        g_1923 = l_1922;
                    }
                    else
                    { /* block id: 898 */
                        return l_1787;
                    }
                }
            }
            for (l_1843 = 0; (l_1843 <= 0); l_1843 += 1)
            { /* block id: 905 */
                union U1 ***l_1925 = (void*)0;
                union U1 **l_1927 = (void*)0;
                union U1 ***l_1926[6][2] = {{&l_1927,&l_1927},{&l_1927,&l_1927},{&l_1927,&l_1927},{&l_1927,&l_1927},{&l_1927,&l_1927},{&l_1927,&l_1927}};
                int i, j;
                l_1928 = &g_647;
            }
            (*l_1721) = l_1741;
        }
        return (**g_1138);
    }
    return l_1929[4];
}


/* ------------------------------------------ */
/* 
 * reads : g_440.f3 g_228 g_79 g_1713 g_1193 g_854.f3 g_338 g_243 g_140 g_1490 g_1491 g_1154 g_1155 g_161
 * writes: g_440.f3 g_228 g_338 g_140 g_347 g_161 g_79
 */
static int32_t ** func_44(int64_t  p_45, struct S0  p_46, int32_t * p_47)
{ /* block id: 812 */
    uint32_t l_1685 = 6UL;
    uint32_t l_1686 = 0x4A870A8BL;
    int32_t l_1692 = 1L;
    int32_t **l_1720 = &g_221;
    for (g_440.f3 = 0; (g_440.f3 < 2); g_440.f3 = safe_add_func_int16_t_s_s(g_440.f3, 5))
    { /* block id: 815 */
        const uint32_t l_1682 = 1UL;
        if (l_1682)
            break;
    }
    for (g_228 = 0; (g_228 == (-3)); g_228--)
    { /* block id: 820 */
        int8_t l_1687 = 0x3AL;
        uint8_t l_1693 = 0xEDL;
        uint32_t l_1715[8];
        const volatile int64_t *****l_1719 = &g_879;
        int i;
        for (i = 0; i < 8; i++)
            l_1715[i] = 0x189EAD00L;
        l_1686 |= (l_1685 != p_46.f4);
        if ((*p_47))
        { /* block id: 822 */
            int32_t *l_1688 = &g_1678.f2;
            int32_t *l_1689 = &g_79;
            int32_t *l_1690 = &g_165;
            int32_t *l_1691[9];
            int i;
            for (i = 0; i < 9; i++)
                l_1691[i] = &g_854.f2;
            ++l_1693;
        }
        else
        { /* block id: 824 */
            int16_t l_1696[9] = {0x4973L,0x952DL,0x952DL,0x4973L,0x952DL,0x952DL,0x4973L,0x952DL,0x952DL};
            int16_t *l_1714 = &g_338;
            int8_t *l_1716 = (void*)0;
            int8_t *l_1717 = &g_347;
            uint32_t l_1718[5] = {0x45B26F16L,0x45B26F16L,0x45B26F16L,0x45B26F16L,0x45B26F16L};
            int i;
            if (l_1696[2])
                break;
            (*p_47) = ((!(((*g_1155) = (!(l_1696[2] < (((((safe_mul_func_int16_t_s_s(p_46.f3, ((((((*l_1717) = (safe_div_func_int64_t_s_s((((safe_add_func_int8_t_s_s((safe_mul_func_uint64_t_u_u((safe_sub_func_int16_t_s_s((((*g_243) ^= (safe_add_func_uint8_t_u_u((g_1713 & (*g_1193)), ((l_1686 <= ((*l_1714) |= p_46.f4)) != (0xDA5CL <= p_46.f3))))) , (9UL == (*g_1490))), p_46.f1)), (**g_1154))), 1UL)) | p_45) == l_1715[2]), (**g_1154)))) , 1UL) , (*g_1490)) >= 0x3AL) || 0x02D0ACA3C7663E58LL))) | p_46.f1) & l_1718[0]) < p_46.f0) >= 0L)))) || 4UL)) <= l_1693);
        }
        l_1719 = &g_879;
    }
    return l_1720;
}


/* ------------------------------------------ */
/* 
 * reads : g_3 g_68 g_2 g_74 g_97 g_675 g_75 g_440.f5 g_165 g_221 g_685 g_378 g_347 g_440.f2 g_1032 g_1033 g_1339 g_346 g_1154 g_1155 g_161 g_1358 g_857 g_858 g_859 g_338 g_243 g_140 g_697 g_918 g_878 g_879 g_242 g_1400 g_1401 g_1433 g_1177 g_1178 g_1179 g_120 g_1193 g_854.f3 g_854.f4 g_860 g_854.f5 g_110 g_939 g_440.f4 g_1465 g_122 g_1489 g_938 g_1490 g_486.f0 g_1280 g_1281 g_163 g_1399 g_1491 g_1002 g_1003 g_1138 g_853 g_854 g_1620 g_440.f3 g_228 g_1010 g_1011 g_1380 g_1678
 * writes: g_75 g_97 g_2 g_440.f5 g_165 g_347 g_675 g_127 g_338 g_697 g_440.f2 g_1153 g_221 g_854.f5 g_110 g_140 g_854.f4 g_440.f4 g_1465 g_854.f3 g_161 g_1529 g_1531 g_1532 g_120 g_163
 */
static struct S0  func_48(int32_t  p_49)
{ /* block id: 9 */
    uint16_t l_71[1][6][9] = {{{0x2B9AL,0x7D51L,0x546DL,0x546DL,0x7D51L,0x2B9AL,5UL,65535UL,1UL},{0xD250L,65531UL,0x1C2BL,65535UL,0x2E7FL,0x2E7FL,65535UL,0x1C2BL,65531UL},{0x7D51L,0UL,0x2B9AL,0x9127L,0x8DB5L,2UL,5UL,5UL,2UL},{0x361AL,0x1C2BL,65535UL,0x1C2BL,0x361AL,0xB720L,0UL,1UL,65535UL},{0x673EL,0UL,0x9127L,0UL,65535UL,0UL,0x9127L,0UL,0x673EL},{0x131AL,65531UL,0xB131L,0x361AL,1UL,0xB131L,65535UL,0xB131L,0x1C2BL}}};
    int32_t *l_686 = &g_440.f2;
    int32_t l_1363 = 0x98A3ED25L;
    struct S0 **l_1373[7][5][2] = {{{&g_853[1],(void*)0},{(void*)0,(void*)0},{&g_853[1],&g_853[1]},{(void*)0,&g_853[1]},{&g_853[1],&g_853[1]}},{{&g_853[1],&g_853[1]},{&g_853[1],&g_853[1]},{&g_853[1],&g_853[1]},{&g_853[1],(void*)0},{&g_853[1],&g_853[1]}},{{&g_853[1],&g_853[0]},{&g_853[1],(void*)0},{(void*)0,(void*)0},{(void*)0,&g_853[0]},{(void*)0,&g_853[1]}},{{&g_853[1],&g_853[1]},{(void*)0,&g_853[1]},{&g_853[1],&g_853[2]},{&g_853[1],&g_853[1]},{(void*)0,&g_853[1]}},{{&g_853[1],&g_853[1]},{(void*)0,&g_853[0]},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_853[1],&g_853[0]}},{{&g_853[1],&g_853[1]},{&g_853[1],(void*)0},{&g_853[1],&g_853[1]},{&g_853[1],&g_853[1]},{&g_853[1],&g_853[1]}},{{&g_853[1],&g_853[1]},{&g_853[1],&g_853[1]},{(void*)0,&g_853[1]},{&g_853[1],(void*)0},{(void*)0,(void*)0}}};
    int16_t ****l_1379 = (void*)0;
    int32_t ***l_1403 = &g_105;
    int32_t ****l_1402 = &l_1403;
    int32_t l_1462 = 0xD88E08E8L;
    uint32_t l_1495 = 0xEB1D01D9L;
    const int32_t *****l_1512 = (void*)0;
    int16_t *** const l_1543 = (void*)0;
    uint32_t l_1553 = 5UL;
    uint64_t **l_1584 = &g_939;
    int8_t l_1587 = 0xA0L;
    int i, j, k;
    if (g_3)
    { /* block id: 10 */
        int32_t *l_62[2];
        int32_t **l_61 = &l_62[1];
        int32_t **l_73 = &l_62[0];
        uint32_t l_1334 = 0x67752224L;
        int64_t *l_1352 = &g_675;
        int8_t *l_1359 = &g_127;
        uint16_t l_1360 = 0xB7E3L;
        int16_t ***l_1362 = (void*)0;
        int16_t ****l_1361 = &l_1362;
        struct S0 l_1392[9][7] = {{{4294967290UL,3,0xD4267601L,0xCB6DFC4AL,0xC576B092DCD2E311LL,0UL},{0xD0BFD73EL,-2,0xB9A8A535L,0x6547C48AL,0x9FCDDD8D046E7511LL,65535UL},{1UL,-0,0xE458005AL,0x32729612L,0xD6CF5AF72D85E9C1LL,0xB17FL},{4294967290UL,3,0xD4267601L,0xCB6DFC4AL,0xC576B092DCD2E311LL,0UL},{0x26A9CD13L,1,0x7E75DB80L,0x059C37BEL,18446744073709551615UL,0UL},{0x26A9CD13L,1,0x7E75DB80L,0x059C37BEL,18446744073709551615UL,0UL},{4294967290UL,3,0xD4267601L,0xCB6DFC4AL,0xC576B092DCD2E311LL,0UL}},{{1UL,-0,0xE458005AL,0x32729612L,0xD6CF5AF72D85E9C1LL,0xB17FL},{4294967294UL,0,0x2DDDB91DL,0xAFCA3479L,1UL,0xE0F5L},{1UL,-0,0xE458005AL,0x32729612L,0xD6CF5AF72D85E9C1LL,0xB17FL},{0x26A9CD13L,1,0x7E75DB80L,0x059C37BEL,18446744073709551615UL,0UL},{4294967294UL,0,0x2DDDB91DL,0xAFCA3479L,1UL,0xE0F5L},{0xD0BFD73EL,-2,0xB9A8A535L,0x6547C48AL,0x9FCDDD8D046E7511LL,65535UL},{0xD0BFD73EL,-2,0xB9A8A535L,0x6547C48AL,0x9FCDDD8D046E7511LL,65535UL}},{{4294967294UL,0,0x2DDDB91DL,0xAFCA3479L,1UL,0xE0F5L},{4294967290UL,3,0xD4267601L,0xCB6DFC4AL,0xC576B092DCD2E311LL,0UL},{4294967295UL,1,8L,0x64CBE767L,18446744073709551615UL,0x914FL},{4294967290UL,3,0xD4267601L,0xCB6DFC4AL,0xC576B092DCD2E311LL,0UL},{4294967294UL,0,0x2DDDB91DL,0xAFCA3479L,1UL,0xE0F5L},{4294967295UL,1,8L,0x64CBE767L,18446744073709551615UL,0x914FL},{4294967293UL,3,-1L,0x8D8C52CBL,8UL,0x05E6L}},{{4294967293UL,3,-1L,0x8D8C52CBL,8UL,0x05E6L},{0xD0BFD73EL,-2,0xB9A8A535L,0x6547C48AL,0x9FCDDD8D046E7511LL,65535UL},{0x26A9CD13L,1,0x7E75DB80L,0x059C37BEL,18446744073709551615UL,0UL},{4294967293UL,3,-1L,0x8D8C52CBL,8UL,0x05E6L},{0x26A9CD13L,1,0x7E75DB80L,0x059C37BEL,18446744073709551615UL,0UL},{0xD0BFD73EL,-2,0xB9A8A535L,0x6547C48AL,0x9FCDDD8D046E7511LL,65535UL},{4294967293UL,3,-1L,0x8D8C52CBL,8UL,0x05E6L}},{{1UL,-0,0xE458005AL,0x32729612L,0xD6CF5AF72D85E9C1LL,0xB17FL},{4294967293UL,3,-1L,0x8D8C52CBL,8UL,0x05E6L},{0xD0BFD73EL,-2,0xB9A8A535L,0x6547C48AL,0x9FCDDD8D046E7511LL,65535UL},{0x26A9CD13L,1,0x7E75DB80L,0x059C37BEL,18446744073709551615UL,0UL},{4294967293UL,3,-1L,0x8D8C52CBL,8UL,0x05E6L},{0x26A9CD13L,1,0x7E75DB80L,0x059C37BEL,18446744073709551615UL,0UL},{0xD0BFD73EL,-2,0xB9A8A535L,0x6547C48AL,0x9FCDDD8D046E7511LL,65535UL}},{{4294967293UL,3,-1L,0x8D8C52CBL,8UL,0x05E6L},{4294967293UL,3,-1L,0x8D8C52CBL,8UL,0x05E6L},{4294967295UL,1,8L,0x64CBE767L,18446744073709551615UL,0x914FL},{4294967294UL,0,0x2DDDB91DL,0xAFCA3479L,1UL,0xE0F5L},{4294967290UL,3,0xD4267601L,0xCB6DFC4AL,0xC576B092DCD2E311LL,0UL},{4294967295UL,1,8L,0x64CBE767L,18446744073709551615UL,0x914FL},{4294967290UL,3,0xD4267601L,0xCB6DFC4AL,0xC576B092DCD2E311LL,0UL}},{{4294967294UL,0,0x2DDDB91DL,0xAFCA3479L,1UL,0xE0F5L},{0xD0BFD73EL,-2,0xB9A8A535L,0x6547C48AL,0x9FCDDD8D046E7511LL,65535UL},{0xD0BFD73EL,-2,0xB9A8A535L,0x6547C48AL,0x9FCDDD8D046E7511LL,65535UL},{4294967294UL,0,0x2DDDB91DL,0xAFCA3479L,1UL,0xE0F5L},{0x26A9CD13L,1,0x7E75DB80L,0x059C37BEL,18446744073709551615UL,0UL},{1UL,-0,0xE458005AL,0x32729612L,0xD6CF5AF72D85E9C1LL,0xB17FL},{4294967294UL,0,0x2DDDB91DL,0xAFCA3479L,1UL,0xE0F5L}},{{1UL,-0,0xE458005AL,0x32729612L,0xD6CF5AF72D85E9C1LL,0xB17FL},{4294967290UL,3,0xD4267601L,0xCB6DFC4AL,0xC576B092DCD2E311LL,0UL},{0x26A9CD13L,1,0x7E75DB80L,0x059C37BEL,18446744073709551615UL,0UL},{0x26A9CD13L,1,0x7E75DB80L,0x059C37BEL,18446744073709551615UL,0UL},{4294967290UL,3,0xD4267601L,0xCB6DFC4AL,0xC576B092DCD2E311LL,0UL},{1UL,-0,0xE458005AL,0x32729612L,0xD6CF5AF72D85E9C1LL,0xB17FL},{0xD0BFD73EL,-2,0xB9A8A535L,0x6547C48AL,0x9FCDDD8D046E7511LL,65535UL}},{{4294967290UL,3,0xD4267601L,0xCB6DFC4AL,0xC576B092DCD2E311LL,0UL},{4294967294UL,0,0x2DDDB91DL,0xAFCA3479L,1UL,0xE0F5L},{4294967295UL,1,8L,0x64CBE767L,18446744073709551615UL,0x914FL},{4294967293UL,3,-1L,0x8D8C52CBL,8UL,0x05E6L},{4294967293UL,3,-1L,0x8D8C52CBL,8UL,0x05E6L},{4294967295UL,1,8L,0x64CBE767L,18446744073709551615UL,0x914FL},{4294967294UL,0,0x2DDDB91DL,0xAFCA3479L,1UL,0xE0F5L}}};
        int32_t ****l_1393 = (void*)0;
        struct S0 ***l_1424 = &l_1373[2][4][1];
        int64_t ***l_1425 = &g_1154;
        int i, j;
        for (i = 0; i < 2; i++)
            l_62[i] = &g_3;
        l_1334 ^= (func_50(p_49, ((safe_mod_func_uint64_t_u_u((func_57(l_61, func_63((g_68 , (0L > (safe_add_func_uint16_t_u_u(l_71[0][1][7], ((p_49 ^ ((((+(g_3 , (((g_2 || ((&l_62[1] != l_73) , g_2)) , &p_49) == (void*)0))) != (**l_73)) , p_49) ^ g_3)) , 0x10A0L))))), g_3, &g_3, l_71[0][5][2]), g_675) || p_49), (**l_61))) <= 0x573EL), p_49, l_686) , (*l_686));
        l_1363 |= (1UL || (safe_add_func_uint8_t_u_u((((*g_1032) || (g_338 &= (safe_rshift_func_uint16_t_u_s(1UL, (((*g_221) = (g_1339 , (safe_mul_func_int16_t_s_s((safe_mul_func_int64_t_s_s((((((safe_mul_func_uint8_t_u_u((g_346[6][3] || (safe_rshift_func_uint64_t_u_s((safe_sub_func_uint16_t_u_u((0xF4L != (((*l_1352) &= (**g_1154)) != ((safe_add_func_int16_t_s_s(p_49, (((((safe_rshift_func_uint32_t_u_s((+((*l_1359) = g_1358[3][2][1])), 28)) , l_1352) != (**g_857)) && 65532UL) <= 0xFA91L))) > 0x7ED576BC30A5ACC2LL))), (**l_73))), 23))), (*l_686))) != l_1360) , (void*)0) == l_1361) < (*l_686)), 1UL)), p_49)))) , (-6L)))))) == (*g_243)), p_49)));
        for (g_697 = (-4); (g_697 > 29); ++g_697)
        { /* block id: 626 */
            struct S0 **l_1372 = &g_853[3];
            int32_t l_1395[7][3] = {{0x0836CF00L,(-1L),(-1L)},{0x0836CF00L,(-1L),(-1L)},{0x0836CF00L,(-1L),(-1L)},{0x0836CF00L,(-1L),(-1L)},{0x0836CF00L,(-1L),(-1L)},{0x0836CF00L,(-1L),(-1L)},{0x0836CF00L,(-1L),(-1L)}};
            int64_t ****l_1410 = &g_1153[3];
            int64_t *****l_1409 = &l_1410;
            union U1 *l_1421 = &g_985;
            struct S0 l_1426[4] = {{1UL,3,0xC9C99904L,4294967292UL,18446744073709551613UL,0xD3EBL},{1UL,3,0xC9C99904L,4294967292UL,18446744073709551613UL,0xD3EBL},{1UL,3,0xC9C99904L,4294967292UL,18446744073709551613UL,0xD3EBL},{1UL,3,0xC9C99904L,4294967292UL,18446744073709551613UL,0xD3EBL}};
            int i, j;
            for (p_49 = 0; (p_49 <= 27); p_49 = safe_add_func_uint8_t_u_u(p_49, 9))
            { /* block id: 629 */
                struct S0 **l_1371[5][4][6] = {{{&g_853[1],(void*)0,&g_853[1],&g_853[2],(void*)0,&g_853[2]},{&g_853[1],&g_853[2],&g_853[2],&g_853[2],&g_853[2],&g_853[1]},{&g_853[1],&g_853[1],&g_853[2],&g_853[2],&g_853[1],&g_853[2]},{&g_853[1],(void*)0,&g_853[1],&g_853[2],(void*)0,&g_853[2]}},{{&g_853[1],&g_853[2],&g_853[2],&g_853[2],&g_853[2],&g_853[0]},{&g_853[0],&g_853[1],(void*)0,&g_853[1],&g_853[1],&g_853[1]},{&g_853[0],&g_853[2],&g_853[0],&g_853[1],&g_853[2],(void*)0},{&g_853[0],&g_853[2],&g_853[1],&g_853[1],&g_853[2],&g_853[0]}},{{&g_853[0],&g_853[1],(void*)0,&g_853[1],&g_853[1],&g_853[1]},{&g_853[0],&g_853[2],&g_853[0],&g_853[1],&g_853[2],(void*)0},{&g_853[0],&g_853[2],&g_853[1],&g_853[1],&g_853[2],&g_853[0]},{&g_853[0],&g_853[1],(void*)0,&g_853[1],&g_853[1],&g_853[1]}},{{&g_853[0],&g_853[2],&g_853[0],&g_853[1],&g_853[2],(void*)0},{&g_853[0],&g_853[2],&g_853[1],&g_853[1],&g_853[2],&g_853[0]},{&g_853[0],&g_853[1],(void*)0,&g_853[1],&g_853[1],&g_853[1]},{&g_853[0],&g_853[2],&g_853[0],&g_853[1],&g_853[2],(void*)0}},{{&g_853[0],&g_853[2],&g_853[1],&g_853[1],&g_853[2],&g_853[0]},{&g_853[0],&g_853[1],(void*)0,&g_853[1],&g_853[1],&g_853[1]},{&g_853[0],&g_853[2],&g_853[0],&g_853[1],&g_853[2],(void*)0},{&g_853[0],&g_853[2],&g_853[1],&g_853[1],&g_853[2],&g_853[0]}}};
                struct S0 ***l_1370[9] = {&l_1371[4][0][4],&l_1371[4][0][4],&l_1371[4][0][4],&l_1371[4][0][4],&l_1371[4][0][4],&l_1371[4][0][4],&l_1371[4][0][4],&l_1371[4][0][4],&l_1371[4][0][4]};
                int i, j, k;
                (*l_686) = (((safe_add_func_uint8_t_u_u(0UL, ((l_1372 = (p_49 , (void*)0)) == (l_1373[2][4][1] = &g_853[1])))) , (void*)0) == (g_918[0][2] , (void*)0));
            }
            (*l_686) = (((void*)0 == &g_243) > (safe_add_func_uint8_t_u_u((safe_lshift_func_int16_t_s_s((((safe_lshift_func_int16_t_s_u(((l_1421 != (((safe_sub_func_int16_t_s_s(((&g_1137 != l_1424) && ((**g_878) != ((*l_1410) = l_1425))), ((&g_1401 != (l_1395[3][2] , &g_105)) , p_49))) || 4UL) , l_1421)) , p_49), 3)) == p_49) == 18446744073709551612UL), 2)), (**g_242))));
            (**g_1400) = (*l_61);
            return l_1426[3];
        }
    }
    else
    { /* block id: 668 */
        uint16_t l_1436 = 0x4372L;
        int8_t *l_1451 = (void*)0;
        int32_t l_1461 = 1L;
        int32_t l_1464[3];
        int32_t *l_1497 = &g_440.f2;
        struct S0 l_1515 = {4294967291UL,-0,0x23B1B174L,0x822D01FBL,1UL,65529UL};
        int64_t ****l_1527 = (void*)0;
        int64_t *****l_1526 = &l_1527;
        struct S0 l_1549 = {4294967295UL,2,0x3FEE1C35L,0UL,0UL,0x7E22L};
        int16_t * const *l_1648 = (void*)0;
        int16_t * const **l_1647[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
        int16_t * const ***l_1646 = &l_1647[3];
        int16_t * const ****l_1645 = &l_1646;
        int64_t ****l_1670[8][3] = {{&g_1153[4],&g_1153[0],&g_1153[1]},{&g_1153[1],&g_1153[0],&g_1153[4]},{&g_1153[0],&g_1153[2],&g_1153[2]},{&g_1153[3],&g_1153[1],&g_1153[4]},{&g_1153[0],(void*)0,&g_1153[1]},{&g_1153[0],&g_1153[3],&g_1153[0]},{&g_1153[3],&g_1153[3],&g_1153[3]},{&g_1153[0],&g_1153[3],&g_1153[0]}};
        int i, j;
        for (i = 0; i < 3; i++)
            l_1464[i] = 0xBEEADBF0L;
lbl_1616:
        for (g_854.f5 = 0; (g_854.f5 <= 5); g_854.f5 += 1)
        { /* block id: 671 */
            int8_t *l_1441 = &g_127;
            int32_t l_1442 = 6L;
            int16_t *l_1443 = &g_110[3][2][4];
            int32_t *l_1456[10] = {&g_1179,&g_1179,&g_228,&g_1179,&g_1179,&g_228,&g_1179,&g_1179,&g_228,&g_1179};
            int32_t **l_1455[8][4] = {{&l_1456[6],&l_1456[6],&l_1456[6],&l_1456[6]},{&l_1456[6],&l_1456[6],&l_1456[6],&l_1456[6]},{&l_1456[6],&l_1456[6],&l_1456[6],&l_1456[6]},{&l_1456[6],&l_1456[6],&l_1456[6],&l_1456[6]},{&l_1456[6],&l_1456[6],&l_1456[6],&l_1456[6]},{&l_1456[6],&l_1456[6],&l_1456[6],&l_1456[6]},{&l_1456[6],&l_1456[6],&l_1456[6],&l_1456[6]},{&l_1456[6],&l_1456[6],&l_1456[6],&l_1456[6]}};
            int32_t ***l_1454 = &l_1455[5][3];
            int32_t l_1463 = 0x3818B036L;
            struct S0 l_1469 = {4294967291UL,0,0x70EC23EDL,3UL,0xE7A0B63C4C55D439LL,0x9FA2L};
            int i, j;
            if (p_49)
                break;
            (**g_1401) = (((safe_div_func_int32_t_s_s((p_49 = (safe_lshift_func_uint32_t_u_u((safe_lshift_func_int16_t_s_s(((*l_1443) = (((*l_686) || ((l_1442 = ((p_49 , g_1433) <= (safe_add_func_int32_t_s_s(p_49, (l_1436 | (((**g_1177) , (safe_rshift_func_uint8_t_u_u(2UL, 3))) , (safe_mod_func_int16_t_s_s(p_49, (((*l_1441) = (p_49 & g_120[0][3])) | p_49))))))))) ^ p_49)) , 0x2E8CL)), g_440.f2)), (*g_1193)))), 0x926935A9L)) && (*l_686)) || l_1442);
            for (g_140 = 0; (g_140 <= 5); g_140 += 1)
            { /* block id: 680 */
                int32_t l_1457[2][5][2] = {{{0x6C7DCF23L,0x6C7DCF23L},{0x6C7DCF23L,0x6C7DCF23L},{0x6C7DCF23L,0x6C7DCF23L},{0x6C7DCF23L,0x6C7DCF23L},{0x6C7DCF23L,0x6C7DCF23L}},{{0x6C7DCF23L,0x6C7DCF23L},{0x6C7DCF23L,0x6C7DCF23L},{0x6C7DCF23L,0x6C7DCF23L},{0x6C7DCF23L,0x6C7DCF23L},{0x6C7DCF23L,0x6C7DCF23L}}};
                int32_t l_1460[1];
                struct S0 l_1468[5] = {{0x0879C0A6L,1,0x6D2DC081L,0xAE53BEA4L,6UL,7UL},{0x0879C0A6L,1,0x6D2DC081L,0xAE53BEA4L,6UL,7UL},{0x0879C0A6L,1,0x6D2DC081L,0xAE53BEA4L,6UL,7UL},{0x0879C0A6L,1,0x6D2DC081L,0xAE53BEA4L,6UL,7UL},{0x0879C0A6L,1,0x6D2DC081L,0xAE53BEA4L,6UL,7UL}};
                int i, j, k;
                for (i = 0; i < 1; i++)
                    l_1460[i] = 0x2CB04A3AL;
                if ((safe_div_func_uint16_t_u_u(l_1436, l_1436)))
                { /* block id: 681 */
                    for (g_854.f4 = 0; (g_854.f4 <= 2); g_854.f4 += 1)
                    { /* block id: 684 */
                        int i, j, k;
                        if (g_860[g_854.f4])
                            break;
                        (***g_1400) = g_110[g_140][g_854.f5][(g_854.f5 + 1)];
                        if (p_49)
                            break;
                    }
                    for (l_1442 = 2; (l_1442 >= 0); l_1442 -= 1)
                    { /* block id: 691 */
                        int8_t **l_1450[6][6][7] = {{{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,(void*)0,(void*)0,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{(void*)0,&l_1441,(void*)0,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441}},{{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{(void*)0,&l_1441,(void*)0,(void*)0,&l_1441,(void*)0,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,(void*)0,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,(void*)0,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441}},{{&l_1441,&l_1441,&l_1441,&l_1441,(void*)0,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,(void*)0,(void*)0},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,(void*)0,(void*)0,&l_1441},{(void*)0,&l_1441,&l_1441,&l_1441,&l_1441,(void*)0,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441}},{{&l_1441,&l_1441,(void*)0,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,(void*)0,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,(void*)0,&l_1441,(void*)0,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441}},{{&l_1441,(void*)0,(void*)0,&l_1441,(void*)0,(void*)0,&l_1441},{(void*)0,&l_1441,&l_1441,(void*)0,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,(void*)0,&l_1441,&l_1441,&l_1441,(void*)0},{&l_1441,&l_1441,&l_1441,(void*)0,&l_1441,&l_1441,(void*)0},{&l_1441,&l_1441,&l_1441,&l_1441,(void*)0,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441}},{{(void*)0,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,(void*)0,&l_1441,&l_1441,(void*)0,&l_1441,&l_1441},{(void*)0,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,&l_1441,(void*)0,&l_1441,&l_1441},{&l_1441,&l_1441,(void*)0,&l_1441,&l_1441,&l_1441,&l_1441},{&l_1441,&l_1441,&l_1441,(void*)0,(void*)0,&l_1441,&l_1441}}};
                        int i, j, k;
                        (*g_221) |= (safe_add_func_int64_t_s_s((safe_div_func_int64_t_s_s(((l_1451 = (void*)0) == &g_1117), ((safe_sub_func_int64_t_s_s(g_860[l_1442], (g_110[(l_1442 + 3)][g_140][g_854.f5] && ((((l_1454 == &l_1455[5][3]) , ((*g_939) |= ((l_1457[0][1][0] | (((*g_1193) ^ p_49) || p_49)) && 7UL))) && g_110[(l_1442 + 3)][g_140][g_854.f5]) , p_49)))) ^ 0x35120692L))), 18446744073709551612UL));
                    }
                    if (p_49)
                        continue;
                }
                else
                { /* block id: 697 */
                    int32_t *l_1458 = &l_1363;
                    int32_t *l_1459[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_1459[i] = &l_1363;
                    ++g_1465;
                    l_1442 = p_49;
                }
                for (l_1442 = 0; (l_1442 <= 2); l_1442 += 1)
                { /* block id: 703 */
                    return l_1468[1];
                }
                return l_1469;
            }
        }
        for (l_1462 = 12; (l_1462 <= 13); l_1462 = safe_add_func_int16_t_s_s(l_1462, 8))
        { /* block id: 711 */
            int8_t **l_1492 = &l_1451;
            int32_t * const *l_1508 = &l_1497;
            int32_t * const **l_1507[7] = {&l_1508,&l_1508,&l_1508,&l_1508,&l_1508,&l_1508,&l_1508};
            int32_t * const ***l_1506[1];
            int32_t * const ****l_1505 = &l_1506[0];
            uint8_t **l_1517 = &g_243;
            int64_t *****l_1528[1];
            int64_t *****l_1533 = &g_1530;
            int16_t *l_1546 = &g_110[0][2][2];
            int16_t **l_1545 = &l_1546;
            int16_t ***l_1544[4] = {&l_1545,&l_1545,&l_1545,&l_1545};
            struct S0 l_1556 = {0xF663BD60L,1,7L,4294967288UL,1UL,1UL};
            uint32_t **l_1566 = (void*)0;
            uint32_t ***l_1565 = &l_1566;
            uint64_t l_1638[7] = {0xDB54E219C1F8D2EALL,0xDB54E219C1F8D2EALL,0x30C2F5B004A72881LL,0xDB54E219C1F8D2EALL,0xDB54E219C1F8D2EALL,0x30C2F5B004A72881LL,0xDB54E219C1F8D2EALL};
            int16_t * const *l_1644 = &l_1546;
            int16_t * const **l_1643 = &l_1644;
            int16_t * const ***l_1642[8] = {&l_1643,&l_1643,&l_1643,&l_1643,&l_1643,&l_1643,&l_1643,&l_1643};
            int16_t * const ****l_1641 = &l_1642[1];
            int i;
            for (i = 0; i < 1; i++)
                l_1506[i] = &l_1507[2];
            for (i = 0; i < 1; i++)
                l_1528[i] = (void*)0;
            for (g_854.f3 = 0; (g_854.f3 == 28); g_854.f3 = safe_add_func_uint16_t_u_u(g_854.f3, 4))
            { /* block id: 714 */
                (*g_221) = p_49;
                for (g_440.f4 = 0; (g_440.f4 <= 0); g_440.f4 += 1)
                { /* block id: 718 */
                    uint16_t *l_1496 = &l_71[0][0][2];
                    int i, j;
                    (***g_1400) = (g_860[(g_440.f4 + 2)] ^ ((2UL | (+g_122[(g_440.f4 + 9)][(g_440.f4 + 4)])) || (((safe_lshift_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u((+(3UL == (((!(safe_mod_func_int64_t_s_s((safe_div_func_uint16_t_u_u(((*l_1496) = (safe_add_func_int32_t_s_s(((((((((*g_243) = (safe_sub_func_int64_t_s_s((g_1489 != (p_49 , l_1492)), ((*g_1155) = (~(((**g_938) <= (+(p_49 > g_122[(g_440.f4 + 9)][(g_440.f4 + 4)]))) <= 5UL)))))) && 255UL) <= 18446744073709551615UL) ^ 0xC08DL) , &g_400) != &g_400) & l_1495), 6L))), (-7L))), (-7L)))) && p_49) && g_122[2][2]))), 11)), 3)) || p_49) & (-5L))));
                    l_1497 = &l_1464[1];
                }
            }
            for (g_854.f3 = (-19); (g_854.f3 >= 20); g_854.f3 = safe_add_func_uint8_t_u_u(g_854.f3, 6))
            { /* block id: 728 */
                uint8_t l_1534 = 7UL;
                uint32_t *l_1536 = &g_120[0][3];
                for (p_49 = (-18); (p_49 > (-27)); --p_49)
                { /* block id: 731 */
                    const int32_t ***l_1511 = (void*)0;
                    const int32_t ****l_1510 = &l_1511;
                    const int32_t *****l_1509 = &l_1510;
                    const int16_t **l_1516 = (void*)0;
                    (**l_1508) = (((~(safe_sub_func_uint8_t_u_u(0xEEL, ((((p_49 , (p_49 , l_1505)) == (l_1512 = l_1509)) , (void*)0) != ((safe_sub_func_int16_t_s_s(((l_1515 , (*g_1489)) != (*g_1489)), p_49)) , l_1516))))) >= (*g_243)) , (*l_1497));
                    if (p_49)
                        break;
                }
                p_49 &= (*l_1497);
                p_49 = ((void*)0 != l_1517);
                (*l_686) = (safe_add_func_uint8_t_u_u((safe_mul_func_int64_t_s_s(p_49, (((safe_rshift_func_int8_t_s_u((safe_div_func_int64_t_s_s((((void*)0 == l_1526) | ((9UL > ((g_1529 = l_1528[0]) != (l_1533 = (g_1532 = (g_1531 = &g_1530))))) != ((l_1534 = 1L) < ((((*l_1536) = (~p_49)) && (((p_49 > p_49) || g_120[0][0]) == p_49)) , 0xC169L)))), (*l_686))), (**g_242))) | g_486.f0) < g_347))), (*l_686)));
            }
            if ((safe_rshift_func_int16_t_s_s((safe_rshift_func_uint64_t_u_u((p_49 >= (safe_div_func_int64_t_s_s(((l_1543 == l_1544[1]) || (((safe_mod_func_uint16_t_u_u(((*g_221) != ((l_1549 , (((((*l_1497) = (safe_div_func_uint64_t_u_u(0x7485DD73D6D121A9LL, p_49))) | (p_49 > ((!(((((l_1553 < p_49) , (void*)0) == (*g_1177)) >= (*g_243)) , 9L)) != p_49))) , (*l_1497)) == p_49)) , p_49)), p_49)) || p_49) >= p_49)), l_1515.f2))), 58)), 0)))
            { /* block id: 747 */
                int8_t l_1564 = 0x00L;
                uint32_t ****l_1567 = &l_1565;
                uint32_t ***l_1569 = &l_1566;
                uint32_t ****l_1568 = &l_1569;
                uint8_t l_1580 = 0x9DL;
                int32_t l_1581 = 0x9EF4E786L;
                uint64_t **l_1585 = &g_939;
                int32_t * volatile l_1586[10] = {(void*)0,(void*)0,&l_1581,(void*)0,(void*)0,&l_1581,(void*)0,(void*)0,&l_1581,(void*)0};
                int16_t **** const l_1615 = &l_1544[1];
                int i;
                (**l_1508) &= 0L;
                for (p_49 = 0; (p_49 >= 18); p_49 = safe_add_func_int8_t_s_s(p_49, 2))
                { /* block id: 751 */
                    return l_1556;
                }
                l_1581 |= (!(safe_mod_func_int32_t_s_s((1UL <= (((((((l_1564 < (((*l_1567) = l_1565) == ((*l_1568) = (void*)0))) < 247UL) ^ (((safe_div_func_uint64_t_u_u((****g_1280), ((safe_div_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((safe_rshift_func_int64_t_s_u(p_49, (safe_mul_func_int64_t_s_s(((**g_1401) ^ (0x3A60D8BBCC05B170LL && p_49)), (*l_1497))))), l_1580)), l_1564)) || g_165))) | (*g_243)) | 0x597EL)) && (*l_686)) > (**l_1508)) > 18446744073709551615UL) == (*l_1497))), (*l_686))));
                for (g_163 = 0; (g_163 == 39); g_163++)
                { /* block id: 759 */
                    int16_t l_1602 = 8L;
                    int32_t l_1603 = 0x814596A6L;
                    union U1 **l_1606 = &g_647;
                    p_49 = ((**g_1280) != (l_1585 = l_1584));
                    l_1586[0] = (***g_1399);
                    if (p_49)
                    { /* block id: 763 */
                        l_1603 = (((l_1556 , 3UL) >= 1UL) , (l_1363 = ((***g_1400) = ((((*l_1497) &= (l_1587 = p_49)) == ((((safe_div_func_int32_t_s_s(0x05C013FDL, (safe_mul_func_uint64_t_u_u(p_49, (&g_647 != ((((((safe_rshift_func_uint16_t_u_u((((((safe_div_func_int8_t_s_s((((((*g_1193) = 0xEC4C5F73L) > (safe_sub_func_int32_t_s_s((((safe_lshift_func_int64_t_s_s((safe_rshift_func_uint8_t_u_s(0xEFL, 0)), 40)) > (***g_1281)) > g_675), p_49))) <= p_49) || (*g_243)), 0x01L)) & (*g_1032)) | 0x2E742782L) >= (**g_1401)) != p_49), 15)) != g_346[4][0]) | p_49) , l_1602) , l_1556) , &g_647)))))) != 0xA8L) | 0x774F5478L) , 0xFB9AL)) <= p_49))));
                        l_1603 = (safe_mul_func_uint32_t_u_u((((*g_1490) && (l_1606 == ((safe_sub_func_int16_t_s_s((safe_div_func_int8_t_s_s((safe_rshift_func_uint16_t_u_s((safe_mul_func_uint8_t_u_u(0xAAL, 0x2BL)), (*g_1032))), (*g_243))), ((((***g_1400) , l_1615) == ((*g_1002) , (void*)0)) && p_49))) , &g_647))) || 0x582ED69BL), l_1580));
                    }
                    else
                    { /* block id: 771 */
                        if (l_1515.f5)
                            goto lbl_1616;
                        return (**g_1138);
                    }
                }
            }
            else
            { /* block id: 776 */
                const uint8_t l_1632 = 1UL;
                int32_t l_1637[5] = {0L,0L,0L,0L,0L};
                struct S0 l_1649 = {0UL,-2,0xED42C2F0L,0x12D69DA2L,1UL,65528UL};
                int32_t *l_1673 = &l_1556.f2;
                int i;
                (*g_1401) = (l_1497 = &l_1461);
                if ((l_1556 , ((!p_49) >= (+((void*)0 != &g_1002)))))
                { /* block id: 779 */
                    int32_t l_1634 = 0x30D81B43L;
                    int32_t l_1635 = (-1L);
                    int64_t ****l_1669 = &g_1153[3];
                    if ((p_49 , 1L))
                    { /* block id: 780 */
                        (*g_1620) = (*g_378);
                    }
                    else
                    { /* block id: 782 */
                        const int32_t *l_1633 = &l_1556.f2;
                        int32_t l_1636 = 0x2040F56DL;
                        (*l_1497) = (0x44DD092268F5C114LL >= (((***g_1281) = (safe_mul_func_int64_t_s_s((((((g_440.f5 &= p_49) ^ ((((*l_686) |= (safe_div_func_int16_t_s_s((((safe_mul_func_int32_t_s_s((****g_1399), (-1L))) < (safe_mod_func_uint64_t_u_u(p_49, ((0L <= (0x05L && g_163)) || (((~(safe_add_func_int16_t_s_s(g_161, 8UL))) , g_120[0][3]) <= l_1632))))) , 2L), g_440.f3))) == g_228) > 0L)) > (*l_1497)) , (*g_243)) == g_697), p_49))) & 0x8B6261F277B12BD7LL));
                        l_1633 = (*g_1010);
                        l_1638[1]++;
                        (*l_686) ^= ((((l_1645 = l_1641) != (l_1649 , g_1380)) ^ ((***l_1643) &= (safe_mod_func_int64_t_s_s(((((l_1649.f1 ^ (safe_lshift_func_uint64_t_u_u(2UL, 35))) >= (*l_1497)) , ((((safe_sub_func_int64_t_s_s((safe_mul_func_uint32_t_u_u((safe_add_func_int64_t_s_s((safe_unary_minus_func_int32_t_s(0x101CFB27L)), ((((p_49 , l_1636) || 0xB2L) & l_1649.f4) | g_1003[0][0][3]))), 0xD068C913L)), 3UL)) >= 0x88L) ^ p_49) <= p_49)) > (*g_1155)), p_49)))) & (-4L));
                    }
                    (*g_221) ^= (safe_add_func_int8_t_s_s(p_49, ((1L >= (safe_lshift_func_int16_t_s_u((safe_div_func_int64_t_s_s((*****g_878), (safe_sub_func_int8_t_s_s((&l_1642[0] == (void*)0), ((l_1670[1][2] = l_1669) == l_1669))))), (safe_div_func_int8_t_s_s((-1L), p_49))))) >= (*l_686))));
                    l_1673 = (void*)0;
                }
                else
                { /* block id: 796 */
                    uint32_t l_1675 = 18446744073709551612UL;
                    for (l_1515.f3 = 0; (l_1515.f3 <= 2); l_1515.f3 += 1)
                    { /* block id: 799 */
                        int32_t l_1674 = 0x61F27CDDL;
                        int i;
                        --l_1675;
                        (*l_1673) &= (-1L);
                    }
                    l_1497 = &p_49;
                    p_49 |= 0xF7E7B822L;
                }
                return l_1649;
            }
            return g_1678;
        }
    }
    return (**g_1138);
}


/* ------------------------------------------ */
/* 
 * reads : g_440.f5 g_347 g_440.f2
 * writes: g_440.f5 g_347
 */
static const uint32_t  func_50(int8_t  p_51, uint16_t  p_52, int32_t  p_53, int32_t * p_54)
{ /* block id: 286 */
    uint8_t l_705 = 2UL;
    union U1 *l_730[8];
    int32_t *l_732[9][9] = {{&g_440.f2,&g_165,&g_3,&g_165,&g_440.f2,&g_3,&g_165,&g_3,&g_79},{&g_440.f2,&g_165,&g_165,&g_3,(void*)0,&g_3,&g_165,&g_165,&g_440.f2},{&g_440.f2,&g_3,&g_79,&g_440.f2,&g_3,&g_3,&g_440.f2,&g_3,&g_3},{&g_440.f2,&g_165,&g_165,&g_440.f2,&g_3,&g_165,&g_165,&g_79,&g_3},{&g_440.f2,&g_3,&g_440.f2,&g_440.f2,&g_440.f2,&g_440.f2,&g_3,&g_440.f2,&g_3},{&g_440.f2,&g_440.f2,&g_3,&g_440.f2,&g_3,&g_79,&g_79,&g_3,&g_440.f2},{&g_440.f2,&g_165,&g_440.f2,&g_3,&g_3,&g_440.f2,&g_79,&g_3,&g_3},{&g_165,&g_440.f2,(void*)0,&g_79,(void*)0,&g_440.f2,&g_165,&g_165,&g_3},{&g_79,&g_440.f2,&g_3,&g_3,&g_440.f2,&g_165,&g_440.f2,&g_3,&g_3}};
    int16_t *l_794[6] = {&g_338,&g_338,&g_338,&g_110[0][5][5],&g_110[0][5][5],&g_338};
    int16_t **l_793 = &l_794[4];
    int16_t ***l_792 = &l_793;
    int16_t *** const *l_791 = &l_792;
    const int32_t *l_801 = &g_228;
    const int32_t ** const l_800 = &l_801;
    const int64_t **l_821 = (void*)0;
    struct S0 *l_852[8] = {&g_440,&g_440,&g_440,&g_440,&g_440,&g_440,&g_440,&g_440};
    uint64_t l_895 = 0UL;
    int8_t l_952 = 0x98L;
    int32_t l_960 = 0xC8B9D4C1L;
    struct S0 l_1057[2] = {{0x547D96FEL,1,0x4F5B5EB8L,0xD9D67430L,9UL,0xBFB2L},{0x547D96FEL,1,0x4F5B5EB8L,0xD9D67430L,9UL,0xBFB2L}};
    int32_t l_1088 = 0xCB1C1C36L;
    int32_t l_1111 = (-1L);
    const uint32_t **l_1196 = &g_1002;
    int i, j;
    for (i = 0; i < 8; i++)
        l_730[i] = &g_685[0];
    for (g_440.f5 = 16; (g_440.f5 < 43); ++g_440.f5)
    { /* block id: 289 */
        int32_t l_719[10] = {0x1CC63DD5L,0x1CC63DD5L,0x1CC63DD5L,0x1CC63DD5L,0x1CC63DD5L,0x1CC63DD5L,0x1CC63DD5L,0x1CC63DD5L,0x1CC63DD5L,0x1CC63DD5L};
        uint32_t l_768 = 0xFCFB8AE5L;
        uint64_t *l_781 = &g_236;
        int16_t *l_787 = &g_338;
        int16_t **l_786 = &l_787;
        int16_t ***l_785[1][5][3] = {{{&l_786,&l_786,&l_786},{&l_786,&l_786,&l_786},{&l_786,&l_786,&l_786},{&l_786,&l_786,&l_786},{&l_786,&l_786,&l_786}}};
        int16_t ****l_784 = &l_785[0][2][0];
        int8_t *l_795 = &g_347;
        const uint8_t l_796 = 0x02L;
        const int64_t l_817 = 0x448A4D6C4803CC9BLL;
        int64_t *l_819 = &g_675;
        int64_t **l_818 = &l_819;
        int32_t l_874[7][10] = {{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L,1L,1L}};
        uint8_t ** const l_880 = &g_243;
        const struct S0 *l_965 = &g_440;
        int32_t **l_995[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
        int32_t ***l_994 = &l_995[2];
        uint8_t l_1040 = 0x7EL;
        int32_t l_1099 = 0xE528B7C9L;
        uint32_t l_1181[7][10] = {{0x16319169L,18446744073709551607UL,18446744073709551608UL,0x16319169L,0x17EB94EBL,0x17EB94EBL,0x16319169L,18446744073709551608UL,18446744073709551607UL,0x16319169L},{18446744073709551608UL,6UL,18446744073709551607UL,0x17EB94EBL,6UL,0x17EB94EBL,18446744073709551607UL,6UL,18446744073709551608UL,18446744073709551608UL},{0x16319169L,5UL,0UL,6UL,6UL,0UL,5UL,0x16319169L,0UL,0x16319169L},{6UL,18446744073709551607UL,0x17EB94EBL,6UL,0x17EB94EBL,18446744073709551607UL,6UL,18446744073709551608UL,18446744073709551608UL,6UL},{18446744073709551608UL,0x16319169L,0x17EB94EBL,0x17EB94EBL,0x16319169L,18446744073709551608UL,18446744073709551607UL,0x16319169L,18446744073709551607UL,18446744073709551608UL},{5UL,0x16319169L,0UL,0x16319169L,5UL,0UL,6UL,6UL,0UL,5UL},{5UL,18446744073709551607UL,18446744073709551607UL,5UL,0x17EB94EBL,18446744073709551608UL,5UL,18446744073709551608UL,0x17EB94EBL,5UL}};
        int i, j, k;
    }
    for (g_347 = 0; (g_347 == (-15)); g_347--)
    { /* block id: 550 */
        uint64_t *** const l_1217[2][3][8] = {{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}}};
        int32_t l_1236 = 0x8B44F719L;
        int32_t *l_1274 = &g_3;
        int32_t ** const l_1273 = &l_1274;
        int32_t ** const *l_1272 = &l_1273;
        int32_t l_1324 = 4L;
        int32_t l_1325 = 0xA06B2738L;
        int32_t l_1326[6] = {0L,0L,0L,0L,0L,0L};
        int16_t l_1328 = 4L;
        int i, j, k;
        if ((*p_54))
            break;
    }
    return p_51;
}


/* ------------------------------------------ */
/* 
 * reads : g_75 g_440.f5 g_165 g_74 g_2 g_221 g_685 g_378
 * writes: g_2 g_440.f5 g_165
 */
static uint16_t  func_57(int32_t ** p_58, int64_t  p_59, int32_t  p_60)
{ /* block id: 276 */
    int32_t *l_676[7];
    int32_t l_677[6] = {0x2D400F4EL,0x2FAF8F5DL,0x2D400F4EL,0x2D400F4EL,0x2FAF8F5DL,0x2D400F4EL};
    uint64_t l_678 = 0UL;
    int i;
    for (i = 0; i < 7; i++)
        l_676[i] = &g_79;
    l_678++;
    (*g_75) = (0x62415FF63AB21607LL <= p_60);
    for (g_440.f5 = 0; (g_440.f5 != 24); g_440.f5++)
    { /* block id: 281 */
        (*g_221) = (1UL != (p_59 <= (safe_mod_func_uint32_t_u_u(g_165, (**g_74)))));
        (*g_75) = (g_685[4] , (**g_378));
    }
    return p_60;
}


/* ------------------------------------------ */
/* 
 * reads : g_74 g_97
 * writes: g_75 g_97
 */
static int64_t  func_63(uint32_t  p_64, int32_t  p_65, int32_t * p_66, int32_t  p_67)
{ /* block id: 11 */
    int32_t l_93 = 0x15C01E8BL;
    int32_t l_94 = 1L;
    uint8_t *l_204 = &g_140;
    uint8_t **l_203 = &l_204;
    int32_t l_305 = (-10L);
    int32_t * const l_385 = (void*)0;
    const int16_t *l_391[1][10][7] = {{{&g_392,&g_392,(void*)0,&g_392,&g_392,&g_392,&g_392},{&g_392,&g_392,&g_392,&g_392,&g_392,&g_392,&g_392},{&g_392,&g_392,&g_392,&g_392,&g_392,&g_392,&g_392},{&g_392,&g_392,&g_392,&g_392,(void*)0,&g_392,&g_392},{(void*)0,(void*)0,(void*)0,&g_392,&g_392,&g_392,&g_392},{&g_392,(void*)0,&g_392,&g_392,&g_392,&g_392,&g_392},{&g_392,&g_392,&g_392,&g_392,&g_392,&g_392,&g_392},{&g_392,&g_392,&g_392,&g_392,(void*)0,&g_392,&g_392},{&g_392,&g_392,&g_392,&g_392,&g_392,&g_392,&g_392},{&g_392,&g_392,&g_392,&g_392,&g_392,&g_392,(void*)0}}};
    int16_t *l_393 = &g_110[2][0][1];
    volatile int32_t *l_441[9] = {&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2,&g_2};
    int64_t l_520 = 0x12D9F4B4A6F76CACLL;
    uint64_t l_569 = 7UL;
    int32_t *l_651 = &g_79;
    uint32_t *** const l_668 = (void*)0;
    uint32_t l_669 = 0x5A41B0CAL;
    uint8_t l_672 = 0x83L;
    int i, j, k;
    (*g_74) = &g_2;
    for (p_65 = (-17); (p_65 != 23); p_65++)
    { /* block id: 15 */
        int32_t *l_78 = &g_79;
        int32_t *l_80 = &g_79;
        int32_t *l_81 = &g_79;
        int32_t *l_82 = &g_79;
        int32_t *l_83 = &g_79;
        int32_t *l_84 = &g_79;
        int32_t *l_85 = &g_79;
        int32_t *l_86 = &g_79;
        int32_t l_87 = 5L;
        int32_t *l_88 = &l_87;
        int32_t *l_89 = (void*)0;
        int32_t *l_90 = (void*)0;
        int32_t *l_91 = &g_79;
        int32_t *l_92[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
        int16_t *l_167 = &g_110[3][2][4];
        int16_t **l_166 = &l_167;
        uint8_t *l_187 = &g_163;
        uint64_t *l_249 = &g_236;
        int8_t l_343 = 0xC9L;
        uint32_t l_422 = 2UL;
        int64_t *l_462 = &g_161;
        int64_t ** const l_461 = &l_462;
        uint32_t l_476 = 0x54DC8086L;
        const int32_t *l_481 = &g_228;
        const int32_t **l_480 = &l_481;
        int8_t l_573 = 0x63L;
        uint16_t l_579 = 0xD267L;
        int i;
        g_97++;
    }
    ++l_669;
    ++l_672;
    return p_67;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_3, "g_3", print_hash_value);
    transparent_crc(g_68.f0, "g_68.f0", print_hash_value);
    transparent_crc(g_79, "g_79", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_95[i][j][k], "g_95[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_96, "g_96", print_hash_value);
    transparent_crc(g_97, "g_97", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_110[i][j][k], "g_110[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_120[i][j], "g_120[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_122[i][j], "g_122[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_127, "g_127", print_hash_value);
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_161, "g_161", print_hash_value);
    transparent_crc(g_163, "g_163", print_hash_value);
    transparent_crc(g_165, "g_165", print_hash_value);
    transparent_crc(g_228, "g_228", print_hash_value);
    transparent_crc(g_236, "g_236", print_hash_value);
    transparent_crc(g_262, "g_262", print_hash_value);
    transparent_crc(g_338, "g_338", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_346[i][j], "g_346[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_347, "g_347", print_hash_value);
    transparent_crc(g_392, "g_392", print_hash_value);
    transparent_crc(g_440.f0, "g_440.f0", print_hash_value);
    transparent_crc(g_440.f1, "g_440.f1", print_hash_value);
    transparent_crc(g_440.f2, "g_440.f2", print_hash_value);
    transparent_crc(g_440.f3, "g_440.f3", print_hash_value);
    transparent_crc(g_440.f4, "g_440.f4", print_hash_value);
    transparent_crc(g_440.f5, "g_440.f5", print_hash_value);
    transparent_crc(g_486.f0, "g_486.f0", print_hash_value);
    transparent_crc(g_650.f0, "g_650.f0", print_hash_value);
    transparent_crc(g_675, "g_675", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_685[i].f0, "g_685[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_697, "g_697", print_hash_value);
    transparent_crc(g_854.f0, "g_854.f0", print_hash_value);
    transparent_crc(g_854.f1, "g_854.f1", print_hash_value);
    transparent_crc(g_854.f2, "g_854.f2", print_hash_value);
    transparent_crc(g_854.f3, "g_854.f3", print_hash_value);
    transparent_crc(g_854.f4, "g_854.f4", print_hash_value);
    transparent_crc(g_854.f5, "g_854.f5", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_860[i], "g_860[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_918[i][j].f0, "g_918[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_985.f0, "g_985.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1003[i][j][k], "g_1003[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1014.f0, "g_1014.f0", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1029[i].f0, "g_1029[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_1033[i][j][k], "g_1033[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1035, "g_1035", print_hash_value);
    transparent_crc(g_1117, "g_1117", print_hash_value);
    transparent_crc(g_1172.f0, "g_1172.f0", print_hash_value);
    transparent_crc(g_1179, "g_1179", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1188[i].f0, "g_1188[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1235.f0, "g_1235.f0", print_hash_value);
    transparent_crc(g_1240.f0, "g_1240.f0", print_hash_value);
    transparent_crc(g_1339.f0, "g_1339.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1358[i][j][k], "g_1358[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1433, "g_1433", print_hash_value);
    transparent_crc(g_1465, "g_1465", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_1491[i], "g_1491[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1678.f0, "g_1678.f0", print_hash_value);
    transparent_crc(g_1678.f1, "g_1678.f1", print_hash_value);
    transparent_crc(g_1678.f2, "g_1678.f2", print_hash_value);
    transparent_crc(g_1678.f3, "g_1678.f3", print_hash_value);
    transparent_crc(g_1678.f4, "g_1678.f4", print_hash_value);
    transparent_crc(g_1678.f5, "g_1678.f5", print_hash_value);
    transparent_crc(g_1713, "g_1713", print_hash_value);
    transparent_crc(g_1758, "g_1758", print_hash_value);
    transparent_crc(g_1788.f0, "g_1788.f0", print_hash_value);
    transparent_crc(g_1801.f0, "g_1801.f0", print_hash_value);
    transparent_crc(g_1815, "g_1815", print_hash_value);
    transparent_crc(g_1852.f0, "g_1852.f0", print_hash_value);
    transparent_crc(g_1865.f0, "g_1865.f0", print_hash_value);
    transparent_crc(g_1924.f0, "g_1924.f0", print_hash_value);
    transparent_crc(g_1924.f1, "g_1924.f1", print_hash_value);
    transparent_crc(g_1924.f2, "g_1924.f2", print_hash_value);
    transparent_crc(g_1924.f3, "g_1924.f3", print_hash_value);
    transparent_crc(g_1924.f4, "g_1924.f4", print_hash_value);
    transparent_crc(g_1924.f5, "g_1924.f5", print_hash_value);
    transparent_crc(g_1988, "g_1988", print_hash_value);
    transparent_crc(g_2002.f0, "g_2002.f0", print_hash_value);
    transparent_crc(g_2003.f0, "g_2003.f0", print_hash_value);
    transparent_crc(g_2020.f0, "g_2020.f0", print_hash_value);
    transparent_crc(g_2078, "g_2078", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            for (k = 0; k < 8; k++)
            {
                transparent_crc(g_2188[i][j][k], "g_2188[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2270.f0, "g_2270.f0", print_hash_value);
    transparent_crc(g_2290, "g_2290", print_hash_value);
    transparent_crc(g_2515, "g_2515", print_hash_value);
    transparent_crc(g_2526.f0, "g_2526.f0", print_hash_value);
    transparent_crc(g_2551.f0, "g_2551.f0", print_hash_value);
    transparent_crc(g_2561.f0, "g_2561.f0", print_hash_value);
    transparent_crc(g_2685, "g_2685", print_hash_value);
    transparent_crc(g_2732.f0, "g_2732.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2733[i].f0, "g_2733[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2929, "g_2929", print_hash_value);
    transparent_crc(g_2936.f0, "g_2936.f0", print_hash_value);
    transparent_crc(g_2936.f1, "g_2936.f1", print_hash_value);
    transparent_crc(g_2936.f2, "g_2936.f2", print_hash_value);
    transparent_crc(g_2936.f3, "g_2936.f3", print_hash_value);
    transparent_crc(g_2936.f4, "g_2936.f4", print_hash_value);
    transparent_crc(g_2936.f5, "g_2936.f5", print_hash_value);
    transparent_crc(g_3066, "g_3066", print_hash_value);
    transparent_crc(g_3140, "g_3140", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_3239[i][j][k].f0, "g_3239[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3253, "g_3253", print_hash_value);
    transparent_crc(g_3386.f0, "g_3386.f0", print_hash_value);
    transparent_crc(g_3408.f0, "g_3408.f0", print_hash_value);
    transparent_crc(g_3408.f1, "g_3408.f1", print_hash_value);
    transparent_crc(g_3408.f2, "g_3408.f2", print_hash_value);
    transparent_crc(g_3408.f3, "g_3408.f3", print_hash_value);
    transparent_crc(g_3408.f4, "g_3408.f4", print_hash_value);
    transparent_crc(g_3408.f5, "g_3408.f5", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_3427[i], "g_3427[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3448.f0, "g_3448.f0", print_hash_value);
    transparent_crc(g_3464.f0, "g_3464.f0", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_3466[i], "g_3466[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3475, "g_3475", print_hash_value);
    transparent_crc(g_3487, "g_3487", print_hash_value);
    transparent_crc(g_3521, "g_3521", print_hash_value);
    transparent_crc(g_3547, "g_3547", print_hash_value);
    transparent_crc(g_3558.f0, "g_3558.f0", print_hash_value);
    transparent_crc(g_3558.f1, "g_3558.f1", print_hash_value);
    transparent_crc(g_3558.f2, "g_3558.f2", print_hash_value);
    transparent_crc(g_3558.f3, "g_3558.f3", print_hash_value);
    transparent_crc(g_3558.f4, "g_3558.f4", print_hash_value);
    transparent_crc(g_3558.f5, "g_3558.f5", print_hash_value);
    transparent_crc(g_3594.f0, "g_3594.f0", print_hash_value);
    transparent_crc(g_3614.f0, "g_3614.f0", print_hash_value);
    transparent_crc(g_3668, "g_3668", print_hash_value);
    transparent_crc(g_3686.f0, "g_3686.f0", print_hash_value);
    transparent_crc(g_3686.f1, "g_3686.f1", print_hash_value);
    transparent_crc(g_3686.f2, "g_3686.f2", print_hash_value);
    transparent_crc(g_3686.f3, "g_3686.f3", print_hash_value);
    transparent_crc(g_3686.f4, "g_3686.f4", print_hash_value);
    transparent_crc(g_3686.f5, "g_3686.f5", print_hash_value);
    transparent_crc(g_3819, "g_3819", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_3840[i][j].f0, "g_3840[i][j].f0", print_hash_value);
            transparent_crc(g_3840[i][j].f1, "g_3840[i][j].f1", print_hash_value);
            transparent_crc(g_3840[i][j].f2, "g_3840[i][j].f2", print_hash_value);
            transparent_crc(g_3840[i][j].f3, "g_3840[i][j].f3", print_hash_value);
            transparent_crc(g_3840[i][j].f4, "g_3840[i][j].f4", print_hash_value);
            transparent_crc(g_3840[i][j].f5, "g_3840[i][j].f5", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_3887[i], "g_3887[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3911, "g_3911", print_hash_value);
    transparent_crc(g_4054, "g_4054", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 1006
   depth: 1, occurrence: 29
XXX total union variables: 29

XXX non-zero bitfields defined in structs: 2
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 117
breakdown:
   indirect level: 0, occurrence: 58
   indirect level: 1, occurrence: 33
   indirect level: 2, occurrence: 12
   indirect level: 3, occurrence: 4
   indirect level: 4, occurrence: 5
   indirect level: 5, occurrence: 5
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 49
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 85
XXX times a single bitfield on LHS: 12
XXX times a single bitfield on RHS: 37

XXX max expression depth: 36
breakdown:
   depth: 1, occurrence: 186
   depth: 2, occurrence: 49
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 6, occurrence: 1
   depth: 7, occurrence: 1
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 2
   depth: 15, occurrence: 1
   depth: 16, occurrence: 4
   depth: 17, occurrence: 1
   depth: 18, occurrence: 2
   depth: 19, occurrence: 3
   depth: 20, occurrence: 2
   depth: 22, occurrence: 2
   depth: 23, occurrence: 4
   depth: 24, occurrence: 2
   depth: 25, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 29, occurrence: 2
   depth: 30, occurrence: 2
   depth: 31, occurrence: 1
   depth: 32, occurrence: 2
   depth: 36, occurrence: 1

XXX total number of pointers: 853

XXX times a variable address is taken: 2186
XXX times a pointer is dereferenced on RHS: 662
breakdown:
   depth: 1, occurrence: 402
   depth: 2, occurrence: 219
   depth: 3, occurrence: 21
   depth: 4, occurrence: 12
   depth: 5, occurrence: 8
XXX times a pointer is dereferenced on LHS: 621
breakdown:
   depth: 1, occurrence: 502
   depth: 2, occurrence: 99
   depth: 3, occurrence: 17
   depth: 4, occurrence: 0
   depth: 5, occurrence: 3
XXX times a pointer is compared with null: 72
XXX times a pointer is compared with address of another variable: 24
XXX times a pointer is compared with another pointer: 22
XXX times a pointer is qualified to be dereferenced: 15857

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2348
   level: 2, occurrence: 1059
   level: 3, occurrence: 292
   level: 4, occurrence: 159
   level: 5, occurrence: 61
XXX number of pointers point to pointers: 458
XXX number of pointers point to scalars: 358
XXX number of pointers point to structs: 16
XXX percent of pointers has null in alias set: 30.1
XXX average alias set size: 1.49

XXX times a non-volatile is read: 3608
XXX times a non-volatile is write: 1794
XXX times a volatile is read: 267
XXX    times read thru a pointer: 107
XXX times a volatile is write: 103
XXX    times written thru a pointer: 61
XXX times a volatile is available for access: 1.16e+04
XXX percentage of non-volatile access: 93.6

XXX forward jumps: 1
XXX backward jumps: 16

XXX stmts: 190
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 29
   depth: 1, occurrence: 28
   depth: 2, occurrence: 27
   depth: 3, occurrence: 31
   depth: 4, occurrence: 39
   depth: 5, occurrence: 36

XXX percentage a fresh-made variable is used: 16.6
XXX percentage an existing variable is used: 83.4
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

