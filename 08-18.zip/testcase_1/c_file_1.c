/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      1186073082
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile uint32_t  f0;
   volatile uint32_t  f1;
   const volatile int32_t  f2;
   const volatile int32_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_2 = 1L;
static uint16_t g_8 = 2UL;
static int16_t g_19 = 0L;
static int16_t g_38 = 0x826FL;
static uint16_t g_69 = 1UL;
static int64_t g_97 = 6L;
static uint8_t g_102 = 255UL;
static int16_t g_142 = 0x1122L;
static int32_t * volatile g_144 = (void*)0;/* VOLATILE GLOBAL g_144 */
static int32_t g_146 = (-2L);
static int32_t * volatile g_145 = &g_146;/* VOLATILE GLOBAL g_145 */
static union U0 g_153[1][4] = {{{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}}};
static uint32_t g_180 = 4294967292UL;
static uint16_t g_183 = 65532UL;
static uint64_t g_192 = 18446744073709551608UL;
static int16_t *g_198 = (void*)0;
static int16_t **g_197[3][4][10] = {{{&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198},{&g_198,&g_198,&g_198,&g_198,&g_198,(void*)0,(void*)0,(void*)0,(void*)0,&g_198},{(void*)0,&g_198,&g_198,&g_198,(void*)0,(void*)0,&g_198,&g_198,(void*)0,&g_198},{(void*)0,&g_198,(void*)0,&g_198,&g_198,(void*)0,(void*)0,&g_198,&g_198,(void*)0}},{{(void*)0,(void*)0,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198},{&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198},{&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,(void*)0,&g_198,&g_198,&g_198},{&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198}},{{&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,(void*)0,&g_198},{&g_198,&g_198,&g_198,&g_198,&g_198,(void*)0,&g_198,&g_198,(void*)0,&g_198},{&g_198,&g_198,&g_198,&g_198,&g_198,(void*)0,(void*)0,&g_198,&g_198,&g_198},{&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198,&g_198}}};
static int16_t *** volatile g_196 = &g_197[2][2][6];/* VOLATILE GLOBAL g_196 */
static union U0 g_203 = {1UL};/* VOLATILE GLOBAL g_203 */
static int64_t g_215 = 0xAD7911D495938EECLL;
static int32_t * volatile g_234 = (void*)0;/* VOLATILE GLOBAL g_234 */
static volatile uint32_t g_279 = 0x8C3D364CL;/* VOLATILE GLOBAL g_279 */
static uint32_t g_285 = 0UL;
static int32_t g_288 = 6L;
static int32_t * volatile *g_290 = &g_234;
static int32_t * volatile ** volatile g_289 = &g_290;/* VOLATILE GLOBAL g_289 */
static volatile int32_t *g_307[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static volatile int32_t ** volatile g_306 = &g_307[5];/* VOLATILE GLOBAL g_306 */
static volatile int32_t ** volatile *g_305 = &g_306;
static volatile int32_t ** volatile * volatile * volatile g_304 = &g_305;/* VOLATILE GLOBAL g_304 */
static volatile int32_t ** volatile * volatile * volatile * const  volatile g_308 = (void*)0;/* VOLATILE GLOBAL g_308 */
static volatile int32_t ** volatile * volatile * volatile * volatile g_309 = &g_304;/* VOLATILE GLOBAL g_309 */
static int32_t * volatile g_311 = (void*)0;/* VOLATILE GLOBAL g_311 */
static int32_t * volatile g_375 = (void*)0;/* VOLATILE GLOBAL g_375 */
static volatile union U0 g_383 = {0x0642E423L};/* VOLATILE GLOBAL g_383 */
static int64_t g_416 = 0xB1335DF6C0377350LL;
static int32_t g_419 = 0x206E420CL;
static uint64_t *g_458[5] = {&g_192,&g_192,&g_192,&g_192,&g_192};
static uint64_t **g_457 = &g_458[4];
static uint64_t *** volatile g_456 = &g_457;/* VOLATILE GLOBAL g_456 */
static int32_t * volatile g_502 = &g_288;/* VOLATILE GLOBAL g_502 */
static int32_t *g_559[2] = {&g_146,&g_146};
static uint32_t g_561 = 0xCF775939L;
static const int32_t *g_637 = &g_419;
static volatile int32_t g_651 = 0x91FCCB2FL;/* VOLATILE GLOBAL g_651 */
static uint16_t g_652 = 1UL;
static volatile int8_t g_704 = 0x52L;/* VOLATILE GLOBAL g_704 */
static const volatile int8_t *g_703 = &g_704;
static uint32_t g_780 = 0x81A45DB4L;
static int16_t g_789 = 0x0DC5L;
static int32_t * volatile g_812[9] = {&g_419,(void*)0,(void*)0,&g_419,(void*)0,(void*)0,&g_419,(void*)0,(void*)0};
static int32_t * volatile g_814 = (void*)0;/* VOLATILE GLOBAL g_814 */
static int32_t **g_828 = &g_559[1];
static int32_t ***g_827 = &g_828;
static int32_t ****g_826 = &g_827;
static int32_t *****g_825 = &g_826;
static int16_t g_888[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
static int32_t * volatile g_922 = &g_288;/* VOLATILE GLOBAL g_922 */
static const int32_t ** volatile g_924 = &g_637;/* VOLATILE GLOBAL g_924 */
static volatile uint32_t **g_1022 = (void*)0;
static volatile uint32_t ***g_1021 = &g_1022;
static volatile union U0 g_1027[2][2][1] = {{{{18446744073709551608UL}},{{8UL}}},{{{18446744073709551608UL}},{{8UL}}}};
static uint64_t ***g_1029 = &g_457;
static uint64_t ***g_1031 = &g_457;
static uint64_t **** volatile g_1030 = &g_1031;/* VOLATILE GLOBAL g_1030 */
static uint8_t g_1053 = 0xB4L;
static int32_t g_1056[4][5] = {{0xA16FE3E2L,0xA16FE3E2L,(-2L),0xA16FE3E2L,0xA16FE3E2L},{0x334DFBD7L,0x36CD1E20L,0x334DFBD7L,0x334DFBD7L,0x36CD1E20L},{0xA16FE3E2L,(-3L),(-3L),0xA16FE3E2L,(-3L)},{0x36CD1E20L,0x36CD1E20L,(-10L),0x36CD1E20L,0x36CD1E20L}};
static const uint64_t g_1101 = 4UL;
static const uint64_t *g_1104 = (void*)0;
static const uint64_t ** const g_1103 = &g_1104;
static const uint64_t ** const *g_1102 = &g_1103;
static volatile uint8_t g_1107 = 0xE3L;/* VOLATILE GLOBAL g_1107 */
static int32_t g_1109 = 0x7FBE32C7L;
static int64_t g_1134 = 1L;
static volatile union U0 g_1168 = {18446744073709551610UL};/* VOLATILE GLOBAL g_1168 */
static volatile uint16_t g_1199 = 0x637BL;/* VOLATILE GLOBAL g_1199 */
static int16_t *****g_1228 = (void*)0;
static int64_t g_1243[1] = {(-3L)};
static int32_t g_1283 = 0L;


/* --- FORWARD DECLARATIONS --- */
static int8_t  func_1(void);
static int32_t  func_13(int32_t  p_14, int32_t  p_15, int32_t  p_16, uint32_t  p_17);
static int16_t  func_49(uint32_t  p_50, uint16_t * p_51);
static uint16_t * func_52(uint32_t  p_53, int16_t * p_54, int16_t  p_55, int16_t * p_56, int32_t  p_57);
static uint16_t  func_72(uint8_t  p_73, int32_t * p_74);
static const uint64_t  func_75(int32_t * p_76, int8_t  p_77, int32_t * p_78, uint32_t  p_79);
static int32_t * func_81(int16_t * p_82);
static int16_t * func_83(uint64_t  p_84, const int16_t * const  p_85, int16_t * p_86, int32_t * p_87);
static uint8_t  func_88(int32_t * p_89);
static int32_t * func_90(int8_t  p_91);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_828 g_559 g_146 g_102 g_826 g_827 g_38 g_703 g_704 g_888 g_1109 g_1053 g_457 g_458 g_192 g_1283 g_69
 * writes: g_2 g_197 g_146 g_102 g_38
 */
static int8_t  func_1(void)
{ /* block id: 0 */
    int32_t l_24 = (-6L);
    int16_t *l_37 = &g_38;
    const uint64_t l_1132 = 0xBCEC884EE4978249LL;
    int32_t l_1153 = 0x7EBD3DABL;
    int32_t l_1156[6][5] = {{(-1L),9L,0x3D811927L,0xE1E3B237L,0xE1E3B237L},{(-7L),9L,(-7L),0x9A0376A6L,9L},{0xE1E3B237L,1L,0x9A0376A6L,0xE1E3B237L,0x9A0376A6L},{0xE1E3B237L,0xE1E3B237L,0x3D811927L,9L,(-1L)},{(-7L),(-1L),0x9A0376A6L,0x9A0376A6L,(-1L)},{(-1L),1L,(-7L),(-1L),0x9A0376A6L}};
    uint16_t l_1186[2];
    uint16_t l_1236 = 0x4E5EL;
    int16_t l_1253[9] = {6L,6L,(-6L),6L,6L,(-6L),6L,6L,(-6L)};
    int16_t ***l_1257 = (void*)0;
    int16_t ***l_1258 = (void*)0;
    int16_t ***l_1259 = (void*)0;
    int16_t ***l_1260 = &g_197[2][1][3];
    int32_t l_1284 = 0x5CE72B1DL;
    int i, j;
    for (i = 0; i < 2; i++)
        l_1186[i] = 65535UL;
lbl_1292:
    for (g_2 = (-1); (g_2 > (-10)); --g_2)
    { /* block id: 3 */
        uint16_t *l_7 = &g_8;
        int32_t l_18 = 0L;
        int16_t *l_25 = &g_19;
        uint32_t l_39 = 4UL;
        uint8_t l_40 = 0x8CL;
        int32_t *l_1108 = &g_1109;
        uint32_t l_1110 = 0x2AED42ECL;
        uint64_t **l_1131 = &g_458[3];
        int32_t l_1135[6];
        int8_t l_1154 = 7L;
        int32_t l_1167 = (-10L);
        int i;
        for (i = 0; i < 6; i++)
            l_1135[i] = 0x6869C21CL;
    }
lbl_1291:
    if (((**g_828) &= (l_1236 > (((*l_1260) = (void*)0) == (void*)0))))
    { /* block id: 523 */
        uint64_t l_1265 = 1UL;
        int32_t l_1272 = 0L;
        for (g_102 = 0; (g_102 > 50); ++g_102)
        { /* block id: 526 */
            (***g_827) = (****g_826);
            if (g_2)
                goto lbl_1291;
        }
        (****g_826) &= (((((safe_rshift_func_uint64_t_u_s((l_1265 > l_1186[1]), 42)) && (safe_mod_func_uint8_t_u_u((((l_1132 , (safe_lshift_func_int64_t_s_s((0L < (safe_div_func_int16_t_s_s((l_1272 = ((*l_37) ^= 0x922CL)), ((*g_703) || (((((+(safe_mod_func_uint32_t_u_u(((safe_unary_minus_func_uint8_t_u(g_704)) != (safe_div_func_uint16_t_u_u(((((safe_mod_func_int8_t_s_s((safe_mod_func_int8_t_s_s((l_1265 , g_888[7]), g_1109)), 0x0FL)) == g_1053) >= (**g_457)) , l_1253[1]), l_1153))), 0x2BAAF341L))) , g_2) ^ l_1265) , 65535UL) , (*g_703)))))), g_1283))) > (-1L)) <= l_1265), 0x4DL))) || l_1284) , l_1153) ^ g_69);
        return l_24;
    }
    else
    { /* block id: 533 */
        int32_t *l_1285 = &g_146;
        int32_t *l_1286 = &g_2;
        int32_t *l_1287[3];
        uint32_t l_1288 = 0UL;
        int i;
        for (i = 0; i < 3; i++)
            l_1287[i] = &g_419;
        l_1288++;
    }
    if (g_1283)
        goto lbl_1292;
    return (*g_703);
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_102 g_19 g_2 g_97 g_145 g_146 g_153 g_69 g_153.f0 g_192 g_196 g_203 g_203.f0 g_279 g_289 g_183 g_215 g_304 g_309 g_290 g_305 g_180 g_285 g_383 g_419 g_142 g_456 g_307 g_1056 g_652 g_924 g_637 g_827 g_828 g_559 g_288 g_888 g_1107 g_825 g_826
 * writes: g_38 g_97 g_102 g_146 g_19 g_180 g_183 g_142 g_192 g_197 g_215 g_144 g_285 g_288 g_290 g_304 g_234 g_416 g_69 g_457 g_307 g_1056 g_1031 g_1053 g_1102
 */
static int32_t  func_13(int32_t  p_14, int32_t  p_15, int32_t  p_16, uint32_t  p_17)
{ /* block id: 7 */
    const int16_t *l_45 = &g_38;
    int32_t l_48 = 0xB5A47B6CL;
    int16_t *l_60 = (void*)0;
    uint16_t *l_1064 = &g_183;
    uint16_t **l_1063 = &l_1064;
    uint64_t *l_1106 = &g_192;
    (*****g_825) = ((safe_add_func_uint64_t_u_u((l_48 = (((*l_1106) = (safe_div_func_int8_t_s_s(((l_45 != l_45) ^ ((((safe_mul_func_uint16_t_u_u(l_48, (func_49(l_48, ((*l_1063) = func_52((safe_lshift_func_uint32_t_u_u(0x4EE00B46L, 9)), l_60, ((safe_add_func_int16_t_s_s(p_17, (safe_mod_func_uint16_t_u_u(65531UL, 1UL)))) > l_48), &g_38, p_16))) , 0x4855L))) || 7UL) , p_15) & (-9L))), g_888[8]))) != p_15)), 1L)) , g_1107);
    return l_48;
}


/* ------------------------------------------ */
/* 
 * reads : g_419 g_1056 g_827 g_828 g_559 g_146 g_288
 * writes: g_1031 g_1053 g_1102
 */
static int16_t  func_49(uint32_t  p_50, uint16_t * p_51)
{ /* block id: 454 */
    int32_t *l_1065 = (void*)0;
    int32_t *l_1066 = &g_288;
    int32_t *l_1067 = &g_146;
    int32_t *l_1068 = &g_1056[2][0];
    int32_t l_1069 = 0x2C78BD0AL;
    int32_t l_1070[5][7] = {{1L,1L,1L,1L,1L,1L,1L},{1L,0xD3687036L,0xD3687036L,1L,0xD3687036L,0xD3687036L,1L},{1L,0xD3687036L,1L,1L,0xD3687036L,1L,1L},{0xD3687036L,0xD3687036L,1L,0xD3687036L,0xD3687036L,1L,0xD3687036L},{0xD3687036L,1L,1L,0xD3687036L,1L,1L,0xD3687036L}};
    int32_t *l_1071 = &g_1056[2][0];
    int32_t *l_1072 = &g_419;
    int32_t *l_1073 = &l_1070[4][3];
    int32_t *l_1074 = (void*)0;
    int32_t *l_1075 = &l_1069;
    int32_t *l_1076 = &g_419;
    int32_t *l_1077 = (void*)0;
    int32_t *l_1078[5] = {&g_1056[0][4],&g_1056[0][4],&g_1056[0][4],&g_1056[0][4],&g_1056[0][4]};
    uint32_t l_1079 = 0xD1D1E61EL;
    uint64_t ***l_1084 = &g_457;
    uint64_t ****l_1085 = &g_1031;
    uint8_t *l_1096 = &g_1053;
    const uint64_t *l_1100[5];
    const uint64_t ** const l_1099[6] = {&l_1100[4],&l_1100[4],&l_1100[4],&l_1100[4],&l_1100[4],&l_1100[4]};
    const uint64_t ** const *l_1098 = &l_1099[2];
    const uint64_t ** const **l_1097[5];
    int8_t l_1105[5];
    int i, j;
    for (i = 0; i < 5; i++)
        l_1100[i] = &g_1101;
    for (i = 0; i < 5; i++)
        l_1097[i] = &l_1098;
    for (i = 0; i < 5; i++)
        l_1105[i] = 0x84L;
    ++l_1079;
    l_1105[0] &= ((p_50 == ((void*)0 == &g_704)) , (safe_sub_func_uint64_t_u_u(((((((*l_1085) = l_1084) != (g_1102 = ((safe_mod_func_int8_t_s_s((*l_1075), (safe_lshift_func_int64_t_s_u((safe_lshift_func_int16_t_s_u((*l_1076), (safe_lshift_func_uint32_t_u_u((*l_1068), (safe_mul_func_int8_t_s_s((((*l_1096) = (((***g_827) || ((*l_1066) ^ (*l_1067))) , p_50)) > (*l_1066)), (*l_1075))))))), (*l_1073))))) , (void*)0))) ^ 0xA074L) >= (*l_1075)) <= p_50), (*l_1068))));
    return (*l_1071);
}


/* ------------------------------------------ */
/* 
 * reads : g_38 g_102 g_19 g_2 g_97 g_145 g_146 g_153 g_69 g_153.f0 g_192 g_196 g_203 g_203.f0 g_279 g_289 g_183 g_215 g_304 g_309 g_290 g_305 g_180 g_285 g_383 g_419 g_142 g_456 g_307 g_1056 g_652 g_924 g_637
 * writes: g_38 g_97 g_102 g_146 g_19 g_180 g_183 g_142 g_192 g_197 g_215 g_144 g_285 g_288 g_290 g_304 g_234 g_416 g_69 g_457 g_307 g_1056
 */
static uint16_t * func_52(uint32_t  p_53, int16_t * p_54, int16_t  p_55, int16_t * p_56, int32_t  p_57)
{ /* block id: 8 */
    int32_t *l_65 = (void*)0;
    int8_t l_66[3];
    uint16_t l_105 = 0x59FCL;
    int16_t *l_286 = (void*)0;
    int32_t l_1054 = 0x86227EF5L;
    int32_t l_1062 = 0x7F2ACA79L;
    int i;
    for (i = 0; i < 3; i++)
        l_66[i] = 0xE9L;
    l_65 = (void*)0;
    for (g_38 = 2; (g_38 >= 0); g_38 -= 1)
    { /* block id: 12 */
        const uint16_t *l_68[4] = {&g_69,&g_69,&g_69,&g_69};
        int32_t l_100 = 1L;
        int i;
        for (p_55 = 0; (p_55 <= 2); p_55 += 1)
        { /* block id: 15 */
            const uint32_t l_80 = 0x54759719L;
            int64_t *l_95 = (void*)0;
            int64_t *l_96 = &g_97;
            uint8_t *l_101 = &g_102;
            int32_t **l_147 = (void*)0;
            int32_t **l_148 = &l_65;
            int32_t *l_348 = &g_2;
            uint16_t *l_1051 = &g_183;
            uint8_t *l_1052[5][8] = {{&g_1053,&g_1053,&g_1053,&g_1053,&g_1053,(void*)0,&g_1053,(void*)0},{&g_1053,&g_1053,(void*)0,(void*)0,&g_1053,(void*)0,(void*)0,(void*)0},{(void*)0,&g_1053,&g_1053,&g_1053,(void*)0,(void*)0,&g_1053,&g_1053},{(void*)0,&g_1053,(void*)0,&g_1053,(void*)0,&g_1053,&g_1053,&g_1053},{(void*)0,&g_1053,(void*)0,(void*)0,&g_1053,(void*)0,&g_1053,(void*)0}};
            int32_t *l_1055 = &g_1056[2][0];
            int i, j;
            (*l_1055) |= (((~l_66[p_55]) , ((0L && (((l_1054 |= ((l_68[0] == ((safe_mul_func_uint16_t_u_u(((*l_1051) = func_72(((((func_75(((l_80 || 0UL) , func_81(func_83((0x0EL ^ func_88(((*l_148) = func_90(((safe_rshift_func_int64_t_s_s((~((*l_96) = (-1L))), (safe_sub_func_uint8_t_u_u(((l_105 &= (l_100 , (--(*l_101)))) < (safe_rshift_func_int16_t_s_u((+((safe_add_func_int64_t_s_s((safe_add_func_int64_t_s_s((safe_div_func_uint16_t_u_u((+l_100), 0x2B3AL)), 0x1D25F4349FEC891FLL)), p_57)) | g_38)), l_100))), 0L)))) != 0x36L))))), &g_38, l_286, &g_2))), g_69, &l_100, g_38) || 0xB8C2CD7695A7DD32LL) != p_57) <= l_100) < p_53), l_348)), g_38)) , (void*)0)) , l_100)) && 0x03L) | 65534UL)) || l_100)) , l_100);
            if ((*g_145))
                continue;
        }
        l_1062 = (((void*)0 != (*g_289)) > (0x81L ^ (p_53 | ((safe_lshift_func_uint32_t_u_u(((safe_add_func_uint16_t_u_u(0xAD9FL, 0UL)) != (safe_unary_minus_func_uint64_t_u((((((g_652 >= 0x0726L) || l_100) > p_57) || p_57) >= p_53)))), 15)) | l_100))));
        if ((**g_924))
            continue;
    }
    return p_56;
}


/* ------------------------------------------ */
/* 
 * reads : g_180 g_19 g_2 g_102 g_192 g_285 g_383 g_38 g_215 g_146 g_183 g_419 g_142 g_153.f0 g_309 g_304 g_456 g_290 g_307 g_97
 * writes: g_180 g_97 g_285 g_288 g_146 g_215 g_416 g_69 g_457 g_234 g_192 g_307
 */
static uint16_t  func_72(uint8_t  p_73, int32_t * p_74)
{ /* block id: 102 */
    uint64_t l_370[1][4] = {{0x16B48063A026B292LL,0x16B48063A026B292LL,0x16B48063A026B292LL,0x16B48063A026B292LL}};
    int8_t l_374[4][9] = {{0L,0xB8L,0L,0xB8L,0L,0xB8L,0L,0xB8L,0L},{1L,1L,0x49L,0x49L,1L,1L,0x49L,0x49L,1L},{8L,0xB8L,8L,0xB8L,8L,0xB8L,8L,0xB8L,8L},{1L,0x49L,0x49L,1L,1L,0x49L,0x49L,1L,1L}};
    int32_t l_405[2][2] = {{(-7L),(-7L)},{(-7L),(-7L)}};
    int16_t ***l_431[3][7][1] = {{{&g_197[2][2][6]},{&g_197[2][2][6]},{&g_197[2][2][6]},{&g_197[2][2][6]},{&g_197[2][3][2]},{(void*)0},{&g_197[2][2][6]}},{{(void*)0},{&g_197[2][3][2]},{&g_197[2][2][6]},{&g_197[2][2][6]},{&g_197[2][2][6]},{&g_197[2][2][6]},{&g_197[2][3][2]}},{{(void*)0},{&g_197[2][2][6]},{(void*)0},{&g_197[2][3][2]},{&g_197[2][2][6]},{&g_197[2][2][6]},{&g_197[2][2][6]}}};
    int16_t ****l_430 = &l_431[1][5][0];
    int8_t l_480 = 5L;
    int32_t l_537 = 0L;
    int8_t l_540 = 0xDFL;
    uint64_t l_542 = 18446744073709551610UL;
    int8_t l_578 = 0L;
    uint8_t *l_613 = &g_102;
    uint8_t l_713 = 0xD4L;
    int32_t l_720 = 0x98484162L;
    int64_t *l_745 = &g_215;
    int8_t l_779 = 0x95L;
    int64_t l_781 = 0x29C9FA64256A23C4LL;
    const uint64_t *l_787[10][9][2] = {{{&l_542,&l_370[0][2]},{(void*)0,&l_370[0][1]},{&l_370[0][0],&l_370[0][1]},{&l_370[0][0],&g_192},{&l_370[0][1],&l_542},{(void*)0,&l_542},{&g_192,&l_370[0][1]},{&l_370[0][3],&l_370[0][1]},{&g_192,&l_370[0][1]}},{{&l_370[0][1],&l_370[0][2]},{(void*)0,&l_370[0][1]},{(void*)0,(void*)0},{&g_192,(void*)0},{&l_370[0][1],&l_370[0][1]},{&l_542,&l_370[0][1]},{&l_370[0][1],&g_192},{&l_370[0][3],(void*)0},{&l_370[0][0],&l_370[0][3]}},{{&l_370[0][2],&l_370[0][0]},{&l_370[0][2],&l_370[0][3]},{&l_370[0][0],(void*)0},{&l_370[0][3],&g_192},{&l_370[0][1],&l_370[0][1]},{&l_542,&l_370[0][1]},{&l_370[0][1],(void*)0},{&l_370[0][1],&l_542},{&l_370[0][1],&l_370[0][1]}},{{&l_370[0][3],&l_370[0][0]},{(void*)0,(void*)0},{&l_370[0][2],&g_192},{&l_370[0][3],&l_370[0][1]},{&l_370[0][1],(void*)0},{(void*)0,&l_370[0][1]},{&l_370[0][1],&l_370[0][1]},{&l_370[0][1],&l_370[0][2]},{(void*)0,(void*)0}},{{&l_370[0][0],&l_542},{&l_370[0][1],(void*)0},{&g_192,&g_192},{(void*)0,&l_370[0][0]},{&l_370[0][0],&l_370[0][1]},{&l_370[0][0],&l_370[0][1]},{&g_192,&l_370[0][1]},{&l_370[0][0],&l_370[0][1]},{&l_370[0][0],&l_370[0][0]}},{{(void*)0,&g_192},{&g_192,(void*)0},{&l_370[0][1],&l_542},{&l_370[0][0],(void*)0},{(void*)0,&l_370[0][2]},{&l_370[0][1],&l_370[0][1]},{&l_370[0][1],&l_370[0][1]},{(void*)0,(void*)0},{&l_370[0][1],&l_370[0][1]}},{{&l_370[0][3],&g_192},{&l_370[0][2],(void*)0},{(void*)0,&l_370[0][0]},{&l_370[0][3],&l_370[0][1]},{&l_370[0][1],&l_542},{&l_370[0][1],(void*)0},{&l_370[0][1],&l_370[0][1]},{&l_542,&l_370[0][1]},{(void*)0,&l_542}},{{&l_542,&l_370[0][1]},{&g_192,&l_542},{&l_542,&l_370[0][1]},{&l_542,&l_542},{&g_192,&l_370[0][1]},{&l_542,&l_542},{(void*)0,&l_370[0][1]},{&l_542,&l_370[0][1]},{&l_370[0][1],(void*)0}},{{&l_370[0][1],&l_542},{&l_370[0][1],&l_370[0][1]},{&l_370[0][3],&l_370[0][0]},{(void*)0,(void*)0},{&l_370[0][2],&g_192},{&l_370[0][3],&l_370[0][1]},{&l_370[0][1],(void*)0},{(void*)0,&l_370[0][1]},{&l_370[0][1],&l_370[0][1]}},{{&l_370[0][1],&l_370[0][2]},{(void*)0,(void*)0},{&l_370[0][0],&l_542},{&l_370[0][1],(void*)0},{&g_192,&g_192},{(void*)0,&l_370[0][0]},{&l_370[0][0],&l_370[0][1]},{&l_370[0][0],&l_370[0][1]},{&g_192,&l_370[0][1]}}};
    const uint64_t **l_786 = &l_787[8][8][0];
    uint32_t l_858 = 18446744073709551613UL;
    int32_t *** const l_866 = &g_828;
    uint64_t l_919 = 0xF8584792E24AD189LL;
    int32_t l_920 = 1L;
    const int32_t * const l_923 = (void*)0;
    uint32_t l_963 = 3UL;
    uint8_t l_990 = 0x92L;
    int i, j, k;
    for (g_180 = 0; (g_180 != 18); g_180 = safe_add_func_int64_t_s_s(g_180, 6))
    { /* block id: 105 */
        uint32_t l_369[3];
        uint64_t *l_385 = (void*)0;
        int32_t l_414 = 0x1D93221EL;
        int32_t *l_469 = &g_2;
        int32_t **l_468 = &l_469;
        int32_t ***l_467 = &l_468;
        int16_t *l_473 = &g_142;
        int16_t *l_476 = &g_19;
        int64_t *l_525 = &g_215;
        int8_t *l_526 = &l_374[0][5];
        int32_t l_533 = (-8L);
        int32_t l_534 = (-1L);
        int32_t l_535 = 0xE440D9E5L;
        int32_t l_536[1];
        int32_t l_538 = 1L;
        int64_t l_541 = 0xA5CD8A67D6D30267LL;
        uint64_t ***l_564 = &g_457;
        int16_t l_579 = 0x94A6L;
        int16_t ***l_601 = &g_197[2][0][6];
        int64_t l_689 = 1L;
        int32_t l_691 = (-1L);
        uint32_t l_778 = 0x79E005C4L;
        int64_t l_892 = 0L;
        uint32_t l_893 = 0x0C0E6ABFL;
        int32_t l_921 = 0x2FD1893BL;
        uint32_t l_955 = 0xC8D2C28CL;
        int i;
        for (i = 0; i < 3; i++)
            l_369[i] = 4294967295UL;
        for (i = 0; i < 1; i++)
            l_536[i] = 0x4DE0FEB4L;
        for (g_97 = 8; (g_97 >= 0); g_97 -= 1)
        { /* block id: 108 */
            int8_t l_371 = (-1L);
            const uint16_t * const l_384 = &g_183;
            uint64_t l_417 = 18446744073709551615UL;
            int32_t l_418 = (-1L);
            int16_t *l_447 = (void*)0;
            int16_t *l_448 = &g_19;
            int8_t l_471 = 0x4DL;
            int16_t *l_474[6] = {&g_19,&g_19,&g_19,&g_19,&g_19,&g_19};
            uint32_t l_481 = 9UL;
            int32_t l_493 = 0x0B0963F1L;
            int i;
            for (g_285 = 0; (g_285 <= 8); g_285 += 1)
            { /* block id: 111 */
                uint64_t l_356 = 0x905371D5E848DC6ELL;
                int32_t l_411 = 0xBFAA2CB4L;
                int32_t l_412[4];
                int32_t l_420[3];
                int16_t ****l_432 = &l_431[1][6][0];
                int i;
                for (i = 0; i < 4; i++)
                    l_412[i] = 6L;
                for (i = 0; i < 3; i++)
                    l_420[i] = (-5L);
                for (g_288 = 0; (g_288 <= 8); g_288 += 1)
                { /* block id: 114 */
                    int32_t l_355 = 0x4925EA10L;
                    int16_t *l_372[4][4] = {{&g_19,&g_19,&g_19,(void*)0},{&g_19,&g_19,&g_19,&g_38},{&g_19,(void*)0,&g_38,&g_38},{&g_19,&g_19,&g_38,(void*)0}};
                    int32_t l_373 = 0x95F33A8DL;
                    int32_t *l_376 = &g_146;
                    uint8_t l_435 = 0UL;
                    int i, j;
                    (*l_376) = ((l_373 |= (safe_add_func_uint32_t_u_u((l_355 < (l_356 < 0x52L)), ((+((safe_mod_func_int64_t_s_s(p_73, (p_73 || 0L))) | (safe_sub_func_int16_t_s_s((safe_add_func_int8_t_s_s((+((safe_mod_func_int8_t_s_s(((((safe_mod_func_int8_t_s_s((1L & (l_355 | l_369[2])), l_369[2])) == l_370[0][1]) , 0x2C697FA2FD7D8613LL) && g_180), 0x8DL)) != l_371)), (-4L))), 0xB3F6L)))) != 1L)))) || l_374[0][5]);
                    if ((safe_mul_func_uint64_t_u_u((safe_mod_func_uint16_t_u_u(((g_19 != ((((safe_mul_func_uint8_t_u_u(8UL, (((*p_74) & p_73) && (((g_102 && (((g_192 , g_285) , g_383) , ((void*)0 != l_384))) != g_38) > (*p_74))))) , (void*)0) != (void*)0) < g_2)) & p_73), l_369[2])), 0x680AF3E0FC458331LL)))
                    { /* block id: 117 */
                        int64_t *l_386 = (void*)0;
                        int64_t *l_387 = &g_215;
                        int32_t *l_410[3];
                        uint8_t *l_413[10] = {&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102};
                        int64_t *l_415 = &g_416;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_410[i] = &l_373;
                        (*l_376) = (*p_74);
                        l_420[2] = (((*l_387) ^= ((&g_192 != l_385) <= 0x958541D5164D0CA8LL)) == (safe_rshift_func_int32_t_s_u((((1L >= (safe_rshift_func_int8_t_s_s((safe_div_func_int8_t_s_s(((safe_div_func_uint16_t_u_u((safe_mul_func_int16_t_s_s(((l_418 = (((((((safe_add_func_int32_t_s_s((*l_376), (!((*l_376) | (((safe_rshift_func_int16_t_s_u(p_73, 6)) && ((*l_415) = ((safe_sub_func_int32_t_s_s((l_405[1][0] = (*p_74)), (!(l_414 = ((safe_lshift_func_int32_t_s_s((~(l_412[3] &= (((l_411 = (*p_74)) < p_73) || 0x9D081BB5C9429CADLL))), 24)) & g_183))))) , g_146))) <= 2UL))))) | l_356) == l_417) <= l_418) , l_370[0][2]) | 0x5626L) && p_73)) <= 1L), g_419)), l_371)) > l_369[2]), g_142)), 2))) == p_73) >= g_153[0][0].f0), 12)));
                        (*l_376) ^= (l_411 = (*p_74));
                    }
                    else
                    { /* block id: 129 */
                        uint64_t **l_427 = (void*)0;
                        uint64_t **l_428 = &l_385;
                        uint16_t *l_429 = &g_69;
                        (*l_376) = (l_417 != (safe_mul_func_uint16_t_u_u(g_2, (p_73 && (safe_lshift_func_int32_t_s_s(((safe_mod_func_uint8_t_u_u((((((0x14F1L | ((*l_429) = (g_285 & (((*l_428) = &g_192) == (void*)0)))) , l_430) != l_432) != g_19) <= 1UL), 0x28L)) != p_73), l_371))))));
                        (*l_376) |= (safe_mod_func_int32_t_s_s(0x62CF15C3L, l_435));
                    }
                }
                for (g_215 = 2; (g_215 <= 8); g_215 += 1)
                { /* block id: 138 */
                    int16_t *l_446 = &g_142;
                    int32_t l_449 = 0xD27EA404L;
                    l_405[1][0] &= (safe_lshift_func_int16_t_s_s((l_420[1] &= p_73), ((((safe_sub_func_int8_t_s_s((safe_add_func_int64_t_s_s(l_374[0][5], ((((safe_mod_func_uint64_t_u_u(0UL, p_73)) == (safe_lshift_func_int32_t_s_s((&p_73 == &g_102), (0x6A01L | p_73)))) && ((l_447 = l_446) != l_448)) ^ g_215))), 0L)) ^ p_73) , 65535UL) , l_449)));
                    for (l_417 = 0; (l_417 <= 8); l_417 += 1)
                    { /* block id: 144 */
                        int32_t *l_454 = &l_420[2];
                        uint64_t **l_455 = &l_385;
                        int i;
                        (*l_454) ^= (safe_div_func_uint64_t_u_u((l_405[1][0] ^ ((void*)0 == (*g_309))), 1UL));
                        (*g_456) = l_455;
                        if (l_371)
                            break;
                    }
                }
                for (l_418 = 8; (l_418 >= 3); l_418 -= 1)
                { /* block id: 152 */
                    (*g_290) = p_74;
                }
                (*g_290) = &l_418;
            }
            for (g_192 = 3; (g_192 <= 8); g_192 += 1)
            { /* block id: 159 */
                uint64_t *l_470[3];
                const int16_t * const l_472 = &g_142;
                int16_t *l_475 = &g_19;
                uint64_t l_477 = 0x0507924D338BC81BLL;
                int32_t l_488 = 0xA223F371L;
                int i;
                for (i = 0; i < 3; i++)
                    l_470[i] = &l_417;
                g_307[g_97] = g_307[g_192];
            }
        }
    }
    return p_73;
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_192 g_38 g_2 g_304 g_305 g_97 g_145 g_146 g_290 g_153.f0
 * writes: g_192 g_146 g_234
 */
static const uint64_t  func_75(int32_t * p_76, int8_t  p_77, int32_t * p_78, uint32_t  p_79)
{ /* block id: 95 */
    uint32_t l_314 = 1UL;
    uint8_t *l_337[1][7][7] = {{{&g_102,&g_102,&g_102,&g_102,(void*)0,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,(void*)0,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,(void*)0,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102},{&g_102,&g_102,&g_102,&g_102,&g_102,&g_102,&g_102}}};
    int32_t l_340 = 0x44B1DD05L;
    uint64_t *l_341 = &g_192;
    uint32_t *l_346[6] = {&g_285,&g_285,&g_285,&g_285,&g_285,&g_285};
    uint16_t l_347 = 0x2986L;
    int i, j, k;
    l_314++;
    (*g_290) = func_90((safe_add_func_uint64_t_u_u((safe_mul_func_int32_t_s_s(0x81482DDDL, (((safe_div_func_int32_t_s_s(((safe_add_func_int16_t_s_s((safe_lshift_func_int64_t_s_s(0x07341646E61053FCLL, (safe_rshift_func_uint16_t_u_s(p_79, ((safe_lshift_func_uint16_t_u_s(((safe_mod_func_int16_t_s_s((((safe_mod_func_int32_t_s_s(((g_19 | (safe_add_func_uint8_t_u_u(((*p_78) < (l_340 = (((void*)0 == l_337[0][0][4]) == (safe_add_func_int16_t_s_s(((++(*l_341)) > (safe_div_func_uint32_t_u_u(g_38, 4294967290UL))), 0xC176L))))), g_2))) == l_314), l_314)) | p_79) >= l_314), (-5L))) != l_314), 5)) >= l_314))))), l_314)) | l_347), l_347)) , (*g_304)) != &g_290))), 0xEBFF0220364D17ABLL)));
    (*g_290) = &l_340;
    return g_153[0][0].f0;
}


/* ------------------------------------------ */
/* 
 * reads : g_290 g_19 g_2 g_97 g_145 g_146
 * writes: g_234 g_146
 */
static int32_t * func_81(int16_t * p_82)
{ /* block id: 89 */
    int32_t l_310 = 0L;
    int32_t *l_313 = &g_2;
    int32_t **l_312 = &l_313;
    l_310 = l_310;
    (*g_290) = ((*l_312) = &l_310);
    (*l_312) = func_90((**l_312));
    return &g_2;
}


/* ------------------------------------------ */
/* 
 * reads : g_145 g_289 g_2 g_183 g_153.f0 g_146 g_38 g_215 g_304 g_309 g_142
 * writes: g_288 g_146 g_290 g_183 g_304
 */
static int16_t * func_83(uint64_t  p_84, const int16_t * const  p_85, int16_t * p_86, int32_t * p_87)
{ /* block id: 80 */
    int32_t *l_287[3][2];
    int16_t ****l_293 = (void*)0;
    uint16_t *l_300 = &g_183;
    uint64_t *l_301[6][1] = {{&g_192},{&g_192},{&g_192},{&g_192},{&g_192},{&g_192}};
    int32_t l_302[9][5][5] = {{{0x7677E7D2L,5L,0x7677E7D2L,1L,1L},{0x268EDA36L,1L,1L,0x268EDA36L,1L},{1L,5L,0xA13B45BEL,5L,1L},{1L,0x268EDA36L,1L,1L,0x268EDA36L},{1L,1L,0x7677E7D2L,5L,0x7677E7D2L}},{{0x268EDA36L,0x268EDA36L,(-3L),0x268EDA36L,0x268EDA36L},{0x7677E7D2L,5L,0x7677E7D2L,1L,1L},{0x268EDA36L,1L,1L,0x268EDA36L,1L},{1L,5L,0xA13B45BEL,5L,1L},{1L,0x268EDA36L,1L,1L,0x268EDA36L}},{{1L,1L,0x7677E7D2L,5L,0x7677E7D2L},{0x268EDA36L,0x268EDA36L,(-3L),0x268EDA36L,0x268EDA36L},{0x7677E7D2L,5L,0x7677E7D2L,1L,1L},{0x268EDA36L,1L,1L,0x268EDA36L,1L},{1L,5L,0xA13B45BEL,5L,1L}},{{1L,0x268EDA36L,1L,1L,0x268EDA36L},{1L,1L,0x7677E7D2L,5L,0x7677E7D2L},{0x268EDA36L,0x268EDA36L,(-3L),0x268EDA36L,0x268EDA36L},{0x7677E7D2L,5L,0x7677E7D2L,1L,1L},{0x268EDA36L,1L,1L,0x268EDA36L,1L}},{{1L,5L,0xA13B45BEL,5L,1L},{1L,0x268EDA36L,1L,1L,0x268EDA36L},{1L,1L,0x7677E7D2L,5L,0x7677E7D2L},{0x268EDA36L,0x268EDA36L,(-3L),0x268EDA36L,0x268EDA36L},{0x7677E7D2L,5L,0x7677E7D2L,1L,1L}},{{0x268EDA36L,1L,1L,0x268EDA36L,1L},{1L,5L,0xA13B45BEL,5L,1L},{1L,0x268EDA36L,1L,1L,0x268EDA36L},{1L,1L,0x7677E7D2L,5L,0x7677E7D2L},{0x268EDA36L,0x268EDA36L,(-3L),0x268EDA36L,0x268EDA36L}},{{0x7677E7D2L,5L,0x7677E7D2L,1L,1L},{0x268EDA36L,1L,1L,1L,(-3L)},{0x7677E7D2L,1L,1L,1L,0x7677E7D2L},{(-3L),1L,(-3L),(-3L),1L},{0x7677E7D2L,0xCC489696L,0xA13B45BEL,1L,0xA13B45BEL}},{{1L,1L,0x268EDA36L,1L,1L},{0xA13B45BEL,1L,0xA13B45BEL,0xCC489696L,0x7677E7D2L},{1L,(-3L),(-3L),1L,(-3L)},{0x7677E7D2L,1L,1L,1L,0x7677E7D2L},{(-3L),1L,(-3L),(-3L),1L}},{{0x7677E7D2L,0xCC489696L,0xA13B45BEL,1L,0xA13B45BEL},{1L,1L,0x268EDA36L,1L,1L},{0xA13B45BEL,1L,0xA13B45BEL,0xCC489696L,0x7677E7D2L},{1L,(-3L),(-3L),1L,(-3L)},{0x7677E7D2L,1L,1L,1L,0x7677E7D2L}}};
    int8_t l_303 = 4L;
    int i, j, k;
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 2; j++)
            l_287[i][j] = &g_146;
    }
    (*g_145) = (p_84 == (g_288 = 0x5D0A9E49L));
    (*g_289) = &g_234;
    l_303 = (((((*p_87) , (safe_mod_func_int16_t_s_s((((((void*)0 == l_293) , 0UL) && ((((g_146 &= ((((safe_add_func_uint32_t_u_u(((safe_mod_func_int8_t_s_s(((g_183 && (safe_add_func_uint16_t_u_u(((*l_300) = (0xB20AL < 1L)), ((p_84 | 0x691BFD6407CE13FBLL) >= g_153[0][0].f0)))) , 0x7FL), g_2)) , 1UL), (-4L))) , (void*)0) == l_301[1][0]) , l_302[5][4][3])) | p_84) && (*p_87)) | 0x94L)) ^ 1UL), (*p_85)))) || 8L) , 0x01380ACBL) | g_215);
    (*g_309) = g_304;
    return p_86;
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_153 g_69 g_2 g_153.f0 g_38 g_146 g_192 g_196 g_203 g_203.f0 g_215 g_279 g_102
 * writes: g_19 g_180 g_183 g_102 g_142 g_192 g_197 g_146 g_97 g_215 g_144 g_285
 */
static uint8_t  func_88(int32_t * p_89)
{ /* block id: 26 */
    const uint64_t l_174 = 0x956BE94C56F68EFBLL;
    int32_t l_185 = 0x737D7061L;
    int16_t *l_194 = &g_38;
    int16_t **l_193[3][6] = {{&l_194,&l_194,&l_194,&l_194,&l_194,&l_194},{&l_194,&l_194,&l_194,&l_194,&l_194,&l_194},{&l_194,&l_194,&l_194,&l_194,&l_194,&l_194}};
    int32_t ***l_199 = (void*)0;
    int32_t *l_202 = &g_146;
    int32_t **l_201 = &l_202;
    int32_t ***l_200 = &l_201;
    int64_t *l_213 = &g_97;
    int64_t *l_214[5][1];
    int16_t *l_226 = &g_142;
    int64_t l_227 = 0x84385FFE76D6E16ALL;
    int32_t ** const l_262[2][9][9] = {{{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{&l_202,(void*)0,&l_202,&l_202,&l_202,&l_202,&l_202,(void*)0,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,(void*)0,&l_202,&l_202},{&l_202,(void*)0,(void*)0,&l_202,&l_202,(void*)0,&l_202,&l_202,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{(void*)0,&l_202,&l_202,(void*)0,&l_202,&l_202,&l_202,(void*)0,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,(void*)0,&l_202,&l_202}},{{&l_202,&l_202,&l_202,(void*)0,&l_202,(void*)0,&l_202,&l_202,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{(void*)0,&l_202,(void*)0,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202,&l_202},{&l_202,(void*)0,&l_202,&l_202,&l_202,&l_202,&l_202,(void*)0,&l_202}}};
    int i, j, k;
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
            l_214[i][j] = &g_215;
    }
    for (g_19 = 0; (g_19 <= 9); g_19++)
    { /* block id: 29 */
        int32_t *l_152 = &g_2;
        int32_t **l_151 = &l_152;
        const uint32_t l_168 = 0x2A2CB73AL;
        int16_t l_169 = 0xBE0BL;
        uint32_t *l_179 = &g_180;
        uint16_t *l_181 = (void*)0;
        uint16_t *l_182 = &g_183;
        int32_t *l_184[3][2] = {{&g_146,&g_146},{&g_146,&g_146},{&g_146,&g_146}};
        uint8_t *l_186 = (void*)0;
        uint8_t *l_187 = (void*)0;
        uint8_t *l_188 = (void*)0;
        uint8_t *l_189 = (void*)0;
        uint8_t *l_190[8];
        int16_t *l_191 = &g_142;
        int16_t ***l_195 = (void*)0;
        int i, j;
        for (i = 0; i < 8; i++)
            l_190[i] = &g_102;
        (*l_151) = (void*)0;
        g_192 |= (g_153[0][0] , (0xE899L ^ (safe_mul_func_int64_t_s_s((safe_add_func_uint64_t_u_u(g_69, (safe_mul_func_uint16_t_u_u((safe_mod_func_uint16_t_u_u(((~((*l_191) = (safe_lshift_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u((g_102 = (+(l_168 & ((l_169 & (l_185 &= (((((safe_sub_func_uint16_t_u_u(((*l_182) = (((((safe_rshift_func_int8_t_s_s((0xD83E4BC4L || l_174), ((safe_mul_func_int64_t_s_s((((((*l_179) = ((safe_mul_func_int16_t_s_s((&g_2 == p_89), g_2)) != 0UL)) ^ l_174) & 3UL) == 1UL), l_174)) < l_174))) != l_174) & 0xDE941380A060787BLL) <= g_69) >= 0L)), l_174)) > (-2L)) > l_174) & 0x39L) && 0xCB083140AF3A0D74LL))) , g_153[0][0].f0)))), g_2)), l_174)))) | g_38), 0x4A55L)), g_146)))), l_174))));
        (*g_196) = l_193[2][1];
    }
lbl_228:
    g_146 |= (((*l_200) = &p_89) == (g_203 , &g_145));
    if (((*l_202) = ((-1L) || (safe_sub_func_uint32_t_u_u((safe_unary_minus_func_uint64_t_u(((safe_mod_func_uint8_t_u_u((safe_add_func_int32_t_s_s((safe_sub_func_uint8_t_u_u(((*l_202) ^ (g_215 = ((*l_213) = 4L))), ((*l_202) , ((((safe_div_func_uint8_t_u_u((safe_div_func_uint16_t_u_u((((safe_lshift_func_uint32_t_u_s(g_38, 18)) || (safe_sub_func_int16_t_s_s(((*l_226) = (((((*p_89) != (safe_mul_func_int16_t_s_s((**l_201), (l_226 == (void*)0)))) < (**l_201)) ^ l_227) > (-8L))), (*l_202)))) , (*l_202)), (*l_202))), 0x79L)) ^ g_2) & g_203.f0) , (*l_202))))), 4294967295UL)), (***l_200))) || 0xD3D6L))), (*p_89))))))
    { /* block id: 45 */
        uint64_t l_242 = 0x018A576ED2DD3FA2LL;
        int16_t **l_261 = (void*)0;
        if (l_174)
            goto lbl_228;
        for (g_215 = (-25); (g_215 == (-4)); g_215++)
        { /* block id: 49 */
            uint64_t *l_231 = &g_192;
            int64_t l_235 = 0xA1BEE393E8204132LL;
            int32_t l_245 = (-6L);
            int32_t l_252 = 8L;
            int32_t *l_253 = (void*)0;
            int32_t l_254[10] = {0L,0L,0L,0L,0L,0L,0L,0L,0L,0L};
            int i;
            (*l_202) = (*p_89);
        }
        (*l_202) = (((safe_rshift_func_uint8_t_u_u((safe_lshift_func_int8_t_s_s((((l_242 , (safe_rshift_func_uint8_t_u_s((((-1L) <= (-8L)) | (l_261 == &l_226)), l_242))) , (void*)0) == (void*)0), l_242)), 3)) == g_192) <= 0x045A8B82L);
        (*l_200) = l_262[0][3][7];
    }
    else
    { /* block id: 63 */
        int32_t l_273 = 0L;
        int16_t ***l_275 = &g_197[2][2][6];
        int16_t ****l_274 = &l_275;
        int32_t l_280[1][2][4] = {{{0x10A6EAA2L,0x10A6EAA2L,(-4L),0x10A6EAA2L},{0x10A6EAA2L,4L,4L,0x10A6EAA2L}}};
        uint64_t *l_281[6] = {&g_192,&g_192,&g_192,&g_192,&g_192,&g_192};
        uint16_t l_282 = 0x9433L;
        int i, j, k;
        for (g_19 = (-24); (g_19 < 27); g_19 = safe_add_func_int64_t_s_s(g_19, 1))
        { /* block id: 66 */
            for (g_97 = (-23); (g_97 < (-2)); g_97 = safe_add_func_uint16_t_u_u(g_97, 4))
            { /* block id: 69 */
                g_144 = &g_146;
            }
        }
        g_285 = (safe_rshift_func_uint64_t_u_u((((safe_mul_func_uint8_t_u_u((safe_lshift_func_uint32_t_u_u(l_273, 26)), (&l_193[2][1] != ((*l_274) = &l_193[2][1])))) > ((safe_unary_minus_func_uint64_t_u(((safe_add_func_uint16_t_u_u(g_279, (l_280[0][1][2] ^= ((*l_202) = l_273)))) != 0x42E1L))) & ((((l_282 &= l_273) || (l_273 , (safe_mod_func_int64_t_s_s(g_102, 18446744073709551613UL)))) , 0x7AL) || 0L))) , 1UL), 38));
    }
    return g_279;
}


/* ------------------------------------------ */
/* 
 * reads : g_19 g_2 g_97 g_145 g_146
 * writes: g_146
 */
static int32_t * func_90(int8_t  p_91)
{ /* block id: 19 */
    uint8_t *l_120 = &g_102;
    uint8_t *l_121[6] = {&g_102,(void*)0,&g_102,&g_102,(void*)0,&g_102};
    uint8_t *l_130 = &g_102;
    uint8_t **l_129 = &l_130;
    uint8_t *l_132 = &g_102;
    uint8_t **l_131 = &l_132;
    int32_t l_140[9][2][1] = {{{1L},{0x292F9027L}},{{0x292F9027L},{1L}},{{0x292F9027L},{0x292F9027L}},{{1L},{0x292F9027L}},{{0x292F9027L},{1L}},{{0x292F9027L},{0x292F9027L}},{{1L},{0x292F9027L}},{{0x292F9027L},{1L}},{{0x292F9027L},{0x292F9027L}}};
    int16_t *l_141[3][9] = {{&g_142,&g_142,&g_38,&g_19,(void*)0,&g_38,&g_19,&g_38,&g_19},{&g_142,&g_142,&g_38,&g_38,&g_142,&g_142,&g_19,&g_38,&g_142},{&g_38,&g_19,&g_38,&g_142,&g_142,&g_142,&g_142,&g_38,&g_19}};
    int32_t l_143 = (-1L);
    int i, j, k;
    (*g_145) &= (0x1B24C01D5BC3FA0ELL > ((safe_mod_func_int8_t_s_s((safe_unary_minus_func_uint16_t_u((g_19 != (!(((l_120 != l_121[3]) == (safe_unary_minus_func_int16_t_s((safe_sub_func_int32_t_s_s((safe_sub_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u((((l_120 == ((*l_131) = ((*l_129) = &g_102))) == ((safe_lshift_func_uint8_t_u_u((safe_add_func_int64_t_s_s((((void*)0 == &g_97) > (l_140[3][0][0] = ((safe_mul_func_int16_t_s_s(((safe_unary_minus_func_int16_t_s((((g_2 || 0xA932E4B48400EC86LL) <= g_97) <= l_140[8][0][0]))) < l_140[8][0][0]), 0x84ACL)) ^ 6UL))), p_91)), 6)) != 0xBF61L)) == l_143), l_143)), l_143)), 0x24D9C5E1L))))) != p_91))))), 6UL)) >= 0x4D83983135CAF2BFLL));
    return &g_2;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    transparent_crc(g_8, "g_8", print_hash_value);
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_38, "g_38", print_hash_value);
    transparent_crc(g_69, "g_69", print_hash_value);
    transparent_crc(g_97, "g_97", print_hash_value);
    transparent_crc(g_102, "g_102", print_hash_value);
    transparent_crc(g_142, "g_142", print_hash_value);
    transparent_crc(g_146, "g_146", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 4; j++)
        {
            transparent_crc(g_153[i][j].f0, "g_153[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_180, "g_180", print_hash_value);
    transparent_crc(g_183, "g_183", print_hash_value);
    transparent_crc(g_192, "g_192", print_hash_value);
    transparent_crc(g_203.f0, "g_203.f0", print_hash_value);
    transparent_crc(g_215, "g_215", print_hash_value);
    transparent_crc(g_279, "g_279", print_hash_value);
    transparent_crc(g_285, "g_285", print_hash_value);
    transparent_crc(g_288, "g_288", print_hash_value);
    transparent_crc(g_383.f0, "g_383.f0", print_hash_value);
    transparent_crc(g_416, "g_416", print_hash_value);
    transparent_crc(g_419, "g_419", print_hash_value);
    transparent_crc(g_561, "g_561", print_hash_value);
    transparent_crc(g_651, "g_651", print_hash_value);
    transparent_crc(g_652, "g_652", print_hash_value);
    transparent_crc(g_704, "g_704", print_hash_value);
    transparent_crc(g_780, "g_780", print_hash_value);
    transparent_crc(g_789, "g_789", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_888[i], "g_888[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 2; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_1027[i][j][k].f0, "g_1027[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1053, "g_1053", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 5; j++)
        {
            transparent_crc(g_1056[i][j], "g_1056[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1101, "g_1101", print_hash_value);
    transparent_crc(g_1107, "g_1107", print_hash_value);
    transparent_crc(g_1109, "g_1109", print_hash_value);
    transparent_crc(g_1134, "g_1134", print_hash_value);
    transparent_crc(g_1168.f0, "g_1168.f0", print_hash_value);
    transparent_crc(g_1199, "g_1199", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_1243[i], "g_1243[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1283, "g_1283", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 292
XXX total union variables: 5

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 47
breakdown:
   depth: 1, occurrence: 77
   depth: 2, occurrence: 20
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 5, occurrence: 1
   depth: 12, occurrence: 1
   depth: 14, occurrence: 1
   depth: 16, occurrence: 1
   depth: 17, occurrence: 1
   depth: 18, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 1
   depth: 22, occurrence: 1
   depth: 26, occurrence: 1
   depth: 27, occurrence: 1
   depth: 28, occurrence: 2
   depth: 29, occurrence: 1
   depth: 30, occurrence: 1
   depth: 37, occurrence: 1
   depth: 38, occurrence: 1
   depth: 47, occurrence: 1

XXX total number of pointers: 275

XXX times a variable address is taken: 570
XXX times a pointer is dereferenced on RHS: 134
breakdown:
   depth: 1, occurrence: 104
   depth: 2, occurrence: 15
   depth: 3, occurrence: 13
   depth: 4, occurrence: 2
XXX times a pointer is dereferenced on LHS: 156
breakdown:
   depth: 1, occurrence: 118
   depth: 2, occurrence: 19
   depth: 3, occurrence: 10
   depth: 4, occurrence: 2
   depth: 5, occurrence: 7
XXX times a pointer is compared with null: 29
XXX times a pointer is compared with address of another variable: 11
XXX times a pointer is compared with another pointer: 6
XXX times a pointer is qualified to be dereferenced: 5816

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 905
   level: 2, occurrence: 178
   level: 3, occurrence: 139
   level: 4, occurrence: 24
   level: 5, occurrence: 28
XXX number of pointers point to pointers: 91
XXX number of pointers point to scalars: 183
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 35.3
XXX average alias set size: 1.4

XXX times a non-volatile is read: 920
XXX times a non-volatile is write: 523
XXX times a volatile is read: 61
XXX    times read thru a pointer: 19
XXX times a volatile is write: 23
XXX    times written thru a pointer: 10
XXX times a volatile is available for access: 4.12e+03
XXX percentage of non-volatile access: 94.5

XXX forward jumps: 1
XXX backward jumps: 2

XXX stmts: 77
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 33
   depth: 1, occurrence: 17
   depth: 2, occurrence: 8
   depth: 3, occurrence: 6
   depth: 4, occurrence: 5
   depth: 5, occurrence: 8

XXX percentage a fresh-made variable is used: 13.9
XXX percentage an existing variable is used: 86.1
XXX total OOB instances added: 0
********************* end of statistics **********************/

