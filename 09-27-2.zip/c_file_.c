/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      2927589339
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
/* --- GLOBAL VARIABLES --- */
static int32_t g_4[4][8][5] = {{{6L,0x66FA4BC4L,0xEC46BC22L,0xAEE50770L,0xAEE50770L},{0x0CA70051L,5L,0x0CA70051L,(-1L),(-1L)},{8L,1L,0x3B8C105AL,0x66FA4BC4L,0x7834D8A9L},{0xF451D52AL,(-1L),(-4L),(-7L),1L},{0xAEE50770L,0x690F1D89L,0x3B8C105AL,0x7834D8A9L,4L},{1L,0xF7E813A3L,0x0CA70051L,(-8L),0xC4E7CCCEL},{0x7834D8A9L,0x612D29EDL,0xEC46BC22L,0x3B8C105AL,(-1L)},{0xF451D52AL,(-8L),0L,(-8L),0xF451D52AL}},{{4L,0x66FA4BC4L,0L,0x7834D8A9L,1L},{0x0CA70051L,1L,0xC4E7CCCEL,(-7L),(-1L)},{(-1L),0x612D29EDL,0x0A5DEC4FL,0x66FA4BC4L,1L},{1L,(-7L),(-4L),(-1L),0xF451D52AL},{1L,0x690F1D89L,0x66FA4BC4L,0xAEE50770L,(-1L)},{1L,(-1L),0xC4E7CCCEL,6L,0xC4E7CCCEL},{1L,1L,0x3825062DL,0x3B8C105AL,4L},{1L,6L,0L,5L,1L}},{{(-1L),0x66FA4BC4L,(-6L),0xAEE50770L,0x7834D8A9L},{0x0CA70051L,6L,0x0CA70051L,(-1L),(-1L)},{4L,1L,0x690F1D89L,0x66FA4BC4L,0xAEE50770L},{0xF451D52AL,(-1L),(-4L),0xF7E813A3L,1L},{0x7834D8A9L,0x690F1D89L,0x690F1D89L,0x7834D8A9L,8L},{1L,(-7L),0x0CA70051L,1L,0xC4E7CCCEL},{0xAEE50770L,0x612D29EDL,(-6L),0x3B8C105AL,6L},{0xF451D52AL,1L,0L,1L,0xF451D52AL}},{{8L,0x66FA4BC4L,0x3825062DL,0x7834D8A9L,0x612D29EDL},{0x0CA70051L,(-8L),0xC4E7CCCEL,0xF7E813A3L,(-1L)},{6L,0x612D29EDL,0x66FA4BC4L,0x66FA4BC4L,0x612D29EDL},{1L,0xF7E813A3L,(-4L),(-1L),0xF451D52AL},{0x612D29EDL,0x690F1D89L,0x0A5DEC4FL,0xAEE50770L,6L},{1L,(-1L),0xC4E7CCCEL,5L,0xC4E7CCCEL},{0x612D29EDL,1L,0L,0x3B8C105AL,8L},{1L,5L,0L,6L,1L}}};
static int32_t * volatile g_3[10] = {&g_4[3][5][2],&g_4[3][5][2],&g_4[3][5][2],&g_4[3][5][2],&g_4[3][5][2],&g_4[3][5][2],&g_4[3][5][2],&g_4[3][5][2],&g_4[3][5][2],&g_4[3][5][2]};


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4
 * writes: g_4
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    int16_t l_2 = 4L;
    int32_t *l_5 = &g_4[3][5][2];
    (*l_5) = l_2;
    return g_4[3][1][0];
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_4[i][j][k], "g_4[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 1
XXX total union variables: 0

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 1
breakdown:
   depth: 1, occurrence: 3

XXX total number of pointers: 2

XXX times a variable address is taken: 3
XXX times a pointer is dereferenced on RHS: 0
breakdown:
XXX times a pointer is dereferenced on LHS: 1
breakdown:
   depth: 1, occurrence: 1
XXX times a pointer is compared with null: 0
XXX times a pointer is compared with address of another variable: 0
XXX times a pointer is compared with another pointer: 0
XXX times a pointer is qualified to be dereferenced: 2

XXX max dereference level: 1
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1
XXX number of pointers point to pointers: 0
XXX number of pointers point to scalars: 2
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 0
XXX average alias set size: 1

XXX times a non-volatile is read: 2
XXX times a non-volatile is write: 2
XXX times a volatile is read: 0
XXX    times read thru a pointer: 0
XXX times a volatile is write: 0
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 1
XXX percentage of non-volatile access: 100

XXX forward jumps: 0
XXX backward jumps: 0

XXX stmts: 2
XXX max block depth: 0
breakdown:
   depth: 0, occurrence: 2

XXX percentage a fresh-made variable is used: 33.3
XXX percentage an existing variable is used: 66.7
XXX total OOB instances added: 0
********************* end of statistics **********************/

