/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      1515652284
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   int16_t  f0;
   volatile int64_t  f1;
   volatile unsigned f2 : 9;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_19 = 0x76427603L;
static int32_t g_23 = (-5L);
static int16_t g_31 = 0x28D5L;
static int16_t g_33 = 8L;
static uint16_t g_39[8] = {0x6971L,0x6971L,0x6971L,0x6971L,0x6971L,0x6971L,0x6971L,0x6971L};
static int32_t g_40 = 1L;
static volatile union U0 g_73 = {4L};/* VOLATILE GLOBAL g_73 */
static int32_t g_100 = 0L;
static int32_t * const  volatile g_99 = &g_100;/* VOLATILE GLOBAL g_99 */
static int32_t * volatile g_155 = (void*)0;/* VOLATILE GLOBAL g_155 */
static int32_t g_158 = (-7L);
static int32_t * volatile g_157 = &g_158;/* VOLATILE GLOBAL g_157 */
static volatile int64_t g_165[10][2] = {{0x6493B66AF959E53FLL,6L},{0x6493B66AF959E53FLL,0x6493B66AF959E53FLL},{6L,0x6493B66AF959E53FLL},{0x6493B66AF959E53FLL,6L},{0x6493B66AF959E53FLL,0x6493B66AF959E53FLL},{6L,0x6493B66AF959E53FLL},{0x6493B66AF959E53FLL,6L},{0x6493B66AF959E53FLL,0x6493B66AF959E53FLL},{6L,0x6493B66AF959E53FLL},{0x6493B66AF959E53FLL,6L}};
static volatile int64_t g_168 = 0x4B1B73CF63262D62LL;/* VOLATILE GLOBAL g_168 */
static uint8_t g_169 = 255UL;
static int8_t g_239 = 0L;
static uint16_t g_244 = 0x1B25L;
static int16_t g_265 = (-10L);
static int16_t * const *g_266 = (void*)0;
static int64_t g_268 = 0L;
static int64_t g_270 = 0x50C06EE1ACB922D4LL;
static uint64_t g_273 = 0UL;
static uint32_t g_276 = 0x5BDB795EL;
static int8_t g_279[7] = {0x93L,0x93L,(-1L),0x93L,0x93L,(-1L),0x93L};
static int16_t * const **g_285 = &g_266;
static int16_t * const *** volatile g_284[9][5][5] = {{{&g_285,&g_285,&g_285,&g_285,&g_285},{&g_285,(void*)0,&g_285,(void*)0,(void*)0},{&g_285,&g_285,&g_285,&g_285,&g_285},{&g_285,(void*)0,(void*)0,(void*)0,(void*)0},{&g_285,&g_285,&g_285,&g_285,&g_285}},{{(void*)0,(void*)0,(void*)0,(void*)0,&g_285},{&g_285,&g_285,&g_285,&g_285,&g_285},{(void*)0,(void*)0,&g_285,(void*)0,&g_285},{&g_285,&g_285,&g_285,&g_285,&g_285},{&g_285,(void*)0,&g_285,(void*)0,(void*)0}},{{&g_285,&g_285,&g_285,&g_285,&g_285},{&g_285,(void*)0,(void*)0,(void*)0,(void*)0},{&g_285,&g_285,&g_285,&g_285,&g_285},{(void*)0,(void*)0,(void*)0,(void*)0,&g_285},{&g_285,&g_285,&g_285,&g_285,&g_285}},{{(void*)0,(void*)0,&g_285,(void*)0,&g_285},{&g_285,&g_285,&g_285,&g_285,&g_285},{&g_285,(void*)0,&g_285,(void*)0,(void*)0},{&g_285,&g_285,&g_285,&g_285,&g_285},{&g_285,(void*)0,(void*)0,(void*)0,(void*)0}},{{&g_285,&g_285,&g_285,&g_285,&g_285},{(void*)0,(void*)0,(void*)0,(void*)0,&g_285},{&g_285,&g_285,&g_285,&g_285,&g_285},{(void*)0,(void*)0,&g_285,(void*)0,&g_285},{&g_285,&g_285,&g_285,&g_285,&g_285}},{{&g_285,(void*)0,&g_285,(void*)0,(void*)0},{&g_285,&g_285,&g_285,&g_285,&g_285},{&g_285,(void*)0,(void*)0,(void*)0,(void*)0},{&g_285,&g_285,&g_285,&g_285,&g_285},{(void*)0,(void*)0,(void*)0,(void*)0,&g_285}},{{&g_285,&g_285,&g_285,&g_285,&g_285},{(void*)0,(void*)0,&g_285,(void*)0,&g_285},{&g_285,&g_285,&g_285,&g_285,&g_285},{&g_285,(void*)0,&g_285,(void*)0,(void*)0},{&g_285,&g_285,&g_285,&g_285,&g_285}},{{&g_285,(void*)0,(void*)0,(void*)0,(void*)0},{&g_285,&g_285,&g_285,&g_285,&g_285},{(void*)0,(void*)0,(void*)0,(void*)0,&g_285},{&g_285,&g_285,&g_285,&g_285,&g_285},{(void*)0,(void*)0,&g_285,(void*)0,&g_285}},{{&g_285,&g_285,&g_285,&g_285,&g_285},{&g_285,(void*)0,&g_285,(void*)0,(void*)0},{&g_285,&g_285,&g_285,&g_285,&g_285},{&g_285,(void*)0,(void*)0,(void*)0,(void*)0},{&g_285,&g_285,&g_285,&g_285,&g_285}}};
static int16_t * const *** const  volatile g_286 = &g_285;/* VOLATILE GLOBAL g_286 */
static volatile int64_t g_314 = (-1L);/* VOLATILE GLOBAL g_314 */
static volatile int32_t g_316 = 0x15FCF543L;/* VOLATILE GLOBAL g_316 */
static uint32_t g_317 = 0x4C5EAA5AL;
static const int16_t *g_345 = &g_33;
static const int16_t **g_344 = &g_345;
static const int16_t ***g_343 = &g_344;
static const int16_t **** volatile g_342[6][9][4] = {{{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,(void*)0,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343}},{{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,(void*)0,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343}},{{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,(void*)0,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343}},{{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,(void*)0,&g_343,&g_343}},{{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{(void*)0,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343}},{{(void*)0,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,(void*)0,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,(void*)0,&g_343},{&g_343,(void*)0,&g_343,(void*)0},{&g_343,(void*)0,&g_343,&g_343},{(void*)0,&g_343,&g_343,&g_343}}};
static const int16_t **** volatile g_346[1][4][8] = {{{&g_343,&g_343,&g_343,&g_343,&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343,&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343,&g_343,&g_343,&g_343,&g_343},{&g_343,&g_343,&g_343,&g_343,&g_343,&g_343,&g_343,&g_343}}};
static const int16_t **** volatile g_347 = (void*)0;/* VOLATILE GLOBAL g_347 */
static const int16_t **** volatile g_348 = &g_343;/* VOLATILE GLOBAL g_348 */
static volatile int8_t g_353 = 0x20L;/* VOLATILE GLOBAL g_353 */
static volatile int64_t g_354 = 0xA5E22DACE22F3474LL;/* VOLATILE GLOBAL g_354 */
static uint16_t g_356[1] = {5UL};
static uint64_t g_383 = 0x55BC204D39E5BC21LL;
static int32_t g_386[7] = {(-6L),0L,0L,(-6L),0L,0L,(-6L)};
static uint32_t g_424 = 0x5E46161DL;
static volatile uint16_t g_428 = 0x726AL;/* VOLATILE GLOBAL g_428 */
static int64_t *g_445[8][8] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
static int64_t **g_444 = &g_445[6][1];
static volatile int64_t g_503 = 0xEB5BE354D0A62D92LL;/* VOLATILE GLOBAL g_503 */
static const uint64_t g_524 = 0x279EA1CAB745BA1ELL;
static const uint64_t g_528 = 0xDA16B08FCBEA088DLL;
static const uint64_t *g_527 = &g_528;
static volatile union U0 g_544 = {8L};/* VOLATILE GLOBAL g_544 */
static int64_t g_584 = 0L;
static volatile uint64_t g_585[1] = {0x22C89D0FA47EDB1ELL};
static const union U0 g_590 = {0x5685L};/* VOLATILE GLOBAL g_590 */
static int32_t *g_599 = &g_23;
static int32_t **g_598 = &g_599;
static int32_t ** volatile *g_597[1] = {&g_598};
static int32_t g_666 = 2L;
static volatile union U0 g_698[5][7] = {{{0x437AL},{1L},{-10L},{-10L},{1L},{0x437AL},{0x21BDL}},{{1L},{-7L},{-1L},{0xF913L},{0xF913L},{-1L},{-7L}},{{1L},{0x21BDL},{0x437AL},{1L},{-10L},{-10L},{1L}},{{0x437AL},{-7L},{0x437AL},{-10L},{-7L},{0x21BDL},{0x21BDL}},{{-7L},{1L},{-1L},{1L},{-7L},{-1L},{0xF913L}}};
static int8_t *g_727[2][10] = {{&g_279[6],&g_279[6],&g_279[6],&g_279[0],&g_279[6],&g_279[6],&g_279[0],&g_279[6],&g_279[6],&g_279[0]},{&g_279[6],&g_279[0],&g_279[6],&g_279[6],&g_279[0],&g_279[6],&g_279[6],&g_279[0],&g_279[6],&g_279[6]}};
static int8_t **g_726 = &g_727[1][2];
static int8_t *** volatile g_725[4] = {&g_726,&g_726,&g_726,&g_726};
static int16_t *g_737 = &g_31;
static int16_t **g_736 = &g_737;
static int16_t ***g_735 = &g_736;
static int16_t **** volatile g_734 = &g_735;/* VOLATILE GLOBAL g_734 */
static uint8_t * volatile g_788 = &g_169;/* VOLATILE GLOBAL g_788 */
static uint8_t * volatile * const g_787[10][5][5] = {{{&g_788,&g_788,&g_788,&g_788,(void*)0},{&g_788,(void*)0,&g_788,&g_788,&g_788},{&g_788,&g_788,(void*)0,&g_788,&g_788},{(void*)0,&g_788,&g_788,&g_788,&g_788},{&g_788,&g_788,&g_788,&g_788,&g_788}},{{&g_788,&g_788,&g_788,&g_788,&g_788},{&g_788,&g_788,&g_788,(void*)0,&g_788},{&g_788,&g_788,(void*)0,&g_788,&g_788},{(void*)0,&g_788,&g_788,&g_788,(void*)0},{&g_788,(void*)0,&g_788,&g_788,&g_788}},{{(void*)0,&g_788,&g_788,&g_788,(void*)0},{(void*)0,&g_788,&g_788,(void*)0,&g_788},{&g_788,&g_788,(void*)0,&g_788,&g_788},{&g_788,&g_788,&g_788,&g_788,&g_788},{(void*)0,&g_788,(void*)0,&g_788,&g_788}},{{&g_788,&g_788,(void*)0,(void*)0,&g_788},{(void*)0,&g_788,&g_788,&g_788,&g_788},{&g_788,(void*)0,&g_788,&g_788,&g_788},{&g_788,&g_788,(void*)0,&g_788,&g_788},{&g_788,&g_788,&g_788,&g_788,&g_788}},{{(void*)0,&g_788,(void*)0,(void*)0,&g_788},{&g_788,&g_788,&g_788,&g_788,&g_788},{(void*)0,&g_788,&g_788,&g_788,(void*)0},{&g_788,(void*)0,&g_788,&g_788,&g_788},{&g_788,&g_788,(void*)0,&g_788,&g_788}},{{(void*)0,&g_788,&g_788,&g_788,&g_788},{(void*)0,&g_788,(void*)0,&g_788,&g_788},{&g_788,&g_788,&g_788,&g_788,&g_788},{(void*)0,&g_788,&g_788,(void*)0,&g_788},{&g_788,&g_788,(void*)0,&g_788,&g_788}},{{&g_788,&g_788,(void*)0,&g_788,(void*)0},{&g_788,&g_788,&g_788,(void*)0,&g_788},{&g_788,&g_788,(void*)0,&g_788,&g_788},{(void*)0,&g_788,&g_788,&g_788,&g_788},{(void*)0,&g_788,&g_788,&g_788,&g_788}},{{&g_788,&g_788,&g_788,(void*)0,&g_788},{&g_788,&g_788,(void*)0,&g_788,&g_788},{&g_788,(void*)0,&g_788,&g_788,(void*)0},{&g_788,&g_788,(void*)0,&g_788,&g_788},{(void*)0,&g_788,&g_788,&g_788,&g_788}},{{&g_788,(void*)0,&g_788,&g_788,&g_788},{(void*)0,&g_788,&g_788,&g_788,&g_788},{&g_788,&g_788,&g_788,&g_788,&g_788},{&g_788,&g_788,&g_788,(void*)0,&g_788},{&g_788,(void*)0,&g_788,&g_788,&g_788}},{{&g_788,&g_788,&g_788,&g_788,&g_788},{(void*)0,&g_788,&g_788,&g_788,(void*)0},{&g_788,(void*)0,&g_788,&g_788,(void*)0},{(void*)0,&g_788,&g_788,&g_788,&g_788},{&g_788,(void*)0,&g_788,(void*)0,(void*)0}}};
static volatile union U0 g_801[8][4][5] = {{{{-1L},{0L},{1L},{0x4365L},{0xEAA2L}},{{-1L},{0xEAA2L},{0xE7CEL},{1L},{1L}},{{0x4365L},{-8L},{0x4365L},{0L},{0xEAA2L}},{{0xFDDAL},{1L},{0xEAA2L},{0L},{0x4365L}}},{{{0xEAA2L},{0xE7CEL},{1L},{1L},{0xE7CEL}},{{0xE7CEL},{1L},{0xEAA2L},{0x4365L},{1L}},{{-8L},{1L},{0x4365L},{0L},{0xD3C0L}},{{0xB2E4L},{0xE7CEL},{0xE7CEL},{0xB2E4L},{0L}}},{{{-8L},{1L},{1L},{-1L},{0L}},{{0xE7CEL},{-8L},{0xD3C0L},{0xEAA2L},{0xD3C0L}},{{0xEAA2L},{0xEAA2L},{0L},{-1L},{1L}},{{0xFDDAL},{0L},{0L},{0xB2E4L},{0xE7CEL}}},{{{0x4365L},{0L},{0xD3C0L},{0L},{0x4365L}},{{-1L},{0L},{1L},{0x4365L},{0xEAA2L}},{{-1L},{0xEAA2L},{0xE7CEL},{1L},{1L}},{{0x4365L},{-8L},{0x4365L},{0L},{0xEAA2L}}},{{{0xFDDAL},{1L},{0xEAA2L},{0L},{0x4365L}},{{0xEAA2L},{0xE7CEL},{1L},{1L},{0xE7CEL}},{{0xE7CEL},{1L},{0xEAA2L},{0x4365L},{1L}},{{-8L},{1L},{0x4365L},{0L},{0xD3C0L}}},{{{0xB2E4L},{0xE7CEL},{0xE7CEL},{0xB2E4L},{0L}},{{-8L},{1L},{1L},{-1L},{-8L}},{{0xB2E4L},{-1L},{0xFDDAL},{0L},{0xFDDAL}},{{0L},{0L},{-8L},{0L},{0xD3C0L}}},{{{0x4365L},{1L},{-8L},{0xEAA2L},{0xB2E4L}},{{1L},{-8L},{0xFDDAL},{-8L},{1L}},{{0L},{1L},{0xD3C0L},{1L},{0L}},{{0L},{0L},{0xB2E4L},{0xE7CEL},{0xE7CEL}}},{{{1L},{-1L},{1L},{1L},{0L}},{{0x4365L},{0xE7CEL},{0L},{1L},{1L}},{{0L},{0xB2E4L},{0xE7CEL},{0xE7CEL},{0xB2E4L}},{{0xB2E4L},{1L},{0L},{1L},{0xD3C0L}}}};
static volatile uint32_t g_813 = 0UL;/* VOLATILE GLOBAL g_813 */
static volatile uint32_t * volatile g_812 = &g_813;/* VOLATILE GLOBAL g_812 */
static volatile uint32_t * volatile *g_811 = &g_812;
static volatile uint32_t * volatile * volatile *g_810 = &g_811;
static union U0 g_851 = {0xD64EL};/* VOLATILE GLOBAL g_851 */
static union U0 *g_861 = (void*)0;
static union U0 ** volatile g_860 = &g_861;/* VOLATILE GLOBAL g_860 */
static int64_t *g_905 = &g_268;
static union U0 g_918 = {-1L};/* VOLATILE GLOBAL g_918 */
static volatile int8_t g_932 = 0xC8L;/* VOLATILE GLOBAL g_932 */
static int32_t ** const  volatile g_973[7][3] = {{&g_599,(void*)0,&g_599},{&g_599,(void*)0,(void*)0},{(void*)0,&g_599,&g_599},{(void*)0,&g_599,(void*)0},{(void*)0,(void*)0,&g_599},{(void*)0,(void*)0,&g_599},{(void*)0,(void*)0,(void*)0}};
static int32_t ** const  volatile g_974 = &g_599;/* VOLATILE GLOBAL g_974 */
static uint16_t g_977 = 0x029AL;
static uint16_t *g_976[4] = {&g_977,&g_977,&g_977,&g_977};
static uint64_t * const  volatile g_988 = &g_383;/* VOLATILE GLOBAL g_988 */
static int32_t *g_1038[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
static int32_t ** volatile g_1037[4][2][5] = {{{&g_1038[1],&g_1038[1],(void*)0,(void*)0,&g_1038[1]},{(void*)0,&g_1038[0],&g_1038[1],&g_1038[1],&g_1038[0]}},{{&g_1038[1],&g_1038[1],(void*)0,(void*)0,&g_1038[1]},{(void*)0,&g_1038[0],&g_1038[1],&g_1038[1],&g_1038[0]}},{{&g_1038[1],&g_1038[1],(void*)0,(void*)0,&g_1038[1]},{(void*)0,&g_1038[0],&g_1038[1],&g_1038[1],&g_1038[0]}},{{&g_1038[1],&g_1038[1],(void*)0,(void*)0,&g_1038[1]},{(void*)0,&g_1038[0],&g_1038[1],&g_1038[1],&g_1038[0]}}};
static int32_t ** const  volatile g_1039 = &g_1038[2];/* VOLATILE GLOBAL g_1039 */
static uint8_t g_1136 = 1UL;
static volatile uint32_t g_1139 = 18446744073709551615UL;/* VOLATILE GLOBAL g_1139 */
static int32_t g_1187 = (-1L);
static union U0 g_1225 = {-1L};/* VOLATILE GLOBAL g_1225 */
static const int32_t *g_1239 = &g_23;
static const int32_t ** const  volatile g_1238 = &g_1239;/* VOLATILE GLOBAL g_1238 */
static volatile int32_t g_1274 = 2L;/* VOLATILE GLOBAL g_1274 */
static int64_t g_1330 = (-1L);
static uint8_t *g_1378 = &g_169;
static uint8_t **g_1377[9] = {&g_1378,&g_1378,&g_1378,&g_1378,&g_1378,&g_1378,&g_1378,&g_1378,&g_1378};
static int32_t * volatile g_1394 = (void*)0;/* VOLATILE GLOBAL g_1394 */
static int32_t * const  volatile g_1395 = &g_100;/* VOLATILE GLOBAL g_1395 */
static union U0 **g_1408 = &g_861;
static union U0 ***g_1407 = &g_1408;
static const int32_t g_1414 = 0x8A3FE23FL;
static uint64_t *g_1457 = &g_273;
static int8_t ***g_1464 = (void*)0;
static int32_t g_1518 = 6L;
static int64_t g_1548 = 0xFC19E784F94D0C70LL;
static uint16_t g_1575 = 1UL;
static int8_t g_1647 = 0x36L;


/* --- FORWARD DECLARATIONS --- */
static uint32_t  func_1(void);
static uint32_t  func_4(uint32_t  p_5, const int32_t  p_6, const int16_t  p_7);
static uint64_t  func_9(uint32_t  p_10, uint16_t  p_11, int32_t  p_12, uint64_t  p_13);
static uint32_t  func_14(uint8_t  p_15, int32_t  p_16, int32_t  p_17);
static int32_t * func_46(uint8_t  p_47, int16_t  p_48);
static uint32_t  func_49(int16_t * p_50, uint16_t * p_51);
static int16_t * func_52(int32_t  p_53);
static int32_t  func_54(int8_t  p_55, uint32_t  p_56);
static int16_t * func_59(int16_t * p_60, int16_t * p_61, int64_t  p_62, int64_t  p_63, int32_t  p_64);
static int16_t * func_65(int64_t  p_66, int16_t  p_67, uint16_t  p_68, int8_t  p_69, int16_t * p_70);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_19 g_23 g_33 g_39 g_527 g_528 g_918 g_905 g_988 g_383 g_598 g_599 g_974 g_734 g_735 g_736 g_737 g_31 g_157 g_158 g_356 g_244 g_811 g_812 g_813 g_851.f0 g_1330 g_1407 g_279 g_1414 g_268 g_584 g_99 g_100 g_1238 g_1239 g_788 g_169 g_977 g_810 g_276 g_726 g_727 g_428 g_1464 g_1518 g_1378 g_1187 g_1548 g_386 g_918.f0 g_1575 g_343 g_344 g_345 g_1647 g_1457 g_273
 * writes: g_23 g_31 g_33 g_39 g_40 g_1136 g_268 g_851.f0 g_356 g_276 g_244 g_1187 g_1407 g_100 g_584 g_444 g_977 g_1457 g_1464 g_279 g_169 g_599 g_1548 g_158 g_239 g_1647
 */
static uint32_t  func_1(void)
{ /* block id: 0 */
    uint32_t l_18 = 4294967295UL;
    int32_t *l_22 = &g_23;
    int16_t *l_30 = &g_31;
    int16_t *l_32 = &g_33;
    uint16_t *l_38 = &g_39[4];
    int16_t l_41 = 6L;
    int32_t l_1544 = 0x95825340L;
    int32_t l_1547[8][2] = {{1L,1L},{1L,3L},{0x5B3D8BABL,1L},{3L,1L},{0x5B3D8BABL,3L},{1L,1L},{1L,3L},{0x5B3D8BABL,1L}};
    uint64_t l_1549[7] = {0x3991E7AE273F6BE3LL,0x45DF75E916FB4B1BLL,0x45DF75E916FB4B1BLL,0x3991E7AE273F6BE3LL,0x45DF75E916FB4B1BLL,0x45DF75E916FB4B1BLL,0x3991E7AE273F6BE3LL};
    uint64_t l_1583 = 0x9F228991CF4FBCC9LL;
    int64_t l_1598 = 0x5F6CB6E4576052ABLL;
    uint32_t * const ***l_1629 = (void*)0;
    uint32_t * const *** const *l_1628 = &l_1629;
    int8_t *l_1634 = &g_239;
    uint8_t l_1645 = 1UL;
    int8_t *l_1646 = &g_1647;
    int32_t **l_1648[5];
    int i, j;
    for (i = 0; i < 5; i++)
        l_1648[i] = (void*)0;
    (*l_22) = (safe_div_func_uint32_t_u_u(func_4((!(func_9(func_14(l_18, g_19, (((l_18 ^ (safe_mul_func_uint32_t_u_u((((((*l_22) = 4L) , (((((safe_div_func_int8_t_s_s((safe_div_func_int16_t_s_s(((safe_sub_func_uint16_t_u_u((*l_22), ((*l_32) &= ((*l_30) = 5L)))) & (g_40 = (((*l_38) |= ((safe_sub_func_int32_t_s_s((g_23 , ((((((*l_22) , ((safe_div_func_int32_t_s_s((g_19 < g_19), g_23)) > (*l_22))) < 0x1B8D8131DDA87B8BLL) ^ 0xE7EA1B14L) > (*l_22)) < g_19)), g_23)) >= (*l_22))) & 0x4E78L))), g_19)), (*l_22))) ^ (*l_22)) , (*l_22)) && l_41) > g_23)) , 0x6FL) ^ 1UL), g_19))) & g_19) && 0xDD53L)), l_41, g_1330, (*g_527)) , 0x0FB25E631CE03053LL)), g_279[6], g_1414), 0x0D8F490CL));
    for (g_169 = 12; (g_169 <= 22); ++g_169)
    { /* block id: 687 */
        int32_t *l_1542 = &g_1518;
        int32_t *l_1543 = &g_23;
        int32_t *l_1545 = &g_1518;
        int32_t *l_1546[4][7] = {{&g_100,&g_100,&g_100,&g_100,&g_100,&g_100,&g_100},{&g_1518,&g_1518,&g_1518,&g_1518,&g_1518,&g_1518,&g_1518},{&g_100,&g_100,&g_100,&g_100,&g_100,&g_100,&g_100},{&g_1518,&g_1518,&g_1518,&g_1518,&g_1518,&g_1518,&g_1518}};
        int i, j;
        l_1549[0]++;
    }
    for (g_1187 = 16; (g_1187 <= (-8)); g_1187 = safe_sub_func_uint64_t_u_u(g_1187, 9))
    { /* block id: 692 */
        uint64_t l_1556 = 18446744073709551615UL;
        int32_t *l_1559 = &l_1544;
        int16_t ***l_1622 = &g_736;
        for (g_1548 = 3; (g_1548 >= 0); g_1548 -= 1)
        { /* block id: 695 */
            int16_t l_1582[1];
            int32_t l_1615[2][8] = {{0L,1L,6L,6L,1L,0L,1L,6L},{0xC142261AL,1L,6L,0xC142261AL,0xC142261AL,6L,(-1L),6L}};
            const int16_t l_1616 = 0L;
            int16_t ** const *l_1621 = (void*)0;
            int i, j;
            for (i = 0; i < 1; i++)
                l_1582[i] = 7L;
            if ((safe_add_func_uint32_t_u_u(((l_1556 & (*l_22)) , (safe_sub_func_int64_t_s_s(((*g_905) |= (l_1556 != (l_1559 == (*g_974)))), ((*l_22) || (**g_726))))), g_386[1])))
            { /* block id: 697 */
                int32_t l_1568 = 0x326C00FAL;
                (*l_1559) = ((safe_lshift_func_int16_t_s_u((safe_lshift_func_int64_t_s_u((-4L), 61)), 15)) < 0xE905CED2L);
                for (g_31 = 0; (g_31 <= 3); g_31 += 1)
                { /* block id: 701 */
                    int16_t *l_1576 = &g_918.f0;
                    int32_t l_1584 = (-1L);
                    if ((((safe_add_func_uint8_t_u_u(((*g_1378) = ((safe_div_func_uint32_t_u_u(l_1568, (**g_811))) | 0x6AB6FC67L)), (((safe_add_func_uint32_t_u_u(g_918.f0, (((safe_mul_func_int16_t_s_s(((*l_32) = (safe_mul_func_int32_t_s_s((g_1575 & ((**g_343) == ((***g_735) , l_1576))), (~(safe_mul_func_int32_t_s_s((safe_mul_func_uint8_t_u_u(4UL, l_1582[0])), 0x185D2657L)))))), l_1582[0])) | 0x115875FE1938DFA3LL) < 0UL))) > l_1583) , (-1L)))) , l_1584) ^ l_1568))
                    { /* block id: 704 */
                        uint64_t l_1585[4][10][5];
                        int i, j, k;
                        for (i = 0; i < 4; i++)
                        {
                            for (j = 0; j < 10; j++)
                            {
                                for (k = 0; k < 5; k++)
                                    l_1585[i][j][k] = 9UL;
                            }
                        }
                        (**g_598) &= l_1568;
                        return l_1585[3][6][3];
                    }
                    else
                    { /* block id: 707 */
                        int8_t l_1586 = 1L;
                        return l_1586;
                    }
                }
                if (l_1582[0])
                    break;
            }
            else
            { /* block id: 712 */
                uint16_t l_1614 = 65528UL;
                uint16_t *l_1617 = (void*)0;
                uint16_t *l_1618 = (void*)0;
                uint16_t *l_1619 = (void*)0;
                uint16_t *l_1620 = &g_977;
                int64_t l_1623[4];
                int i;
                for (i = 0; i < 4; i++)
                    l_1623[i] = (-1L);
                if ((*l_22))
                    break;
                (*g_157) ^= (((safe_div_func_uint64_t_u_u(((*l_22) == 0x053EL), (safe_rshift_func_uint32_t_u_s(((safe_add_func_int32_t_s_s((*g_599), (safe_mul_func_int16_t_s_s((+((((*l_1620) = (((safe_lshift_func_uint64_t_u_u(1UL, 60)) , (l_1598 || (((*l_38) = ((safe_add_func_uint32_t_u_u(((safe_sub_func_int64_t_s_s((*g_905), (safe_mod_func_uint16_t_u_u((safe_mod_func_int8_t_s_s(((safe_mul_func_uint64_t_u_u((safe_div_func_uint32_t_u_u((safe_mod_func_uint64_t_u_u((l_1582[0] || (l_1615[0][1] = (((!(*l_1559)) < l_1614) , 65535UL))), 0x6B954DD9FC24BFA2LL)), l_1614)), l_1582[0])) < l_1582[0]), (*l_1559))), l_1582[0])))) , l_1616), 0xFAC17D49L)) != l_1614)) != (***g_343)))) < (*l_1559))) , l_1621) == l_1622)), l_1623[0])))) > 0x16E2L), 21)))) , (*g_527)) && (*l_22));
                if ((*l_1559))
                    continue;
            }
        }
    }
    (*g_157) &= (((((((safe_add_func_uint8_t_u_u(((~(**g_726)) , (+((void*)0 == l_1628))), ((*l_1646) |= (safe_mul_func_int64_t_s_s((safe_lshift_func_int16_t_s_u((((((*l_1634) = (*l_22)) || (*l_22)) && ((safe_sub_func_int16_t_s_s(0xF627L, (safe_mod_func_uint32_t_u_u(((safe_rshift_func_int16_t_s_u((safe_div_func_int8_t_s_s((safe_div_func_int16_t_s_s(((*g_737) = (0UL & ((((**g_344) ^ ((l_1645 <= (*l_22)) < (*l_22))) && (*g_1239)) , (*l_22)))), (*g_345))), 0xB7L)), 10)) <= 1L), 0xEFE43365L)))) & (*l_22))) < 0xAF1C272EDD89ADB9LL), 2)), 0x274EDFE8FD0E2B90LL))))) || 9L) , &l_22) == l_1648[4]) < (*g_1457)) , (void*)0) != (void*)0);
    return (*l_22);
}


/* ------------------------------------------ */
/* 
 * reads : g_905 g_268 g_736 g_737 g_31 g_599 g_584 g_99 g_100 g_1238 g_1239 g_23 g_788 g_169 g_977 g_810 g_811 g_812 g_813 g_276 g_598 g_726 g_727 g_428 g_1464 g_1518 g_988 g_974 g_39 g_383 g_1378
 * writes: g_23 g_584 g_444 g_977 g_276 g_1457 g_1464 g_268 g_279 g_39 g_169 g_100 g_599
 */
static uint32_t  func_4(uint32_t  p_5, const int32_t  p_6, const int16_t  p_7)
{ /* block id: 634 */
    uint32_t *l_1419 = &g_276;
    uint32_t **l_1418 = &l_1419;
    uint32_t ***l_1417 = &l_1418;
    uint32_t ****l_1416 = &l_1417;
    uint32_t *****l_1415 = &l_1416;
    int32_t l_1422 = (-5L);
    uint32_t l_1425[8] = {1UL,0x163F9B54L,0x163F9B54L,1UL,0x163F9B54L,0x163F9B54L,1UL,0x163F9B54L};
    int32_t l_1444 = (-1L);
    uint64_t *l_1458 = &g_273;
    int16_t ** const *l_1475 = &g_736;
    int16_t ** const **l_1474 = &l_1475;
    int32_t l_1487[1][7];
    uint16_t l_1533[8];
    const int64_t *l_1535 = &g_270;
    const int64_t **l_1534 = &l_1535;
    int32_t *l_1536 = &g_100;
    uint16_t l_1537 = 1UL;
    int i, j;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 7; j++)
            l_1487[i][j] = (-2L);
    }
    for (i = 0; i < 8; i++)
        l_1533[i] = 65527UL;
    (*g_599) = (((((l_1415 == &l_1416) > (safe_lshift_func_uint32_t_u_s((l_1422 == ((safe_rshift_func_int8_t_s_s((l_1425[6] != (l_1422 & 0L)), 3)) >= ((*g_905) && ((void*)0 != (***l_1415))))), 25))) != 0xBDL) != 0xA9DB102BB396C38CLL) == (**g_736));
    for (g_584 = 21; (g_584 == (-19)); g_584 = safe_sub_func_uint32_t_u_u(g_584, 4))
    { /* block id: 638 */
        int64_t ***l_1436 = &g_444;
        int32_t l_1437 = (-3L);
        int32_t l_1483 = (-1L);
        if ((*g_99))
            break;
        if (l_1425[2])
            break;
        if (p_5)
            break;
        if ((18446744073709551615UL > (safe_sub_func_int32_t_s_s(((safe_mul_func_int32_t_s_s((safe_mul_func_uint32_t_u_u((((p_6 , 1L) > ((safe_add_func_uint64_t_u_u(((((*l_1436) = &g_445[6][1]) == &g_445[6][1]) | ((**g_1238) , (l_1437 > (l_1437 , ((safe_mul_func_int8_t_s_s((((safe_div_func_int8_t_s_s((safe_mod_func_int8_t_s_s(9L, l_1444)), (*g_788))) != 0xE7BAL) & l_1437), 0x1CL)) && l_1437))))), l_1444)) , 1L)) < l_1437), p_7)), l_1437)) != l_1422), g_977))))
        { /* block id: 643 */
            (*g_599) = 0L;
        }
        else
        { /* block id: 645 */
            const int32_t l_1459 = 0xEE94DD05L;
            int16_t ****l_1473[1];
            int32_t l_1486[3];
            int i;
            for (i = 0; i < 1; i++)
                l_1473[i] = &g_735;
            for (i = 0; i < 3; i++)
                l_1486[i] = 0x3B149789L;
            for (g_977 = 0; (g_977 < 34); g_977 = safe_add_func_int8_t_s_s(g_977, 1))
            { /* block id: 648 */
                uint64_t *l_1455[10] = {&g_383,&g_383,&g_383,&g_383,&g_383,&g_383,&g_383,&g_383,&g_383,&g_383};
                uint64_t **l_1456[4];
                int8_t ***l_1461[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                int8_t ****l_1460 = &l_1461[2];
                int8_t ***l_1463 = &g_726;
                int8_t ****l_1462[6][3] = {{&l_1463,&l_1463,&l_1463},{&l_1463,&l_1463,&l_1463},{&l_1463,&l_1463,&l_1463},{&l_1463,&l_1463,&l_1463},{&l_1463,&l_1463,&l_1463},{&l_1463,&l_1463,&l_1463}};
                int32_t l_1471 = 7L;
                int i, j;
                for (i = 0; i < 4; i++)
                    l_1456[i] = &l_1455[4];
                (**g_598) &= ((safe_sub_func_int64_t_s_s((safe_lshift_func_int64_t_s_u((safe_sub_func_uint32_t_u_u(((***l_1417) ^= (***g_810)), l_1437)), 23)), 0x626CE711ABBD7A47LL)) ^ (-1L));
                if (p_7)
                    break;
                if (((safe_mul_func_int8_t_s_s(((g_1457 = l_1455[2]) != l_1458), ((*g_1239) != ((((0x5131L & l_1459) < ((((g_1464 = ((*l_1460) = &g_726)) == (void*)0) > (safe_mod_func_int16_t_s_s((safe_sub_func_uint8_t_u_u((((p_6 | p_6) <= (**g_736)) ^ p_5), l_1444)), 3L))) != 1L)) | p_6) > 1UL)))) , l_1425[6]))
                { /* block id: 655 */
                    uint32_t l_1488[6];
                    int i;
                    for (i = 0; i < 6; i++)
                        l_1488[i] = 0x3849ADD6L;
                    if ((((**g_726) = (l_1422 < ((*g_905) ^= l_1459))) , 0x283F9F7DL))
                    { /* block id: 658 */
                        int32_t *l_1476 = &l_1437;
                        int32_t *l_1477 = &l_1444;
                        int32_t *l_1478 = &g_23;
                        int32_t *l_1479 = &g_100;
                        int32_t *l_1480 = (void*)0;
                        int32_t *l_1481 = &l_1444;
                        int32_t l_1482 = 1L;
                        int32_t *l_1484 = &l_1422;
                        int32_t *l_1485[4][5][9] = {{{&g_158,&l_1422,&g_100,&l_1471,&l_1483,(void*)0,&l_1483,&l_1471,&g_100},{&l_1437,&l_1437,&l_1483,&g_100,&l_1471,(void*)0,&l_1444,(void*)0,&l_1422},{&l_1471,&g_23,(void*)0,&l_1483,&l_1422,&l_1444,&l_1483,&l_1437,&g_23},{&g_23,&l_1482,&l_1483,&l_1444,&l_1471,(void*)0,&l_1471,&g_23,&l_1437},{(void*)0,&l_1444,&g_100,&l_1483,&l_1437,&g_23,&l_1471,(void*)0,&g_23}},{{&l_1483,&g_100,(void*)0,&l_1483,(void*)0,&l_1482,&g_23,&l_1482,(void*)0},{&l_1444,&g_158,&g_158,&l_1444,&g_23,&g_23,(void*)0,&g_100,&l_1483},{&l_1437,&g_158,&g_23,&l_1483,&g_23,(void*)0,(void*)0,&g_100,&g_158},{&g_23,&g_100,(void*)0,&g_100,&g_23,&g_100,(void*)0,&l_1471,(void*)0},{(void*)0,&g_158,&g_100,&l_1471,(void*)0,&l_1437,&g_100,(void*)0,&g_23}},{{&l_1482,&l_1483,&g_158,&l_1444,&l_1437,&l_1437,&g_100,(void*)0,&g_100},{&g_100,&l_1471,&g_23,&g_23,&l_1471,&g_100,&g_23,&g_100,&l_1482},{&g_23,(void*)0,(void*)0,&l_1483,&l_1422,(void*)0,&l_1444,&g_23,&l_1444},{&g_23,&g_100,&g_23,&g_158,&l_1471,&g_23,&g_23,&l_1483,&l_1437},{&g_23,&g_23,&g_158,&l_1482,&l_1483,&l_1482,&g_100,&l_1483,(void*)0}},{{&g_100,(void*)0,&g_23,(void*)0,&l_1437,&l_1483,(void*)0,&l_1482,&g_23},{&l_1482,&l_1437,&g_100,(void*)0,(void*)0,&g_100,&l_1437,&l_1482,&l_1444},{&g_23,&l_1444,&l_1482,&g_158,&l_1483,&l_1422,&g_158,&l_1483,&g_158},{&l_1422,&g_158,&g_158,&l_1471,(void*)0,&g_23,&g_23,&l_1483,&l_1444},{&g_158,&l_1422,&g_158,(void*)0,&l_1444,&l_1437,&g_158,(void*)0,&g_23}}};
                        int i, j, k;
                        l_1471 = (safe_rshift_func_int8_t_s_u(((g_428 , (void*)0) != l_1458), 5));
                        (**g_598) &= (safe_unary_minus_func_int32_t_s((l_1473[0] == l_1474)));
                        --l_1488[1];
                        if (l_1488[1])
                            continue;
                    }
                    else
                    { /* block id: 663 */
                        (*g_599) |= (safe_div_func_int32_t_s_s((safe_add_func_uint64_t_u_u(l_1444, (safe_mod_func_int64_t_s_s((safe_div_func_uint16_t_u_u((safe_div_func_int16_t_s_s(1L, (safe_lshift_func_uint8_t_u_s(((l_1444 == 0x6FCC03E9C99065C9LL) | (safe_mul_func_uint64_t_u_u((safe_div_func_uint32_t_u_u(p_5, p_5)), p_5))), (((p_6 , (2L < p_7)) , &p_5) == (*l_1418)))))), 0x230BL)), 0x8F657AE1E37635A9LL)))), 0x12D6125EL));
                    }
                }
                else
                { /* block id: 666 */
                    uint32_t l_1511 = 0x849EAB29L;
                    (*g_598) = func_46((l_1471 | ((l_1486[2] > 0xB9A2C43AL) , ((l_1487[0][4] ^= (safe_lshift_func_int8_t_s_s((p_5 || 0UL), l_1511))) < ((safe_rshift_func_uint64_t_u_s(((safe_mul_func_uint8_t_u_u((p_6 != (((safe_rshift_func_int8_t_s_u(((***g_1464) = 0x75L), g_1518)) || p_5) && 1UL)), p_5)) >= p_6), 49)) , l_1471)))), p_5);
                    if (l_1511)
                        continue;
                    if (l_1483)
                        break;
                }
                (**g_974) = p_6;
            }
            (*g_598) = (*g_974);
        }
    }
    (*l_1536) = ((**g_598) = (((***l_1417) ^= (safe_div_func_int8_t_s_s(((safe_mul_func_uint16_t_u_u((p_6 , (safe_add_func_uint64_t_u_u(((((safe_lshift_func_uint32_t_u_u((((safe_rshift_func_uint64_t_u_u(((safe_sub_func_int16_t_s_s(l_1444, ((safe_mod_func_uint32_t_u_u(((p_6 , l_1533[7]) || (((4UL || (2L || 65535UL)) || ((*g_905) = p_6)) <= (((void*)0 != l_1534) , l_1422))), (-1L))) , p_7))) & 0xE7L), (*g_988))) || p_6) && p_6), l_1425[6])) >= 0x54AFE2CE4AF32098LL) == 0x98L) || p_5), p_5))), l_1487[0][6])) > (*g_1378)), (-1L)))) == p_5));
    (*g_598) = func_46(l_1537, ((safe_div_func_uint16_t_u_u((*l_1536), (-8L))) , (-5L)));
    return (*l_1536);
}


/* ------------------------------------------ */
/* 
 * reads : g_599 g_23 g_988 g_383 g_1407
 * writes: g_23 g_1407 g_100
 */
static uint64_t  func_9(uint32_t  p_10, uint16_t  p_11, int32_t  p_12, uint64_t  p_13)
{ /* block id: 627 */
    uint32_t l_1404[4][4] = {{18446744073709551612UL,18446744073709551613UL,18446744073709551612UL,18446744073709551613UL},{18446744073709551612UL,18446744073709551613UL,18446744073709551612UL,18446744073709551613UL},{18446744073709551612UL,18446744073709551613UL,18446744073709551612UL,18446744073709551613UL},{18446744073709551612UL,18446744073709551613UL,18446744073709551612UL,18446744073709551613UL}};
    union U0 **l_1406 = &g_861;
    union U0 ***l_1405 = &l_1406;
    union U0 ****l_1409 = &g_1407;
    int32_t *l_1412 = &g_100;
    int32_t l_1413 = 0xDF482A29L;
    int i, j;
    (*g_599) = 1L;
    l_1413 = ((*l_1412) = (safe_lshift_func_uint32_t_u_s((safe_rshift_func_uint8_t_u_s(p_11, ((((!(((*g_599) = (*g_599)) && (~(*g_988)))) && l_1404[2][3]) || (p_11 >= (((l_1405 == ((*l_1409) = (p_12 , g_1407))) <= (safe_add_func_uint32_t_u_u((p_10 < 0x81DBL), p_10))) | 0xFE9C628AL))) || p_13))), 12)));
    return (*g_988);
}


/* ------------------------------------------ */
/* 
 * reads : g_527 g_528 g_918 g_905 g_988 g_383 g_598 g_599 g_974 g_23 g_734 g_735 g_736 g_737 g_31 g_157 g_158 g_356 g_244 g_811 g_812 g_813 g_851.f0
 * writes: g_1136 g_268 g_851.f0 g_23 g_31 g_356 g_276 g_244 g_1187
 */
static uint32_t  func_14(uint8_t  p_15, int32_t  p_16, int32_t  p_17)
{ /* block id: 6 */
    int16_t l_730 = 2L;
    int32_t l_1065 = 2L;
    int32_t l_1066[9] = {0xE9AA4BD4L,0L,0xE9AA4BD4L,0xE9AA4BD4L,0L,0xE9AA4BD4L,0xE9AA4BD4L,0L,0xE9AA4BD4L};
    uint32_t l_1075 = 0x13E26053L;
    int64_t * const *l_1088[10] = {&g_445[6][2],&g_445[6][2],&g_445[6][2],&g_445[6][2],&g_445[6][2],&g_445[6][2],&g_445[6][2],&g_445[6][2],&g_445[6][2],&g_445[6][2]};
    uint16_t *l_1105 = &g_356[0];
    int64_t l_1189 = 0L;
    int8_t l_1195 = 0x18L;
    int64_t l_1204 = (-1L);
    const int32_t *l_1237 = (void*)0;
    uint32_t l_1255 = 4294967291UL;
    int8_t l_1275[7] = {1L,1L,1L,1L,1L,1L,1L};
    uint16_t l_1280 = 0x2AC6L;
    uint32_t l_1327 = 0UL;
    uint8_t **l_1381 = &g_1378;
    int32_t l_1385 = 5L;
    int i;
    for (p_17 = (-20); (p_17 != 12); p_17++)
    { /* block id: 9 */
        int16_t *l_738[5] = {&g_265,&g_265,&g_265,&g_265,&g_265};
        int32_t l_985 = 5L;
        const uint32_t *l_1055 = &g_276;
        const uint32_t **l_1054 = &l_1055;
        int32_t l_1062 = (-1L);
        union U0 *l_1097[8] = {&g_918,&g_918,&g_918,&g_918,&g_918,&g_918,&g_918,&g_918};
        int32_t l_1191 = 1L;
        int32_t l_1192 = 0x5B63F499L;
        int32_t l_1193 = (-8L);
        int32_t l_1194 = 6L;
        int32_t l_1196 = 0x8AC2CE8DL;
        int32_t l_1197 = 0x3DF475E1L;
        int32_t l_1198[5][2];
        uint16_t l_1199 = 0x5BE6L;
        int i, j;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 2; j++)
                l_1198[i][j] = 0x1CB6D3F7L;
        }
        if (((void*)0 != &g_33))
        { /* block id: 10 */
            int64_t l_74 = 0xE95372A7181CA8FDLL;
            int32_t l_1049 = 0xA5F6CAECL;
            int32_t l_1068 = 0xBA84A708L;
            int32_t l_1070 = (-1L);
            int32_t l_1071 = 9L;
            int32_t l_1073[3][10] = {{5L,(-1L),0x3E532DA8L,(-1L),5L,9L,9L,5L,(-1L),0x3E532DA8L},{0x7CEA70FBL,0x7CEA70FBL,0x3E532DA8L,5L,0L,5L,0x3E532DA8L,0x7CEA70FBL,0x7CEA70FBL,0x3E532DA8L},{(-1L),5L,9L,9L,5L,(-1L),0x3E532DA8L,(-1L),5L,9L}};
            int64_t **l_1089 = &g_905;
            uint64_t **l_1119 = (void*)0;
            int i, j;
            for (p_15 = (-4); (p_15 < 33); p_15 = safe_add_func_int8_t_s_s(p_15, 8))
            { /* block id: 13 */
                uint64_t l_75[4];
                uint16_t *l_80[9][10][2] = {{{&g_39[1],&g_39[4]},{(void*)0,&g_39[2]},{&g_39[4],&g_39[2]},{(void*)0,&g_39[4]},{&g_39[1],&g_39[3]},{&g_39[7],&g_39[4]},{&g_39[7],(void*)0},{&g_39[4],&g_39[4]},{(void*)0,&g_39[0]},{&g_39[4],(void*)0}},{{(void*)0,(void*)0},{&g_39[4],&g_39[4]},{&g_39[4],&g_39[4]},{(void*)0,&g_39[5]},{&g_39[4],&g_39[4]},{&g_39[0],&g_39[4]},{&g_39[1],(void*)0},{&g_39[4],&g_39[3]},{(void*)0,&g_39[2]},{&g_39[4],(void*)0}},{{&g_39[4],&g_39[4]},{(void*)0,(void*)0},{&g_39[4],&g_39[1]},{&g_39[7],&g_39[4]},{&g_39[4],&g_39[4]},{(void*)0,&g_39[0]},{(void*)0,&g_39[4]},{&g_39[6],&g_39[4]},{&g_39[4],&g_39[3]},{&g_39[4],&g_39[2]}},{{(void*)0,&g_39[5]},{&g_39[4],(void*)0},{&g_39[4],&g_39[1]},{(void*)0,(void*)0},{&g_39[4],&g_39[2]},{&g_39[0],(void*)0},{&g_39[2],&g_39[4]},{&g_39[5],&g_39[3]},{&g_39[4],(void*)0},{&g_39[6],&g_39[6]}},{{&g_39[2],(void*)0},{(void*)0,(void*)0},{&g_39[4],&g_39[7]},{&g_39[6],&g_39[4]},{&g_39[4],&g_39[0]},{&g_39[4],&g_39[4]},{&g_39[6],&g_39[7]},{&g_39[4],(void*)0},{(void*)0,(void*)0},{&g_39[2],&g_39[6]}},{{&g_39[6],(void*)0},{&g_39[4],&g_39[3]},{&g_39[5],&g_39[4]},{&g_39[2],(void*)0},{&g_39[0],&g_39[2]},{&g_39[4],(void*)0},{(void*)0,(void*)0},{&g_39[0],&g_39[1]},{(void*)0,&g_39[4]},{&g_39[5],&g_39[4]}},{{&g_39[3],&g_39[4]},{&g_39[4],&g_39[2]},{&g_39[4],&g_39[4]},{&g_39[6],&g_39[1]},{&g_39[5],&g_39[2]},{&g_39[7],(void*)0},{&g_39[4],(void*)0},{&g_39[4],&g_39[4]},{&g_39[4],&g_39[0]},{&g_39[0],(void*)0}},{{&g_39[4],(void*)0},{&g_39[1],&g_39[3]},{&g_39[4],&g_39[4]},{(void*)0,&g_39[4]},{&g_39[2],&g_39[4]},{&g_39[7],&g_39[4]},{&g_39[1],&g_39[7]},{(void*)0,&g_39[4]},{&g_39[4],&g_39[5]},{&g_39[4],&g_39[5]}},{{&g_39[3],&g_39[1]},{&g_39[1],(void*)0},{&g_39[4],&g_39[1]},{&g_39[4],&g_39[4]},{&g_39[6],&g_39[4]},{&g_39[4],&g_39[0]},{&g_39[1],&g_39[4]},{(void*)0,&g_39[4]},{&g_39[1],&g_39[0]},{&g_39[4],&g_39[4]}}};
                int32_t l_81 = 0L;
                int32_t l_1067 = 0x194D38A7L;
                int32_t l_1069 = 0L;
                int32_t l_1072 = 1L;
                int32_t l_1074[6][8][4] = {{{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL}},{{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL}},{{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL}},{{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL}},{{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL}},{{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL},{(-6L),(-6L),0x4C10600BL,0x4C10600BL}}};
                int16_t * const ***l_1140 = &g_285;
                int i, j, k;
                for (i = 0; i < 4; i++)
                    l_75[i] = 0xD12EA0FEFE6B3E96LL;
            }
        }
        else
        { /* block id: 476 */
            uint32_t *l_1173 = &g_276;
            uint16_t *l_1174 = &g_244;
            int32_t l_1188 = 0x2613F4DDL;
            int32_t *l_1190[8] = {&l_1066[5],&l_1066[5],&l_1066[5],&l_1066[5],&l_1066[5],&l_1066[5],&l_1066[5],&l_1066[5]};
            int i;
            for (g_1136 = 0; (g_1136 >= 41); g_1136 = safe_add_func_int32_t_s_s(g_1136, 6))
            { /* block id: 479 */
                int8_t l_1154[1][7][9] = {{{0x00L,0L,0xC7L,0L,0x00L,0x00L,0L,0xC7L,0L},{0L,0x14L,0xC7L,0xC7L,0x14L,0L,0x14L,0xC7L,0xC7L},{0x00L,0x00L,0L,0xC7L,0L,0x00L,0x00L,0L,0xC7L},{(-1L),0x14L,(-1L),0L,0L,(-1L),0x14L,(-1L),0L},{(-1L),0L,0L,(-1L),0x14L,(-1L),0L,0L,(-1L)},{0x00L,0L,0xC7L,0L,0x00L,0x00L,0L,0xC7L,0L},{0L,0x14L,0xC7L,0xC7L,0x14L,0L,0x14L,0xC7L,0xC7L}}};
                int i, j, k;
                if ((((safe_lshift_func_int32_t_s_u((safe_mul_func_int8_t_s_s(((safe_mod_func_int64_t_s_s(0x44A01BBF1E82622ELL, (safe_mul_func_uint64_t_u_u((*g_527), (g_918 , (+((safe_div_func_int8_t_s_s(((*g_527) >= ((*g_905) = l_1154[0][6][7])), (p_15 | 0xAFL))) > p_17))))))) && (safe_mul_func_uint16_t_u_u((1L || l_1066[2]), 0x6E0BL))), l_985)), p_16)) >= p_17) || (*g_988)))
                { /* block id: 481 */
                    for (g_851.f0 = 1; (g_851.f0 >= 0); g_851.f0 -= 1)
                    { /* block id: 484 */
                        int i, j, k;
                        (**g_598) = p_17;
                        if ((**g_974))
                            continue;
                        (**g_598) = (8L <= (****g_734));
                    }
                    l_1065 = (safe_rshift_func_int32_t_s_s(0x51E6D84DL, 20));
                }
                else
                { /* block id: 490 */
                    for (l_730 = 0; (l_730 != 28); l_730++)
                    { /* block id: 493 */
                        if ((*g_157))
                            break;
                    }
                }
                return p_15;
            }
            (*g_599) &= ((safe_lshift_func_uint8_t_u_s((((*l_1173) = ((safe_sub_func_uint32_t_u_u(((safe_rshift_func_int16_t_s_s(((*g_737) &= (safe_rshift_func_uint16_t_u_u(p_15, 9))), 15)) & l_1065), (safe_div_func_uint16_t_u_u(0UL, (--(*l_1105)))))) != 0xDC40269D4C325C45LL)) < (((*l_1174) ^= p_17) > ((((safe_sub_func_int64_t_s_s((-10L), p_15)) == ((((safe_mod_func_uint16_t_u_u((safe_rshift_func_uint16_t_u_s((safe_sub_func_uint32_t_u_u(p_17, ((safe_mul_func_uint8_t_u_u((safe_mul_func_uint8_t_u_u(((g_1187 = ((((l_1066[0] & (**g_811)) == p_16) , p_17) & l_985)) >= p_15), l_1188)), l_985)) && p_15))), 8)), p_15)) >= l_1188) || p_16) , 0x1085583BF310E01FLL)) <= 5L) , p_17))), 1)) == l_985);
            ++l_1199;
        }
        (*g_599) = (g_851.f0 , (safe_mul_func_uint16_t_u_u(0xC327L, l_1204)));
    }
    for (g_31 = 1; (g_31 >= 0); g_31 -= 1)
    { /* block id: 511 */
        uint32_t *l_1214 = &g_276;
        int32_t l_1224 = 0x8850FDB3L;
        int16_t *l_1226[6][10][2] = {{{&l_730,&g_1225.f0},{&l_730,&g_1225.f0},{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_918.f0,&g_918.f0},{&g_31,&g_918.f0},{&g_918.f0,&g_851.f0}},{{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_918.f0,&g_918.f0},{&g_31,&g_918.f0},{&g_918.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0}},{{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_918.f0,&g_918.f0},{&g_31,&g_918.f0},{&g_918.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0}},{{&g_1225.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_918.f0,&g_918.f0},{&g_31,&g_918.f0},{&g_918.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0}},{{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_918.f0,&g_918.f0},{&g_31,&g_918.f0},{&g_918.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0}},{{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_918.f0,&g_918.f0},{&g_31,&g_918.f0},{&g_918.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0},{&g_1225.f0,&g_851.f0},{&g_1225.f0,&g_1225.f0},{&g_31,&g_1225.f0}}};
        int32_t l_1235[2][7] = {{1L,7L,1L,7L,1L,7L,1L},{0x7C828272L,0x7C828272L,0x7C828272L,0x7C828272L,0x7C828272L,0x7C828272L,0x7C828272L}};
        int8_t *l_1236 = &g_279[6];
        const int32_t *l_1250[10] = {&g_158,&g_158,&g_158,&g_158,&g_158,&g_158,&g_158,&g_158,&g_158,&g_158};
        int32_t *l_1251 = &g_23;
        int32_t *l_1252 = &l_1066[7];
        int32_t *l_1253 = (void*)0;
        int32_t *l_1254[4][10] = {{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&l_1235[0][6],(void*)0,(void*)0,&l_1235[0][6],(void*)0,(void*)0,&l_1235[0][6],(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
        int i, j, k;
    }
    return p_17;
}


/* ------------------------------------------ */
/* 
 * reads : g_988 g_977 g_811 g_905 g_598 g_599 g_268 g_158 g_23 g_974 g_737 g_33 g_39 g_99 g_31
 * writes: g_39 g_268 g_169 g_158 g_23 g_276 g_100
 */
static int32_t * func_46(uint8_t  p_47, int16_t  p_48)
{ /* block id: 426 */
    uint64_t *l_989 = &g_383;
    uint32_t *l_991 = &g_276;
    uint32_t **l_990 = &l_991;
    int32_t l_994 = 1L;
    uint16_t *l_995 = &g_39[4];
    uint16_t l_996 = 0UL;
    int32_t **l_1029 = &g_599;
    if ((!((~(((*l_995) = (0UL >= (((g_988 == l_989) >= (g_977 , ((l_990 != g_811) > p_47))) | ((safe_rshift_func_uint64_t_u_u(18446744073709551615UL, l_994)) , p_47)))) == l_996)) > l_996)))
    { /* block id: 428 */
        uint8_t l_1001 = 1UL;
        uint8_t *l_1015 = &g_169;
        int16_t *l_1016 = (void*)0;
        (**g_598) = ((safe_mul_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u(l_1001, (((253UL ^ p_48) > (safe_lshift_func_int64_t_s_u(((safe_unary_minus_func_uint32_t_u((p_48 >= (safe_div_func_int16_t_s_s((p_47 < ((*g_905) = p_47)), (safe_add_func_uint64_t_u_u((safe_mul_func_uint32_t_u_u((((safe_mul_func_int64_t_s_s(((safe_mul_func_uint8_t_u_u(((*l_1015) = 249UL), (((&l_1015 == (void*)0) , l_1016) == &p_48))) , l_1001), 0xB76AF5EB7EDB2650LL)) | p_48) , l_1001), l_996)), 0xCB7517E2B818381BLL))))))) , p_47), 2))) <= 3L))), p_47)) <= l_994);
    }
    else
    { /* block id: 432 */
        int16_t l_1026[8];
        int i;
        for (i = 0; i < 8; i++)
            l_1026[i] = 1L;
        for (g_268 = 0; (g_268 < 17); g_268 = safe_add_func_int32_t_s_s(g_268, 6))
        { /* block id: 435 */
            uint64_t l_1019 = 0xA65B37F74538BC45LL;
            int32_t ** const l_1036[3] = {&g_599,&g_599,&g_599};
            int i;
            (*g_99) = (p_47 & (l_1019 | (safe_mod_func_int8_t_s_s(p_48, (safe_lshift_func_uint32_t_u_u(((*l_991) = (((*g_599) = (safe_rshift_func_uint64_t_u_s((l_1026[4] < (safe_div_func_uint32_t_u_u((p_47 & ((l_1029 == ((safe_lshift_func_int32_t_s_s((-1L), (((safe_sub_func_int32_t_s_s((4294967290UL && ((safe_mul_func_int16_t_s_s((p_48 < (**l_1029)), 0x4582L)) != l_1019)), (**g_974))) || 0x9792L) & (*g_599)))) , l_1036[2])) , (*g_737))), 9L))), p_48))) ^ g_977)), g_39[4]))))));
        }
    }
    return (*l_1029);
}


/* ------------------------------------------ */
/* 
 * reads : g_273 g_23
 * writes: g_273
 */
static uint32_t  func_49(int16_t * p_50, uint16_t * p_51)
{ /* block id: 418 */
    uint64_t l_982[4];
    int i;
    for (i = 0; i < 4; i++)
        l_982[i] = 18446744073709551615UL;
    for (g_273 = 0; (g_273 <= 38); g_273 = safe_add_func_int16_t_s_s(g_273, 1))
    { /* block id: 421 */
        int32_t *l_980 = &g_23;
        int32_t *l_981[3];
        int i;
        for (i = 0; i < 3; i++)
            l_981[i] = &g_100;
        l_982[1]--;
        if (l_982[1])
            break;
    }
    return g_23;
}


/* ------------------------------------------ */
/* 
 * reads : g_317 g_598 g_599 g_265 g_974
 * writes: g_317 g_599 g_158 g_23 g_265
 */
static int16_t * func_52(int32_t  p_53)
{ /* block id: 395 */
    int32_t *l_965 = &g_100;
    int16_t *l_975[5];
    int i;
    for (i = 0; i < 5; i++)
        l_975[i] = &g_33;
    for (g_317 = 0; (g_317 >= 4); ++g_317)
    { /* block id: 398 */
        l_965 = (*g_598);
        (*g_598) = l_965;
        for (g_158 = 0; (g_158 > (-6)); g_158 = safe_sub_func_int32_t_s_s(g_158, 1))
        { /* block id: 403 */
            for (g_23 = 1; (g_23 >= 0); g_23 -= 1)
            { /* block id: 406 */
                int32_t *l_968 = &g_158;
                int32_t **l_969 = &l_965;
                (*l_969) = ((*g_598) = l_968);
            }
            for (g_265 = 20; (g_265 < (-22)); g_265 = safe_sub_func_uint32_t_u_u(g_265, 1))
            { /* block id: 412 */
                int32_t * const l_972 = &g_158;
                (*g_974) = l_972;
            }
        }
    }
    return l_975[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_737 g_33 g_265 g_527 g_528 g_424 g_356 g_503 g_279 g_169 g_344 g_345 g_599 g_23 g_598 g_268 g_787 g_31 g_157 g_158 g_239 g_165 g_801 g_810 g_811 g_812 g_736 g_851 g_788 g_860
 * writes: g_33 g_424 g_356 g_169 g_23 g_268 g_270 g_239 g_861 g_158
 */
static int32_t  func_54(int8_t  p_55, uint32_t  p_56)
{ /* block id: 279 */
    int32_t l_739[10][6] = {{(-1L),(-5L),0x6257AD38L,(-5L),(-1L),(-1L)},{0x6295F52CL,(-5L),0x6295F52CL,0x6257AD38L,(-1L),0x6257AD38L},{0x6257AD38L,(-1L),0x6257AD38L,0x6295F52CL,0x6295F52CL,0x6257AD38L},{(-5L),(-5L),0x6295F52CL,0xF01599E9L,0x6295F52CL,(-5L)},{0x6295F52CL,(-1L),0xF01599E9L,0xF01599E9L,(-1L),0x6295F52CL},{(-5L),0x6295F52CL,0xF01599E9L,0x6295F52CL,(-5L),(-5L)},{0x6257AD38L,0x6295F52CL,0x6295F52CL,0x6257AD38L,(-1L),0x6257AD38L},{0x6257AD38L,(-1L),0x6257AD38L,0x6295F52CL,0x6295F52CL,0x6257AD38L},{(-5L),(-5L),0x6295F52CL,0xF01599E9L,0x6295F52CL,(-5L)},{0x6295F52CL,(-1L),0xF01599E9L,0xF01599E9L,(-1L),0x6295F52CL}};
    int8_t *l_755[9] = {&g_279[3],&g_279[3],&g_279[3],&g_279[3],&g_279[3],&g_279[3],&g_279[3],&g_279[3],&g_279[3]};
    int64_t **l_756 = &g_445[6][1];
    int16_t ***l_776[4];
    uint16_t * const l_792 = &g_39[5];
    const int8_t *l_800[4] = {&g_279[6],&g_279[6],&g_279[6],&g_279[6]};
    const int8_t **l_799[7][9] = {{&l_800[3],(void*)0,&l_800[3],&l_800[2],&l_800[2],&l_800[3],(void*)0,&l_800[3],&l_800[2]},{&l_800[2],&l_800[2],&l_800[2],&l_800[3],&l_800[3],(void*)0,(void*)0,&l_800[3],&l_800[3]},{&l_800[1],&l_800[2],&l_800[1],&l_800[2],(void*)0,&l_800[2],(void*)0,&l_800[2],&l_800[2]},{&l_800[3],&l_800[2],&l_800[2],(void*)0,&l_800[2],&l_800[2],&l_800[3],(void*)0,&l_800[2]},{(void*)0,&l_800[2],(void*)0,&l_800[2],&l_800[1],&l_800[2],&l_800[1],&l_800[2],(void*)0},{(void*)0,(void*)0,&l_800[3],&l_800[3],&l_800[2],&l_800[2],&l_800[2],(void*)0,&l_800[2]},{(void*)0,&l_800[3],&l_800[2],&l_800[2],&l_800[3],(void*)0,&l_800[3],&l_800[2],(void*)0}};
    const int8_t ***l_798 = &l_799[5][6];
    int32_t l_823 = 0x80B4B6EDL;
    uint64_t l_901 = 0UL;
    int64_t *l_904 = &g_270;
    int64_t l_923 = 0x54132536EBA879A1LL;
    int32_t l_925 = 0x828262C6L;
    int32_t l_926[1][3][8];
    int16_t l_937 = 0L;
    uint8_t l_939 = 0UL;
    int32_t *l_962 = &g_100;
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_776[i] = &g_736;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 8; k++)
                l_926[i][j][k] = (-9L);
        }
    }
    if (((l_739[2][2] >= (((*g_737) &= 0x7AEDL) < ((safe_sub_func_int32_t_s_s((p_55 >= (safe_div_func_int8_t_s_s(((((safe_sub_func_int8_t_s_s((((-1L) | (0x849A9DA0L != (&p_55 == ((safe_lshift_func_uint8_t_u_u((+((safe_mul_func_int64_t_s_s(0L, (safe_lshift_func_uint32_t_u_s((safe_mul_func_uint64_t_u_u(l_739[2][2], (-3L))), 16)))) && 2UL)), g_265)) , l_755[5])))) <= (*g_527)), 1UL)) & 0xC64373F0L) , (void*)0) != l_756), p_56))), 0x34C485B2L)) > l_739[2][2]))) != 0x9D516C35L))
    { /* block id: 281 */
        const int16_t l_765 = (-10L);
        uint64_t l_771[5][3];
        int16_t ***l_774 = (void*)0;
        int i, j;
        for (i = 0; i < 5; i++)
        {
            for (j = 0; j < 3; j++)
                l_771[i][j] = 18446744073709551608UL;
        }
        for (g_424 = 0; (g_424 > 20); g_424++)
        { /* block id: 284 */
            uint32_t *l_761[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
            uint32_t **l_760 = &l_761[2];
            uint32_t ***l_759 = &l_760;
            uint16_t *l_766 = (void*)0;
            uint16_t *l_767[7][10] = {{&g_39[6],&g_39[5],&g_356[0],&g_39[4],&g_244,&g_39[4],(void*)0,&g_39[4],&g_356[0],&g_356[0]},{&g_356[0],&g_244,&g_356[0],&g_244,&g_39[4],&g_39[4],&g_244,&g_356[0],&g_244,&g_356[0]},{&g_39[6],&g_39[4],&g_39[4],&g_356[0],&g_39[5],&g_39[4],&g_356[0],&g_244,&g_356[0],&g_356[0]},{(void*)0,&g_356[0],&g_356[0],&g_39[4],&g_39[5],&g_39[4],&g_356[0],&g_356[0],(void*)0,&g_356[0]},{&g_39[5],&g_356[0],&g_39[4],&g_244,&g_39[4],(void*)0,&g_39[4],&g_356[0],&g_356[0],&g_356[0]},{&g_39[4],&g_356[0],&g_244,&g_244,&g_244,&g_244,&g_356[0],&g_39[4],&g_356[0],&g_356[0]},{&g_39[6],&g_356[0],&g_356[0],&g_244,&g_39[4],&g_39[4],&g_244,&g_39[6],&g_356[0],&g_39[6]}};
            uint8_t *l_770 = &g_169;
            int32_t l_772 = 0x590251D6L;
            int32_t l_773[10][8] = {{(-9L),0L,(-9L),0L,(-1L),(-1L),0L,(-9L)},{0L,0L,(-1L),0x73DD002BL,0x0405A8C3L,0x73DD002BL,(-1L),0L},{0L,(-9L),0L,(-1L),(-1L),0L,(-9L),0L},{(-9L),(-8L),0L,0x73DD002BL,0L,(-8L),(-9L),(-9L)},{(-8L),0x73DD002BL,0L,0L,0x73DD002BL,(-8L),(-1L),(-8L)},{0x73DD002BL,(-8L),(-1L),(-8L),0x73DD002BL,0L,0L,0x73DD002BL},{(-8L),(-9L),(-9L),(-8L),0L,0x73DD002BL,0L,(-8L)},{(-9L),0L,(-9L),0L,(-1L),(-1L),0L,(-9L)},{0L,0L,(-1L),0x73DD002BL,0x0405A8C3L,0x73DD002BL,(-1L),0L},{0L,(-9L),0L,(-1L),(-1L),0L,(-9L),0L}};
            int16_t ****l_775[3];
            uint8_t **l_777 = &l_770;
            int i, j;
            for (i = 0; i < 3; i++)
                l_775[i] = &l_774;
            l_773[5][3] &= ((((l_759 == (void*)0) <= (((((safe_sub_func_uint16_t_u_u((g_356[0] &= (+l_765)), g_503)) , ((((((((safe_div_func_uint8_t_u_u((((((void*)0 != l_767[3][5]) < g_279[6]) <= ((((*l_770) ^= g_265) ^ (p_55 = p_55)) | l_771[2][1])) || 0x4604L), p_56)) == l_765) & (**g_344)) && 0x6FL) ^ p_56) & (*g_599)) & 1UL) , (*g_527))) < l_772) & l_739[6][4]) && p_56)) < 0L) >= 8UL);
            l_776[3] = l_774;
            if (p_55)
                continue;
            (**g_598) = ((((((*l_777) = &g_169) != (void*)0) < (-1L)) ^ 0L) >= l_771[1][1]);
        }
    }
    else
    { /* block id: 294 */
        uint32_t l_793 = 4294967295UL;
        int32_t *l_802[1];
        int32_t *l_803 = (void*)0;
        int8_t **l_845 = &g_727[0][2];
        int i;
        for (i = 0; i < 1; i++)
            l_802[i] = &g_100;
        for (g_268 = 0; (g_268 >= 0); g_268 -= 1)
        { /* block id: 297 */
            uint8_t *l_790 = (void*)0;
            uint8_t **l_789 = &l_790;
            uint8_t ***l_791 = &l_789;
            uint32_t *l_808 = &g_276;
            uint32_t **l_807 = &l_808;
            uint32_t ***l_806 = &l_807;
            int32_t l_843 = 0L;
            int32_t l_844 = 0L;
            int i;
            (*g_599) &= (safe_mul_func_int16_t_s_s(((((0L < (safe_add_func_int32_t_s_s((safe_sub_func_uint8_t_u_u((g_356[g_268] < ((safe_rshift_func_int16_t_s_u(((((safe_unary_minus_func_int8_t_s((g_787[8][3][4] == ((*l_791) = l_789)))) | ((l_792 == &g_356[0]) , l_793)) | ((((safe_mul_func_int32_t_s_s((safe_mod_func_uint32_t_u_u(g_31, ((*g_157) || g_503))), l_793)) , 3UL) || p_56) >= p_56)) == 0xB4C0L), 5)) | 0L)), p_55)), 0x807DF576L))) , g_239) , &g_726) != l_798), 65535UL));
            for (g_270 = 0; (g_270 >= 0); g_270 -= 1)
            { /* block id: 302 */
                uint32_t ***l_809[1];
                int32_t l_830 = 1L;
                int8_t ***l_846 = &l_845;
                int i, j;
                for (i = 0; i < 1; i++)
                    l_809[i] = &l_807;
                if (g_165[(g_268 + 2)][(g_268 + 1)])
                { /* block id: 303 */
                    return l_793;
                }
                else
                { /* block id: 305 */
                    uint64_t l_824[3];
                    int32_t l_829 = 0x0C2CB76EL;
                    int32_t l_831 = 0xFE67035BL;
                    int i;
                    for (i = 0; i < 3; i++)
                        l_824[i] = 0xCE39A167CC05716BLL;
                    l_802[0] = (g_801[1][0][3] , (void*)0);
                    for (g_169 = 0; (g_169 <= 0); g_169 += 1)
                    { /* block id: 309 */
                        return g_279[6];
                    }
                    for (g_239 = 0; (g_239 <= 0); g_239 += 1)
                    { /* block id: 314 */
                        uint64_t *l_822[6][3] = {{&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273},{&g_383,&g_273,&g_273},{&g_273,&g_383,&g_273},{&g_383,&g_383,&g_383},{&g_273,&g_273,&g_273}};
                        int32_t l_827[3][7][6] = {{{0x30F1EC4CL,0xFE66DD63L,(-1L),0xFE66DD63L,0x30F1EC4CL,0xFB43F214L},{0x30F1EC4CL,0xFD2B2C47L,0xFE66DD63L,0L,0x68FA9819L,0x68FA9819L},{0xFD2B2C47L,1L,1L,0xFD2B2C47L,(-1L),0x68FA9819L},{(-9L),0x68FA9819L,0xFE66DD63L,0xFB43F214L,0L,0xFB43F214L},{(-1L),0x5E1B16F7L,(-1L),1L,0L,0x30F1EC4CL},{0xFE66DD63L,0x68FA9819L,(-9L),(-1L),(-1L),(-9L)},{1L,1L,0xFD2B2C47L,(-1L),0x68FA9819L,1L}},{{0xFE66DD63L,0xFD2B2C47L,0x30F1EC4CL,1L,0x30F1EC4CL,0xFD2B2C47L},{(-1L),0xFE66DD63L,0x30F1EC4CL,0xFB43F214L,1L,1L},{(-9L),0xFB43F214L,0xFD2B2C47L,0xFD2B2C47L,0xFB43F214L,(-9L)},{0xFD2B2C47L,0xFB43F214L,(-9L),0L,1L,0x30F1EC4CL},{0x30F1EC4CL,0xFE66DD63L,(-1L),0xFE66DD63L,0x30F1EC4CL,0xFB43F214L},{0x30F1EC4CL,0xFD2B2C47L,0xFE66DD63L,0L,0x68FA9819L,0x68FA9819L},{0xFD2B2C47L,1L,1L,1L,0xFB43F214L,0x30F1EC4CL}},{{(-1L),0x30F1EC4CL,0x5E1B16F7L,0xFD2B2C47L,0x68FA9819L,0xFD2B2C47L},{0xFB43F214L,0L,0xFB43F214L,0xFE66DD63L,0x68FA9819L,(-9L)},{0x5E1B16F7L,0x30F1EC4CL,(-1L),0xFB43F214L,0xFB43F214L,(-1L)},{1L,1L,1L,0xFB43F214L,0x30F1EC4CL,0xFE66DD63L},{0x5E1B16F7L,1L,(-9L),0xFE66DD63L,(-9L),1L},{0xFB43F214L,0x5E1B16F7L,(-9L),0xFD2B2C47L,1L,0xFE66DD63L},{(-1L),0xFD2B2C47L,1L,1L,0xFD2B2C47L,(-1L)}}};
                        uint8_t *l_828 = &g_169;
                        int i, j, k;
                    }
                }
                (**g_598) = ((((p_56 | p_56) || ((safe_rshift_func_uint64_t_u_s((&p_56 != (**g_810)), 44)) == 0xE3EE1754E3B3F979LL)) & (safe_mul_func_uint16_t_u_u(1UL, p_55))) & ((((!l_830) == (safe_sub_func_uint64_t_u_u(((safe_sub_func_uint32_t_u_u((((**g_736) = ((safe_mul_func_int32_t_s_s((l_844 |= ((l_843 = (p_56 < l_830)) | 0xB2L)), p_56)) > p_55)) >= p_55), 0xFF115DAAL)) && (*g_527)), 0xE22995FA702A3431LL))) , p_56) , l_844));
                (*l_846) = l_845;
            }
        }
        if (((safe_mod_func_uint64_t_u_u(0x2DBD9A4567622088LL, (0L ^ (-7L)))) > (safe_div_func_uint32_t_u_u((g_851 , ((0x3CB0AE59L >= ((safe_lshift_func_int16_t_s_s(l_823, (((safe_add_func_int16_t_s_s((!0UL), (safe_lshift_func_uint8_t_u_u((*g_788), (((-5L) > p_56) & 65534UL))))) && g_165[0][1]) , p_56))) != p_55)) > 5L)), p_55))))
        { /* block id: 331 */
            union U0 * const l_859 = (void*)0;
            (*g_860) = l_859;
        }
        else
        { /* block id: 333 */
            (*g_599) = (**g_598);
        }
    }
    for (g_158 = 7; (g_158 >= 0); g_158 -= 1)
    { /* block id: 339 */
        int8_t l_883 = (-3L);
        int32_t l_888 = 2L;
        int32_t l_894 = 1L;
        int32_t l_896 = (-5L);
        int32_t l_899 = 6L;
        if ((*g_157))
            break;
    }
    l_962 = &l_926[0][1][3];
    return p_55;
}


/* ------------------------------------------ */
/* 
 * reads : g_734
 * writes: g_735
 */
static int16_t * func_59(int16_t * p_60, int16_t * p_61, int64_t  p_62, int64_t  p_63, int32_t  p_64)
{ /* block id: 274 */
    int16_t *l_733 = &g_33;
    int16_t **l_732 = &l_733;
    int16_t ***l_731 = &l_732;
    (*g_734) = l_731;
    return p_61;
}


/* ------------------------------------------ */
/* 
 * reads : g_23 g_99 g_100 g_31 g_40 g_33 g_39 g_19 g_157 g_158 g_169 g_165 g_168 g_244
 * writes: g_23 g_100 g_31 g_39 g_19 g_158 g_169 g_244
 */
static int16_t * func_65(int64_t  p_66, int16_t  p_67, uint16_t  p_68, int8_t  p_69, int16_t * p_70)
{ /* block id: 15 */
    int16_t *l_113 = &g_33;
    int32_t l_124[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
    int32_t *l_180 = &g_23;
    int32_t **l_179 = &l_180;
    uint8_t l_207 = 0xBAL;
    uint32_t l_240 = 0x2F1F12ECL;
    const int16_t *l_259[9][5][2] = {{{&g_31,&g_31},{&g_33,&g_31},{&g_31,&g_33},{&g_31,&g_31},{&g_33,&g_31}},{{&g_31,&g_31},{&g_33,&g_31},{&g_31,&g_33},{&g_31,&g_31},{&g_33,&g_31}},{{&g_31,&g_31},{&g_33,&g_31},{&g_31,&g_33},{&g_31,&g_31},{&g_33,&g_31}},{{&g_31,&g_31},{&g_33,&g_31},{&g_31,&g_33},{&g_31,&g_31},{&g_33,&g_31}},{{&g_31,&g_31},{&g_33,&g_31},{&g_31,&g_33},{&g_31,&g_31},{&g_33,&g_31}},{{&g_31,&g_31},{&g_33,&g_31},{&g_31,&g_33},{&g_31,&g_31},{&g_33,&g_31}},{{&g_31,&g_31},{&g_33,&g_31},{&g_31,&g_33},{&g_31,&g_31},{&g_33,&g_31}},{{&g_31,&g_31},{&g_33,&g_31},{&g_31,&g_33},{&g_31,&g_31},{&g_33,&g_31}},{{&g_31,&g_31},{&g_33,&g_31},{&g_31,&g_33},{&g_31,&g_31},{&g_33,&g_31}}};
    const int16_t **l_258 = &l_259[0][3][1];
    const uint32_t l_293 = 4294967290UL;
    int16_t l_442 = (-1L);
    uint8_t l_443 = 3UL;
    uint16_t l_480 = 0x290FL;
    int64_t **l_565 = &g_445[7][3];
    uint16_t l_605 = 0xC970L;
    uint32_t l_646 = 0x4AD64E58L;
    int i, j, k;
    for (p_66 = 0; (p_66 != 22); p_66++)
    { /* block id: 18 */
        uint64_t l_91[7][4] = {{18446744073709551615UL,0x457BBF0BED92BB84LL,18446744073709551613UL,18446744073709551613UL},{0x41160C006E742402LL,0x41160C006E742402LL,18446744073709551615UL,18446744073709551613UL},{18446744073709551612UL,0x457BBF0BED92BB84LL,18446744073709551612UL,18446744073709551615UL},{18446744073709551612UL,18446744073709551615UL,18446744073709551615UL,18446744073709551612UL},{0x41160C006E742402LL,18446744073709551615UL,18446744073709551613UL,18446744073709551615UL},{18446744073709551615UL,0x457BBF0BED92BB84LL,18446744073709551613UL,18446744073709551613UL},{0x41160C006E742402LL,0x41160C006E742402LL,18446744073709551615UL,18446744073709551613UL}};
        const uint32_t l_123 = 0xFE1997BDL;
        int32_t *l_125 = &g_100;
        int64_t l_154 = 0xE5F25790E88B3BFFLL;
        int32_t l_161 = 0x1D071B3EL;
        int32_t l_162 = 0L;
        int32_t l_167 = 0x3798E47AL;
        int i, j;
        if ((((void*)0 != &g_33) && p_67))
        { /* block id: 19 */
            int32_t *l_88 = &g_23;
            int32_t *l_89 = &g_23;
            int32_t *l_90[2];
            int i;
            for (i = 0; i < 2; i++)
                l_90[i] = &g_23;
            l_91[5][2]--;
        }
        else
        { /* block id: 21 */
            const uint64_t l_95[10] = {5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL,5UL};
            int32_t l_164 = 1L;
            int32_t l_166 = (-1L);
            int i;
            if ((!l_95[1]))
            { /* block id: 22 */
                int32_t l_98 = 1L;
                int8_t l_160 = 1L;
                int32_t l_163 = 0x888E0995L;
                int32_t * const *l_178 = &l_125;
                for (g_23 = 0; (g_23 <= (-19)); g_23 = safe_sub_func_int16_t_s_s(g_23, 1))
                { /* block id: 25 */
                    (*g_99) = l_98;
                }
                if ((safe_unary_minus_func_int64_t_s((!(safe_mul_func_uint32_t_u_u((safe_rshift_func_int32_t_s_u(5L, 6)), (*g_99)))))))
                { /* block id: 28 */
                    int32_t *l_122 = &g_23;
                    int32_t *l_159[6] = {&l_98,(void*)0,&l_98,&l_98,(void*)0,&l_98};
                    int i;
                    for (g_31 = 6; (g_31 >= 2); g_31 -= 1)
                    { /* block id: 31 */
                        int16_t **l_114 = &l_113;
                        int32_t l_119 = 0x49E5CE90L;
                        int32_t *l_121[5][2] = {{&l_98,(void*)0},{&l_98,(void*)0},{&l_98,(void*)0},{&l_98,(void*)0},{&l_98,(void*)0}};
                        int32_t **l_120 = &l_121[2][1];
                        int i, j;
                        if (p_67)
                            break;
                        if (p_67)
                            continue;
                        l_125 = (((l_98 >= 1L) < ((safe_lshift_func_uint16_t_u_u((g_39[g_31] ^= (0x6DL & (((safe_rshift_func_int64_t_s_s(((safe_sub_func_int8_t_s_s((((*l_114) = l_113) == &g_31), ((safe_sub_func_uint64_t_u_u((((safe_mul_func_int8_t_s_s(((*g_99) ^ (l_119 | (((*l_120) = &g_100) != l_122))), p_66)) < p_66) < g_23), g_40)) != 18446744073709551606UL))) < g_33), g_23)) ^ 1L) >= l_123))), p_68)) < l_124[0])) , &g_23);
                        if (p_69)
                            continue;
                    }
                    for (g_19 = 0; (g_19 == 37); g_19 = safe_add_func_int8_t_s_s(g_19, 2))
                    { /* block id: 42 */
                        int64_t *l_152 = (void*)0;
                        int32_t l_153 = 0xBD6C5452L;
                        int32_t *l_156 = (void*)0;
                        (*g_157) ^= (safe_add_func_int32_t_s_s((safe_sub_func_int8_t_s_s(l_124[0], (5L < ((safe_sub_func_int8_t_s_s(g_33, ((l_153 = (p_66 ^ (safe_mod_func_int16_t_s_s((p_68 | (safe_sub_func_int64_t_s_s(((safe_add_func_uint64_t_u_u(((((safe_rshift_func_int64_t_s_u(g_19, (safe_sub_func_int8_t_s_s(((safe_sub_func_uint64_t_u_u((safe_mod_func_int16_t_s_s(((safe_div_func_uint64_t_u_u((safe_mul_func_uint64_t_u_u((((&g_99 == (void*)0) || ((*l_125) &= 0xCCF3C38EL)) > 0x3939L), p_67)), 0x0A8A208FD8E19E2ELL)) > g_19), l_124[0])), 0xE517F063A1A89D35LL)) <= g_31), 0x72L)))) == 0L) > 0L) > 255UL), 18446744073709551615UL)) || 0xD18CL), (-6L)))), g_31)))) | p_69))) <= l_154)))), p_69));
                    }
                    g_169++;
                }
                else
                { /* block id: 48 */
                    if (((p_68 || ((-1L) | (0xBE3FBEB0L == (p_68 | 0x6AL)))) ^ (-9L)))
                    { /* block id: 49 */
                        return &g_33;
                    }
                    else
                    { /* block id: 51 */
                        uint32_t l_174 = 0xAB3D763EL;
                        int32_t ***l_181 = &l_179;
                        (*l_180) = (safe_sub_func_uint32_t_u_u(((l_174 == l_163) > l_124[0]), (safe_add_func_int8_t_s_s(((l_174 ^ (+((l_174 , 0L) > (l_178 == ((*l_181) = l_179))))) || (safe_add_func_int8_t_s_s(4L, (-1L)))), p_68))));
                    }
                    (**l_178) = 1L;
                    if ((**l_178))
                        break;
                }
                return &g_33;
            }
            else
            { /* block id: 59 */
                uint16_t *l_191 = &g_39[6];
                int32_t *l_196 = &g_100;
                int32_t *l_197 = (void*)0;
                int32_t *l_198 = &l_164;
                int32_t *l_199 = &l_161;
                int32_t *l_200 = (void*)0;
                int32_t *l_201 = &l_164;
                int32_t *l_202 = &l_162;
                int32_t *l_203[10] = {&g_158,&g_158,&g_23,&l_161,&g_23,&g_158,&g_158,&g_23,&l_161,&g_23};
                uint32_t l_204 = 4UL;
                int i;
                (**l_179) = (safe_mul_func_int16_t_s_s(((~p_68) || ((safe_lshift_func_uint64_t_u_s((safe_rshift_func_int32_t_s_s(1L, 18)), 25)) , (++(*l_191)))), (safe_mod_func_int8_t_s_s((*l_125), 6L))));
                ++l_204;
                (*l_198) ^= l_207;
                if (((*l_125) &= p_69))
                { /* block id: 65 */
                    if ((*g_157))
                        break;
                    (*l_202) = (l_95[5] & (safe_mul_func_int64_t_s_s((((p_68 < l_166) || ((*p_70) = (~(safe_add_func_int32_t_s_s((*l_198), (safe_add_func_uint16_t_u_u(((&l_203[6] != (void*)0) && p_66), (*p_70)))))))) == ((**l_179) == (*g_99))), g_23)));
                }
                else
                { /* block id: 69 */
                    int32_t **l_234 = &l_198;
                    uint32_t l_237 = 0x46280EF9L;
                    int8_t *l_238[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_238[i] = &g_239;
                    (*l_199) &= (((*l_125) ^= (safe_add_func_uint64_t_u_u(g_33, (((safe_mul_func_uint64_t_u_u(((safe_lshift_func_uint64_t_u_u((+(((((l_240 &= (safe_mod_func_int8_t_s_s(g_31, ((((safe_lshift_func_int8_t_s_u(g_165[1][0], (safe_rshift_func_int32_t_s_s(g_158, 5)))) , (safe_div_func_uint64_t_u_u(7UL, (safe_lshift_func_uint8_t_u_u(g_165[0][1], 1))))) || ((((void*)0 != l_234) , (safe_rshift_func_uint32_t_u_u(((l_237 && (-5L)) | (**l_234)), p_69))) <= p_69)) , 7L)))) || p_66) && g_168) == 1UL) , 65535UL)), p_68)) , p_68), 0x98484EA1F2CDD552LL)) != g_31) ^ p_66)))) | (**l_179));
                    for (l_237 = 0; (l_237 <= 38); l_237 = safe_add_func_uint8_t_u_u(l_237, 1))
                    { /* block id: 75 */
                        int16_t l_243 = 0x8471L;
                        g_244++;
                    }
                }
            }
        }
    }
    for (l_240 = 0; (l_240 >= 24); l_240++)
    { /* block id: 84 */
        int16_t l_255 = (-1L);
        const int16_t ***l_260 = (void*)0;
        const int16_t ***l_261 = &l_258;
        int16_t * const l_264 = &g_265;
        int16_t * const *l_263 = &l_264;
        int16_t * const **l_262[1];
        int64_t *l_267 = &g_268;
        int64_t *l_269[10] = {&g_270,&g_270,&g_270,&g_270,&g_270,&g_270,&g_270,&g_270,&g_270,&g_270};
        int32_t l_271[4][4][2] = {{{9L,9L},{9L,1L},{(-1L),(-1L)},{1L,(-1L)}},{{(-1L),1L},{9L,9L},{9L,1L},{(-1L),(-1L)}},{{1L,(-1L)},{(-1L),1L},{9L,9L},{9L,1L}},{{(-1L),(-1L)},{1L,(-1L)},{(-1L),1L},{9L,9L}}};
        uint64_t *l_272[1][2][7] = {{{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273,&g_273},{&g_273,&g_273,&g_273,&g_273,&g_273,&g_273,&g_273}}};
        int16_t l_312 = 0xC5F0L;
        int8_t *l_412 = &g_279[6];
        const int64_t l_422[10][7] = {{(-8L),5L,(-6L),5L,(-8L),(-1L),0xAA462603D80BB3D1LL},{0xAA462603D80BB3D1LL,5L,5L,1L,0xF15E46916117551BLL,0L,0x1BE30D7236005EBFLL},{5L,1L,0xF15E46916117551BLL,0xA873BF1479107913LL,(-6L),(-6L),0xA873BF1479107913LL},{0xAA462603D80BB3D1LL,1L,0xAA462603D80BB3D1LL,(-6L),1L,1L,0xA873BF1479107913LL},{(-8L),0L,0L,(-1L),0xA873BF1479107913LL,0xAA462603D80BB3D1LL,0x1BE30D7236005EBFLL},{0L,0xAA462603D80BB3D1LL,1L,0L,0L,1L,0xAA462603D80BB3D1LL},{0x1BE30D7236005EBFLL,0xA932F1ED42EEBEE6LL,(-1L),0L,0L,(-6L),(-5L)},{1L,(-8L),0xA932F1ED42EEBEE6LL,5L,0xA873BF1479107913LL,0L,(-1L)},{(-1L),1L,0L,0L,1L,(-1L),1L},{0xA932F1ED42EEBEE6LL,(-1L),0L,0L,(-6L),(-5L),1L}};
        int32_t *l_454 = &l_124[0];
        int32_t **l_453 = &l_454;
        int32_t l_459 = 0x4D9FC251L;
        uint32_t l_482 = 18446744073709551608UL;
        int32_t l_626[9] = {0L,1L,0L,1L,0L,1L,0L,1L,0L};
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_262[i] = &l_263;
    }
    return &g_31;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_19, "g_19", print_hash_value);
    transparent_crc(g_23, "g_23", print_hash_value);
    transparent_crc(g_31, "g_31", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_39[i], "g_39[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_40, "g_40", print_hash_value);
    transparent_crc(g_73.f0, "g_73.f0", print_hash_value);
    transparent_crc(g_100, "g_100", print_hash_value);
    transparent_crc(g_158, "g_158", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 2; j++)
        {
            transparent_crc(g_165[i][j], "g_165[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_168, "g_168", print_hash_value);
    transparent_crc(g_169, "g_169", print_hash_value);
    transparent_crc(g_239, "g_239", print_hash_value);
    transparent_crc(g_244, "g_244", print_hash_value);
    transparent_crc(g_265, "g_265", print_hash_value);
    transparent_crc(g_268, "g_268", print_hash_value);
    transparent_crc(g_270, "g_270", print_hash_value);
    transparent_crc(g_273, "g_273", print_hash_value);
    transparent_crc(g_276, "g_276", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_279[i], "g_279[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_314, "g_314", print_hash_value);
    transparent_crc(g_316, "g_316", print_hash_value);
    transparent_crc(g_317, "g_317", print_hash_value);
    transparent_crc(g_353, "g_353", print_hash_value);
    transparent_crc(g_354, "g_354", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_356[i], "g_356[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_383, "g_383", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_386[i], "g_386[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_424, "g_424", print_hash_value);
    transparent_crc(g_428, "g_428", print_hash_value);
    transparent_crc(g_503, "g_503", print_hash_value);
    transparent_crc(g_524, "g_524", print_hash_value);
    transparent_crc(g_528, "g_528", print_hash_value);
    transparent_crc(g_544.f0, "g_544.f0", print_hash_value);
    transparent_crc(g_584, "g_584", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_585[i], "g_585[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_590.f0, "g_590.f0", print_hash_value);
    transparent_crc(g_666, "g_666", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_698[i][j].f0, "g_698[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 8; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_801[i][j][k].f0, "g_801[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_813, "g_813", print_hash_value);
    transparent_crc(g_851.f0, "g_851.f0", print_hash_value);
    transparent_crc(g_918.f0, "g_918.f0", print_hash_value);
    transparent_crc(g_932, "g_932", print_hash_value);
    transparent_crc(g_977, "g_977", print_hash_value);
    transparent_crc(g_1136, "g_1136", print_hash_value);
    transparent_crc(g_1139, "g_1139", print_hash_value);
    transparent_crc(g_1187, "g_1187", print_hash_value);
    transparent_crc(g_1225.f0, "g_1225.f0", print_hash_value);
    transparent_crc(g_1274, "g_1274", print_hash_value);
    transparent_crc(g_1330, "g_1330", print_hash_value);
    transparent_crc(g_1414, "g_1414", print_hash_value);
    transparent_crc(g_1518, "g_1518", print_hash_value);
    transparent_crc(g_1548, "g_1548", print_hash_value);
    transparent_crc(g_1575, "g_1575", print_hash_value);
    transparent_crc(g_1647, "g_1647", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 364
XXX total union variables: 8

XXX non-zero bitfields defined in structs: 1
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 14
breakdown:
   indirect level: 0, occurrence: 8
   indirect level: 1, occurrence: 2
   indirect level: 2, occurrence: 2
   indirect level: 3, occurrence: 2
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 2
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 13
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 45
breakdown:
   depth: 1, occurrence: 122
   depth: 2, occurrence: 37
   depth: 3, occurrence: 3
   depth: 4, occurrence: 2
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3
   depth: 8, occurrence: 1
   depth: 9, occurrence: 1
   depth: 12, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1
   depth: 16, occurrence: 2
   depth: 17, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 2
   depth: 23, occurrence: 4
   depth: 24, occurrence: 3
   depth: 27, occurrence: 1
   depth: 28, occurrence: 1
   depth: 29, occurrence: 2
   depth: 31, occurrence: 1
   depth: 32, occurrence: 1
   depth: 34, occurrence: 1
   depth: 45, occurrence: 1

XXX total number of pointers: 380

XXX times a variable address is taken: 877
XXX times a pointer is dereferenced on RHS: 201
breakdown:
   depth: 1, occurrence: 138
   depth: 2, occurrence: 44
   depth: 3, occurrence: 18
   depth: 4, occurrence: 1
XXX times a pointer is dereferenced on LHS: 200
breakdown:
   depth: 1, occurrence: 160
   depth: 2, occurrence: 34
   depth: 3, occurrence: 6
XXX times a pointer is compared with null: 24
XXX times a pointer is compared with address of another variable: 6
XXX times a pointer is compared with another pointer: 8
XXX times a pointer is qualified to be dereferenced: 4412

XXX max dereference level: 4
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 619
   level: 2, occurrence: 221
   level: 3, occurrence: 57
   level: 4, occurrence: 7
XXX number of pointers point to pointers: 136
XXX number of pointers point to scalars: 241
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 23.9
XXX average alias set size: 1.36

XXX times a non-volatile is read: 1183
XXX times a non-volatile is write: 602
XXX times a volatile is read: 97
XXX    times read thru a pointer: 22
XXX times a volatile is write: 18
XXX    times written thru a pointer: 0
XXX times a volatile is available for access: 2.3e+03
XXX percentage of non-volatile access: 93.9

XXX forward jumps: 0
XXX backward jumps: 4

XXX stmts: 140
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 31
   depth: 1, occurrence: 20
   depth: 2, occurrence: 21
   depth: 3, occurrence: 24
   depth: 4, occurrence: 23
   depth: 5, occurrence: 21

XXX percentage a fresh-made variable is used: 18.7
XXX percentage an existing variable is used: 81.3
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

