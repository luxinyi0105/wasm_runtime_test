/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      989842095
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   int32_t  f0;
   const int8_t  f1;
};

/* --- GLOBAL VARIABLES --- */
static uint32_t g_2 = 0x84C506D4L;
static int32_t g_4[9][3] = {{9L,9L,9L},{1L,5L,1L},{9L,9L,9L},{1L,5L,1L},{9L,9L,9L},{1L,5L,1L},{9L,9L,9L},{1L,5L,1L},{9L,9L,9L}};
static int16_t g_11 = 7L;
static int32_t g_53 = 0xBC41BBBBL;
static uint32_t g_63 = 18446744073709551615UL;
static uint32_t g_66 = 3UL;
static int8_t g_74[6][6] = {{0xECL,0x65L,0xE9L,0xE9L,0x65L,0xECL},{0x7BL,0x9BL,0xD2L,0x89L,0xECL,0x72L},{0x65L,0xB0L,(-1L),0xECL,(-1L),0xB0L},{0x65L,0xD2L,0L,0xE9L,(-1L),0x72L},{0x9BL,0L,0L,0x65L,0x65L,0L},{0L,0L,0xB0L,0x9BL,(-1L),0x65L}};
static uint64_t g_91 = 3UL;
static int32_t *g_95 = &g_53;
static int64_t g_119 = 1L;
static uint32_t g_120 = 0x79244252L;
static int32_t *g_121 = &g_53;
static uint16_t g_147[1] = {0UL};
static uint8_t g_162 = 0x37L;
static int32_t g_167 = 0x9ED47904L;
static uint8_t g_168[3][3][7] = {{{0xD3L,0xD7L,0xD7L,0xD3L,0xD3L,0xD7L,0xD7L},{255UL,0x12L,255UL,0x12L,255UL,0x12L,255UL},{0xD3L,0xD3L,0xD7L,0xD7L,0xD3L,0xD3L,0xD7L}},{{0x48L,0x12L,0x48L,0x12L,0x48L,0x12L,0x48L},{0xD3L,0xD7L,0xD7L,0xD3L,0xD3L,0xD7L,0xD7L},{255UL,0x12L,255UL,0x12L,255UL,0x12L,255UL}},{{0xD3L,0xD3L,0xD7L,0xD7L,0xD3L,0xD3L,0xD7L},{0x48L,0x12L,0x48L,0x12L,0x48L,0x12L,0x48L},{0xD3L,0xD7L,0xD7L,0xD3L,0xD3L,0xD7L,0xD7L}}};
static volatile uint64_t g_186 = 0x9E6B8C764DEBD41BLL;/* VOLATILE GLOBAL g_186 */
static union U0 g_190 = {0xD217F2CAL};
static union U0 * volatile g_189 = &g_190;/* VOLATILE GLOBAL g_189 */
static union U0 * volatile * volatile g_191[10] = {&g_189,&g_189,&g_189,&g_189,&g_189,&g_189,&g_189,&g_189,&g_189,&g_189};
static union U0 * volatile * volatile g_192 = &g_189;/* VOLATILE GLOBAL g_192 */
static int32_t ** volatile g_195[2][2] = {{&g_121,&g_121},{&g_121,&g_121}};
static int32_t ** volatile g_196 = &g_95;/* VOLATILE GLOBAL g_196 */
static int8_t * volatile * const g_204 = (void*)0;
static int8_t * volatile g_207 = &g_74[4][1];/* VOLATILE GLOBAL g_207 */
static int8_t * volatile *g_206 = &g_207;
static int8_t * volatile ** volatile g_205 = &g_206;/* VOLATILE GLOBAL g_205 */
static uint32_t g_366 = 0UL;
static int64_t * volatile g_381 = (void*)0;/* VOLATILE GLOBAL g_381 */
static int64_t * volatile * volatile g_380 = &g_381;/* VOLATILE GLOBAL g_380 */
static uint32_t g_387 = 0xEB14B404L;
static int32_t ** volatile g_423[7] = {&g_121,&g_121,&g_121,&g_121,&g_121,&g_121,&g_121};
static uint16_t g_425 = 0xB1B0L;
static int32_t * volatile g_431 = &g_190.f0;/* VOLATILE GLOBAL g_431 */
static union U0 g_499 = {0x778C0CBDL};
static uint32_t g_504 = 0x52DA53EEL;
static uint64_t *g_521 = &g_91;
static uint64_t ** const  volatile g_520 = &g_521;/* VOLATILE GLOBAL g_520 */
static int16_t g_549 = (-10L);
static int16_t *g_578 = &g_549;
static int16_t **g_577 = &g_578;
static int16_t ***g_576[8][9][3] = {{{&g_577,(void*)0,(void*)0},{&g_577,(void*)0,&g_577},{&g_577,(void*)0,&g_577},{(void*)0,&g_577,&g_577},{&g_577,&g_577,(void*)0},{&g_577,&g_577,(void*)0},{&g_577,&g_577,(void*)0},{&g_577,&g_577,&g_577},{(void*)0,&g_577,&g_577}},{{&g_577,&g_577,&g_577},{&g_577,&g_577,(void*)0},{&g_577,(void*)0,(void*)0},{&g_577,(void*)0,(void*)0},{&g_577,&g_577,&g_577},{(void*)0,(void*)0,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,(void*)0,(void*)0}},{{&g_577,(void*)0,&g_577},{(void*)0,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,(void*)0,(void*)0},{&g_577,(void*)0,&g_577},{&g_577,(void*)0,&g_577},{&g_577,(void*)0,&g_577},{&g_577,&g_577,(void*)0}},{{&g_577,&g_577,&g_577},{&g_577,&g_577,(void*)0},{&g_577,(void*)0,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,(void*)0},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577}},{{&g_577,&g_577,&g_577},{(void*)0,&g_577,&g_577},{&g_577,&g_577,&g_577},{(void*)0,(void*)0,(void*)0},{&g_577,&g_577,&g_577},{&g_577,(void*)0,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577}},{{(void*)0,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,(void*)0},{(void*)0,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,(void*)0,&g_577},{(void*)0,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577}},{{(void*)0,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,(void*)0},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{(void*)0,&g_577,&g_577},{&g_577,(void*)0,(void*)0},{(void*)0,&g_577,&g_577}},{{&g_577,(void*)0,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577},{&g_577,&g_577,&g_577}}};
static int64_t g_661[3] = {6L,6L,6L};
static int16_t ****g_666 = &g_576[4][1][1];
static int16_t ***** volatile g_665 = &g_666;/* VOLATILE GLOBAL g_665 */
static uint8_t *g_715 = (void*)0;
static uint8_t **g_714[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static uint8_t *** volatile g_713[8] = {&g_714[0],&g_714[0],&g_714[0],&g_714[0],&g_714[0],&g_714[0],&g_714[0],&g_714[0]};
static volatile uint32_t g_720 = 1UL;/* VOLATILE GLOBAL g_720 */
static volatile uint32_t * volatile g_719 = &g_720;/* VOLATILE GLOBAL g_719 */
static volatile uint32_t * volatile *g_718 = &g_719;
static union U0 * volatile * volatile g_744 = &g_189;/* VOLATILE GLOBAL g_744 */
static const uint16_t *g_801 = (void*)0;
static uint16_t *g_937[7] = {&g_147[0],&g_147[0],&g_147[0],&g_147[0],&g_147[0],&g_147[0],&g_147[0]};
static uint16_t **g_936 = &g_937[0];
static volatile int16_t g_949 = 0x12D8L;/* VOLATILE GLOBAL g_949 */
static int8_t g_956[2] = {0xE0L,0xE0L};
static union U0 g_976 = {-1L};
static union U0 *g_975 = &g_976;
static union U0 ** volatile g_982[10] = {(void*)0,&g_975,(void*)0,&g_975,(void*)0,&g_975,(void*)0,&g_975,(void*)0,&g_975};
static union U0 ** volatile g_983 = &g_975;/* VOLATILE GLOBAL g_983 */
static uint64_t g_1022 = 0x8E96CE6B629C2166LL;
static volatile uint32_t *g_1033 = (void*)0;
static volatile uint32_t * volatile * const g_1032[2][3] = {{&g_1033,&g_1033,&g_1033},{&g_1033,&g_1033,&g_1033}};
static int32_t **g_1096[8] = {&g_95,&g_95,&g_95,&g_95,&g_95,&g_95,&g_95,&g_95};
static int32_t ***g_1095 = &g_1096[2];
static int32_t * const **g_1097[2] = {(void*)0,(void*)0};
static int64_t ***g_1120 = (void*)0;
static int64_t **g_1122 = (void*)0;
static int64_t ***g_1121 = &g_1122;
static uint64_t **g_1166 = &g_521;
static int64_t g_1234 = 0xE94176C4DBBC0113LL;
static int16_t g_1282 = 0L;
static const union U0 g_1318 = {0xF5D6A690L};
static const union U0 g_1320 = {0L};
static const union U0 *g_1319 = &g_1320;
static volatile int64_t g_1360 = 8L;/* VOLATILE GLOBAL g_1360 */
static volatile int64_t *g_1359 = &g_1360;
static volatile int64_t * volatile * volatile g_1358[6][6] = {{&g_1359,(void*)0,(void*)0,&g_1359,(void*)0,(void*)0},{&g_1359,(void*)0,&g_1359,(void*)0,&g_1359,&g_1359},{(void*)0,&g_1359,&g_1359,&g_1359,(void*)0,(void*)0},{&g_1359,&g_1359,&g_1359,&g_1359,&g_1359,&g_1359},{&g_1359,&g_1359,&g_1359,&g_1359,&g_1359,&g_1359},{(void*)0,(void*)0,&g_1359,(void*)0,&g_1359,(void*)0}};
static volatile int64_t * volatile * volatile * volatile g_1357[8][1][7] = {{{&g_1358[4][4],&g_1358[3][0],&g_1358[4][4],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[0][1]}},{{&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0]}},{{&g_1358[3][0],&g_1358[3][0],&g_1358[0][1],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0]}},{{&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[4][4],(void*)0,&g_1358[3][0]}},{{&g_1358[3][0],(void*)0,&g_1358[0][1],&g_1358[4][4],&g_1358[4][4],&g_1358[0][1],(void*)0}},{{&g_1358[4][4],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0]}},{{&g_1358[3][0],&g_1358[3][0],&g_1358[4][4],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0]}},{{&g_1358[0][1],(void*)0,&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0],&g_1358[3][0]}}};
static volatile int64_t * volatile * volatile * volatile *g_1356 = &g_1357[4][0][3];
static volatile int64_t * volatile * volatile * volatile * volatile *g_1355 = &g_1356;
static int64_t *g_1628 = &g_119;
static int64_t * const *g_1627 = &g_1628;
static int64_t * const **g_1626 = &g_1627;
static int64_t * const ***g_1625 = &g_1626;
static uint32_t g_1639 = 2UL;
static const union U0 g_1650 = {0x1D4AE841L};
static int8_t *g_1759[3] = {&g_956[0],&g_956[0],&g_956[0]};
static int8_t **g_1758 = &g_1759[2];
static int8_t ***g_1757 = &g_1758;
static int8_t ****g_1756 = &g_1757;
static int32_t g_1766 = 0x9D42130EL;
static uint32_t *g_1768 = &g_387;
static uint32_t ** volatile g_1767 = &g_1768;/* VOLATILE GLOBAL g_1767 */
static int32_t g_1781 = 1L;
static volatile union U0 g_1864 = {0xEEE2A88CL};/* VOLATILE GLOBAL g_1864 */
static const volatile union U0 *g_1863 = &g_1864;
static int32_t * volatile g_1870 = &g_499.f0;/* VOLATILE GLOBAL g_1870 */
static uint16_t g_1912 = 6UL;
static uint16_t g_1914 = 0x71EDL;
static int8_t g_1984 = 4L;
static int32_t g_2029 = 4L;
static uint32_t *g_2036 = &g_63;
static uint32_t **g_2035 = &g_2036;
static volatile int32_t * volatile g_2053 = &g_1864.f0;/* VOLATILE GLOBAL g_2053 */
static volatile int32_t * volatile * volatile g_2054 = &g_2053;/* VOLATILE GLOBAL g_2054 */
static uint32_t g_2097 = 1UL;
static volatile int32_t * volatile * volatile g_2126 = &g_2053;/* VOLATILE GLOBAL g_2126 */
static int32_t g_2175 = (-2L);
static int16_t *****g_2181 = &g_666;
static uint64_t g_2204 = 18446744073709551615UL;
static uint64_t * const g_2203 = &g_2204;
static uint64_t * const *g_2202[1][4] = {{&g_2203,&g_2203,&g_2203,&g_2203}};
static uint64_t * const **g_2201 = &g_2202[0][0];
static int8_t g_2239 = 0xE1L;
static volatile int8_t g_2338[1] = {0xEBL};
static int32_t ****g_2403 = &g_1095;
static int32_t *****g_2402 = &g_2403;
static volatile uint64_t ** volatile *** volatile g_2454 = (void*)0;/* VOLATILE GLOBAL g_2454 */


/* --- FORWARD DECLARATIONS --- */
static int32_t  func_1(void);
static int8_t  func_5(int32_t * p_6, uint32_t  p_7, uint32_t  p_8, int32_t * p_9);
static int32_t ** func_12(int32_t  p_13, int32_t * p_14, int32_t * p_15, int32_t ** p_16, int32_t * p_17);
static int32_t * func_20(int32_t * p_21, int32_t ** p_22, int32_t ** p_23, union U0  p_24);
static int32_t * func_25(int32_t  p_26, int32_t * p_27, int32_t  p_28);
static int32_t  func_31(uint16_t  p_32, union U0  p_33, int32_t ** p_34, uint8_t  p_35);
static int32_t ** func_37(const int32_t * p_38, int32_t  p_39, const uint16_t  p_40, int32_t  p_41);
static const int32_t * func_42(int16_t  p_43, int32_t  p_44, int32_t ** p_45, const int32_t ** p_46);
static uint64_t  func_47(int16_t  p_48, int32_t * const * p_49);
static int64_t  func_79(int8_t  p_80, int8_t * p_81, int8_t  p_82, uint32_t  p_83);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_2 g_4 g_121 g_53
 * writes: g_4
 */
static int32_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_3 = &g_4[4][2];
    uint32_t l_10 = 0x06EC6E54L;
    union U0 l_36[3] = {{0xD7BA9668L},{0xD7BA9668L},{0xD7BA9668L}};
    uint8_t l_1611 = 0x7BL;
    int32_t l_1633 = 0x6E05E5FFL;
    const union U0 *l_1649 = &g_1650;
    uint64_t *l_1661 = &g_1022;
    uint64_t *l_1662 = &g_1022;
    int16_t ****l_1680 = &g_576[1][1][1];
    int32_t l_1686[9] = {0L,0x5768058EL,0L,0L,0x5768058EL,0L,0L,0x5768058EL,0L};
    uint32_t l_1687 = 4294967288UL;
    int16_t l_1690[9];
    uint32_t l_1729 = 0UL;
    union U0 *l_1739 = &g_976;
    const int32_t l_1748 = 0xA453722AL;
    uint32_t l_1749 = 4294967293UL;
    int8_t *l_1754[5];
    int8_t **l_1753 = &l_1754[2];
    int8_t ***l_1752 = &l_1753;
    int8_t ****l_1751[2][9][7] = {{{(void*)0,&l_1752,&l_1752,&l_1752,(void*)0,&l_1752,&l_1752},{&l_1752,(void*)0,(void*)0,&l_1752,&l_1752,&l_1752,&l_1752},{&l_1752,&l_1752,&l_1752,&l_1752,&l_1752,&l_1752,&l_1752},{&l_1752,&l_1752,&l_1752,&l_1752,(void*)0,&l_1752,&l_1752},{&l_1752,(void*)0,&l_1752,&l_1752,&l_1752,(void*)0,&l_1752},{(void*)0,&l_1752,(void*)0,&l_1752,&l_1752,&l_1752,&l_1752},{&l_1752,&l_1752,&l_1752,&l_1752,(void*)0,(void*)0,&l_1752},{(void*)0,&l_1752,(void*)0,&l_1752,&l_1752,&l_1752,&l_1752},{(void*)0,&l_1752,&l_1752,&l_1752,&l_1752,&l_1752,&l_1752}},{{&l_1752,(void*)0,&l_1752,&l_1752,(void*)0,&l_1752,&l_1752},{(void*)0,&l_1752,&l_1752,&l_1752,&l_1752,(void*)0,&l_1752},{&l_1752,&l_1752,(void*)0,&l_1752,&l_1752,&l_1752,(void*)0},{&l_1752,&l_1752,&l_1752,(void*)0,(void*)0,&l_1752,&l_1752},{(void*)0,&l_1752,(void*)0,&l_1752,&l_1752,&l_1752,&l_1752},{(void*)0,&l_1752,&l_1752,&l_1752,(void*)0,&l_1752,(void*)0},{&l_1752,&l_1752,&l_1752,&l_1752,&l_1752,&l_1752,&l_1752},{&l_1752,&l_1752,(void*)0,&l_1752,&l_1752,(void*)0,&l_1752},{&l_1752,&l_1752,&l_1752,(void*)0,&l_1752,(void*)0,&l_1752}}};
    int32_t ****l_1924[5][6] = {{(void*)0,(void*)0,&g_1095,(void*)0,(void*)0,&g_1095},{(void*)0,(void*)0,&g_1095,&g_1095,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1095,&g_1095,&g_1095,&g_1095},{(void*)0,(void*)0,&g_1095,(void*)0,&g_1095,(void*)0}};
    uint64_t l_1991 = 0xA7F0648BF60C3B00LL;
    uint16_t l_2010 = 65535UL;
    int8_t l_2099 = 0xE9L;
    int64_t l_2151 = 0x96C33DD0FE0B83C8LL;
    uint32_t l_2174 = 0x50D1AB45L;
    uint32_t l_2240[6][6][7] = {{{0xE8CCA444L,18446744073709551606UL,3UL,5UL,0x82ACCF28L,0x70717FBBL,18446744073709551615UL},{0x47940A57L,0x628359E5L,0UL,18446744073709551615UL,2UL,18446744073709551615UL,0x28FC5B07L},{0x657260AAL,0x5A3DE521L,0UL,18446744073709551610UL,0x03205632L,0x82ACCF28L,0x28FC5B07L},{18446744073709551609UL,6UL,0x4B207C9AL,18446744073709551615UL,0x28FC5B07L,0xFD44F726L,18446744073709551615UL},{0x7A269148L,0x775A96C6L,0x2290EEF7L,1UL,0xFD44F726L,18446744073709551609UL,18446744073709551615UL},{0UL,0x58883DD1L,5UL,0x28FC5B07L,0x1ABAB164L,0x60EF88C6L,0xE8CCA444L}},{{1UL,0x1ABAB164L,0UL,18446744073709551609UL,18446744073709551615UL,18446744073709551610UL,0xC871134AL},{0x4F0F703FL,0x53A3F4C5L,18446744073709551615UL,18446744073709551615UL,8UL,2UL,0xF9672033L},{18446744073709551607UL,0x4F0F703FL,0x60EF88C6L,0x49CD5ED0L,0xDF00AB33L,0x6D58B664L,0x6D58B664L},{0x2290EEF7L,18446744073709551615UL,8UL,18446744073709551615UL,0x2290EEF7L,0x94AC123BL,1UL},{2UL,18446744073709551610UL,18446744073709551615UL,0x94AC123BL,1UL,0x58883DD1L,1UL},{0xE8CCA444L,0xDF00AB33L,0x55A8382AL,18446744073709551607UL,0x3011E881L,0xC871134AL,5UL}},{{2UL,0x94AC123BL,18446744073709551609UL,0x55A8382AL,2UL,0x685ADDDFL,0x2BC36036L},{0x2290EEF7L,18446744073709551609UL,0x4F0F703FL,1UL,18446744073709551610UL,0x0CA1BD18L,0UL},{18446744073709551607UL,6UL,18446744073709551615UL,0x250231E9L,1UL,0x2290EEF7L,18446744073709551611UL},{0x4F0F703FL,1UL,0x657260AAL,18446744073709551613UL,0x60650AD4L,18446744073709551609UL,0x7A269148L},{1UL,0xC7592885L,18446744073709551615UL,0x4917781AL,0UL,0x60650AD4L,0xDF00AB33L},{0UL,0x41FE0419L,0UL,1UL,2UL,0x657260AAL,0x7A269148L}},{{0x075A61A1L,0x60EF88C6L,0x83895417L,0xF035D380L,0x628359E5L,18446744073709551607UL,0x657260AAL},{0xF035D380L,0x646F6970L,18446744073709551615UL,3UL,1UL,1UL,18446744073709551615UL},{18446744073709551611UL,0x646F6970L,2UL,18446744073709551614UL,2UL,0xC159EC5CL,0x6D58B664L},{18446744073709551615UL,0x60EF88C6L,18446744073709551615UL,1UL,0x03205632L,18446744073709551609UL,0x646F6970L},{18446744073709551613UL,18446744073709551610UL,0x41FE0419L,0xD1C93A55L,0xFD44F726L,0UL,18446744073709551615UL},{5UL,0x55A8382AL,0xE8CCA444L,9UL,0x26012B22L,18446744073709551615UL,0xC0017004L}},{{18446744073709551615UL,9UL,0x075A61A1L,0xE9873D04L,8UL,18446744073709551615UL,0x03205632L},{0xC7592885L,0x2BC36036L,0x628359E5L,0x906F5F45L,0xF9672033L,0x685ADDDFL,0x6A00F5B4L},{18446744073709551610UL,0xBCDE97C3L,0x47940A57L,0x4F0F703FL,0x47940A57L,0xBCDE97C3L,18446744073709551610UL},{0xDF00AB33L,0x775A96C6L,1UL,0x258F17E0L,18446744073709551613UL,18446744073709551615UL,0x70717FBBL},{0xBCDE97C3L,0xE26B3593L,0x70717FBBL,0xC9F86AEDL,0xD8C83411L,0x2290EEF7L,0x2FB09614L},{18446744073709551615UL,0x688B12C7L,1UL,18446744073709551615UL,0xD1C93A55L,0x83895417L,0x657260AAL}},{{0x94AC123BL,18446744073709551614UL,0x47940A57L,0x5A3DE521L,0xCFBFF3FEL,0x2FB09614L,0x4F0F703FL},{0x47940A57L,18446744073709551613UL,0x628359E5L,18446744073709551614UL,18446744073709551615UL,0x26012B22L,18446744073709551610UL},{0x1827E3B4L,18446744073709551615UL,0x075A61A1L,18446744073709551609UL,0xC0017004L,0xE2C88E4FL,1UL},{18446744073709551613UL,0xC871134AL,0xE8CCA444L,2UL,0x2290EEF7L,0x4F0F703FL,0x83895417L},{18446744073709551615UL,0UL,0x41FE0419L,0UL,0x26012B22L,1UL,0xF9672033L},{7UL,0x1ABAB164L,18446744073709551615UL,0xC0017004L,0x657260AAL,8UL,0x0CA1BD18L}}};
    int16_t l_2304 = 4L;
    int32_t *l_2355 = &g_976.f0;
    int16_t l_2371 = (-1L);
    int64_t l_2435[6][5] = {{5L,0L,0xE5C6B9971AD17905LL,(-5L),0L},{0x59700A65A28AB481LL,0xE5C6B9971AD17905LL,0xE5C6B9971AD17905LL,0x59700A65A28AB481LL,(-5L)},{0x5B81C32DA90C5504LL,0x59700A65A28AB481LL,9L,0L,0L},{5L,0x59700A65A28AB481LL,5L,(-5L),0x59700A65A28AB481LL},{0L,0xE5C6B9971AD17905LL,(-5L),0L,(-5L)},{0L,0L,9L,0x59700A65A28AB481LL,0x5B81C32DA90C5504LL}};
    int32_t l_2453 = 0x637FF1DAL;
    volatile uint64_t ** volatile *l_2457 = (void*)0;
    volatile uint64_t ** volatile **l_2456 = &l_2457;
    volatile uint64_t ** volatile *** volatile l_2455 = &l_2456;/* VOLATILE GLOBAL l_2455 */
    int i, j, k;
    for (i = 0; i < 9; i++)
        l_1690[i] = 0xBE58L;
    for (i = 0; i < 5; i++)
        l_1754[i] = &g_74[0][4];
    (*l_3) |= g_2;
    return (*g_121);
}


/* ------------------------------------------ */
/* 
 * reads : g_4 g_11
 * writes: g_11
 */
static int8_t  func_5(int32_t * p_6, uint32_t  p_7, uint32_t  p_8, int32_t * p_9)
{ /* block id: 2 */
    g_11 |= g_4[5][2];
    return g_11;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t ** func_12(int32_t  p_13, int32_t * p_14, int32_t * p_15, int32_t ** p_16, int32_t * p_17)
{ /* block id: 729 */
    int32_t **l_1614[6][6] = {{&g_95,&g_95,(void*)0,&g_95,&g_95,(void*)0},{&g_95,&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,(void*)0,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95,&g_95},{&g_95,&g_95,&g_95,&g_95,&g_95,(void*)0},{&g_95,(void*)0,&g_95,&g_95,(void*)0,&g_95}};
    int i, j;
    return l_1614[4][3];
}


/* ------------------------------------------ */
/* 
 * reads : g_387 g_1359 g_1360 g_578 g_549 g_207 g_74 g_53 g_4 g_95 g_1095 g_1096 g_206 g_719 g_720 g_520 g_521 g_91 g_121 g_504 g_167
 * writes: g_387 g_549 g_4 g_95 g_504 g_167
 */
static int32_t * func_20(int32_t * p_21, int32_t ** p_22, int32_t ** p_23, union U0  p_24)
{ /* block id: 656 */
    uint16_t l_1443 = 0xD4E3L;
    int16_t **l_1473 = &g_578;
    uint64_t l_1474 = 18446744073709551610UL;
    uint8_t *l_1475[5][1] = {{&g_168[1][2][4]},{&g_168[0][0][1]},{&g_168[1][2][4]},{&g_168[0][0][1]},{&g_168[1][2][4]}};
    int32_t l_1476 = 0x0D107688L;
    int32_t l_1477 = 0x7D017EB1L;
    int16_t *l_1478 = (void*)0;
    int16_t *l_1479[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
    int32_t l_1480 = 0xAC048A10L;
    int64_t l_1481 = 6L;
    int32_t *l_1483 = (void*)0;
    int32_t **l_1482[9] = {&l_1483,&l_1483,&l_1483,&l_1483,&l_1483,&l_1483,&l_1483,&l_1483,&l_1483};
    uint16_t l_1490 = 65526UL;
    uint32_t l_1492[6] = {0xA7657623L,1UL,0xA7657623L,0xA7657623L,1UL,0xA7657623L};
    int32_t *l_1592 = &g_499.f0;
    int8_t l_1598 = 4L;
    int32_t l_1599 = 0x4B957F8AL;
    int32_t l_1600 = (-7L);
    int32_t l_1601 = 1L;
    int32_t l_1602 = (-1L);
    int32_t l_1603 = 1L;
    int32_t l_1604 = 0xA5CEC90BL;
    int32_t l_1605 = 1L;
    int32_t l_1606[8] = {(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L),(-8L)};
    int i, j;
    (**p_22) ^= (!(+((safe_mod_func_int64_t_s_s((((l_1481 = ((l_1480 = (safe_mul_func_int8_t_s_s(0x2BL, ((l_1443 , (safe_mod_func_uint32_t_u_u((((safe_lshift_func_int8_t_s_u(((safe_mul_func_int16_t_s_s((((safe_add_func_uint8_t_u_u(p_24.f0, (safe_mul_func_int8_t_s_s((safe_div_func_uint32_t_u_u((--g_387), ((+((l_1477 = ((**l_1473) &= ((l_1476 = (safe_sub_func_uint32_t_u_u((safe_add_func_int32_t_s_s(((*g_1359) ^ (((l_1443 & (safe_sub_func_uint8_t_u_u(l_1443, (safe_add_func_int16_t_s_s((((safe_rshift_func_int32_t_s_u(((safe_mod_func_int8_t_s_s((l_1474 |= ((safe_mul_func_uint8_t_u_u((p_24.f0 , ((void*)0 != l_1473)), p_24.f0)) != p_24.f0)), l_1443)) && p_24.f0), 24)) , (void*)0) != (void*)0), l_1443))))) , l_1474) && 0x3329AB9DC5378F64LL)), (-7L))), 3L))) >= 0L))) > l_1443)) , l_1443))), p_24.f0)))) | 0xBA0BL) || p_24.f0), 0x2B48L)) , (*g_207)), l_1443)) != l_1443) < 0xE018DD36L), 4294967295UL))) < p_24.f0)))) , (*p_21))) , 65531UL) < (-4L)), l_1443)) != l_1443)));
    (**p_22) = (((void*)0 == l_1482[6]) , ((((((((**g_1095) = (*p_23)) == (void*)0) , 0x074AL) , (((safe_rshift_func_int8_t_s_s((**g_206), (p_24 , (safe_add_func_int8_t_s_s(1L, (safe_sub_func_int32_t_s_s((l_1490 > 0xD6CF3F39L), 4294967292UL))))))) || (*g_719)) , l_1480)) , l_1476) || (**g_520)) && 0L));
    (*g_121) = 0xC7357238L;
    for (g_504 = 0; (g_504 <= 8); g_504 += 1)
    { /* block id: 670 */
        uint64_t l_1496[2];
        int32_t l_1518 = 0x60C8A7C6L;
        uint16_t l_1539 = 0x288BL;
        int64_t l_1591 = 0xB42E489D748899EALL;
        int32_t l_1593 = 0xB4606141L;
        int32_t *l_1594 = &g_499.f0;
        int32_t *l_1595 = (void*)0;
        int32_t *l_1596 = &g_190.f0;
        int32_t *l_1597[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
        uint32_t l_1607[3][9][7] = {{{0x05F854E4L,0xC6736919L,0x3278771DL,0UL,0x8147B315L,4294967289UL,0x0E1083B2L},{4294967293UL,8UL,4294967295UL,0UL,0x5B67755FL,6UL,0x5B67755FL},{0UL,0UL,0UL,0UL,0x31BBE749L,0x0E1083B2L,1UL},{0xE0103218L,0x5B67755FL,4294967293UL,6UL,4294967295UL,0xA013FAE6L,0UL},{1UL,4294967294UL,0x0E1083B2L,0xC6736919L,0x0E1083B2L,4294967294UL,1UL},{4294967295UL,0x913FC6F7L,8UL,0UL,0xE0103218L,0xD7CF292BL,0x5B67755FL},{1UL,0UL,4294967290UL,0x0E1083B2L,0x05F854E4L,0x05F854E4L,0x0E1083B2L},{8UL,1UL,8UL,8UL,0xA013FAE6L,4294967291UL,0xD7CF292BL},{4294967294UL,4294967292UL,0x0E1083B2L,0UL,0UL,0x3278771DL,1UL}},{{4294967291UL,4294967295UL,4294967293UL,4294967293UL,4294967295UL,4294967291UL,4294967295UL},{0x8147B315L,0x0E1083B2L,0UL,0UL,4294967290UL,0x05F854E4L,0x31BBE749L},{0UL,4294967291UL,4294967295UL,0xD7CF292BL,0UL,0xD7CF292BL,4294967295UL},{0x0E1083B2L,0x0E1083B2L,0x3278771DL,4294967289UL,0UL,4294967294UL,0UL},{4294967295UL,4294967295UL,8UL,0xE0103218L,4294967295UL,0xA013FAE6L,0xA013FAE6L},{0UL,4294967292UL,1UL,4294967292UL,0UL,0x0E1083B2L,0UL},{4294967295UL,1UL,0UL,0x913FC6F7L,0UL,6UL,4294967291UL},{0xC6736919L,0UL,4294967289UL,4294967290UL,4294967290UL,4294967289UL,0UL},{4294967295UL,0x913FC6F7L,1UL,4294967295UL,4294967295UL,8UL,0xE0103218L}},{{0UL,4294967294UL,0UL,1UL,0UL,4294967290UL,0UL},{4294967295UL,0x5B67755FL,0x5B67755FL,4294967295UL,0xA013FAE6L,0xE0103218L,0UL},{0x0E1083B2L,0UL,0UL,4294967290UL,0x05F854E4L,0x31BBE749L,4294967292UL},{0UL,8UL,0UL,4294967295UL,0UL,0xA013FAE6L,0x913FC6F7L},{0UL,0UL,0x31BBE749L,0x0E1083B2L,1UL,1UL,0UL},{0UL,4294967291UL,4294967293UL,0UL,8UL,8UL,0UL},{0x31BBE749L,0UL,0x31BBE749L,0x8147B315L,0x3278771DL,4294967292UL,1UL},{0xA013FAE6L,0xE0103218L,0UL,4294967291UL,4294967295UL,0xD7CF292BL,0UL},{4294967292UL,0UL,4294967294UL,4294967294UL,0UL,4294967292UL,0x05F854E4L}}};
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_1496[i] = 0xD805832F618839EALL;
        if ((*p_21))
        { /* block id: 671 */
            int32_t l_1491[8] = {0xC2983A41L,0xC2983A41L,0xC2983A41L,0xC2983A41L,0xC2983A41L,0xC2983A41L,0xC2983A41L,0xC2983A41L};
            uint8_t l_1582[2];
            int i;
            for (i = 0; i < 2; i++)
                l_1582[i] = 2UL;
            l_1492[2]--;
            for (g_167 = 0; (g_167 <= 5); g_167 += 1)
            { /* block id: 675 */
                int32_t *l_1499 = &l_1480;
                int32_t l_1535 = 7L;
                int32_t l_1536 = 0xBCEE8104L;
                int32_t l_1537 = 0x10D50002L;
                int32_t l_1538 = (-1L);
            }
        }
        else
        { /* block id: 722 */
            return l_1592;
        }
        l_1607[1][5][0]--;
    }
    return (*p_23);
}


/* ------------------------------------------ */
/* 
 * reads : g_1095 g_1096 g_95 g_121
 * writes:
 */
static int32_t * func_25(int32_t  p_26, int32_t * p_27, int32_t  p_28)
{ /* block id: 397 */
    int32_t l_880 = 0x9B38FD81L;
    int32_t l_881 = 0L;
    int32_t l_884 = 0L;
    int16_t ****l_887 = &g_576[1][4][1];
    union U0 l_890 = {0x07F2B0D9L};
    int32_t ***l_896 = (void*)0;
    uint8_t **l_946 = &g_715;
    int32_t l_953 = 0xC36403C3L;
    int8_t *l_971 = &g_956[1];
    uint16_t **l_981[3][6] = {{&g_937[5],&g_937[5],&g_937[2],&g_937[2],&g_937[5],&g_937[5]},{&g_937[5],&g_937[2],&g_937[2],&g_937[5],&g_937[5],&g_937[2]},{&g_937[5],&g_937[5],&g_937[2],&g_937[2],&g_937[5],&g_937[5]}};
    const int32_t *l_993 = &l_884;
    uint32_t l_996 = 3UL;
    int16_t l_997 = 7L;
    uint32_t l_1008 = 0xD08DBF32L;
    union U0 *l_1048 = &g_190;
    uint32_t *l_1071 = &g_63;
    uint32_t **l_1070 = &l_1071;
    uint8_t l_1085 = 0UL;
    const int32_t *l_1195[9] = {&g_4[3][2],&g_4[3][2],&g_4[3][2],&g_4[3][2],&g_4[3][2],&g_4[3][2],&g_4[3][2],&g_4[3][2],&g_4[3][2]};
    const int32_t **l_1194[1][7][4] = {{{&l_1195[4],&l_1195[7],&l_1195[7],&l_1195[4]},{(void*)0,&l_1195[7],(void*)0,&l_1195[7]},{(void*)0,&l_1195[7],&l_1195[7],&l_1195[4]},{&l_1195[7],&l_1195[7],&l_1195[7],&l_1195[7]},{(void*)0,&l_1195[4],&l_1195[7],&l_1195[7]},{&l_1195[7],(void*)0,&l_1195[7],(void*)0},{(void*)0,&l_1195[7],(void*)0,(void*)0}}};
    uint16_t l_1199 = 1UL;
    int8_t **l_1203[4];
    int8_t ***l_1202 = &l_1203[1];
    int32_t l_1284 = 0x59F39B79L;
    int32_t l_1289 = (-1L);
    int32_t l_1290[7][7] = {{0xAF92911FL,(-1L),0x61504EDFL,0x61504EDFL,(-1L),0xAF92911FL,(-9L)},{(-1L),(-1L),0x8EAD8232L,5L,5L,0x8EAD8232L,(-1L)},{(-1L),(-9L),0xAF92911FL,(-1L),0x61504EDFL,0x61504EDFL,(-1L)},{0xAF92911FL,(-1L),0xAF92911FL,0x61504EDFL,(-1L),(-9L),(-9L)},{(-1L),(-1L),0x8EAD8232L,(-1L),(-1L),0x8EAD8232L,5L},{5L,(-9L),0x61504EDFL,5L,0x61504EDFL,(-9L),5L},{0xAF92911FL,5L,(-9L),0x61504EDFL,5L,0x61504EDFL,(-9L)}};
    uint32_t l_1291 = 0xBE2011B6L;
    union U0 *l_1321[3][5][10] = {{{&g_499,&g_976,&g_976,&g_499,&g_499,(void*)0,&g_976,&g_499,&l_890,&g_499},{(void*)0,&g_190,&l_890,&g_190,&l_890,&g_190,&g_976,&g_976,&l_890,&g_976},{&g_190,&g_499,(void*)0,&g_499,&g_190,&g_499,&l_890,(void*)0,&g_499,&g_190},{(void*)0,&g_499,&g_190,&l_890,&g_190,&l_890,&g_190,&g_190,&l_890,&g_190},{&g_190,(void*)0,&g_976,&g_499,&g_499,&g_499,&g_499,&g_499,&g_976,(void*)0}},{{(void*)0,&g_190,&g_499,&g_190,&l_890,&l_890,&g_499,&g_976,&l_890,&g_499},{(void*)0,&g_190,&g_499,&g_499,&g_976,&l_890,(void*)0,&g_190,(void*)0,(void*)0},{(void*)0,&g_499,(void*)0,&g_190,&g_976,&g_499,&l_890,&g_190,&g_499,&g_499},{&g_190,&g_976,&g_499,&l_890,&g_499,&l_890,&g_499,&g_499,&g_499,&g_499},{(void*)0,&g_190,&l_890,&g_190,&g_190,&l_890,&g_190,(void*)0,&g_499,(void*)0}},{{(void*)0,&g_976,&g_190,&l_890,&g_499,&l_890,&g_976,&g_499,&g_499,&g_190},{&l_890,&g_499,&g_190,&g_499,(void*)0,&g_499,(void*)0,(void*)0,&g_976,&g_499},{&g_190,&g_499,&l_890,(void*)0,&l_890,(void*)0,(void*)0,&g_499,(void*)0,&l_890},{&g_976,&g_499,&g_499,&l_890,(void*)0,&g_976,&g_976,&g_190,&g_976,&g_976},{&g_190,(void*)0,(void*)0,(void*)0,&g_190,&g_976,&g_499,&g_190,&g_499,(void*)0}}};
    uint32_t l_1391 = 18446744073709551615UL;
    union U0 l_1431 = {0x3377AA09L};
    int i, j, k;
    for (i = 0; i < 4; i++)
        l_1203[i] = (void*)0;
    return (**g_1095);
}


/* ------------------------------------------ */
/* 
 * reads : g_121
 * writes: g_121
 */
static int32_t  func_31(uint16_t  p_32, union U0  p_33, int32_t ** p_34, uint8_t  p_35)
{ /* block id: 394 */
    uint8_t l_866 = 0x22L;
    (*p_34) = (*p_34);
    return l_866;
}


/* ------------------------------------------ */
/* 
 * reads : g_11 g_66
 * writes: g_11 g_66
 */
static int32_t ** func_37(const int32_t * p_38, int32_t  p_39, const uint16_t  p_40, int32_t  p_41)
{ /* block id: 381 */
    uint16_t l_861 = 0xC7B4L;
    int32_t **l_864 = &g_121;
    for (g_11 = 0; (g_11 > (-6)); g_11 = safe_sub_func_uint16_t_u_u(g_11, 3))
    { /* block id: 384 */
        return &g_121;
    }
    for (g_66 = 0; (g_66 > 11); ++g_66)
    { /* block id: 389 */
        ++l_861;
    }
    return l_864;
}


/* ------------------------------------------ */
/* 
 * reads : g_95 g_53 g_431 g_190.f0 g_147 g_121 g_4 g_387 g_66 g_11 g_74 g_120 g_504 g_520 g_63 g_168 g_425 g_521 g_91 g_196 g_366 g_192 g_189 g_190 g_576 g_207 g_577 g_578 g_549 g_206 g_119 g_665 g_162 g_499.f0 g_713 g_718 g_719 g_720 g_167 g_2 g_744
 * writes: g_121 g_190.f0 g_53 g_120 g_11 g_74 g_504 g_425 g_91 g_549 g_119 g_366 g_168 g_387 g_576 g_661 g_666 g_162 g_147 g_713 g_95 g_189 g_801 g_714
 */
static const int32_t * func_42(int16_t  p_43, int32_t  p_44, int32_t ** p_45, const int32_t ** p_46)
{ /* block id: 188 */
    int32_t **l_428 = &g_121;
    int32_t *l_429 = (void*)0;
    int32_t *l_430 = (void*)0;
    uint32_t *l_443 = &g_387;
    uint32_t **l_442 = &l_443;
    uint32_t *l_445 = &g_120;
    uint32_t **l_444 = &l_445;
    int8_t *l_455 = &g_74[0][3];
    int8_t **l_454 = &l_455;
    union U0 l_456[6][5][7] = {{{{0x66918ABFL},{0x15954689L},{1L},{0x15954689L},{0x66918ABFL},{1L},{0x44E524CAL}},{{0x44E524CAL},{-9L},{0x9287168DL},{0x44E524CAL},{0x9287168DL},{-9L},{0x44E524CAL}},{{8L},{0x44E524CAL},{-9L},{0x9287168DL},{0x44E524CAL},{0x9287168DL},{-9L}},{{0x44E524CAL},{0x44E524CAL},{1L},{0x66918ABFL},{0x15954689L},{1L},{0x15954689L}},{{0x66918ABFL},{-9L},{-9L},{0x66918ABFL},{0x9287168DL},{8L},{0x66918ABFL}}},{{{8L},{0x15954689L},{0x9287168DL},{0x9287168DL},{0x15954689L},{8L},{-9L}},{{0x15954689L},{0x66918ABFL},{1L},{0x44E524CAL},{0x44E524CAL},{1L},{0x66918ABFL}},{{0x15954689L},{-9L},{8L},{0x15954689L},{0x9287168DL},{0x9287168DL},{0x15954689L}},{{8L},{0x66918ABFL},{8L},{0x9287168DL},{0x66918ABFL},{-9L},{-9L}},{{0x66918ABFL},{0x15954689L},{1L},{0x15954689L},{0x66918ABFL},{1L},{0x44E524CAL}}},{{{0x44E524CAL},{-9L},{0x9287168DL},{0x44E524CAL},{0x9287168DL},{-9L},{0x44E524CAL}},{{8L},{0x44E524CAL},{-9L},{-5L},{8L},{-5L},{1L}},{{8L},{8L},{0x44E524CAL},{-9L},{0x9287168DL},{0x44E524CAL},{0x9287168DL}},{{-9L},{1L},{1L},{-9L},{-5L},{1L},{-9L}},{{1L},{0x9287168DL},{-5L},{-5L},{0x9287168DL},{1L},{1L}}},{{{0x9287168DL},{-9L},{0x44E524CAL},{8L},{8L},{0x44E524CAL},{-9L}},{{0x9287168DL},{1L},{1L},{0x9287168DL},{-5L},{-5L},{0x9287168DL}},{{1L},{-9L},{1L},{-5L},{-9L},{1L},{1L}},{{-9L},{0x9287168DL},{0x44E524CAL},{0x9287168DL},{-9L},{0x44E524CAL},{8L}},{{8L},{1L},{-5L},{8L},{-5L},{1L},{8L}}},{{{1L},{8L},{1L},{-5L},{8L},{-5L},{1L}},{{8L},{8L},{0x44E524CAL},{-9L},{0x9287168DL},{0x44E524CAL},{0x9287168DL}},{{-9L},{1L},{1L},{-9L},{-5L},{1L},{-9L}},{{1L},{0x9287168DL},{-5L},{-5L},{0x9287168DL},{1L},{1L}},{{0x9287168DL},{-9L},{0x44E524CAL},{8L},{8L},{0x44E524CAL},{-9L}}},{{{0x9287168DL},{1L},{1L},{0x9287168DL},{-5L},{-5L},{0x9287168DL}},{{1L},{-9L},{1L},{-5L},{-9L},{1L},{1L}},{{-9L},{0x9287168DL},{0x44E524CAL},{0x9287168DL},{-9L},{0x44E524CAL},{8L}},{{8L},{1L},{-5L},{8L},{-5L},{1L},{8L}},{{1L},{8L},{1L},{-5L},{8L},{-5L},{1L}}}};
    uint32_t *l_457 = &g_120;
    int32_t *l_458 = &l_456[4][4][1].f0;
    int32_t l_550 = (-1L);
    uint32_t l_568 = 0UL;
    int16_t * const *l_581 = &g_578;
    int16_t * const **l_580 = &l_581;
    int32_t l_606[2];
    int8_t l_806 = 0L;
    uint8_t **l_833 = &g_715;
    uint32_t l_844 = 0xEF6633C8L;
    int32_t l_845 = (-6L);
    uint64_t *l_852 = &g_91;
    uint32_t *l_854 = (void*)0;
    uint32_t **l_853 = &l_854;
    uint32_t *l_855 = &l_568;
    const int32_t *l_856 = &g_499.f0;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_606[i] = (-3L);
    (*l_428) = (*p_45);
    (*g_431) &= (*g_95);
    if (((*l_458) = (((*l_457) = ((safe_mul_func_int32_t_s_s(((*g_95) |= (safe_lshift_func_uint64_t_u_u(((((safe_sub_func_uint16_t_u_u(g_147[0], (safe_sub_func_uint16_t_u_u((safe_lshift_func_int8_t_s_u(((((*l_442) = l_430) == ((*l_444) = &g_120)) & ((safe_mod_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_s((safe_lshift_func_int32_t_s_u((((safe_div_func_int64_t_s_s(p_44, ((l_454 != (void*)0) & (((l_456[4][4][1] , (*l_454)) == (l_456[4][3][0] , (*l_454))) && 1L)))) > 3UL) ^ 0x5B647A3EL), 6)), 4)), (**l_428))) == p_44)), g_387)), g_190.f0)))) , (void*)0) == &l_454) , g_387), g_66))), (**l_428))) == (**p_45))) & 0L)))
    { /* block id: 196 */
        uint8_t *l_459 = &g_168[2][0][6];
        int32_t l_463 = 0xF6121DB7L;
        int32_t l_469 = 0x80F1222FL;
        int32_t l_470 = 0L;
        int32_t l_471 = 0x737CDF0EL;
        uint64_t *l_519 = (void*)0;
        uint64_t **l_518 = &l_519;
        int16_t l_555 = 1L;
        int32_t l_607 = 4L;
        int32_t l_615 = (-1L);
        int32_t l_616 = 3L;
        int32_t l_618 = 0x6676534CL;
        union U0 l_628[6] = {{0x5AFB0A8EL},{0x5AFB0A8EL},{0x5AFB0A8EL},{0x5AFB0A8EL},{0x5AFB0A8EL},{0x5AFB0A8EL}};
        uint8_t l_639 = 255UL;
        int32_t l_662 = 0x7B036447L;
        uint8_t l_723 = 0x31L;
        int16_t ****l_776 = (void*)0;
        int i;
lbl_683:
        (*l_428) = (*l_428);
        if ((l_455 == l_459))
        { /* block id: 198 */
            int8_t l_462[10];
            int32_t l_467 = 0x6FE95660L;
            int32_t l_468[1];
            uint64_t l_472 = 0x242EEA31854D727DLL;
            union U0 *l_498[9];
            int32_t *l_508[3][7] = {{(void*)0,&l_470,(void*)0,&g_190.f0,&g_190.f0,(void*)0,&l_470},{&g_190.f0,&l_470,&l_468[0],&l_468[0],&l_470,&g_190.f0,&l_470},{(void*)0,&g_190.f0,&g_190.f0,(void*)0,&l_470,(void*)0,&g_190.f0}};
            uint32_t *l_510[5];
            uint16_t l_586 = 65531UL;
            uint32_t l_604 = 4UL;
            int64_t l_605 = (-5L);
            int16_t l_610[4];
            int32_t l_612[5] = {(-1L),(-1L),(-1L),(-1L),(-1L)};
            uint8_t l_620[3];
            int i, j;
            for (i = 0; i < 10; i++)
                l_462[i] = (-1L);
            for (i = 0; i < 1; i++)
                l_468[i] = (-8L);
            for (i = 0; i < 9; i++)
                l_498[i] = &g_499;
            for (i = 0; i < 5; i++)
                l_510[i] = &g_63;
            for (i = 0; i < 4; i++)
                l_610[i] = 5L;
            for (i = 0; i < 3; i++)
                l_620[i] = 246UL;
            for (g_11 = (-4); (g_11 < 13); g_11 = safe_add_func_uint8_t_u_u(g_11, 3))
            { /* block id: 201 */
                int32_t *l_464 = &g_190.f0;
                int32_t *l_465 = &g_190.f0;
                int32_t *l_466[8];
                int i;
                for (i = 0; i < 8; i++)
                    l_466[i] = &l_456[4][4][1].f0;
                ++l_472;
            }
            for (l_472 = 0; (l_472 < 27); l_472 = safe_add_func_uint16_t_u_u(l_472, 3))
            { /* block id: 206 */
                int8_t l_486 = 7L;
                const union U0 l_493 = {0x8F67E2F7L};
                int16_t l_509 = (-1L);
                for (g_53 = 0; (g_53 != 7); g_53 = safe_add_func_uint8_t_u_u(g_53, 7))
                { /* block id: 209 */
                    int32_t l_492 = (-1L);
                    int32_t *l_507 = &g_190.f0;
                    if ((safe_unary_minus_func_int32_t_s((((*l_455) = (0x51L != (p_44 , (safe_rshift_func_int32_t_s_s((**p_45), 1))))) , (*g_431)))))
                    { /* block id: 211 */
                        (*l_458) = (*g_121);
                    }
                    else
                    { /* block id: 213 */
                        union U0 l_488 = {0x0482F9EEL};
                        uint32_t l_491 = 8UL;
                        int16_t *l_497 = (void*)0;
                        int16_t **l_496 = &l_497;
                        int16_t ***l_495 = &l_496;
                        int16_t ****l_494 = &l_495;
                        (*l_494) = (((safe_rshift_func_int32_t_s_u((safe_mod_func_uint32_t_u_u(((((**p_45) & (-1L)) , ((g_74[1][4] || ((l_486 && (((((+p_43) == ((l_488 , ((g_120 == p_44) , ((l_491 >= l_486) ^ 0L))) > l_492)) | l_469) <= g_74[1][4]) == 0x1DE3L)) , 0x73FD56A67A99ABB8LL)) & p_43)) != 0L), 4294967292UL)), 22)) , l_493) , (void*)0);
                        l_498[1] = &l_488;
                    }
                    for (g_11 = (-23); (g_11 == (-28)); g_11 = safe_sub_func_uint64_t_u_u(g_11, 8))
                    { /* block id: 219 */
                        int32_t *l_502 = &g_190.f0;
                        int32_t *l_503[1];
                        int i;
                        for (i = 0; i < 1; i++)
                            l_503[i] = &l_468[0];
                        (*l_458) &= (-1L);
                        --g_504;
                        if (l_462[4])
                            break;
                        if ((*g_431))
                            break;
                    }
                    if ((**p_45))
                    { /* block id: 225 */
                        (*l_458) = 0x268B26EDL;
                        if (l_469)
                            continue;
                    }
                    else
                    { /* block id: 228 */
                        l_508[1][0] = l_507;
                        (*l_507) ^= l_463;
                        (*l_428) = (*p_45);
                    }
                }
                l_509 = 0x2AA2ABE3L;
            }
            if (((g_504 = p_44) , (safe_sub_func_uint8_t_u_u((((~((safe_add_func_int8_t_s_s((((1UL != (p_44 | ((safe_add_func_uint64_t_u_u((l_518 == g_520), (safe_lshift_func_uint8_t_u_u(g_147[0], 4)))) <= (safe_mod_func_int32_t_s_s(((g_63 < 6L) >= ((safe_div_func_int64_t_s_s((p_44 , 4L), (-1L))) >= 0x77D1L)), l_470))))) & (*g_95)) && 0xABL), (-1L))) != g_168[1][2][0])) & p_43) , 0x62L), 253UL))))
            { /* block id: 237 */
                int16_t l_540 = 0xCDAEL;
                for (g_425 = 0; (g_425 > 28); ++g_425)
                { /* block id: 240 */
                    int16_t l_545 = 0x1759L;
                    int32_t l_546 = 0x5667694CL;
                    int16_t *l_547 = &g_11;
                    int16_t *l_548 = &g_549;
                    int8_t *l_551[4] = {(void*)0,(void*)0,(void*)0,(void*)0};
                    int i;
                    if ((safe_sub_func_int64_t_s_s(((-1L) > p_44), ((l_546 = (safe_lshift_func_int64_t_s_s(((((*l_455) ^= (safe_mul_func_uint8_t_u_u((safe_div_func_int16_t_s_s(((((*g_521) , (l_540 = ((*g_521) = (0x2AL <= 0xEAL)))) | ((p_44 | 0x36L) == ((*l_548) = ((*l_547) &= (safe_sub_func_int64_t_s_s((safe_sub_func_int8_t_s_s(((((*l_458) ^= (*g_431)) && ((l_545 = (*g_431)) <= l_546)) , 0x7CL), l_470)), g_120)))))) || l_540), 1L)), l_550))) > p_43) && g_387), p_44))) > p_43))))
                    { /* block id: 249 */
                        return (*g_196);
                    }
                    else
                    { /* block id: 251 */
                        uint64_t **l_554 = &l_519;
                        int32_t l_556 = 4L;
                        l_556 = (safe_div_func_int32_t_s_s(((&g_521 != l_554) <= p_43), l_555));
                        if ((**p_45))
                            continue;
                    }
                    for (g_119 = 0; g_119 < 10; g_119 += 1)
                    {
                        l_462[g_119] = 0L;
                    }
                }
                for (g_366 = (-9); (g_366 > 35); g_366 = safe_add_func_uint8_t_u_u(g_366, 6))
                { /* block id: 259 */
                    const int32_t l_563 = 0x0C6F659CL;
                    (*l_428) = (*p_45);
                    (*g_95) ^= (p_44 , (safe_div_func_uint64_t_u_u((g_147[0] | ((*l_459) = (g_147[0] , l_540))), ((((**g_192) , (*p_45)) != (void*)0) ^ (l_563 <= ((safe_div_func_uint32_t_u_u((--(*l_457)), ((g_387 = 0x8732A0C2L) , l_568))) > (-6L)))))));
                    if (l_555)
                        break;
                }
                return (*p_45);
            }
            else
            { /* block id: 268 */
                union U0 l_592 = {1L};
                int32_t l_608 = 2L;
                int32_t l_609 = 0L;
                int32_t l_611 = 0x34B7EA03L;
                int32_t l_617[5] = {0L,0L,0L,0L,0L};
                int16_t **** const l_663 = &g_576[5][1][1];
                int i;
                for (g_53 = 24; (g_53 > (-5)); --g_53)
                { /* block id: 271 */
                    uint8_t l_571 = 0x6BL;
                    l_571--;
                    for (g_504 = 0; (g_504 < 23); g_504 = safe_add_func_int64_t_s_s(g_504, 4))
                    { /* block id: 275 */
                        int16_t ****l_579 = &g_576[6][2][2];
                        l_471 = ((*l_458) = (((*l_579) = g_576[4][1][1]) == l_580));
                    }
                }
                p_44 = (safe_lshift_func_uint8_t_u_u(((*l_459) |= g_366), 0));
                if ((safe_lshift_func_uint8_t_u_u(l_586, 3)))
                { /* block id: 283 */
                    uint8_t *l_591[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
                    uint8_t *l_593 = &g_162;
                    int16_t l_598[2][4];
                    int32_t l_614 = (-1L);
                    int32_t l_619[8] = {0x267313A5L,0x267313A5L,0x267313A5L,0x267313A5L,0x267313A5L,0x267313A5L,0x267313A5L,0x267313A5L};
                    union U0 l_625[9] = {{-5L},{-5L},{-5L},{-5L},{-5L},{-5L},{-5L},{-5L},{-5L}};
                    int i, j;
                    for (i = 0; i < 2; i++)
                    {
                        for (j = 0; j < 4; j++)
                            l_598[i][j] = 0x3BD4L;
                    }
                    if ((safe_mul_func_int8_t_s_s((*g_207), 249UL)))
                    { /* block id: 284 */
                        uint8_t **l_594 = (void*)0;
                        uint8_t **l_595[7][7][5] = {{{&l_593,(void*)0,&l_593,&l_593,&l_459},{&l_459,&l_459,&l_459,(void*)0,&l_459},{&l_459,&l_593,&l_459,(void*)0,&l_459},{(void*)0,(void*)0,&l_593,&l_593,(void*)0},{&l_593,(void*)0,(void*)0,&l_593,&l_459},{(void*)0,&l_593,(void*)0,&l_593,(void*)0},{&l_459,&l_593,(void*)0,&l_593,&l_459}},{{(void*)0,&l_459,&l_593,&l_593,&l_459},{(void*)0,&l_593,&l_459,&l_593,(void*)0},{(void*)0,&l_459,&l_593,&l_593,&l_593},{&l_593,(void*)0,&l_593,(void*)0,&l_593},{&l_593,&l_593,&l_459,(void*)0,&l_459},{&l_593,&l_593,&l_459,&l_593,&l_593},{&l_593,&l_593,&l_593,(void*)0,(void*)0}},{{&l_459,&l_593,&l_593,&l_459,&l_593},{&l_593,&l_593,&l_459,(void*)0,&l_593},{&l_459,&l_459,&l_593,&l_593,&l_593},{&l_593,&l_459,(void*)0,&l_593,&l_459},{&l_593,&l_459,(void*)0,&l_593,&l_593},{&l_593,&l_593,(void*)0,&l_593,&l_593},{&l_459,&l_593,&l_593,&l_593,(void*)0}},{{(void*)0,&l_593,&l_459,&l_593,&l_459},{&l_459,&l_593,&l_459,(void*)0,&l_593},{&l_459,&l_593,&l_593,&l_459,&l_459},{(void*)0,(void*)0,&l_593,&l_593,(void*)0},{&l_459,&l_459,&l_593,&l_459,&l_459},{&l_593,&l_593,&l_593,&l_459,&l_593},{&l_593,&l_459,&l_593,&l_593,(void*)0}},{{&l_593,&l_593,&l_593,&l_593,&l_593},{&l_459,&l_593,&l_459,&l_459,&l_459},{&l_593,(void*)0,&l_593,&l_593,(void*)0},{&l_459,(void*)0,&l_593,(void*)0,&l_459},{&l_593,&l_593,(void*)0,&l_459,&l_593},{&l_593,&l_459,&l_459,&l_459,&l_459},{&l_593,(void*)0,&l_593,(void*)0,(void*)0}},{{&l_593,&l_593,(void*)0,&l_593,&l_593},{(void*)0,&l_459,(void*)0,&l_459,&l_593},{(void*)0,&l_593,(void*)0,(void*)0,&l_593},{&l_593,&l_459,&l_459,&l_593,(void*)0},{&l_593,&l_593,(void*)0,&l_593,&l_593},{(void*)0,&l_593,(void*)0,&l_459,&l_593},{&l_459,&l_593,&l_593,&l_459,&l_593}},{{&l_593,(void*)0,&l_459,&l_459,&l_459},{&l_593,&l_593,&l_459,(void*)0,&l_593},{&l_593,&l_593,&l_593,&l_593,&l_459},{&l_593,(void*)0,&l_459,&l_593,(void*)0},{&l_593,&l_593,&l_593,&l_593,&l_593},{(void*)0,&l_593,&l_593,&l_593,&l_459},{&l_459,&l_593,(void*)0,&l_459,&l_459}}};
                        int32_t l_601 = 7L;
                        int32_t l_613[2];
                        int i, j, k;
                        for (i = 0; i < 2; i++)
                            l_613[i] = (-2L);
                        (*g_95) |= (safe_rshift_func_int8_t_s_s(((l_591[0] = &g_168[1][2][4]) != (l_592 , (l_593 = l_593))), (safe_div_func_int16_t_s_s(l_598[1][0], (safe_mul_func_uint16_t_u_u(((l_601 <= ((**g_577) & (((0x96L == (l_456[4][4][1] , ((safe_mul_func_int16_t_s_s(1L, 0x5779L)) == 4294967295UL))) == l_598[1][0]) <= l_604))) == l_601), (**g_577)))))));
                        ++l_620[2];
                    }
                    else
                    { /* block id: 289 */
                        (*g_95) &= 0x904EFD03L;
                        return (*g_196);
                    }
                    for (l_605 = 0; (l_605 != 21); l_605 = safe_add_func_int8_t_s_s(l_605, 7))
                    { /* block id: 295 */
                        const uint32_t l_640 = 1UL;
                        int64_t *l_641 = &g_119;
                        int32_t l_648 = 0xDFE6C2C8L;
                        int64_t *l_660 = &g_661[2];
                        int16_t *****l_664 = (void*)0;
                        l_609 = (l_625[8] , (safe_sub_func_uint8_t_u_u((l_459 == (l_628[4] , l_459)), (((*l_641) = (safe_lshift_func_int8_t_s_u(((**g_206) = (safe_sub_func_int8_t_s_s((*g_207), (((safe_div_func_int64_t_s_s(p_44, g_549)) || ((safe_lshift_func_int8_t_s_s(((safe_mul_func_uint32_t_u_u(g_120, (*g_121))) , p_43), l_639)) < (*g_95))) || l_640)))), l_607))) > (**l_428)))));
                        (*g_665) = (((**p_45) != (safe_add_func_int64_t_s_s((safe_sub_func_int64_t_s_s((l_648 = (safe_mul_func_uint64_t_u_u(p_44, l_592.f0))), (((void*)0 != l_641) != (safe_add_func_uint16_t_u_u((safe_lshift_func_int32_t_s_u((safe_rshift_func_int64_t_s_u(g_119, 9)), 15)), l_640))))), (safe_sub_func_uint32_t_u_u((((*l_660) = (p_43 && (((~(0x97L && (-1L))) & l_611) > p_44))) == l_471), l_662))))) , l_663);
                    }
                }
                else
                { /* block id: 303 */
                    union U0 *l_682 = (void*)0;
                    for (g_162 = 0; (g_162 <= 8); g_162 += 1)
                    { /* block id: 306 */
                        uint16_t *l_669 = &g_147[0];
                        const uint8_t *l_681 = (void*)0;
                        const uint8_t **l_680 = &l_681;
                        int i;
                        (*l_458) = (4L < ((((*l_669) = (safe_lshift_func_int8_t_s_u((-5L), 1))) || (safe_rshift_func_uint8_t_u_u(((safe_mul_func_int32_t_s_s((((((((p_44 >= (((*g_521) = ((g_499.f0 , (safe_sub_func_int16_t_s_s((**g_577), (((safe_add_func_uint32_t_u_u((l_592.f0 | ((0xF249949ECF8C79AFLL < ((((*l_680) = &g_168[1][2][4]) == (void*)0) , 0x5F1CE4AAB46CA129LL)) <= (**l_428))), g_4[0][2])) && (**p_45)) || 8UL)))) , (**g_520))) >= l_617[4])) , l_617[4]) < (*g_95)) , (void*)0) == (void*)0) != p_44) != 1UL), (*g_95))) | l_609), l_608))) || l_463));
                        l_498[g_162] = l_682;
                    }
                }
            }
            if (g_63)
                goto lbl_683;
        }
        else
        { /* block id: 316 */
            uint8_t ** const l_684 = &l_459;
            const int32_t *l_685 = &l_456[4][4][1].f0;
            (*l_458) ^= ((void*)0 != l_684);
            return (*l_428);
        }
        for (g_53 = 0; (g_53 < (-20)); --g_53)
        { /* block id: 322 */
            uint64_t l_742 = 0x9DD0834FE8117C46LL;
            uint8_t ***l_777 = (void*)0;
            uint16_t *l_793 = (void*)0;
            int32_t l_803 = 7L;
            int32_t l_807 = (-3L);
            int32_t l_808 = 0x27EC7AE6L;
            uint8_t l_809 = 0UL;
            uint8_t ***l_834[3];
            uint64_t ** const *l_843 = &l_518;
            int i;
            for (i = 0; i < 3; i++)
                l_834[i] = &g_714[8];
            for (l_639 = 0; (l_639 >= 20); l_639 = safe_add_func_int16_t_s_s(l_639, 1))
            { /* block id: 325 */
                int16_t *l_690 = (void*)0;
                int64_t *l_693 = &g_119;
                uint16_t *l_708[4][2][1] = {{{(void*)0},{&g_147[0]}},{{(void*)0},{&g_147[0]}},{{(void*)0},{&g_147[0]}},{{(void*)0},{&g_147[0]}}};
                int32_t l_709 = 0xCBD0D02EL;
                int8_t ***l_710[7][5][1] = {{{&l_454},{&l_454},{&l_454},{&l_454},{(void*)0}},{{(void*)0},{&l_454},{&l_454},{&l_454},{&l_454}},{{(void*)0},{&l_454},{(void*)0},{&l_454},{&l_454}},{{&l_454},{&l_454},{(void*)0},{(void*)0},{&l_454}},{{&l_454},{&l_454},{&l_454},{(void*)0},{&l_454}},{{(void*)0},{&l_454},{&l_454},{&l_454},{&l_454}},{{(void*)0},{(void*)0},{&l_454},{&l_454},{&l_454}}};
                int64_t *l_711 = &g_661[2];
                int32_t l_712 = 0L;
                union U0 l_728 = {0xB1F291D3L};
                uint16_t *l_795[7][10][3] = {{{&g_425,&g_147[0],(void*)0},{&g_147[0],&g_425,&g_425},{(void*)0,&g_425,&g_425},{(void*)0,&g_147[0],&g_147[0]},{(void*)0,(void*)0,&g_147[0]},{&g_425,&g_147[0],(void*)0},{&g_425,&g_147[0],&g_425},{&g_147[0],&g_425,&g_425},{&g_147[0],&g_147[0],&g_425},{&g_425,&g_147[0],&g_147[0]}},{{&g_425,&g_147[0],&g_425},{&g_425,&g_147[0],&g_425},{&g_147[0],&g_425,&g_425},{&g_147[0],&g_147[0],&g_147[0]},{&g_425,&g_425,(void*)0},{&g_425,&g_425,&g_147[0]},{(void*)0,&g_425,&g_147[0]},{(void*)0,&g_425,&g_147[0]},{(void*)0,(void*)0,&g_147[0]},{&g_147[0],&g_147[0],&g_147[0]}},{{&g_425,&g_147[0],&g_147[0]},{&g_425,&g_147[0],&g_425},{&g_147[0],&g_425,&g_147[0]},{&g_147[0],&g_147[0],&g_147[0]},{&g_147[0],&g_425,&g_147[0]},{&g_425,&g_147[0],&g_147[0]},{&g_425,&g_147[0],&g_147[0]},{&g_147[0],&g_425,&g_147[0]},{&g_147[0],&g_147[0],(void*)0},{&g_147[0],&g_147[0],&g_425}},{{(void*)0,&g_425,&g_147[0]},{(void*)0,&g_147[0],&g_425},{&g_147[0],(void*)0,&g_147[0]},{&g_147[0],&g_147[0],&g_425},{&g_147[0],(void*)0,&g_147[0]},{&g_425,&g_147[0],&g_425},{&g_147[0],&g_425,&g_147[0]},{&g_425,&g_425,(void*)0},{&g_147[0],&g_425,(void*)0},{(void*)0,&g_147[0],&g_425}},{{&g_425,&g_147[0],&g_147[0]},{(void*)0,&g_147[0],(void*)0},{&g_425,&g_425,&g_425},{&g_147[0],&g_147[0],&g_425},{(void*)0,&g_147[0],&g_147[0]},{&g_147[0],&g_147[0],&g_147[0]},{(void*)0,&g_147[0],(void*)0},{&g_147[0],&g_147[0],(void*)0},{&g_425,&g_147[0],&g_147[0]},{(void*)0,&g_425,&g_147[0]}},{{&g_425,&g_425,&g_147[0]},{(void*)0,(void*)0,&g_147[0]},{&g_147[0],&g_425,&g_147[0]},{&g_425,&g_425,&g_425},{&g_147[0],&g_147[0],&g_147[0]},{&g_425,&g_147[0],&g_147[0]},{&g_147[0],&g_147[0],(void*)0},{&g_147[0],&g_425,&g_147[0]},{&g_147[0],&g_425,&g_147[0]},{(void*)0,&g_425,&g_425}},{{(void*)0,&g_147[0],&g_147[0]},{&g_147[0],&g_147[0],&g_147[0]},{&g_425,(void*)0,&g_147[0]},{&g_147[0],&g_147[0],&g_147[0]},{&g_147[0],&g_147[0],&g_147[0]},{&g_147[0],(void*)0,(void*)0},{&g_425,&g_147[0],(void*)0},{&g_425,&g_147[0],&g_147[0]},{&g_425,&g_147[0],&g_147[0]},{(void*)0,&g_147[0],&g_425}}};
                int64_t l_816 = (-1L);
                int i, j, k;
                g_713[6] = ((((((p_43 , l_690) == (((safe_mul_func_int64_t_s_s(((*l_693) |= g_387), ((+(safe_add_func_uint16_t_u_u(0xBE54L, (safe_sub_func_uint32_t_u_u((0xDCL <= (safe_sub_func_uint32_t_u_u((0xB740A50EL || ((*l_457) = (safe_lshift_func_int8_t_s_s(((l_456[5][0][2] , 0UL) || ((*g_431) = ((((l_712 = ((*l_711) = (((safe_rshift_func_uint8_t_u_s((~(l_709 |= (safe_mod_func_uint8_t_u_u(0xC5L, p_43)))), (*g_207))) , l_710[0][2][0]) == &g_204))) & (-1L)) , (**p_45)) , (-10L)))), l_662)))), (**p_45)))), 0x9304B3DDL))))) ^ p_43))) == g_366) , (void*)0)) >= p_43) != 0x87850A84L) , 0xB4L) , g_713[6]);
                p_44 = ((safe_lshift_func_uint32_t_u_s((g_718 != ((safe_div_func_int64_t_s_s((((l_723 || p_44) , ((safe_add_func_uint16_t_u_u(((((((safe_sub_func_int64_t_s_s((p_43 , ((p_43 | ((l_628[4] , l_728) , (safe_mod_func_int32_t_s_s((safe_unary_minus_func_uint64_t_u((safe_mul_func_int32_t_s_s((safe_add_func_uint64_t_u_u(((*g_521) = (safe_rshift_func_int64_t_s_u(((((*g_578) = (safe_mul_func_uint32_t_u_u(((*l_445) = (safe_lshift_func_uint32_t_u_s((**g_718), ((*l_458) = 0L)))), (*g_95)))) ^ l_742) & p_44), 21))), l_712)), g_167)))), (-5L))))) , 5L)), 0x586951B3F62E05AFLL)) < g_74[1][4]) != g_190.f0) < 7UL) ^ g_2) , p_43), l_662)) < (**l_428))) || 0x133F0C5EFA68F57CLL), g_167)) , &g_719)), 13)) <= p_43);
                if (l_607)
                { /* block id: 338 */
                    int64_t l_743 = 0xCCFEB40BD406E6A3LL;
                    uint32_t **l_761 = (void*)0;
                    int8_t l_778[6][9] = {{0L,(-3L),0L,0x06L,(-5L),0x06L,0L,(-3L),0L},{(-9L),0L,0L,0L,0L,(-9L),0L,0xB1L,(-9L)},{0x3CL,(-3L),0x3CL,0x06L,0x90L,0x06L,0x3CL,(-3L),0x3CL},{(-9L),0xB1L,0L,(-9L),0L,0L,0L,0L,(-9L)},{0L,(-3L),0L,0x06L,(-5L),0x06L,0L,(-3L),0L},{(-9L),0L,0L,0L,0L,(-9L),0L,0xB1L,(-9L)}};
                    uint32_t l_798 = 0UL;
                    int32_t l_802[6][2] = {{0x564A1ACFL,0xCFC35F7DL},{0x564A1ACFL,0xCFC35F7DL},{0x564A1ACFL,0xCFC35F7DL},{0x564A1ACFL,0xCFC35F7DL},{0x564A1ACFL,0xCFC35F7DL},{0x564A1ACFL,0xCFC35F7DL}};
                    int i, j;
                    (*l_458) = l_743;
                    (*g_196) = (*g_196);
                    (*g_744) = (*g_192);
                    if ((18446744073709551608UL & 1L))
                    { /* block id: 342 */
                        int8_t l_758 = 0x58L;
                        int16_t * const ** const * const l_775 = (void*)0;
                        uint64_t ***l_779 = &l_518;
                        uint16_t **l_794[8] = {&l_793,&l_793,&l_793,&l_793,&l_793,&l_793,&l_793,&l_793};
                        uint32_t *l_799 = (void*)0;
                        uint32_t *l_800[1][5][9] = {{{&g_2,(void*)0,(void*)0,&g_2,&g_66,(void*)0,&g_2,(void*)0,&g_66},{&g_2,(void*)0,(void*)0,&g_2,&g_66,(void*)0,&g_2,(void*)0,&g_66},{&g_2,(void*)0,(void*)0,&g_2,&g_66,(void*)0,&g_2,(void*)0,&g_66},{&g_2,(void*)0,(void*)0,&g_2,&g_66,(void*)0,&g_2,(void*)0,&g_66},{&g_2,(void*)0,(void*)0,&g_2,&g_66,(void*)0,&g_2,(void*)0,&g_66}}};
                        int i, j, k;
                        (*l_458) = (safe_div_func_uint16_t_u_u((+(safe_add_func_int64_t_s_s(((safe_lshift_func_int64_t_s_s((safe_mul_func_uint16_t_u_u((((((safe_sub_func_int32_t_s_s((safe_rshift_func_int16_t_s_u(((*g_578) |= p_44), 1)), (*g_95))) == ((((p_43 || (((l_758 || ((((((safe_rshift_func_int8_t_s_s((l_761 != (void*)0), 5)) < ((safe_mul_func_int16_t_s_s((+((((safe_add_func_int8_t_s_s((safe_add_func_uint64_t_u_u(((((safe_mul_func_int8_t_s_s(((*l_458) && (safe_mod_func_int8_t_s_s(((safe_mul_func_uint8_t_u_u(0xB6L, l_639)) || 0x666C9AC66C81FBD9LL), p_44))), p_44)) , 0x086255FBL) , l_775) == l_776), l_712)), p_44)) || p_44) > (-1L)) , p_43)), p_44)) >= 0L)) == l_728.f0) && g_167) , p_44) <= p_44)) , (**g_520)) != l_743)) , &g_714[0]) == l_777) & l_742)) > 1UL) & (*g_121)) != l_778[3][6]), 65535UL)), 22)) >= g_74[1][4]), g_387))), 0xACE5L));
                        (*l_779) = (void*)0;
                        l_728.f0 ^= (((((((g_801 = (((safe_unary_minus_func_uint16_t_u((safe_mod_func_int64_t_s_s((safe_mul_func_int16_t_s_s(((((((((!((!((*l_459) = (((safe_lshift_func_uint64_t_u_u((safe_add_func_int8_t_s_s(((**g_206) = 0x51L), ((((*l_693) = l_758) , ((((safe_mul_func_int16_t_s_s((((((l_795[6][7][2] = l_793) != ((l_615 = (p_44 && (safe_lshift_func_uint32_t_u_s(p_43, (((p_44 , (g_119 && l_798)) , (p_43 | p_43)) == 5UL))))) , (void*)0)) && l_758) | (-1L)) & l_778[3][6]), 0x86D0L)) ^ 0xDFL) , 0x7D79F28288364F07LL) | (*l_458))) ^ 0x04C2ADFBL))), p_43)) || l_712) | 4UL))) <= (**p_45))) & p_44) , l_778[3][6]) | g_147[0]) < 0x9469L) || 0xA6B5053E06DE54C1LL) && l_742) , 0L), g_425)), g_167)))) > p_44) , (void*)0)) == &g_147[0]) ^ p_44) >= 4294967287UL) == 0L) , l_743) < p_44);
                    }
                    else
                    { /* block id: 353 */
                        (*l_458) |= (l_802[2][0] = 0x0D196DDEL);
                        if ((*g_121))
                            continue;
                        l_803 |= 0x064F229FL;
                    }
                }
                else
                { /* block id: 359 */
                    int32_t *l_804 = &l_471;
                    int32_t *l_805[10][1][4] = {{{&l_662,&l_618,&l_618,&l_662}},{{&l_618,&l_662,&l_618,&l_618}},{{&l_662,&l_662,&g_190.f0,&l_662}},{{&l_662,&l_618,&l_618,&l_662}},{{&l_618,&l_662,&l_618,&l_618}},{{&l_662,&l_662,&g_190.f0,&l_662}},{{&l_662,&l_618,&l_618,&l_662}},{{&l_618,&l_662,&l_618,&l_618}},{{&l_662,&l_662,&g_190.f0,&l_662}},{{&l_662,&l_618,&l_618,&l_662}}};
                    int i, j, k;
                    ++l_809;
                    (*l_458) = ((*l_804) && (safe_add_func_uint64_t_u_u(((p_43 & (l_803 = (safe_unary_minus_func_uint16_t_u(((((~l_616) || 0x7DD1L) && (((void*)0 != &l_443) || ((3UL && 0xE3L) < (l_816 && 0x11L)))) >= 2UL))))) != p_44), 2UL)));
                }
            }
            (*l_428) = (*p_45);
            if (l_742)
                continue;
            l_470 = ((safe_sub_func_int8_t_s_s(((safe_mod_func_int64_t_s_s(((0x41L & (safe_rshift_func_int16_t_s_u((safe_sub_func_uint8_t_u_u(((safe_mod_func_uint32_t_u_u((safe_add_func_int64_t_s_s(((safe_add_func_uint16_t_u_u(((safe_sub_func_uint32_t_u_u((*g_719), ((((((g_162 &= ((g_714[0] = l_833) == (void*)0)) > ((**l_454) |= l_742)) , ((((((*l_445) = ((safe_lshift_func_int16_t_s_s(((*g_578) = (safe_sub_func_uint64_t_u_u(((safe_sub_func_int8_t_s_s((safe_div_func_int64_t_s_s((&l_568 == &g_504), 0xD6AA926BA831D103LL)), (0UL ^ p_44))) != g_168[1][2][4]), p_44))), p_44)) && 0x3AL)) < l_723) || 0x24L) , g_120) , 4294967294UL)) , l_843) == (void*)0) , 4294967295UL))) > l_809), g_4[4][2])) || p_44), l_844)), 0xF94EFED4L)) >= 0x75C9L), l_742)), 0))) , 0x15ECF08963EEB41ELL), g_147[0])) ^ 1UL), l_845)) & 1UL);
        }
    }
    else
    { /* block id: 374 */
        const int32_t *l_846 = &g_53;
        return l_846;
    }
    (*l_458) = (((safe_sub_func_int16_t_s_s((p_44 == (+(**l_428))), p_43)) , (safe_mul_func_uint64_t_u_u((((((((((((*g_189) , (*g_520)) == l_852) ^ (((**l_428) > (&l_568 == (l_855 = ((*l_853) = &l_568)))) , 5UL)) , &g_121) != p_46) , (**l_428)) < 0xDA1594C7L) <= 0x9857BD31793E270CLL) , p_44) < p_43), (*g_521)))) , 0x507AF76FL);
    return l_856;
}


/* ------------------------------------------ */
/* 
 * reads : g_63 g_66 g_425
 * writes: g_63 g_66
 */
static uint64_t  func_47(int16_t  p_48, int32_t * const * p_49)
{ /* block id: 6 */
    int32_t *l_52 = &g_53;
    int32_t *l_54 = &g_53;
    int32_t *l_55 = &g_53;
    int32_t *l_56 = &g_53;
    int32_t *l_57 = &g_53;
    int32_t *l_58 = &g_53;
    int32_t *l_59 = &g_53;
    int32_t *l_60 = &g_53;
    int32_t *l_61 = &g_53;
    int32_t *l_62[4] = {&g_53,&g_53,&g_53,&g_53};
    int8_t l_268 = 5L;
    int32_t l_289 = 3L;
    uint64_t l_306 = 18446744073709551607UL;
    uint16_t l_316 = 0x2061L;
    int i;
lbl_69:
    ++g_63;
    --g_66;
    if (g_66)
        goto lbl_70;
lbl_70:
    if (g_66)
        goto lbl_69;
    for (g_66 = 0; (g_66 <= 3); g_66 += 1)
    { /* block id: 13 */
        int32_t **l_84 = &l_54;
        int8_t *l_85 = &g_74[0][3];
        int32_t l_254 = 0x757D178AL;
        int32_t l_256 = 0x8BE36E89L;
        int32_t l_286 = (-5L);
        int32_t l_290 = 5L;
        int32_t l_296 = 4L;
        int32_t l_298 = 0x9C1F7F4DL;
        int32_t l_300 = 0x448582A1L;
        int32_t l_301 = 0x903AD15CL;
        int32_t l_305 = 0x524EEA1DL;
        int32_t l_315 = 1L;
        int8_t l_334 = 0xE4L;
        int64_t *l_389 = &g_119;
        int64_t **l_388[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        int i;
        for (p_48 = 3; (p_48 >= 0); p_48 -= 1)
        { /* block id: 16 */
            int16_t l_143 = (-5L);
            int32_t *l_194 = &g_53;
            int64_t *l_197 = &g_119;
            const uint32_t l_250 = 0x76513EDBL;
            uint16_t *l_251 = &g_147[0];
            int32_t l_279 = 0x344B6569L;
            int32_t l_287 = 2L;
            int32_t l_288 = (-5L);
            int32_t l_292 = 0x9F06A350L;
            int64_t l_293 = 0x420B683A1FF8343CLL;
            int32_t l_294 = (-1L);
            int32_t l_295 = (-1L);
            int32_t l_297 = 0xE700611AL;
            int32_t l_299 = 0x4BBB4929L;
            int32_t l_302 = (-1L);
            int32_t l_303[6][1][3] = {{{0x84B4F694L,(-7L),0x84B4F694L}},{{0x84B4F694L,(-7L),0x84B4F694L}},{{0x84B4F694L,(-7L),0x84B4F694L}},{{0x84B4F694L,(-7L),0x84B4F694L}},{{0x84B4F694L,(-7L),0x84B4F694L}},{{0x84B4F694L,(-7L),0x84B4F694L}}};
            int16_t l_304 = 2L;
            const int8_t *l_345 = &g_74[0][1];
            const uint64_t *l_422[9][10][2] = {{{&g_91,&g_91},{&l_306,&g_91},{&g_91,(void*)0},{(void*)0,(void*)0},{&g_91,&g_91},{&l_306,&g_91},{&g_91,&g_91},{&l_306,(void*)0},{(void*)0,&l_306},{&l_306,&g_91}},{{&l_306,&l_306},{(void*)0,(void*)0},{&l_306,&g_91},{&g_91,&g_91},{&l_306,&g_91},{&g_91,(void*)0},{(void*)0,(void*)0},{&g_91,&g_91},{&l_306,&g_91},{&g_91,&g_91}},{{&l_306,(void*)0},{(void*)0,&l_306},{&l_306,&g_91},{&l_306,&l_306},{(void*)0,(void*)0},{&l_306,&g_91},{&g_91,&g_91},{&l_306,&g_91},{&g_91,(void*)0},{(void*)0,(void*)0}},{{&g_91,&g_91},{&l_306,&g_91},{&g_91,&g_91},{&l_306,(void*)0},{(void*)0,&l_306},{&l_306,&l_306},{&g_91,&l_306},{(void*)0,&g_91},{&l_306,(void*)0},{&l_306,(void*)0}},{{&g_91,&g_91},{&g_91,(void*)0},{&g_91,(void*)0},{&g_91,&g_91},{&g_91,(void*)0},{&l_306,(void*)0},{&l_306,&g_91},{(void*)0,&l_306},{&g_91,&l_306},{&g_91,&l_306}},{{(void*)0,&g_91},{&l_306,(void*)0},{&l_306,(void*)0},{&g_91,&g_91},{&g_91,(void*)0},{&g_91,(void*)0},{&g_91,&g_91},{&g_91,(void*)0},{&l_306,(void*)0},{&l_306,&g_91}},{{(void*)0,&l_306},{&g_91,&l_306},{&g_91,&l_306},{(void*)0,&g_91},{&l_306,(void*)0},{&l_306,(void*)0},{&g_91,&g_91},{&g_91,(void*)0},{&g_91,(void*)0},{&g_91,&g_91}},{{&g_91,(void*)0},{&l_306,(void*)0},{&l_306,&g_91},{(void*)0,&l_306},{&g_91,&l_306},{&g_91,&l_306},{(void*)0,&g_91},{&l_306,(void*)0},{&l_306,(void*)0},{&g_91,&g_91}},{{&g_91,(void*)0},{&g_91,(void*)0},{&g_91,&g_91},{&g_91,(void*)0},{&l_306,(void*)0},{&l_306,&g_91},{(void*)0,&l_306},{&g_91,&l_306},{&g_91,&l_306},{(void*)0,&g_91}}};
            const uint64_t **l_421[3];
            int32_t *l_424 = &l_295;
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_421[i] = &l_422[2][9][1];
        }
    }
    return g_425;
}


/* ------------------------------------------ */
/* 
 * reads : g_91 g_66 g_95 g_4 g_2 g_53 g_11 g_74 g_63
 * writes: g_91 g_95 g_53 g_119 g_120 g_121
 */
static int64_t  func_79(int8_t  p_80, int8_t * p_81, int8_t  p_82, uint32_t  p_83)
{ /* block id: 23 */
    int32_t *l_86 = &g_53;
    int32_t l_87 = 2L;
    int32_t *l_88 = (void*)0;
    int32_t *l_89 = &l_87;
    int32_t *l_90[9][5] = {{&g_53,&g_53,&l_87,&l_87,&g_4[4][0]},{(void*)0,&g_53,&g_53,(void*)0,&g_53},{&g_4[1][1],&l_87,(void*)0,(void*)0,&l_87},{&g_53,&g_53,&l_87,&g_53,&g_53},{&g_4[4][2],&g_53,&g_4[4][2],(void*)0,&l_87},{&g_53,(void*)0,&g_53,(void*)0,&g_53},{&g_4[4][2],&g_4[1][1],&g_53,&l_87,&g_53},{&g_53,&g_53,&g_53,&g_53,&g_53},{&g_4[1][1],&g_4[4][2],&g_4[4][2],&g_4[1][1],&g_53}};
    int32_t **l_94[7];
    uint64_t *l_98 = &g_91;
    int8_t l_117 = (-2L);
    int64_t *l_118 = &g_119;
    int i, j;
    for (i = 0; i < 7; i++)
        l_94[i] = (void*)0;
    g_91++;
    g_95 = &g_4[5][2];
    g_120 = (safe_div_func_uint64_t_u_u(((*l_98) = p_80), ((*l_118) = ((safe_mul_func_int64_t_s_s(g_66, ((safe_mod_func_uint8_t_u_u(((safe_add_func_int32_t_s_s((safe_mul_func_int64_t_s_s((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint32_t_u_u((((((((*g_95) > (safe_rshift_func_int16_t_s_u(g_2, p_82))) , ((*l_86) = ((safe_add_func_uint32_t_u_u(((((*g_95) & (((((safe_mul_func_int8_t_s_s((0xB382L != (-1L)), (0xE7DFL && g_53))) < g_11) > l_117) != p_82) == g_11)) || g_53) , 1UL), p_80)) != g_74[1][4]))) >= (*g_95)) & p_80) ^ g_2) , (*l_89)), 16)), 0x563EDD1FL)), g_74[1][4])), 0xFF8D1E45L)) , p_82), 0xE2L)) == g_74[1][4]))) , g_74[1][4]))));
    g_121 = (g_95 = &g_4[8][1]);
    return g_63;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_2, "g_2", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_4[i][j], "g_4[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_11, "g_11", print_hash_value);
    transparent_crc(g_53, "g_53", print_hash_value);
    transparent_crc(g_63, "g_63", print_hash_value);
    transparent_crc(g_66, "g_66", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 6; j++)
        {
            transparent_crc(g_74[i][j], "g_74[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_91, "g_91", print_hash_value);
    transparent_crc(g_119, "g_119", print_hash_value);
    transparent_crc(g_120, "g_120", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_147[i], "g_147[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_162, "g_162", print_hash_value);
    transparent_crc(g_167, "g_167", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 3; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_168[i][j][k], "g_168[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_186, "g_186", print_hash_value);
    transparent_crc(g_190.f0, "g_190.f0", print_hash_value);
    transparent_crc(g_366, "g_366", print_hash_value);
    transparent_crc(g_387, "g_387", print_hash_value);
    transparent_crc(g_425, "g_425", print_hash_value);
    transparent_crc(g_499.f0, "g_499.f0", print_hash_value);
    transparent_crc(g_504, "g_504", print_hash_value);
    transparent_crc(g_549, "g_549", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_661[i], "g_661[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_720, "g_720", print_hash_value);
    transparent_crc(g_949, "g_949", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_956[i], "g_956[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_976.f0, "g_976.f0", print_hash_value);
    transparent_crc(g_1022, "g_1022", print_hash_value);
    transparent_crc(g_1234, "g_1234", print_hash_value);
    transparent_crc(g_1282, "g_1282", print_hash_value);
    transparent_crc(g_1318.f0, "g_1318.f0", print_hash_value);
    transparent_crc(g_1320.f0, "g_1320.f0", print_hash_value);
    transparent_crc(g_1360, "g_1360", print_hash_value);
    transparent_crc(g_1639, "g_1639", print_hash_value);
    transparent_crc(g_1650.f0, "g_1650.f0", print_hash_value);
    transparent_crc(g_1766, "g_1766", print_hash_value);
    transparent_crc(g_1781, "g_1781", print_hash_value);
    transparent_crc(g_1864.f0, "g_1864.f0", print_hash_value);
    transparent_crc(g_1912, "g_1912", print_hash_value);
    transparent_crc(g_1914, "g_1914", print_hash_value);
    transparent_crc(g_1984, "g_1984", print_hash_value);
    transparent_crc(g_2029, "g_2029", print_hash_value);
    transparent_crc(g_2097, "g_2097", print_hash_value);
    transparent_crc(g_2175, "g_2175", print_hash_value);
    transparent_crc(g_2204, "g_2204", print_hash_value);
    transparent_crc(g_2239, "g_2239", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2338[i], "g_2338[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 649
XXX total union variables: 16

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 47
breakdown:
   depth: 1, occurrence: 125
   depth: 2, occurrence: 25
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 6, occurrence: 1
   depth: 14, occurrence: 1
   depth: 15, occurrence: 1
   depth: 17, occurrence: 3
   depth: 19, occurrence: 1
   depth: 21, occurrence: 1
   depth: 22, occurrence: 2
   depth: 28, occurrence: 1
   depth: 30, occurrence: 1
   depth: 31, occurrence: 1
   depth: 32, occurrence: 1
   depth: 33, occurrence: 1
   depth: 34, occurrence: 1
   depth: 39, occurrence: 1
   depth: 42, occurrence: 1
   depth: 47, occurrence: 2

XXX total number of pointers: 486

XXX times a variable address is taken: 1280
XXX times a pointer is dereferenced on RHS: 532
breakdown:
   depth: 1, occurrence: 314
   depth: 2, occurrence: 183
   depth: 3, occurrence: 31
   depth: 4, occurrence: 4
XXX times a pointer is dereferenced on LHS: 386
breakdown:
   depth: 1, occurrence: 305
   depth: 2, occurrence: 61
   depth: 3, occurrence: 16
   depth: 4, occurrence: 4
XXX times a pointer is compared with null: 59
XXX times a pointer is compared with address of another variable: 12
XXX times a pointer is compared with another pointer: 16
XXX times a pointer is qualified to be dereferenced: 8300

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1294
   level: 2, occurrence: 501
   level: 3, occurrence: 143
   level: 4, occurrence: 72
   level: 5, occurrence: 40
XXX number of pointers point to pointers: 221
XXX number of pointers point to scalars: 251
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 31.9
XXX average alias set size: 1.45

XXX times a non-volatile is read: 2358
XXX times a non-volatile is write: 1114
XXX times a volatile is read: 167
XXX    times read thru a pointer: 61
XXX times a volatile is write: 34
XXX    times written thru a pointer: 15
XXX times a volatile is available for access: 1.42e+03
XXX percentage of non-volatile access: 94.5

XXX forward jumps: 3
XXX backward jumps: 10

XXX stmts: 115
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 32
   depth: 1, occurrence: 9
   depth: 2, occurrence: 13
   depth: 3, occurrence: 12
   depth: 4, occurrence: 19
   depth: 5, occurrence: 30

XXX percentage a fresh-made variable is used: 17
XXX percentage an existing variable is used: 83
XXX total OOB instances added: 0
********************* end of statistics **********************/

