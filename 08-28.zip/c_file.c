/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      2322095806
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
struct S0 {
   volatile unsigned f0 : 13;
   signed f1 : 14;
   unsigned f2 : 24;
   unsigned f3 : 4;
   signed f4 : 3;
   signed f5 : 14;
   unsigned f6 : 20;
   const unsigned f7 : 25;
};

union U1 {
   uint64_t  f0;
   uint16_t  f1;
   uint8_t  f2;
   volatile uint64_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static int32_t g_3 = (-7L);
static uint16_t g_4[5][8][3] = {{{0x0698L,3UL,65535UL},{0xF78DL,3UL,0xF78DL},{0x0121L,0xF2BAL,65535UL},{0x0121L,0x8AB7L,0x0698L},{0xF78DL,0xF2BAL,0x0698L},{0x0698L,3UL,65535UL},{0xF78DL,3UL,0xF78DL},{0x0121L,0xF2BAL,65535UL}},{{0x0121L,0x8AB7L,0x0698L},{0xF78DL,0xF2BAL,0x0698L},{0x0698L,3UL,65535UL},{0xF78DL,3UL,0xF78DL},{0x0121L,0xF2BAL,65535UL},{0x0121L,0x8AB7L,0x0698L},{0xF78DL,0xF2BAL,0x0698L},{0x0698L,0x0121L,0UL}},{{0x1C23L,0x0121L,0x1C23L},{0UL,0xF78DL,0UL},{0UL,0x0698L,4UL},{0x1C23L,0xF78DL,4UL},{4UL,0x0121L,0UL},{0x1C23L,0x0121L,0x1C23L},{0UL,0xF78DL,0UL},{0UL,0x0698L,4UL}},{{0x1C23L,0xF78DL,4UL},{4UL,0x0121L,0UL},{0x1C23L,0x0121L,0x1C23L},{0UL,0xF78DL,0UL},{0UL,0x0698L,4UL},{0x1C23L,0xF78DL,4UL},{4UL,0x0121L,0UL},{0x1C23L,0x0121L,0x1C23L}},{{0UL,0xF78DL,0UL},{0UL,0x0698L,4UL},{0x1C23L,0xF78DL,4UL},{4UL,0x0121L,0UL},{0x1C23L,0x0121L,0x1C23L},{0UL,0xF78DL,0UL},{0UL,0x0698L,4UL},{0x1C23L,0xF78DL,4UL}}};
static volatile uint64_t g_9 = 0xACDD711A53FDE750LL;/* VOLATILE GLOBAL g_9 */
static uint8_t g_18 = 0xCEL;
static uint8_t g_22 = 248UL;
static int32_t *g_31 = &g_3;
static int32_t **g_30 = &g_31;
static uint8_t g_33 = 254UL;
static int64_t g_39[5][7] = {{0x4D24406997B9FFBDLL,0x2A48B7552F0C8C58LL,0x003B9FE29F19B52DLL,(-9L),0x2A48B7552F0C8C58LL,(-9L),0x003B9FE29F19B52DLL},{0x2A48B7552F0C8C58LL,0x2A48B7552F0C8C58LL,0xB0B8B0E31355901ALL,0xB6EF5427E5571BE3LL,2L,0xB0B8B0E31355901ALL,2L},{0xB6EF5427E5571BE3LL,0x003B9FE29F19B52DLL,0x003B9FE29F19B52DLL,0xB6EF5427E5571BE3LL,(-9L),0x4D24406997B9FFBDLL,0xB6EF5427E5571BE3LL},{0x4D24406997B9FFBDLL,2L,(-9L),(-9L),2L,0x4D24406997B9FFBDLL,0x003B9FE29F19B52DLL},{2L,0xB6EF5427E5571BE3LL,0xB0B8B0E31355901ALL,0x2A48B7552F0C8C58LL,0x2A48B7552F0C8C58LL,0xB0B8B0E31355901ALL,0xB6EF5427E5571BE3LL}};
static int64_t g_41[2] = {0x1663B350B8378C3ALL,0x1663B350B8378C3ALL};
static int64_t g_65 = 1L;
static int64_t *g_64 = &g_65;
static uint8_t g_75 = 255UL;
static uint8_t *g_74 = &g_75;
static int32_t g_77[5] = {(-10L),(-10L),(-10L),(-10L),(-10L)};
static int16_t g_105 = 0x4942L;
static const int32_t *g_106[7] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static int8_t g_113 = 0x1AL;
static uint64_t g_115 = 9UL;
static int32_t g_117 = 0x452746A0L;
static int32_t * volatile g_116 = &g_117;/* VOLATILE GLOBAL g_116 */
static int8_t *g_121 = &g_113;
static uint16_t g_140 = 65531UL;
static uint8_t g_210 = 0x7FL;
static int16_t g_213 = 0xA74CL;
static int64_t g_234 = 0L;
static uint32_t g_257 = 7UL;
static int8_t **g_271 = &g_121;
static uint64_t g_283 = 5UL;
static volatile uint32_t g_295 = 0x281A0A5BL;/* VOLATILE GLOBAL g_295 */
static volatile uint32_t * volatile g_294 = &g_295;/* VOLATILE GLOBAL g_294 */
static volatile uint32_t * volatile *g_293 = &g_294;
static volatile int8_t g_318 = 1L;/* VOLATILE GLOBAL g_318 */
static uint32_t g_338[3] = {0UL,0UL,0UL};
static uint16_t *g_343 = &g_4[3][0][2];
static volatile int32_t g_382 = (-1L);/* VOLATILE GLOBAL g_382 */
static int32_t *g_397 = (void*)0;
static int32_t ** volatile g_396 = &g_397;/* VOLATILE GLOBAL g_396 */
static volatile union U1 g_402 = {0x0080204A2B144724LL};/* VOLATILE GLOBAL g_402 */
static union U1 g_464 = {6UL};/* VOLATILE GLOBAL g_464 */
static volatile struct S0 g_474 = {68,-84,1347,1,-0,9,273,277};/* VOLATILE GLOBAL g_474 */
static union U1 g_563 = {1UL};/* VOLATILE GLOBAL g_563 */
static int16_t ** volatile * volatile g_571[1][1] = {{(void*)0}};
static const uint8_t g_595[5] = {0UL,0UL,0UL,0UL,0UL};
static const union U1 g_620 = {0UL};/* VOLATILE GLOBAL g_620 */
static int32_t ** volatile g_649 = &g_397;/* VOLATILE GLOBAL g_649 */
static struct S0 g_689 = {88,-43,2012,1,0,-43,380,2649};/* VOLATILE GLOBAL g_689 */
static int16_t *g_711 = (void*)0;
static int16_t ** const g_710 = &g_711;
static int16_t ** const *g_709 = &g_710;
static int32_t ** volatile g_770[10] = {&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397};
static union U1 ** volatile g_772 = (void*)0;/* VOLATILE GLOBAL g_772 */
static union U1 g_777 = {0x13DE767A8315F2D6LL};/* VOLATILE GLOBAL g_777 */
static union U1 *g_779[1] = {&g_563};
static union U1 **g_778 = &g_779[0];
static const struct S0 g_785 = {66,-16,375,3,-1,-38,456,477};/* VOLATILE GLOBAL g_785 */
static volatile struct S0 g_832 = {2,-79,3469,1,0,95,975,219};/* VOLATILE GLOBAL g_832 */
static volatile union U1 g_880 = {0xBB5EB50CF4395BF1LL};/* VOLATILE GLOBAL g_880 */
static int32_t ***g_891[9] = {&g_30,&g_30,&g_30,&g_30,&g_30,&g_30,&g_30,&g_30,&g_30};
static int32_t ****g_890 = &g_891[0];
static int32_t ***** volatile g_889 = &g_890;/* VOLATILE GLOBAL g_889 */
static int16_t ***g_947 = (void*)0;
static int32_t *****g_973 = &g_890;
static const int32_t ** volatile g_990 = &g_106[2];/* VOLATILE GLOBAL g_990 */
static const uint32_t * volatile *g_1007 = (void*)0;
static const uint32_t * volatile * volatile *g_1006 = &g_1007;
static const uint32_t * volatile * volatile ** volatile g_1005 = &g_1006;/* VOLATILE GLOBAL g_1005 */
static int64_t g_1064 = (-4L);
static volatile uint64_t *g_1069 = &g_9;
static volatile uint64_t **g_1068 = &g_1069;
static int32_t ** volatile g_1094[6] = {&g_397,&g_397,&g_397,&g_397,&g_397,&g_397};
static volatile union U1 g_1109 = {0x054E2FEF26305AF5LL};/* VOLATILE GLOBAL g_1109 */
static uint16_t g_1170 = 0x17FDL;
static uint32_t *g_1186 = &g_257;
static uint32_t **g_1185 = &g_1186;
static uint64_t *g_1256 = &g_283;
static uint64_t **g_1255 = &g_1256;
static volatile uint64_t *** const g_1258 = (void*)0;
static volatile uint64_t *** const * volatile g_1257 = &g_1258;/* VOLATILE GLOBAL g_1257 */
static volatile struct S0 ** const g_1288 = (void*)0;
static int16_t g_1378 = 9L;
static int8_t g_1430[4][10] = {{0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L},{0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L},{0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L},{0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L,0xC6L}};
static int32_t ** volatile g_1438 = &g_397;/* VOLATILE GLOBAL g_1438 */
static int32_t ** volatile g_1439[3][3][6] = {{{(void*)0,&g_31,&g_31,&g_31,(void*)0,&g_397},{&g_31,(void*)0,&g_397,&g_397,(void*)0,&g_31},{&g_397,&g_31,(void*)0,(void*)0,(void*)0,&g_31}},{{(void*)0,&g_397,&g_397,&g_31,&g_31,&g_397},{(void*)0,(void*)0,&g_31,(void*)0,&g_31,(void*)0},{&g_397,(void*)0,&g_397,&g_397,&g_31,&g_31}},{{&g_31,&g_397,&g_397,&g_31,(void*)0,(void*)0},{(void*)0,&g_31,&g_31,&g_31,(void*)0,&g_397},{&g_31,(void*)0,&g_397,&g_397,(void*)0,&g_31}}};
static int32_t **g_1443[6][5][7] = {{{&g_31,&g_31,&g_31,&g_397,&g_397,&g_31,&g_31},{&g_397,&g_31,&g_397,&g_397,&g_31,&g_397,&g_31},{&g_31,&g_397,&g_397,&g_31,&g_31,&g_31,&g_397},{&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397},{&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397}},{{&g_31,&g_31,&g_31,&g_397,&g_397,&g_31,&g_31},{&g_397,&g_31,&g_397,&g_397,&g_31,&g_397,&g_31},{&g_31,&g_397,&g_397,&g_31,&g_31,&g_31,&g_397},{&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397},{&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397}},{{&g_31,&g_31,&g_31,&g_397,&g_397,&g_31,&g_31},{&g_397,&g_31,&g_397,&g_397,&g_31,&g_397,&g_31},{&g_31,&g_397,&g_397,&g_31,&g_31,&g_31,&g_397},{&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397},{&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397}},{{&g_31,&g_31,&g_31,&g_397,&g_397,&g_31,&g_31},{&g_397,&g_31,&g_397,&g_397,&g_31,&g_397,&g_31},{&g_31,&g_397,&g_397,&g_31,&g_31,&g_31,&g_397},{&g_397,&g_397,&g_397,&g_31,&g_31,&g_397,&g_397},{&g_397,&g_31,&g_31,&g_31,&g_397,&g_397,&g_31}},{{&g_397,&g_397,&g_397,&g_31,&g_31,&g_397,&g_397},{&g_31,&g_397,&g_31,&g_31,&g_397,&g_31,&g_397},{&g_397,&g_31,&g_31,&g_397,&g_397,&g_397,&g_31},{&g_397,&g_397,&g_31,&g_31,&g_31,&g_397,&g_397},{&g_397,&g_31,&g_31,&g_31,&g_397,&g_397,&g_31}},{{&g_397,&g_397,&g_397,&g_31,&g_31,&g_397,&g_397},{&g_31,&g_397,&g_31,&g_31,&g_397,&g_31,&g_397},{&g_397,&g_31,&g_31,&g_397,&g_397,&g_397,&g_31},{&g_397,&g_397,&g_31,&g_31,&g_31,&g_397,&g_397},{&g_397,&g_31,&g_31,&g_31,&g_397,&g_397,&g_31}}};
static const volatile union U1 g_1466 = {1UL};/* VOLATILE GLOBAL g_1466 */
static volatile union U1 g_1502 = {0xA85C7D184FC29581LL};/* VOLATILE GLOBAL g_1502 */
static int32_t ** volatile g_1504 = &g_397;/* VOLATILE GLOBAL g_1504 */
static uint32_t ***g_1576 = &g_1185;
static uint32_t ****g_1575 = &g_1576;
static struct S0 g_1578 = {32,27,838,3,-0,46,817,4165};/* VOLATILE GLOBAL g_1578 */
static volatile union U1 g_1585[5][8] = {{{18446744073709551610UL},{1UL},{18446744073709551610UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551610UL},{1UL},{18446744073709551610UL}},{{1UL},{18446744073709551615UL},{0x2E3D7704FD4C6FC0LL},{18446744073709551615UL},{1UL},{1UL},{18446744073709551615UL},{0x2E3D7704FD4C6FC0LL}},{{1UL},{1UL},{18446744073709551615UL},{0x2E3D7704FD4C6FC0LL},{18446744073709551615UL},{1UL},{1UL},{18446744073709551615UL}},{{18446744073709551610UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551610UL},{1UL},{18446744073709551610UL},{18446744073709551615UL},{18446744073709551615UL}},{{18446744073709551615UL},{1UL},{0x2E3D7704FD4C6FC0LL},{0x2E3D7704FD4C6FC0LL},{1UL},{18446744073709551615UL},{1UL},{0x2E3D7704FD4C6FC0LL}}};
static int32_t g_1586 = 0x5BBD893DL;
static volatile struct S0 g_1599 = {39,-44,555,1,-1,88,138,4158};/* VOLATILE GLOBAL g_1599 */
static uint64_t ***g_1620 = &g_1255;
static uint64_t ****g_1619 = &g_1620;
static volatile struct S0 g_1627 = {6,-23,1188,2,-1,-44,494,1926};/* VOLATILE GLOBAL g_1627 */
static uint64_t * const *g_1634 = &g_1256;
static uint64_t * const **g_1633[4] = {&g_1634,&g_1634,&g_1634,&g_1634};
static uint8_t **g_1645 = &g_74;
static uint8_t ***g_1644 = &g_1645;
static volatile struct S0 g_1654[7][1][5] = {{{{43,-101,2557,0,-0,118,470,1598},{16,-76,2569,0,-1,84,428,5478},{16,-76,2569,0,-1,84,428,5478},{43,-101,2557,0,-0,118,470,1598},{8,-84,45,0,0,-62,495,5515}}},{{{43,-101,2557,0,-0,118,470,1598},{16,-76,2569,0,-1,84,428,5478},{16,-76,2569,0,-1,84,428,5478},{43,-101,2557,0,-0,118,470,1598},{8,-84,45,0,0,-62,495,5515}}},{{{43,-101,2557,0,-0,118,470,1598},{16,-76,2569,0,-1,84,428,5478},{16,-76,2569,0,-1,84,428,5478},{43,-101,2557,0,-0,118,470,1598},{8,-84,45,0,0,-62,495,5515}}},{{{43,-101,2557,0,-0,118,470,1598},{16,-76,2569,0,-1,84,428,5478},{16,-76,2569,0,-1,84,428,5478},{43,-101,2557,0,-0,118,470,1598},{8,-84,45,0,0,-62,495,5515}}},{{{43,-101,2557,0,-0,118,470,1598},{16,-76,2569,0,-1,84,428,5478},{16,-76,2569,0,-1,84,428,5478},{43,-101,2557,0,-0,118,470,1598},{8,-84,45,0,0,-62,495,5515}}},{{{43,-101,2557,0,-0,118,470,1598},{16,-76,2569,0,-1,84,428,5478},{16,-76,2569,0,-1,84,428,5478},{43,-101,2557,0,-0,118,470,1598},{8,-84,45,0,0,-62,495,5515}}},{{{43,-101,2557,0,-0,118,470,1598},{16,-76,2569,0,-1,84,428,5478},{16,-76,2569,0,-1,84,428,5478},{43,-101,2557,0,-0,118,470,1598},{8,-84,45,0,0,-62,495,5515}}}};
static volatile uint8_t g_1665 = 0UL;/* VOLATILE GLOBAL g_1665 */
static int64_t g_1666 = 0xB99B52230BD688B2LL;
static volatile struct S0 g_1675 = {15,79,1128,3,-0,116,603,4932};/* VOLATILE GLOBAL g_1675 */
static uint32_t g_1689 = 4294967288UL;
static union U1 * volatile *g_1696 = &g_779[0];
static union U1 * volatile ** const g_1695 = &g_1696;
static uint32_t * const ****g_1711 = (void*)0;
static uint32_t g_1717 = 1UL;
static struct S0 *g_1741 = &g_689;
static struct S0 ** volatile g_1740 = &g_1741;/* VOLATILE GLOBAL g_1740 */
static int16_t ** volatile * volatile * volatile * volatile g_1787 = (void*)0;/* VOLATILE GLOBAL g_1787 */
static uint64_t ** const ***g_1878 = (void*)0;
static uint64_t * volatile *g_1943 = &g_1256;
static uint32_t g_1981 = 0UL;
static volatile struct S0 g_1987 = {36,15,380,1,1,-10,867,1126};/* VOLATILE GLOBAL g_1987 */
static union U1 g_2078 = {18446744073709551615UL};/* VOLATILE GLOBAL g_2078 */
static int64_t **g_2116[4] = {&g_64,&g_64,&g_64,&g_64};
static int64_t ***g_2115 = &g_2116[2];
static int64_t **** volatile g_2114[1] = {&g_2115};
static const struct S0 g_2134[5] = {{37,-124,4071,1,1,49,604,3742},{37,-124,4071,1,1,49,604,3742},{37,-124,4071,1,1,49,604,3742},{37,-124,4071,1,1,49,604,3742},{37,-124,4071,1,1,49,604,3742}};
static const int16_t *g_2138 = &g_213;
static const int16_t **g_2137 = &g_2138;
static const int16_t ***g_2136 = &g_2137;
static const int16_t ****g_2135 = &g_2136;
static struct S0 **g_2145 = &g_1741;
static struct S0 ***g_2144 = &g_2145;
static struct S0 ****g_2143 = &g_2144;
static const struct S0 g_2196 = {56,-59,2057,1,-1,-34,129,748};/* VOLATILE GLOBAL g_2196 */
static volatile union U1 g_2213 = {18446744073709551613UL};/* VOLATILE GLOBAL g_2213 */
static int32_t ** const ***g_2224 = (void*)0;
static const int64_t g_2239 = (-1L);
static const int64_t g_2241 = 0xA9FF659B3B8A3F9CLL;
static struct S0 g_2313[7] = {{37,33,1710,1,1,-118,327,4049},{28,22,2490,1,0,-109,246,4038},{37,33,1710,1,1,-118,327,4049},{37,33,1710,1,1,-118,327,4049},{28,22,2490,1,0,-109,246,4038},{37,33,1710,1,1,-118,327,4049},{37,33,1710,1,1,-118,327,4049}};
static struct S0 g_2335 = {5,-48,200,2,-1,86,466,2060};/* VOLATILE GLOBAL g_2335 */
static struct S0 g_2370 = {31,18,3332,1,1,-71,604,5585};/* VOLATILE GLOBAL g_2370 */
static const uint8_t g_2376 = 0xCDL;
static const volatile union U1 g_2390[1] = {{3UL}};
static const int32_t g_2394 = (-9L);
static int32_t ** volatile g_2443 = &g_397;/* VOLATILE GLOBAL g_2443 */
static int32_t * volatile g_2524 = &g_77[3];/* VOLATILE GLOBAL g_2524 */
static int64_t ** const *g_2532 = &g_2116[1];
static int64_t ** const **g_2531 = &g_2532;
static int64_t ** const *** volatile g_2530[6] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
static struct S0 g_2538 = {52,-92,53,2,0,-75,39,380};/* VOLATILE GLOBAL g_2538 */
static struct S0 g_2579[3][4][4] = {{{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}},{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}},{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}},{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}}},{{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}},{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}},{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}},{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}}},{{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}},{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}},{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}},{{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928},{44,113,2170,1,-1,-84,970,3928}}}};
static const int8_t * volatile *g_2584 = (void*)0;
static const int8_t * volatile * volatile * volatile g_2583 = &g_2584;/* VOLATILE GLOBAL g_2583 */
static const int8_t * volatile * volatile * volatile *g_2582[3][1][6] = {{{&g_2583,&g_2583,&g_2583,&g_2583,&g_2583,&g_2583}},{{&g_2583,&g_2583,&g_2583,&g_2583,&g_2583,&g_2583}},{{&g_2583,&g_2583,&g_2583,&g_2583,&g_2583,&g_2583}}};
static int32_t * const  volatile g_2590[6] = {&g_77[3],&g_77[3],&g_77[3],&g_77[3],&g_77[3],&g_77[3]};
static volatile union U1 g_2593 = {0x569C0FF02EEB5263LL};/* VOLATILE GLOBAL g_2593 */
static int32_t *** volatile g_2628[6] = {&g_1443[4][4][4],&g_1443[4][4][4],&g_1443[4][4][4],&g_1443[4][4][4],&g_1443[4][4][4],&g_1443[4][4][4]};


/* --- FORWARD DECLARATIONS --- */
static uint8_t  func_1(void);
static int32_t ** const  func_12(uint8_t  p_13, const int32_t * p_14, int32_t * p_15, const int32_t  p_16);
static const int32_t * func_23(const uint32_t  p_24, int32_t ** p_25, uint32_t  p_26, uint32_t  p_27, const int32_t * p_28);
static int64_t  func_44(uint8_t * const  p_45, int32_t  p_46);
static uint8_t * const  func_47(int32_t * p_48, int32_t ** p_49, const int64_t * p_50);
static int32_t * func_51(int32_t  p_52, int32_t * const * p_53);
static int32_t ** func_54(int8_t  p_55, const int32_t * p_56, int32_t  p_57, uint8_t * p_58, int8_t  p_59);
static uint8_t  func_61(int64_t * p_62, uint32_t  p_63);
static uint32_t  func_67(uint32_t  p_68, int8_t  p_69, int8_t  p_70);
static int8_t  func_71(uint8_t * p_72, int32_t  p_73);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4 g_3 g_9 g_1645 g_74 g_75
 * writes: g_4 g_3 g_9
 */
static uint8_t  func_1(void)
{ /* block id: 0 */
    int32_t *l_2[3][5][9] = {{{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0},{&g_3,&g_3,&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,(void*)0},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0}},{{&g_3,&g_3,&g_3,(void*)0,(void*)0,&g_3,&g_3,&g_3,&g_3},{(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{(void*)0,&g_3,&g_3,(void*)0,&g_3,(void*)0,&g_3,&g_3,(void*)0},{(void*)0,(void*)0,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3}},{{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,&g_3,&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3},{&g_3,(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0,&g_3},{&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0},{(void*)0,&g_3,&g_3,&g_3,&g_3,&g_3,&g_3,(void*)0,(void*)0}}};
    uint8_t *l_32 = &g_33;
    int32_t l_2555 = 0xCC6504EBL;
    const int32_t *l_2559 = &g_2394;
    int i, j, k;
    ++g_4[3][0][2];
    for (g_3 = 2; (g_3 >= 0); g_3 -= 1)
    { /* block id: 4 */
        return g_3;
    }
    for (g_3 = 0; (g_3 <= 5); g_3 = safe_add_func_int8_t_s_s(g_3, 7))
    { /* block id: 9 */
        uint8_t *l_17 = &g_18;
        uint8_t *l_21[3][5][9] = {{{&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22},{(void*)0,(void*)0,(void*)0,(void*)0,&g_22,&g_22,&g_22,&g_22,&g_22},{&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22},{&g_22,&g_22,(void*)0,&g_22,&g_22,(void*)0,&g_22,&g_22,&g_22},{(void*)0,&g_22,&g_22,&g_22,(void*)0,&g_22,&g_22,&g_22,&g_22}},{{&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22},{&g_22,&g_22,&g_22,(void*)0,&g_22,&g_22,&g_22,&g_22,&g_22},{&g_22,(void*)0,&g_22,&g_22,&g_22,(void*)0,&g_22,&g_22,&g_22},{&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22},{&g_22,(void*)0,&g_22,&g_22,&g_22,&g_22,(void*)0,&g_22,&g_22}},{{(void*)0,&g_22,(void*)0,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22},{&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22},{&g_22,&g_22,&g_22,&g_22,(void*)0,&g_22,(void*)0,&g_22,&g_22},{(void*)0,&g_22,&g_22,&g_22,&g_22,(void*)0,&g_22,&g_22,&g_22},{&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22,&g_22}}};
        const int64_t l_29 = 0xDB9622CFB64730E9LL;
        int64_t *l_38 = &g_39[4][5];
        int64_t *l_40 = &g_41[1];
        uint16_t l_2554 = 65531UL;
        int64_t *l_2556[1];
        int32_t l_2557[6][5] = {{0L,4L,0L,4L,0L},{0x9B82EDC0L,0x9B82EDC0L,0x9B82EDC0L,0x9B82EDC0L,0x9B82EDC0L},{0L,4L,0L,4L,0L},{0x9B82EDC0L,0x9B82EDC0L,0x9B82EDC0L,0x9B82EDC0L,0x9B82EDC0L},{0L,4L,0L,4L,0L},{0x9B82EDC0L,0x9B82EDC0L,0x9B82EDC0L,0x9B82EDC0L,0x9B82EDC0L}};
        int64_t l_2558 = 0xF66EBC83D4632091LL;
        int32_t ***l_2629 = &g_1443[3][3][2];
        int i, j, k;
        for (i = 0; i < 1; i++)
            l_2556[i] = &g_234;
        ++g_9;
    }
    return (**g_1645);
}


/* ------------------------------------------ */
/* 
 * reads : g_140 g_2579 g_1578.f1 g_2582 g_3 g_121 g_77 g_2593 g_2313.f1 g_1576 g_1185 g_1645 g_74 g_75 g_30 g_31 g_2134.f3 g_1644 g_777.f2
 * writes: g_1378 g_1186 g_106 g_777.f2 g_77
 */
static int32_t ** const  func_12(uint8_t  p_13, const int32_t * p_14, int32_t * p_15, const int32_t  p_16)
{ /* block id: 1128 */
    int8_t l_2570 = 7L;
    int8_t * const *l_2587 = &g_121;
    int8_t * const **l_2586 = &l_2587;
    int8_t * const ***l_2585[10] = {&l_2586,&l_2586,&l_2586,&l_2586,&l_2586,&l_2586,&l_2586,&l_2586,&l_2586,&l_2586};
    int8_t * const ****l_2588 = (void*)0;
    int8_t * const ****l_2589 = &l_2585[2];
    int32_t *l_2591 = (void*)0;
    int32_t l_2592 = 0xFB06713FL;
    int16_t *l_2607 = &g_1378;
    uint32_t l_2620 = 1UL;
    const int32_t **l_2621 = &g_106[0];
    int32_t *l_2626 = &g_77[3];
    int32_t ** const l_2627[2] = {&g_31,&g_31};
    int i;
    l_2592 = (((safe_sub_func_int8_t_s_s(((safe_mul_func_int16_t_s_s(((((!(safe_lshift_func_int8_t_s_u((safe_mul_func_int64_t_s_s((((l_2570 >= (g_140 , 0x05L)) == ((safe_mod_func_uint64_t_u_u((safe_add_func_int64_t_s_s(((l_2570 || (safe_sub_func_int16_t_s_s(((safe_mod_func_uint32_t_u_u((&l_2570 == ((g_2579[1][1][0] , ((safe_mod_func_int32_t_s_s(((g_1578.f1 , g_2582[2][0][1]) != ((*l_2589) = l_2585[7])), (*p_15))) || 9L)) , (*l_2587))), (*p_14))) == 0xF2L), p_13))) , l_2570), p_16)), 0x822E894D0847C51FLL)) == p_13)) , 0x5B0FBB6A00515F60LL), p_16)), 1))) == p_16) && p_16) || p_13), p_16)) >= l_2570), l_2570)) , p_13) & l_2570);
    (*l_2621) = (((((g_2593 , 0x3868L) & (safe_add_func_int32_t_s_s((safe_sub_func_uint16_t_u_u((safe_unary_minus_func_int16_t_s((safe_mul_func_int32_t_s_s((*p_15), ((((safe_div_func_int8_t_s_s((safe_sub_func_uint32_t_u_u(((((safe_div_func_int16_t_s_s(l_2592, g_2313[2].f1)) , ((*l_2607) = 0xF814L)) && (safe_mul_func_int32_t_s_s((safe_rshift_func_int32_t_s_s((safe_div_func_int8_t_s_s(((safe_rshift_func_int64_t_s_s(0x437C62FE86CE7215LL, 13)) >= ((((safe_rshift_func_uint8_t_u_u(0x00L, (((((safe_lshift_func_int32_t_s_u((((((((**g_1576) = p_15) != l_2591) && 0x38L) == 1UL) || l_2570) , (*p_15)), 16)) , (**g_1645)) <= (**g_1645)) < l_2570) , (*g_74)))) | l_2620) >= 2UL) ^ l_2620)), p_13)), 10)), (**g_30)))) > l_2620), (*g_31))), 7UL)) || (*p_15)) , p_16) & 1L))))), g_2134[0].f3)), (*p_14)))) && (***g_1644)) && 0x63L) , &p_16);
    if (g_3)
        goto lbl_2625;
lbl_2625:
    for (g_777.f2 = 0; (g_777.f2 != 9); g_777.f2 = safe_add_func_uint16_t_u_u(g_777.f2, 9))
    { /* block id: 1136 */
        uint32_t l_2624 = 0x7A2EE58EL;
        l_2624 = (*p_14);
    }
    (*l_2626) ^= (*p_15);
    return l_2627[1];
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static const int32_t * func_23(const uint32_t  p_24, int32_t ** p_25, uint32_t  p_26, uint32_t  p_27, const int32_t * p_28)
{ /* block id: 1126 */
    const int32_t *l_2560[4];
    int i;
    for (i = 0; i < 4; i++)
        l_2560[i] = &g_77[4];
    return l_2560[3];
}


/* ------------------------------------------ */
/* 
 * reads : g_1981 g_30 g_31 g_3 g_77 g_1185 g_1186 g_1645 g_74 g_75 g_2136 g_2137 g_2138 g_213 g_1378 g_1068 g_1069 g_9 g_2115 g_2116 g_2524 g_1438 g_105 g_2538 g_397 g_777.f0 g_113 g_1696 g_779
 * writes: g_1981 g_65 g_106 g_257 g_117 g_75 g_1378 g_105 g_77 g_397 g_777.f0 g_113 g_779
 */
static int64_t  func_44(uint8_t * const  p_45, int32_t  p_46)
{ /* block id: 1054 */
    uint16_t l_2458[4][7] = {{0UL,0x47AFL,0xE861L,0xAA9BL,0xE861L,0x47AFL,0UL},{0x47AFL,8UL,0x7B1AL,65535UL,0x9962L,0xE861L,0x9962L},{0x47AFL,0x9962L,0x9962L,0x47AFL,0xD5D2L,65535UL,0xAA9BL},{0UL,65535UL,0x7B1AL,0xD5D2L,0xD5D2L,0x7B1AL,65535UL}};
    uint32_t l_2462[5];
    uint32_t * const *l_2482 = &g_1186;
    uint32_t * const * const *l_2481[6][6] = {{(void*)0,&l_2482,&l_2482,(void*)0,(void*)0,&l_2482},{&l_2482,(void*)0,&l_2482,(void*)0,&l_2482,(void*)0},{(void*)0,&l_2482,(void*)0,(void*)0,&l_2482,(void*)0},{&l_2482,(void*)0,(void*)0,&l_2482,(void*)0,(void*)0},{(void*)0,&l_2482,(void*)0,&l_2482,&l_2482,(void*)0},{(void*)0,(void*)0,&l_2482,&l_2482,&l_2482,&l_2482}};
    uint32_t * const * const **l_2480 = &l_2481[3][2];
    uint8_t * const *l_2496 = &g_74;
    uint8_t * const **l_2495 = &l_2496;
    uint8_t * const ***l_2494 = &l_2495;
    int32_t l_2523 = 0xF123D7E6L;
    int32_t * const *l_2525 = &g_397;
    int64_t ** const *l_2529 = (void*)0;
    int64_t ** const **l_2528 = &l_2529;
    int32_t *l_2535 = (void*)0;
    int32_t l_2547 = 0x0600712AL;
    int32_t l_2548 = (-6L);
    int32_t l_2549 = 5L;
    int i, j;
    for (i = 0; i < 5; i++)
        l_2462[i] = 0x4C010B49L;
    for (g_1981 = (-11); (g_1981 < 4); ++g_1981)
    { /* block id: 1057 */
        int32_t l_2454 = 0xDA1F7977L;
        int32_t l_2456 = 0xFEC6B039L;
        int32_t l_2457 = 2L;
        int32_t *l_2526[3][4] = {{(void*)0,&g_77[3],(void*)0,(void*)0},{&g_77[3],&g_77[3],&g_77[3],&g_77[3]},{&g_77[3],(void*)0,(void*)0,&g_77[3]}};
        int i, j;
        for (g_65 = 0; (g_65 > 29); ++g_65)
        { /* block id: 1060 */
            int32_t l_2453 = 1L;
            int32_t l_2461 = 0xAEFF9B11L;
            int64_t ** const **l_2533 = &g_2532;
            if ((safe_rshift_func_uint16_t_u_s(l_2453, 14)))
            { /* block id: 1061 */
                if ((**g_30))
                    break;
            }
            else
            { /* block id: 1063 */
                int32_t *l_2455[4][6][7] = {{{&g_77[3],&g_117,(void*)0,(void*)0,&g_77[1],&g_77[2],&g_117},{&g_3,&g_117,&g_3,&g_117,&g_77[3],&g_77[3],&g_77[3]},{&g_3,&g_77[0],&g_3,&g_77[0],&g_3,&g_77[3],&g_77[3]},{&g_77[2],&g_77[3],&g_77[3],&g_77[3],(void*)0,&g_117,&g_117},{&g_77[3],&g_3,(void*)0,&g_3,&g_77[3],&g_77[3],&g_3},{&g_77[2],&g_77[3],&g_3,&g_3,&g_77[1],&g_77[2],(void*)0}},{{&g_3,&g_77[0],&g_77[0],&g_77[4],&g_117,&g_77[3],(void*)0},{&g_3,&g_77[0],&g_3,&g_77[3],(void*)0,&g_3,(void*)0},{&g_77[3],&g_3,(void*)0,&g_77[3],&g_3,&g_3,&g_117},{&g_3,&g_77[1],&g_77[1],&g_77[4],&g_3,&g_3,&g_3},{&g_3,&g_77[3],&g_77[3],&g_3,&g_77[1],(void*)0,&g_77[3]},{&g_117,&g_77[3],(void*)0,&g_3,&g_3,&g_77[3],&g_77[3]}},{{&g_3,&g_77[0],&g_77[3],&g_77[3],(void*)0,&g_77[3],&g_77[3]},{(void*)0,&g_117,(void*)0,&g_77[0],&g_3,&g_117,&g_3},{(void*)0,&g_77[3],&g_77[3],&g_117,&g_117,&g_77[3],&g_117},{&g_117,&g_77[3],&g_3,(void*)0,&g_77[3],&g_77[1],(void*)0},{&g_77[3],&g_3,&g_117,&g_3,&g_3,&g_3,&g_117},{(void*)0,&g_117,(void*)0,(void*)0,&g_3,&g_3,(void*)0}},{{&g_117,(void*)0,&g_117,&g_77[3],(void*)0,&g_77[1],&g_3},{&g_77[0],(void*)0,&g_3,&g_117,&g_77[3],&g_117,&g_3},{&g_3,&g_3,(void*)0,(void*)0,&g_77[3],&g_77[1],&g_77[1]},{&g_77[3],&g_77[3],&g_77[1],&g_3,&g_117,&g_3,&g_77[0]},{&g_77[0],(void*)0,&g_77[1],&g_117,&g_77[3],&g_3,(void*)0},{&g_117,&g_3,&g_77[1],&g_3,&g_77[1],&g_77[3],&g_117}}};
                int i, j, k;
                l_2458[1][6]--;
                ++l_2462[4];
            }
            if (l_2456)
            { /* block id: 1067 */
                const int32_t *l_2465 = &g_77[3];
                const int32_t **l_2466 = &g_106[3];
                uint32_t *****l_2473 = (void*)0;
                int32_t *l_2476 = &g_117;
                uint8_t ****l_2483[7][9][4] = {{{&g_1644,(void*)0,&g_1644,&g_1644},{&g_1644,(void*)0,(void*)0,&g_1644},{&g_1644,(void*)0,&g_1644,&g_1644},{&g_1644,&g_1644,&g_1644,&g_1644},{&g_1644,(void*)0,(void*)0,&g_1644},{(void*)0,(void*)0,(void*)0,&g_1644},{&g_1644,&g_1644,(void*)0,&g_1644},{&g_1644,&g_1644,(void*)0,(void*)0},{&g_1644,(void*)0,&g_1644,&g_1644}},{{&g_1644,&g_1644,(void*)0,&g_1644},{&g_1644,&g_1644,&g_1644,&g_1644},{(void*)0,&g_1644,&g_1644,(void*)0},{&g_1644,&g_1644,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1644},{&g_1644,&g_1644,&g_1644,(void*)0},{&g_1644,&g_1644,&g_1644,&g_1644},{&g_1644,&g_1644,(void*)0,(void*)0},{&g_1644,&g_1644,&g_1644,&g_1644}},{{&g_1644,(void*)0,(void*)0,(void*)0},{&g_1644,&g_1644,(void*)0,(void*)0},{&g_1644,&g_1644,(void*)0,&g_1644},{&g_1644,&g_1644,&g_1644,&g_1644},{(void*)0,&g_1644,(void*)0,&g_1644},{(void*)0,(void*)0,&g_1644,(void*)0},{&g_1644,&g_1644,&g_1644,&g_1644},{(void*)0,&g_1644,(void*)0,&g_1644},{&g_1644,(void*)0,&g_1644,&g_1644}},{{&g_1644,(void*)0,&g_1644,&g_1644},{&g_1644,&g_1644,(void*)0,&g_1644},{&g_1644,(void*)0,&g_1644,&g_1644},{&g_1644,(void*)0,&g_1644,&g_1644},{&g_1644,(void*)0,&g_1644,&g_1644},{&g_1644,&g_1644,&g_1644,&g_1644},{&g_1644,&g_1644,&g_1644,(void*)0},{&g_1644,&g_1644,(void*)0,&g_1644},{&g_1644,(void*)0,&g_1644,(void*)0}},{{&g_1644,&g_1644,(void*)0,&g_1644},{(void*)0,&g_1644,&g_1644,&g_1644},{&g_1644,(void*)0,&g_1644,(void*)0},{&g_1644,&g_1644,&g_1644,&g_1644},{&g_1644,&g_1644,&g_1644,&g_1644},{(void*)0,(void*)0,&g_1644,&g_1644},{&g_1644,(void*)0,&g_1644,&g_1644},{&g_1644,(void*)0,&g_1644,&g_1644},{(void*)0,&g_1644,&g_1644,(void*)0}},{{&g_1644,&g_1644,(void*)0,&g_1644},{(void*)0,&g_1644,&g_1644,&g_1644},{&g_1644,(void*)0,&g_1644,&g_1644},{&g_1644,&g_1644,&g_1644,&g_1644},{&g_1644,&g_1644,(void*)0,(void*)0},{(void*)0,&g_1644,&g_1644,&g_1644},{&g_1644,(void*)0,&g_1644,&g_1644},{&g_1644,(void*)0,&g_1644,&g_1644},{(void*)0,(void*)0,&g_1644,&g_1644}},{{&g_1644,&g_1644,(void*)0,&g_1644},{&g_1644,&g_1644,(void*)0,(void*)0},{(void*)0,(void*)0,&g_1644,&g_1644},{&g_1644,&g_1644,&g_1644,&g_1644},{&g_1644,&g_1644,&g_1644,(void*)0},{&g_1644,(void*)0,(void*)0,&g_1644},{&g_1644,&g_1644,&g_1644,&g_1644},{&g_1644,&g_1644,&g_1644,(void*)0},{&g_1644,(void*)0,&g_1644,&g_1644}}};
                int32_t l_2512[6];
                int i, j, k;
                for (i = 0; i < 6; i++)
                    l_2512[i] = 0L;
                (*l_2466) = l_2465;
                (*l_2476) = (safe_rshift_func_uint32_t_u_u(((**g_1185) = (safe_div_func_uint16_t_u_u(((safe_add_func_int64_t_s_s(0L, p_46)) == (&g_1575 == (l_2473 = &g_1575))), (safe_sub_func_int64_t_s_s(p_46, (*l_2465)))))), 31));
                if ((safe_mul_func_int32_t_s_s(((~7L) == (((((**g_1645) , (((l_2461 ^= (*g_74)) && 0xB0L) , (((void*)0 == l_2480) & p_46))) , (void*)0) != l_2483[1][1][2]) >= l_2453)), p_46)))
                { /* block id: 1073 */
                    uint8_t * const **l_2493 = (void*)0;
                    uint8_t * const ***l_2492 = &l_2493;
                    int16_t *l_2501 = (void*)0;
                    int16_t *l_2502 = &g_1378;
                    int16_t *l_2503 = (void*)0;
                    int16_t *l_2504 = &g_105;
                    const int32_t l_2509[2][2][5] = {{{(-4L),(-6L),0x8AF67B55L,(-6L),(-4L)},{0xFDE7498CL,(-6L),0xFC0A4C35L,(-4L),0xFC0A4C35L}},{{0xFC0A4C35L,0xFC0A4C35L,0x8AF67B55L,(-4L),0x4B9EA69DL},{(-6L),0xFDE7498CL,0xFDE7498CL,(-6L),0xFC0A4C35L}}};
                    int32_t l_2511 = 0x463D7759L;
                    int i, j, k;
                    if ((safe_lshift_func_int32_t_s_s(p_46, (p_46 != ((*l_2504) = ((*l_2502) ^= ((safe_sub_func_int8_t_s_s(((((*l_2476) = (((((safe_mod_func_uint64_t_u_u((p_46 > (***g_2136)), 18446744073709551615UL)) | (l_2492 == l_2494)) != (safe_lshift_func_int64_t_s_s(p_46, 43))) && ((**l_2496) = (safe_sub_func_uint32_t_u_u((*l_2465), 7L)))) & l_2456)) <= 0L) , p_46), 0x2FL)) , (-1L))))))))
                    { /* block id: 1078 */
                        int64_t *l_2510[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_2510[i] = &g_1666;
                        l_2512[2] = (safe_mod_func_uint64_t_u_u((safe_sub_func_uint64_t_u_u((**g_1068), (l_2511 = (l_2509[0][1][0] <= (-1L))))), l_2457));
                        return p_46;
                    }
                    else
                    { /* block id: 1082 */
                        return l_2461;
                    }
                }
                else
                { /* block id: 1085 */
                    int64_t * const *l_2518 = (void*)0;
                    int64_t * const **l_2517 = &l_2518;
                    int32_t l_2522 = (-1L);
                    l_2523 = (safe_div_func_uint16_t_u_u((l_2458[1][6] , 0x0451L), (safe_mul_func_uint16_t_u_u(((*g_2115) == ((*l_2517) = (void*)0)), (((safe_unary_minus_func_int16_t_s((safe_div_func_uint64_t_u_u((*l_2465), l_2522)))) == l_2457) < l_2453)))));
                }
            }
            else
            { /* block id: 1089 */
                int16_t l_2537 = 0L;
                (*g_2524) |= p_46;
                (*g_1438) = &p_46;
                l_2526[0][3] = func_51(p_46, l_2525);
                for (g_105 = 0; (g_105 <= 3); g_105 += 1)
                { /* block id: 1095 */
                    uint64_t **l_2527 = &g_1256;
                    if (((l_2527 = l_2527) != (void*)0))
                    { /* block id: 1097 */
                        int32_t *l_2534 = &g_117;
                        int i, j;
                        l_2533 = l_2528;
                        if (l_2458[g_105][(g_105 + 3)])
                            continue;
                        l_2535 = l_2534;
                    }
                    else
                    { /* block id: 1101 */
                        int8_t l_2536 = 1L;
                        int16_t ****l_2540 = &g_947;
                        int16_t *****l_2539 = &l_2540;
                        if (l_2536)
                            break;
                        if (l_2537)
                            break;
                        (**l_2525) = (g_2538 , (&g_2135 == l_2539));
                    }
                }
            }
            for (g_777.f0 = 0; (g_777.f0 <= 5); g_777.f0 += 1)
            { /* block id: 1110 */
                const int32_t *l_2541[6] = {&l_2456,&l_2461,&l_2461,&l_2456,&l_2461,&l_2461};
                int i;
                g_106[g_777.f0] = l_2541[4];
            }
        }
        if (p_46)
            break;
        if (p_46)
            continue;
        for (g_113 = 19; (g_113 > 0); g_113 = safe_sub_func_uint16_t_u_u(g_113, 5))
        { /* block id: 1118 */
            uint32_t l_2546 = 1UL;
            int32_t l_2550 = 0x3E6D4287L;
            uint32_t l_2551 = 0xAC76452AL;
            l_2547 = (safe_rshift_func_uint8_t_u_u(l_2546, 7));
            l_2551++;
            (*g_1696) = (*g_1696);
        }
    }
    return p_46;
}


/* ------------------------------------------ */
/* 
 * reads : g_283 g_563.f0 g_74 g_75 g_77 g_1186 g_257 g_1466 g_121 g_33 g_113 g_1256 g_1170 g_116 g_117 g_1502 g_1504 g_30 g_31 g_3 g_832 g_1005 g_1006 g_689.f7 g_689.f3 g_777.f2 g_1430 g_294 g_295 g_1068 g_1069 g_9 g_4 g_1578 g_1585 g_1586 g_1599 g_1619 g_1627 g_1633 g_1620 g_1644 g_1645 g_1665 g_1666 g_1675 g_1689 g_1695 g_1711 g_210 g_1717 g_1740 g_402.f0 g_1787 g_778 g_595 g_105 g_689 g_2078 g_140 g_785.f4 g_1064 g_1378 g_293 g_563.f2 g_2134 g_2135 g_1185 g_2136 g_2137 g_2138 g_213 g_1634 g_1654.f4 g_2143 g_2144 g_2145 g_1741 g_2213 g_2224 g_464 g_2213.f0 g_474 g_1654 g_2313 g_2335 g_2370 g_2376 g_2196.f3 g_2390 g_2394 g_1943 g_1576 g_382 g_2443
 * writes: g_563.f0 g_77 g_1170 g_777.f2 g_75 g_397 g_113 g_33 g_1430 g_1575 g_257 g_283 g_1633 g_1620 g_1644 g_210 g_1666 g_1717 g_1741 g_213 g_4 g_779 g_105 g_65 g_140 g_1378 g_563.f2 g_2135 g_2143 g_778 g_117 g_2078.f0
 */
static uint8_t * const  func_47(int32_t * p_48, int32_t ** p_49, const int64_t * p_50)
{ /* block id: 631 */
    const uint8_t l_1449 = 0x91L;
    int32_t l_1476[2];
    int8_t l_1477 = 2L;
    int32_t l_1605 = 0xE8D4E645L;
    int32_t l_1622 = 0xACCD4ACDL;
    uint8_t ***l_1647[9] = {&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645};
    const uint16_t *l_1690 = (void*)0;
    uint16_t l_1735[2][8][3] = {{{65535UL,0UL,1UL},{3UL,0x3FB0L,0UL},{0x0923L,1UL,0x203EL},{0UL,3UL,0UL},{0UL,0x4AFFL,1UL},{65535UL,0UL,0x542DL},{65527UL,0x0923L,0x0923L},{65527UL,0x542DL,0UL}},{{65535UL,1UL,0x4AFFL},{0UL,0UL,3UL},{0UL,0x203EL,1UL},{0x0923L,0UL,0x3FB0L},{3UL,1UL,0UL},{65535UL,0x203EL,0x55B7L},{0x55B7L,0x0E71L,0x55B7L},{0x4AFFL,0x0923L,0x75A0L}}};
    struct S0 *l_1738[1];
    int16_t ****l_1789 = &g_947;
    int16_t *****l_1788 = &l_1789;
    int32_t l_1790[6] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
    uint64_t **l_1803 = &g_1256;
    int32_t l_1848[9];
    uint16_t l_1874 = 0x0C07L;
    int32_t l_1950 = 4L;
    const int32_t *l_1954[4][2][7] = {{{(void*)0,&l_1476[0],&l_1790[0],&l_1476[0],&l_1790[0],&l_1476[0],(void*)0},{&l_1790[0],&l_1622,&l_1790[0],&l_1476[1],&g_3,&l_1476[0],&l_1790[0]}},{{(void*)0,&l_1622,(void*)0,&l_1476[0],&g_3,&l_1605,(void*)0},{(void*)0,&l_1476[0],&l_1790[0],&l_1476[0],&l_1790[0],&l_1476[0],(void*)0}},{{&l_1790[0],&l_1622,&l_1790[0],&l_1476[1],&g_3,&l_1476[0],&l_1790[0]},{(void*)0,&l_1622,(void*)0,&l_1476[0],&g_3,&l_1605,(void*)0}},{{(void*)0,&l_1476[0],&l_1790[0],&l_1476[0],&l_1790[0],&l_1476[0],(void*)0},{&l_1790[0],&l_1622,&l_1790[0],&l_1476[1],&g_3,&l_1476[0],&l_1790[0]}}};
    int64_t **l_2012 = &g_64;
    int64_t ***l_2011 = &l_2012;
    int8_t **l_2018 = (void*)0;
    uint64_t * const ***l_2027[5] = {&g_1633[3],&g_1633[3],&g_1633[3],&g_1633[3],&g_1633[3]};
    int32_t l_2039 = 0x234C7E6EL;
    int32_t l_2063 = 7L;
    int32_t l_2093[10];
    int8_t l_2123 = 0x78L;
    int32_t * const *l_2147 = &g_31;
    uint32_t l_2190 = 4294967295UL;
    struct S0 *** const *l_2191 = (void*)0;
    union U1 ** const l_2259[7][6][6] = {{{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]}},{{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]}},{{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]}},{{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]}},{{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]}},{{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]}},{{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]},{&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]}}};
    uint64_t *l_2284 = &g_2078.f0;
    int8_t l_2364 = (-1L);
    int8_t ***l_2442 = &g_271;
    int8_t ****l_2441 = &l_2442;
    int8_t *****l_2440[9][2][10] = {{{&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,(void*)0,&l_2441,&l_2441,&l_2441},{&l_2441,&l_2441,&l_2441,&l_2441,(void*)0,&l_2441,(void*)0,&l_2441,&l_2441,&l_2441}},{{&l_2441,(void*)0,(void*)0,&l_2441,(void*)0,(void*)0,&l_2441,&l_2441,(void*)0,&l_2441},{(void*)0,&l_2441,(void*)0,&l_2441,&l_2441,(void*)0,&l_2441,&l_2441,(void*)0,&l_2441}},{{(void*)0,&l_2441,(void*)0,&l_2441,(void*)0,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441},{(void*)0,(void*)0,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,(void*)0}},{{(void*)0,&l_2441,&l_2441,&l_2441,(void*)0,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441},{(void*)0,&l_2441,&l_2441,&l_2441,(void*)0,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441}},{{(void*)0,&l_2441,&l_2441,&l_2441,(void*)0,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441},{&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441}},{{&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441},{&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,(void*)0,&l_2441,&l_2441,&l_2441,&l_2441}},{{&l_2441,&l_2441,&l_2441,&l_2441,(void*)0,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441},{(void*)0,&l_2441,&l_2441,(void*)0,(void*)0,(void*)0,&l_2441,&l_2441,(void*)0,&l_2441}},{{&l_2441,&l_2441,&l_2441,(void*)0,(void*)0,&l_2441,&l_2441,(void*)0,&l_2441,(void*)0},{(void*)0,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441}},{{(void*)0,&l_2441,(void*)0,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,&l_2441,(void*)0},{&l_2441,&l_2441,(void*)0,&l_2441,(void*)0,(void*)0,&l_2441,&l_2441,&l_2441,&l_2441}}};
    uint16_t l_2444 = 65532UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_1476[i] = (-1L);
    for (i = 0; i < 1; i++)
        l_1738[i] = &g_1578;
    for (i = 0; i < 9; i++)
        l_1848[i] = 0xDAE5DB0CL;
    for (i = 0; i < 10; i++)
        l_2093[i] = 1L;
    if ((l_1449 == (*p_50)))
    { /* block id: 632 */
        uint64_t l_1468 = 0UL;
        int32_t l_1470 = 0x38A70DE7L;
        int32_t l_1475 = 0xD0805B79L;
        int32_t l_1478 = (-6L);
        int32_t l_1479 = 0x078E68CFL;
        int32_t l_1480[4];
        int64_t l_1482 = 2L;
        uint8_t l_1484 = 0x27L;
        uint8_t * const l_1487[7][7] = {{&g_75,&g_75,(void*)0,&g_33,&g_75,&g_75,&g_75},{&g_75,&g_75,&g_75,&g_75,&g_75,&g_75,&g_75},{(void*)0,(void*)0,&g_33,&g_75,(void*)0,&g_33,&g_33},{(void*)0,&g_33,&g_33,&g_33,&g_33,(void*)0,(void*)0},{(void*)0,&g_75,&g_33,(void*)0,&g_33,&g_75,&g_75},{&g_75,&g_75,(void*)0,&g_33,(void*)0,&g_75,&g_75},{&g_75,&g_75,&g_33,(void*)0,&g_75,&g_75,(void*)0}};
        int i, j;
        for (i = 0; i < 4; i++)
            l_1480[i] = (-1L);
        for (g_563.f0 = 1; (g_563.f0 == 57); ++g_563.f0)
        { /* block id: 635 */
            uint32_t l_1467[5][3] = {{8UL,1UL,1UL},{0x3C759836L,1UL,18446744073709551615UL},{0x4A44DE23L,8UL,0UL},{0x3C759836L,0x3C759836L,0UL},{8UL,0x4A44DE23L,18446744073709551615UL}};
            int64_t *l_1469[6] = {&g_234,&g_234,&g_234,&g_234,&g_234,&g_234};
            int32_t *l_1474[4][4][7] = {{{&l_1470,(void*)0,&l_1470,(void*)0,&l_1470,&g_77[1],(void*)0},{&g_77[3],&g_77[3],&g_77[3],&g_77[3],&g_77[3],&g_77[3],&g_77[3]},{&g_77[3],(void*)0,(void*)0,&g_3,(void*)0,&g_77[1],(void*)0},{&g_77[3],&g_117,&g_117,&g_77[3],(void*)0,&g_117,&g_77[3]}},{{(void*)0,&g_117,(void*)0,&g_117,&l_1470,&g_77[3],(void*)0},{(void*)0,&g_77[3],&g_77[3],&g_77[3],&g_117,&g_77[3],&g_77[3]},{&l_1470,&g_77[3],&l_1470,&g_77[3],&l_1470,(void*)0,(void*)0},{&g_3,&g_117,&g_77[3],&g_77[3],&g_77[3],&g_77[3],&g_77[3]}},{{(void*)0,&g_77[3],&g_77[3],&g_117,(void*)0,(void*)0,(void*)0},{&g_3,&g_77[3],&g_77[3],&g_77[3],&g_77[3],&g_3,&g_77[3]},{&l_1470,&g_77[3],(void*)0,&g_3,(void*)0,&g_117,&l_1470},{(void*)0,(void*)0,(void*)0,&g_77[3],&g_77[3],&g_77[3],&g_3}},{{(void*)0,&g_77[3],&l_1470,(void*)0,&l_1470,&g_77[3],(void*)0},{&g_77[3],&g_77[3],&g_3,&g_77[3],&g_117,&g_77[3],&g_117},{&g_77[3],&g_77[3],(void*)0,&g_77[3],&l_1470,&g_117,&l_1470},{&g_77[3],&g_117,&g_3,(void*)0,(void*)0,&g_3,&g_117}}};
            int8_t l_1481 = 0x8BL;
            int16_t l_1483 = 0xDD8AL;
            int i, j, k;
            (*p_48) = ((((0xEDL | (safe_lshift_func_int16_t_s_u(((safe_lshift_func_int8_t_s_s((safe_mul_func_uint32_t_u_u((((((safe_rshift_func_int64_t_s_u((l_1470 = (((*g_74) ^ ((((safe_lshift_func_uint32_t_u_u((~(*p_48)), (*g_1186))) || ((safe_mul_func_uint16_t_u_u((safe_unary_minus_func_uint16_t_u(0xB06EL)), 0x41CDL)) >= ((0x75FE8DE03383C42ALL < (g_1466 , ((l_1467[2][1] | l_1468) || 5UL))) , l_1449))) > (*g_74)) & 9L)) ^ l_1467[1][2])), 19)) | (*g_121)) & l_1467[2][1]) , l_1468) == (*g_1256)), 4294967287UL)), l_1468)) < l_1449), l_1449))) >= 0x37L) , l_1467[2][1]) < 0x1FL);
            for (g_1170 = 17; (g_1170 < 21); g_1170 = safe_add_func_uint8_t_u_u(g_1170, 5))
            { /* block id: 640 */
                uint8_t * const l_1473 = &g_210;
                (*p_48) ^= 0xB820165EL;
                return l_1473;
            }
            l_1484--;
        }
        return l_1487[0][4];
    }
    else
    { /* block id: 647 */
        uint8_t l_1501 = 0x69L;
        int32_t l_1512 = 0xF2F7A244L;
        uint32_t ** const *l_1532 = &g_1185;
        int32_t l_1538 = 7L;
        uint32_t l_1539[10] = {0x45CD1345L,0x04B3DF61L,0xAC59ECA3L,0x04B3DF61L,0x45CD1345L,0x45CD1345L,0x04B3DF61L,0xAC59ECA3L,0x04B3DF61L,0x45CD1345L};
        int32_t * const *l_1560 = &g_397;
        uint64_t ***l_1603 = &g_1255;
        uint64_t ****l_1602 = &l_1603;
        uint64_t l_1617 = 1UL;
        uint64_t l_1625 = 18446744073709551611UL;
        volatile struct S0 *l_1653 = &g_1654[2][0][1];
        int32_t l_1670 = (-1L);
        uint32_t l_1701 = 5UL;
        uint32_t ***** const l_1718 = &g_1575;
        uint32_t l_1793 = 4294967295UL;
        int16_t **l_1806 = &g_711;
        int32_t l_1820 = 0x3EACF584L;
        uint32_t l_1821 = 0x25CBA560L;
        uint16_t l_1825 = 0x2A27L;
        uint32_t l_1832 = 4294967294UL;
        uint16_t l_1855 = 0x074DL;
        uint32_t l_1883 = 18446744073709551609UL;
        uint32_t l_1920 = 6UL;
        uint8_t ****l_1929 = &g_1644;
        int64_t l_1996 = 0x52645FEBCD663BC9LL;
        int64_t ***l_2117 = &g_2116[1];
        int32_t l_2167[8] = {0xBCF9C5BDL,0x16FE3902L,0xBCF9C5BDL,0xBCF9C5BDL,0x16FE3902L,0xBCF9C5BDL,0xBCF9C5BDL,0x16FE3902L};
        const struct S0 *l_2195 = &g_2196;
        const struct S0 **l_2194 = &l_2195;
        const struct S0 ***l_2193 = &l_2194;
        const struct S0 ****l_2192[1];
        int32_t l_2336 = (-4L);
        uint64_t l_2354 = 0UL;
        int i;
        for (i = 0; i < 1; i++)
            l_2192[i] = &l_2193;
        if ((*g_116))
        { /* block id: 648 */
            return &g_33;
        }
        else
        { /* block id: 650 */
            uint64_t l_1490 = 0xE6A8061EA362CB1ELL;
            int16_t l_1500[5][7] = {{0x0F9FL,(-5L),0x89B3L,0xFC94L,0x89B3L,(-5L),0x0F9FL},{(-5L),0xD435L,(-1L),0x89B3L,0x0F9FL,(-5L),0x89B3L},{0x8B38L,0x1FD7L,(-7L),0xD435L,0xD435L,(-7L),0x1FD7L},{0xD435L,0x6FFFL,(-1L),0xFC94L,0x6FFFL,0x89B3L,0x1FD7L},{(-6L),0xD435L,0x89B3L,(-6L),0x1FD7L,(-6L),0x89B3L}};
            uint32_t **l_1505 = &g_1186;
            int32_t l_1506[8] = {0xFB221A8EL,0xFB221A8EL,0xFB221A8EL,0xFB221A8EL,0xFB221A8EL,0xFB221A8EL,0xFB221A8EL,0xFB221A8EL};
            int32_t l_1535[6][2][9] = {{{5L,(-1L),1L,0xAF6A1F6BL,0x54393E98L,5L,1L,1L,5L},{9L,1L,0x8C866E10L,0xE2059609L,0x95AE8EF2L,1L,(-3L),0x28BA41E8L,(-3L)}},{{5L,1L,0x8CB00C8BL,0x54393E98L,0x243424A8L,0xAF6A1F6BL,1L,0x54393E98L,0x54393E98L},{0x269D236DL,1L,0x30DFB867L,0x28BA41E8L,0x30DFB867L,1L,0x269D236DL,0xE2059609L,0L}},{{(-2L),0x243424A8L,0x2CB9679EL,0xAF6A1F6BL,5L,(-2L),1L,0x2CB9679EL,5L},{0x8C866E10L,0xE2059609L,(-3L),0xB6BDAC09L,9L,0xB6BDAC09L,(-3L),0xE2059609L,0x8C866E10L}},{{(-1L),0xAF6A1F6BL,0x8CB00C8BL,5L,(-1L),1L,0xAF6A1F6BL,0x54393E98L,5L},{0x30DFB867L,0xFDCCBB1CL,0L,0x28BA41E8L,(-9L),0xE2059609L,(-9L),0x28BA41E8L,0L}},{{(-1L),(-1L),0xAF6A1F6BL,0x8CB00C8BL,5L,(-1L),1L,0xAF6A1F6BL,0x54393E98L},{0x8C866E10L,0xFDCCBB1CL,0x8C866E10L,0xE2059609L,(-3L),0xB6BDAC09L,9L,0xB6BDAC09L,(-3L)}},{{(-2L),0xAF6A1F6BL,0xAF6A1F6BL,(-2L),0x243424A8L,0x2CB9679EL,0xAF6A1F6BL,5L,(-2L)},{0x269D236DL,0xE2059609L,0L,0xE2059609L,0x269D236DL,1L,0x30DFB867L,0x28BA41E8L,0x30DFB867L}}};
            uint32_t ****l_1577 = &g_1576;
            uint64_t ****l_1618 = (void*)0;
            uint16_t l_1630 = 0xDD0EL;
            int32_t *l_1649 = &l_1476[1];
            uint16_t l_1650 = 0x41B0L;
            const uint32_t l_1669[2] = {0xE2300810L,0xE2300810L};
            uint32_t * const l_1716[8] = {&g_1717,&g_1717,&g_1717,&g_1717,&g_1717,&g_1717,&g_1717,&g_1717};
            uint32_t * const *l_1715 = &l_1716[5];
            uint32_t * const **l_1714 = &l_1715;
            uint32_t * const ***l_1713 = &l_1714;
            uint32_t * const ****l_1712 = &l_1713;
            int8_t l_1728 = 0x06L;
            uint8_t * const l_1842 = &g_210;
            const uint64_t *l_1903 = (void*)0;
            const uint64_t **l_1902 = &l_1903;
            uint8_t ****l_1928[9] = {&g_1644,&g_1644,&g_1644,&g_1644,&g_1644,&g_1644,&g_1644,&g_1644,&g_1644};
            int16_t *l_2042 = &g_105;
            const union U1 **l_2081 = (void*)0;
            const union U1 ***l_2080 = &l_2081;
            const union U1 ****l_2079[8] = {&l_2080,&l_2080,&l_2080,&l_2080,&l_2080,&l_2080,&l_2080,&l_2080};
            int32_t ****l_2109 = &g_891[1];
            int i, j, k;
lbl_1847:
            for (g_777.f2 = 0; (g_777.f2 <= 3); g_777.f2 += 1)
            { /* block id: 653 */
                int64_t l_1491 = 0x771D04767D199A00LL;
                int32_t * const l_1503[10][3] = {{&l_1476[0],&g_3,&g_3},{&l_1476[1],&g_117,&g_77[3]},{&l_1476[0],&l_1476[1],&l_1476[0]},{&l_1476[1],&l_1476[1],&g_77[3]},{&l_1476[0],&l_1476[0],&g_3},{&l_1476[1],&l_1476[1],&l_1476[1]},{&g_3,&l_1476[1],&g_77[3]},{&l_1476[1],&g_117,&l_1476[1]},{&l_1476[0],&g_3,&g_77[3]},{&l_1476[1],&l_1476[1],&l_1476[1]}};
                uint64_t ** const *l_1707 = &g_1255;
                uint64_t ** const **l_1706 = &l_1707;
                uint8_t * const l_1730 = (void*)0;
                int i, j;
                if (((safe_lshift_func_int32_t_s_u(l_1490, ((l_1491 , ((1L != l_1477) == 0xF703L)) | 0UL))) >= (l_1490 < (((safe_mod_func_uint16_t_u_u((safe_rshift_func_int16_t_s_u((safe_div_func_uint16_t_u_u(((l_1477 > (safe_add_func_int16_t_s_s((((*g_74) = 249UL) , l_1500[4][3]), 0L))) , l_1501), 0xC8B8L)), 9)), 65530UL)) , (-9L)) , l_1501))))
                { /* block id: 655 */
                    (*g_1504) = (g_1502 , l_1503[8][2]);
                    (*p_48) |= (l_1506[2] |= (l_1505 == (void*)0));
                    if ((*p_48))
                        continue;
                }
                else
                { /* block id: 660 */
                    uint32_t ***l_1531[2][8][5] = {{{&l_1505,&l_1505,&g_1185,&g_1185,&l_1505},{&g_1185,&l_1505,&g_1185,&l_1505,&l_1505},{&g_1185,&l_1505,&g_1185,(void*)0,&g_1185},{&l_1505,&l_1505,&g_1185,&g_1185,&l_1505},{&g_1185,&g_1185,&l_1505,&g_1185,&g_1185},{&g_1185,&g_1185,&l_1505,(void*)0,&l_1505},{&l_1505,&l_1505,&l_1505,&g_1185,&l_1505},{&l_1505,&l_1505,&l_1505,&l_1505,(void*)0}},{{&l_1505,&l_1505,&g_1185,&g_1185,&g_1185},{&l_1505,&g_1185,(void*)0,&g_1185,&l_1505},{&l_1505,&l_1505,&l_1505,&g_1185,&g_1185},{&g_1185,&g_1185,&l_1505,&l_1505,&g_1185},{(void*)0,&g_1185,&l_1505,&l_1505,&l_1505},{&g_1185,&g_1185,&l_1505,&l_1505,&l_1505},{&l_1505,&l_1505,&l_1505,&g_1185,&g_1185},{&g_1185,&g_1185,&l_1505,(void*)0,&g_1185}}};
                    uint32_t ****l_1530 = &l_1531[0][4][2];
                    int32_t l_1534 = 0xE7D9CEC0L;
                    int32_t l_1536 = 0L;
                    int32_t l_1537 = (-6L);
                    int i, j, k;
                    if ((*p_48))
                    { /* block id: 661 */
                        int16_t l_1511 = 0L;
                        (*p_49) = (*p_49);
                        l_1512 ^= ((((((safe_lshift_func_int64_t_s_u((l_1490 < 2UL), 40)) , (safe_div_func_int32_t_s_s(l_1476[0], (**g_30)))) >= ((g_1170 , (g_832 , 1L)) || l_1511)) , (l_1490 == 0xDCADL)) , l_1501) , 0x773E4078L);
                    }
                    else
                    { /* block id: 664 */
                        uint64_t l_1517 = 0x9F2EE438C5B46AC0LL;
                        uint32_t ** const **l_1533 = &l_1532;
                        l_1535[4][0][4] ^= (safe_rshift_func_int16_t_s_u((safe_mod_func_uint8_t_u_u((*g_74), (((l_1517 , ((safe_mul_func_uint64_t_u_u(((+((safe_unary_minus_func_int16_t_s(((&g_1005 == &g_1005) && ((safe_mod_func_int64_t_s_s(l_1506[2], (safe_mul_func_uint16_t_u_u(((safe_mul_func_uint32_t_u_u((((safe_mul_func_int16_t_s_s(((l_1530 == (void*)0) , ((*g_1005) == ((*l_1533) = l_1532))), g_689.f7)) & l_1517) ^ (*g_1186)), l_1501)) >= l_1534), 0xC8F4L)))) < l_1534)))) <= 65535UL)) | 0x853BD4DB6FEAB450LL), g_689.f3)) & (*p_48))) && (*p_50)) & l_1534))), l_1534));
                    }
                    for (g_113 = 4; (g_113 >= 0); g_113 -= 1)
                    { /* block id: 670 */
                        int32_t *l_1550 = &l_1506[3];
                        uint16_t *l_1552[2][8][10] = {{{&g_1170,&g_1170,&g_4[3][0][2],&g_4[3][0][2],&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_4[3][0][2]},{&g_140,&g_1170,&g_140,&g_4[3][0][2],&g_140,&g_140,&g_4[3][0][2],&g_140,&g_1170,&g_140},{&g_140,&g_1170,&g_1170,&g_1170,&g_1170,&g_1170,&g_140,&g_140,&g_1170,&g_1170},{&g_1170,&g_140,&g_140,&g_1170,&g_1170,&g_1170,&g_1170,&g_1170,&g_140,&g_140},{&g_1170,&g_140,&g_4[3][0][2],&g_140,&g_140,&g_4[3][0][2],&g_140,&g_1170,&g_140,&g_4[3][0][2]},{&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_4[3][0][2],&g_4[3][0][2],&g_1170,&g_1170,&g_140},{&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_140},{&g_1170,&g_1170,&g_4[3][0][2],&g_4[3][0][2],&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_4[3][0][2]}},{{&g_140,&g_1170,&g_140,&g_4[3][0][2],&g_140,&g_140,&g_4[3][0][2],&g_140,&g_1170,&g_140},{&g_140,&g_1170,&g_1170,&g_1170,&g_1170,&g_1170,&g_140,&g_140,&g_1170,&g_1170},{&g_1170,&g_140,&g_140,&g_1170,&g_1170,&g_1170,&g_1170,&g_1170,&g_140,&g_140},{&g_1170,&g_140,&g_4[3][0][2],&g_140,&g_140,&g_4[3][0][2],&g_140,&g_1170,&g_140,&g_4[3][0][2]},{&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_4[3][0][2],&g_4[3][0][2],&g_1170,&g_1170,&g_140},{&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_140},{&g_1170,&g_1170,&g_4[3][0][2],&g_4[3][0][2],&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_140},{&g_1170,&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_140,&g_1170,&g_1170,&g_1170}}};
                        int8_t *l_1559 = &l_1477;
                        int i, j, k;
                        --l_1539[0];
                        (*p_49) = func_51(((safe_add_func_int32_t_s_s(((((((safe_mod_func_uint8_t_u_u(((safe_sub_func_uint8_t_u_u((g_1430[g_777.f2][(g_777.f2 + 3)] || (+(l_1536 = (!(l_1550 != ((+g_1430[g_777.f2][(g_113 + 2)]) , l_1550)))))), (safe_sub_func_int32_t_s_s((((((l_1534 < (safe_rshift_func_int32_t_s_s((l_1535[0][1][7] = ((*l_1550) &= ((*p_48) ^= 0L))), (safe_mul_func_int8_t_s_s((((*l_1559) = l_1490) > ((1L || 1L) == (*g_294))), 8UL))))) , 1L) & (*g_1256)) != 18446744073709551613UL) > (-1L)), 0x0E4BE4C8L)))) , (*g_74)), (-8L))) < g_33) || l_1536) >= l_1490) > l_1500[3][4]) ^ l_1449), 0xBD7457DCL)) || (*p_50)), l_1560);
                    }
                }
                if (((0x34F8L != ((((((l_1506[4] |= (**g_1068)) & g_4[3][0][2]) <= (9UL || ((l_1500[4][3] & (((((((*g_1256) , ((0L > (*g_74)) | ((safe_add_func_int16_t_s_s(((safe_div_func_int8_t_s_s((g_1430[1][3] |= ((((*g_121) &= ((0xB6E8L & l_1539[0]) < l_1500[4][3])) < l_1476[0]) & 0xC4A9F7B9L)), l_1535[4][0][4])) , 0x630EL), l_1535[4][0][4])) | l_1500[4][3]))) || l_1490) | l_1449) > l_1476[1]) , 18446744073709551612UL) | l_1535[4][0][4])) & 4294967295UL))) != l_1538) & 0xB077CD23F0DCE3A2LL) < 0xBF0B4FFA1CF36A59LL)) > (**g_30)))
                { /* block id: 683 */
                    uint32_t l_1588 = 18446744073709551609UL;
                    int64_t l_1596 = 6L;
                    if ((safe_rshift_func_uint32_t_u_u(l_1476[1], (safe_add_func_int64_t_s_s((*p_50), 1UL)))))
                    { /* block id: 684 */
                        int8_t l_1571 = 0xABL;
                        uint32_t ***l_1573 = &l_1505;
                        uint32_t ****l_1572[2];
                        uint32_t *****l_1574 = &l_1572[0];
                        int32_t l_1587 = 0x0415D3D1L;
                        int32_t *l_1589 = &l_1535[3][0][3];
                        uint64_t *****l_1604 = &l_1602;
                        int i;
                        for (i = 0; i < 2; i++)
                            l_1572[i] = &l_1573;
                        l_1589 = func_51(((((safe_sub_func_int64_t_s_s(l_1571, 6L)) <= (((*l_1574) = l_1572[1]) != (l_1577 = (g_1575 = (void*)0)))) < ((g_1578 , (safe_mod_func_int8_t_s_s((safe_mod_func_uint32_t_u_u(l_1535[2][0][7], (--(**l_1505)))), ((((*g_121) > (((l_1587 |= ((g_1585[1][2] , (g_1586 == l_1571)) >= l_1571)) , (*g_294)) >= l_1571)) | (*p_48)) , l_1588)))) & (*g_1256))) == 0x0D5485414CC51763LL), l_1560);
                        if ((*p_48))
                            break;
                        (*p_48) = (safe_add_func_uint64_t_u_u((0x7CL && (safe_mul_func_uint8_t_u_u((((safe_rshift_func_int8_t_s_u((*g_121), (((*g_1256) = 2UL) <= (l_1596 < (l_1476[1] == (safe_add_func_int16_t_s_s(l_1506[2], (g_1599 , ((safe_div_func_uint16_t_u_u((&g_1258 == ((*l_1604) = l_1602)), l_1477)) , 0x2820L))))))))) <= l_1506[2]) < 0xE7B7L), 0xB8L))), (*l_1589)));
                    }
                    else
                    { /* block id: 695 */
                        l_1605 &= l_1476[1];
                        if ((*p_48))
                            break;
                    }
                    if ((*p_48))
                        continue;
                }
                else
                { /* block id: 700 */
                    uint64_t *****l_1621 = &l_1602;
                    int32_t l_1626 = 0xE2AE3C5FL;
                    (*p_49) = func_51((0x2FC8B6D78D903DB5LL < (safe_add_func_uint64_t_u_u((**g_1068), l_1535[5][1][8]))), &p_48);
                    if ((safe_add_func_uint64_t_u_u((((((((4294967289UL ^ ((safe_mul_func_uint64_t_u_u(l_1490, (((*p_50) , (safe_rshift_func_uint8_t_u_s((~(safe_rshift_func_int16_t_s_s((l_1617 = l_1512), (l_1506[7] > (l_1622 = (l_1618 == ((*l_1621) = g_1619))))))), 4))) <= (safe_rshift_func_int32_t_s_u((*p_48), l_1625))))) < 0x31L)) && l_1626) ^ l_1626) && (-1L)) == l_1626) || 0xA6L) ^ l_1476[1]), g_1599.f4)))
                    { /* block id: 705 */
                        uint64_t * const ***l_1635 = &g_1633[2];
                        uint64_t ****l_1636 = &l_1603;
                        int32_t l_1643 = 8L;
                        uint8_t ****l_1646 = &g_1644;
                        int32_t l_1648 = 0x37340A96L;
                        l_1648 &= ((g_1627 , (safe_sub_func_uint32_t_u_u((l_1630 ^ (*p_48)), ((safe_add_func_int32_t_s_s(1L, (((*l_1635) = g_1633[2]) != ((*l_1636) = ((*g_1619) = (*l_1602)))))) , (safe_sub_func_uint32_t_u_u((((safe_lshift_func_int64_t_s_u((safe_sub_func_int16_t_s_s(l_1643, (((*l_1646) = g_1644) == l_1647[1]))), 1)) <= l_1477) || l_1622), l_1626)))))) && (**g_1645));
                        l_1649 = (void*)0;
                        --l_1650;
                        if ((*p_48))
                            continue;
                    }
                    else
                    { /* block id: 714 */
                        l_1653 = &g_474;
                    }
                    l_1476[0] ^= (*p_48);
                    (*p_49) = func_51((*p_48), &l_1503[8][2]);
                }
                for (g_33 = 0; (g_33 <= 3); g_33 += 1)
                { /* block id: 722 */
                    int32_t l_1721 = 0xD2E6276DL;
                    uint64_t l_1729 = 18446744073709551606UL;
                    int32_t * const *l_1768 = (void*)0;
                    int i, j;
                    if ((safe_rshift_func_uint64_t_u_u((safe_unary_minus_func_int32_t_s((safe_lshift_func_uint8_t_u_u((safe_add_func_uint16_t_u_u(0x33E6L, (((safe_unary_minus_func_int32_t_s((g_1430[g_777.f2][(g_33 + 3)] & (safe_add_func_int32_t_s_s(g_1665, g_1666))))) < (safe_add_func_uint8_t_u_u(l_1669[0], (*g_121)))) > 65534UL))), (**g_1645))))), (1L >= 0x676B3AB9L))))
                    { /* block id: 723 */
                        if ((*p_48))
                            break;
                        if (l_1605)
                            continue;
                        (*p_48) = l_1670;
                    }
                    else
                    { /* block id: 727 */
                        uint8_t l_1678 = 8UL;
                        int32_t l_1697 = 6L;
                        int32_t l_1698 = 0L;
                        (*p_48) &= ((safe_sub_func_int16_t_s_s(((safe_mod_func_int16_t_s_s(((g_1675 , (safe_mul_func_uint8_t_u_u(l_1678, (-3L)))) & (((+((((((l_1698 = (safe_mul_func_int8_t_s_s((safe_div_func_uint32_t_u_u(g_1430[g_777.f2][(g_33 + 3)], (((safe_mod_func_uint32_t_u_u((safe_rshift_func_int16_t_s_s((+(l_1697 ^= (((**l_1505) &= (g_1689 , (l_1690 == &g_1170))) > (safe_div_func_int16_t_s_s((safe_sub_func_int32_t_s_s((l_1622 > ((l_1678 , (void*)0) == g_1695)), l_1605)), l_1678))))), 5)), g_1430[g_777.f2][(g_33 + 3)])) , l_1477) && 0xF574L))), (*g_121)))) , (*g_121)) | l_1622) , (void*)0) != (void*)0) < 0x1EB382FBL)) <= (*g_121)) >= 1UL)), (-8L))) | (**g_1645)), g_1430[g_777.f2][(g_33 + 3)])) <= 0x530862CA97CDAE33LL);
                        (*p_48) |= (safe_lshift_func_int8_t_s_u(l_1701, 4));
                        if ((*p_48))
                            break;
                        (*p_48) = 0x3208E7B5L;
                    }
                    if ((0xB9012894L == l_1477))
                    { /* block id: 736 */
                        uint64_t l_1726 = 0x897C84CAAF4FBB05LL;
                        int64_t *l_1727 = &g_1666;
                        l_1728 = ((*p_48) &= (safe_sub_func_uint64_t_u_u(((--(***g_1644)) , ((void*)0 == l_1706)), ((*l_1727) = (!(((l_1712 = g_1711) == l_1718) || ((**g_30) >= ((*g_121) ^ (safe_mod_func_int8_t_s_s((((g_210--) , &p_49) == (void*)0), ((safe_rshift_func_uint16_t_u_s(g_1430[g_777.f2][(g_33 + 3)], 6)) ^ l_1726)))))))))));
                        if (l_1729)
                            break;
                    }
                    else
                    { /* block id: 744 */
                        (*p_49) = (*p_49);
                        return l_1730;
                    }
                    if ((safe_sub_func_uint32_t_u_u(0x85542E8DL, ((****l_1713)++))))
                    { /* block id: 749 */
                        struct S0 **l_1739 = (void*)0;
                        ++l_1735[1][5][1];
                        if ((*p_48))
                            continue;
                        (*g_1740) = l_1738[0];
                    }
                    else
                    { /* block id: 753 */
                        int16_t l_1744 = (-7L);
                        int16_t *l_1753 = &g_213;
                        uint16_t *l_1766[1];
                        int32_t l_1767[6] = {1L,1L,1L,1L,1L,1L};
                        int i, j;
                        for (i = 0; i < 1; i++)
                            l_1766[i] = (void*)0;
                        (*p_48) = 0x5846480FL;
                        (*p_49) = func_51(((safe_lshift_func_uint16_t_u_u(0xFC94L, 3)) > (l_1744 < ((safe_rshift_func_uint64_t_u_s(((safe_lshift_func_uint16_t_u_s((l_1767[3] |= (safe_sub_func_int8_t_s_s(((safe_sub_func_uint32_t_u_u((g_1430[g_777.f2][(g_33 + 3)] == ((*l_1753) = l_1670)), (g_1430[g_777.f2][(g_33 + 3)] > (safe_add_func_uint64_t_u_u(((safe_add_func_uint64_t_u_u(((safe_div_func_int64_t_s_s((*p_50), (*p_50))) > (safe_lshift_func_uint64_t_u_s((l_1744 > (((safe_lshift_func_uint8_t_u_u((safe_sub_func_int8_t_s_s((l_1721 = (*g_121)), 0xB2L)), l_1744)) , 9UL) ^ g_1430[g_777.f2][(g_33 + 1)])), 28))), 0xEC6E2D85D0BBA10ALL)) || (*p_48)), 0x8AFA2260BCC0CD64LL))))) ^ l_1729), 255UL))), l_1735[1][5][1])) , 0xE1EB98ED592A384CLL), (*p_50))) <= (*g_294)))), l_1768);
                        l_1767[0] &= 0x96F9CED4L;
                    }
                }
            }
            if (((((((safe_sub_func_int8_t_s_s((safe_mul_func_uint16_t_u_u((g_4[1][1][2]--), (((*g_74) = (safe_sub_func_uint16_t_u_u((l_1605 && (((((void*)0 == &g_1619) , l_1476[0]) < ((safe_mod_func_uint64_t_u_u(((((((safe_mul_func_int64_t_s_s((g_402.f0 , (l_1476[1] ^ (safe_sub_func_uint16_t_u_u((l_1735[1][5][1] > 0x42L), (safe_add_func_int64_t_s_s((safe_add_func_int64_t_s_s((g_1787 != l_1788), l_1790[0])), g_777.f2)))))), l_1625)) || l_1476[0]) && l_1622) , l_1669[1]) & l_1449) ^ (*p_48)), 1UL)) || l_1735[1][0][0])) , 0xEF0669FA068C17C6LL)), l_1790[0]))) >= l_1500[4][3]))), 0L)) , 0x1DL) >= l_1605) , l_1477) < 0UL) || l_1449))
            { /* block id: 765 */
                int16_t **l_1807[1];
                int32_t l_1808 = 0L;
                int32_t l_1809 = 9L;
                union U1 *l_1836 = &g_563;
                int i;
                for (i = 0; i < 1; i++)
                    l_1807[i] = (void*)0;
                (*p_49) = func_51((l_1790[0] = ((l_1790[0] > (safe_sub_func_uint32_t_u_u(((l_1793 <= (l_1476[0] = (l_1809 &= (((((safe_rshift_func_int16_t_s_s(((safe_mul_func_int16_t_s_s((3L & (((safe_lshift_func_int8_t_s_s((safe_unary_minus_func_int64_t_s((safe_rshift_func_uint8_t_u_u(((void*)0 != l_1803), 0)))), 4)) || (0xF0D1L ^ ((l_1806 = &g_711) != (l_1807[0] = l_1807[0])))) | (0xB41E9E76L > l_1808))), l_1535[4][0][4])) > l_1539[5]), 14)) , 0UL) & (***g_1644)) , 0xFBL) != 0x11L)))) , l_1808), l_1701))) && (*p_48))), &l_1649);
                for (l_1701 = 0; (l_1701 != 52); l_1701++)
                { /* block id: 774 */
                    int32_t *l_1812 = &l_1538;
                    int32_t *l_1813 = (void*)0;
                    int32_t *l_1814 = (void*)0;
                    int32_t *l_1815 = &l_1622;
                    int32_t *l_1816 = &l_1790[4];
                    int32_t *l_1817 = &l_1790[0];
                    int32_t *l_1818 = &l_1622;
                    int32_t *l_1819[4][1][1] = {{{&l_1506[2]}},{{&l_1512}},{{&l_1506[2]}},{{&l_1512}}};
                    int i, j, k;
                    l_1821++;
                }
                if (((void*)0 != l_1806))
                { /* block id: 777 */
                    int32_t *l_1824[1];
                    int16_t l_1835 = 0x5422L;
                    uint64_t l_1839 = 1UL;
                    int i;
                    for (i = 0; i < 1; i++)
                        l_1824[i] = &l_1622;
                    ++l_1825;
                    l_1622 ^= (safe_add_func_int32_t_s_s((*p_48), ((((l_1790[0] != (safe_lshift_func_uint16_t_u_u(l_1832, ((safe_rshift_func_uint32_t_u_s(((l_1835 >= (((((*g_778) = l_1836) == (void*)0) >= (**g_1068)) < (((l_1808 = (safe_lshift_func_int64_t_s_s(l_1839, (*p_50)))) > l_1809) == l_1790[0]))) <= 0xAEL), 11)) , g_595[3])))) != l_1605) == l_1809) ^ g_1689)));
                    for (l_1512 = 8; (l_1512 <= 28); ++l_1512)
                    { /* block id: 784 */
                        if ((*p_48))
                            break;
                    }
                }
                else
                { /* block id: 787 */
                    return l_1842;
                }
            }
            else
            { /* block id: 790 */
                int8_t l_1851[3];
                int32_t *l_1854[7] = {&g_77[4],&g_77[4],&g_77[3],&g_77[4],&g_77[4],&g_77[3],&g_77[4]};
                int i;
                for (i = 0; i < 3; i++)
                    l_1851[i] = 0xCBL;
                for (l_1490 = (-7); (l_1490 == 60); l_1490 = safe_add_func_uint32_t_u_u(l_1490, 9))
                { /* block id: 793 */
                    union U1 * const l_1852 = &g_777;
                    (*p_49) = &l_1535[4][0][4];
                    for (g_113 = (-16); (g_113 <= 8); g_113 = safe_add_func_int8_t_s_s(g_113, 2))
                    { /* block id: 797 */
                        union U1 **l_1853 = &g_779[0];
                        if (l_1670)
                            goto lbl_1847;
                        (*l_1853) = ((++(*g_74)) , (l_1851[2] , l_1852));
                        (*p_49) = (*g_30);
                    }
                }
                l_1855++;
            }
lbl_2102:
            for (l_1538 = (-17); (l_1538 < (-21)); l_1538--)
            { /* block id: 808 */
                uint64_t **l_1862 = &g_1256;
                int32_t l_1875 = 0L;
                int32_t * const *l_1885 = &l_1649;
                uint8_t l_1914 = 255UL;
                uint32_t l_1984 = 0xA5911ABCL;
                uint32_t l_1985 = 0xDEA45973L;
                union U1 ***l_1986 = &g_778;
                int32_t ***** const l_2034 = &g_890;
            }
            if (((*p_48) = (safe_mul_func_int16_t_s_s(((*l_2042) &= (l_2039 == (safe_add_func_uint64_t_u_u(l_1728, (*p_50))))), l_1996))))
            { /* block id: 886 */
                const uint32_t l_2049 = 4294967288UL;
                int16_t l_2077 = 5L;
                uint16_t l_2092[7][1][3] = {{{1UL,0xF5D2L,0xF5D2L}},{{0x7EB2L,0xF5D2L,0x1BC2L}},{{0xECF6L,1UL,0UL}},{{0x7EB2L,0x7EB2L,0UL}},{{1UL,0xECF6L,0x1BC2L}},{{0xF5D2L,0x7EB2L,0xF5D2L}},{{0xF5D2L,1UL,0x7EB2L}}};
                int i, j, k;
                for (l_2039 = 22; (l_2039 >= (-27)); l_2039 = safe_sub_func_int32_t_s_s(l_2039, 9))
                { /* block id: 889 */
                    uint16_t l_2058 = 1UL;
                    int32_t l_2067 = 0xCA8EFCA5L;
                    if ((*p_48))
                    { /* block id: 890 */
                        int64_t *l_2050 = (void*)0;
                        int64_t *l_2051 = &g_65;
                        int32_t l_2056 = 4L;
                        int64_t *l_2057[3][1][7] = {{{&l_1996,&l_1996,&l_1996,&l_1996,&l_1996,&l_1996,&l_1996}},{{&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064,&g_1064}},{{&l_1996,&l_1996,&l_1996,&l_1996,&l_1996,&l_1996,&l_1996}}};
                        int32_t l_2066 = 0xC77D8904L;
                        int32_t * const *l_2068[9][4][3] = {{{&g_397,&g_397,&g_397},{&g_397,&g_31,(void*)0},{(void*)0,&g_31,&g_397},{&g_397,&l_1649,&g_397}},{{&g_397,&l_1649,&g_397},{&g_31,&l_1649,&g_31},{&g_31,&g_31,&l_1649},{&g_31,&g_31,&g_31}},{{&l_1649,&g_397,&g_397},{&g_397,(void*)0,&g_397},{&l_1649,&l_1649,&g_397},{&g_31,&g_31,(void*)0}},{{&g_31,&l_1649,&g_397},{&g_31,(void*)0,&l_1649},{&g_397,&g_397,&g_397},{&g_397,&g_31,(void*)0}},{{(void*)0,&g_31,&g_397},{&g_397,&l_1649,&g_397},{&g_397,&l_1649,&g_397},{&g_31,&l_1649,&g_31}},{{&g_31,&g_31,&l_1649},{&g_31,&g_31,&g_31},{&l_1649,&g_397,&g_397},{&g_397,(void*)0,&g_397}},{{&l_1649,&l_1649,&g_397},{&g_31,&g_31,(void*)0},{&g_31,&l_1649,&g_397},{&g_31,(void*)0,&l_1649}},{{&g_397,&g_397,&g_397},{&g_397,&g_31,(void*)0},{(void*)0,&g_31,&g_397},{&g_397,&l_1649,&g_397}},{{&g_397,&l_1649,&g_397},{&g_31,&l_1649,&g_31},{&g_31,&g_31,&l_1649},{&g_31,&g_31,&g_31}}};
                        uint16_t *l_2084[6][7][6] = {{{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058}},{{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058}},{{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058}},{{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058}},{{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058}},{{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058},{&l_2058,&l_2058,&l_2058,&l_2058,&l_2058,&l_2058}}};
                        int64_t l_2091 = 0x67EF67726C1391FDLL;
                        int16_t l_2094 = (-10L);
                        int i, j, k;
                        (*p_49) = func_51((((*l_2042) = ((((safe_lshift_func_int64_t_s_u((safe_mul_func_int8_t_s_s((((l_2049 || 0UL) ^ (((*l_2051) = l_2049) | ((safe_mul_func_int32_t_s_s((safe_mod_func_int64_t_s_s((l_2058 |= (l_2056 ^= (*p_50))), (g_689 , 9UL))), (*g_1186))) > (((safe_add_func_int8_t_s_s((safe_add_func_int8_t_s_s((l_2063 , (safe_add_func_uint32_t_u_u((&g_4[3][0][2] != &g_4[3][0][2]), (*p_48)))), 1L)), l_2049)) < l_2066) || 0xCC12L)))) == (**g_1645)), (*g_74))), l_2066)) || l_2049) < l_2049) && l_2049)) == l_2067), l_2068[1][1][0]);
                        (*p_48) = ((-4L) && (safe_rshift_func_int16_t_s_s((safe_mul_func_uint8_t_u_u((((((((safe_sub_func_uint8_t_u_u((safe_sub_func_uint32_t_u_u((((((l_2077 && ((*l_2042) = ((((g_2078 , &g_1695) == l_2079[4]) > ((((((***g_1644) = ((safe_rshift_func_uint32_t_u_u((((*p_50) && ((g_140++) , (l_2058 , ((safe_lshift_func_uint64_t_u_s((safe_div_func_uint16_t_u_u((l_2091 | ((((***l_1714) = (l_2058 , l_2049)) == 0xB8C1753EL) , 0UL)), (-7L))), 55)) <= 0x9074L)))) <= g_785.f4), 25)) ^ l_1500[0][2])) && (-9L)) < l_2092[0][0][1]) != g_595[3]) , l_2067)) || 0x05C1C6A6206A6716LL))) , (*g_121)) , l_2067) != (-1L)) == l_2092[0][0][1]), l_2067)), 0x97L)) != 0x1CB8L) > l_2093[9]) , (*g_1256)) <= g_1064) & l_2094) ^ (*g_31)), 0x3AL)), 1)));
                        (*p_48) &= (-1L);
                        if (l_2058)
                            continue;
                    }
                    else
                    { /* block id: 903 */
                        uint32_t l_2095 = 0x91FC1A80L;
                        ++l_2095;
                    }
                    return (**g_1644);
                }
                for (g_1378 = 0; (g_1378 < (-10)); --g_1378)
                { /* block id: 910 */
                    for (g_283 = 5; (g_283 != 6); g_283++)
                    { /* block id: 913 */
                        if (g_113)
                            goto lbl_2102;
                        return (*g_1645);
                    }
                }
                (*p_48) &= 0xF2223AF7L;
                (*p_48) ^= (safe_rshift_func_uint64_t_u_s((safe_mul_func_int32_t_s_s((safe_mod_func_int8_t_s_s(0xACL, (l_2077 , (**g_1645)))), ((**g_293) <= ((void*)0 != l_2109)))), 13));
            }
            else
            { /* block id: 920 */
                uint16_t *l_2111 = &l_1735[1][5][1];
                int32_t l_2120 = (-1L);
                (*p_48) = (~(++(*l_2111)));
                l_2117 = &l_2012;
                for (l_1793 = 18; (l_1793 != 29); l_1793 = safe_add_func_int8_t_s_s(l_1793, 1))
                { /* block id: 926 */
                    for (l_1883 = 0; l_1883 < 9; l_1883 += 1)
                    {
                        l_1848[l_1883] = 0x6E620018L;
                    }
                    if (l_2120)
                        break;
                }
            }
        }
        for (g_563.f2 = 0; (g_563.f2 < 50); ++g_563.f2)
        { /* block id: 934 */
            int64_t l_2162[9][2] = {{0x6258F408FB6C8EA2LL,0L},{0x6258F408FB6C8EA2LL,0x6258F408FB6C8EA2LL},{0L,0x6258F408FB6C8EA2LL},{0x6258F408FB6C8EA2LL,0L},{0x6258F408FB6C8EA2LL,0x6258F408FB6C8EA2LL},{0L,0x6258F408FB6C8EA2LL},{0x6258F408FB6C8EA2LL,0L},{0x6258F408FB6C8EA2LL,0x6258F408FB6C8EA2LL},{0L,0x6258F408FB6C8EA2LL}};
            int32_t l_2165[9] = {0x47B79CC9L,0x47B79CC9L,0x47B79CC9L,0x47B79CC9L,0x47B79CC9L,0x47B79CC9L,0x47B79CC9L,0x47B79CC9L,0x47B79CC9L};
            int16_t l_2166[2][10] = {{0x7809L,(-8L),0x7809L,0xD175L,0xD175L,0x7809L,(-8L),0x7809L,0xD175L,0xD175L},{0x7809L,(-8L),0x7809L,0xD175L,0xD175L,0x7809L,(-8L),0x7809L,0xD175L,0xD175L}};
            int32_t *l_2229 = &l_2167[0];
            int32_t *l_2230 = (void*)0;
            int32_t *l_2231 = &l_1605;
            int32_t *l_2232 = &g_117;
            int32_t ** const l_2228[2][7] = {{&l_2231,&l_2229,&l_2231,&l_2230,&l_2230,&l_2231,&l_2229},{&l_2230,&l_2229,&l_2232,&l_2232,&l_2229,&l_2230,&l_2229}};
            int32_t ** const *l_2227 = &l_2228[0][1];
            int32_t ** const **l_2226 = &l_2227;
            int32_t ** const ***l_2225 = &l_2226;
            int32_t **** const *l_2233 = &g_890;
            uint32_t l_2242 = 0xCE988F20L;
            uint64_t **l_2285 = (void*)0;
            uint64_t l_2310 = 1UL;
            uint8_t *l_2373 = &g_210;
            uint64_t l_2375 = 0xD58368254E3FFEBELL;
            uint16_t *l_2419 = &l_1874;
            uint8_t *** const *l_2439[5][6] = {{(void*)0,(void*)0,&l_1647[8],(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_1647[8]},{(void*)0,&g_1644,(void*)0,(void*)0,&g_1644,(void*)0},{(void*)0,(void*)0,&l_1647[8],(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,&l_1647[8]}};
            uint8_t *** const **l_2438 = &l_2439[4][4];
            int i, j;
            if ((*p_48))
                break;
            if (l_2123)
            { /* block id: 936 */
                struct S0 **l_2142 = &l_1738[0];
                struct S0 ***l_2141 = &l_2142;
                struct S0 ****l_2140[2];
                int32_t l_2156 = 0x47D096CAL;
                int32_t l_2161 = 0x49CA4926L;
                int32_t l_2164[7][3][3] = {{{(-1L),0x4A07B356L,0x4A07B356L},{0x6C5C139BL,0L,0L},{0x993B55B6L,0x1E1B29A8L,(-1L)}},{{0x7D03137DL,0x8456AB41L,(-1L)},{1L,0x413CB47CL,3L},{0x84B3CD93L,0x8456AB41L,0xD63D351BL}},{{0x6C5C139BL,0x1E1B29A8L,0x6ED2B8FFL},{0x6FC11CE4L,0L,(-1L)},{0x413CB47CL,0x4A07B356L,(-3L)}},{{0x413CB47CL,0x413CB47CL,0x6C5C139BL},{0x6FC11CE4L,3L,0x8456AB41L},{0x6C5C139BL,0xA16318BBL,0xF203916BL}},{{0x84B3CD93L,0x96EB5099L,(-1L)},{1L,0x6C5C139BL,0xF203916BL},{0x7D03137DL,0x413CB47CL,0x8456AB41L}},{{0x993B55B6L,0xD63D351BL,0x6C5C139BL},{0x6C5C139BL,0x9DA0E182L,(-3L)},{(-1L),0x413CB47CL,(-1L)}},{{0xD63D351BL,0x6FC11CE4L,0x96EB5099L},{0x4A07B356L,0x6C5C139BL,0x6FC11CE4L},{(-3L),0x84B3CD93L,0x993B55B6L}}};
                uint8_t l_2170 = 0UL;
                int i, j, k;
                for (i = 0; i < 2; i++)
                    l_2140[i] = &l_2141;
                for (g_33 = 14; (g_33 < 59); g_33 = safe_add_func_uint16_t_u_u(g_33, 6))
                { /* block id: 939 */
                    int16_t ****l_2133[5][2] = {{&g_947,&g_947},{&g_947,&g_947},{&g_947,&g_947},{&g_947,&g_947},{&g_947,&g_947}};
                    uint32_t *l_2139 = &l_1821;
                    uint64_t *** const *l_2154 = &l_1603;
                    const int32_t l_2157 = 0L;
                    int32_t l_2163 = 0xE4F589C3L;
                    int32_t l_2168[8][8] = {{1L,1L,1L,1L,1L,1L,1L,1L},{0xB26F4A63L,1L,0xB26F4A63L,1L,1L,0xB26F4A63L,1L,0xB26F4A63L},{3L,1L,1L,1L,3L,3L,1L,1L},{3L,3L,1L,1L,1L,3L,3L,1L},{0xB26F4A63L,1L,1L,0xB26F4A63L,1L,0xB26F4A63L,1L,1L},{1L,1L,1L,1L,1L,1L,1L,1L},{0xB26F4A63L,1L,0xB26F4A63L,1L,1L,0xB26F4A63L,1L,0xB26F4A63L},{3L,1L,1L,1L,3L,3L,1L,1L}};
                    int8_t l_2169 = 1L;
                    int i, j;
                    if ((safe_div_func_int32_t_s_s((-9L), (((*l_2139) = (0xFC30240187CAB0EALL | (((**l_1803) = (0x178F886CA2376953LL < (safe_add_func_uint8_t_u_u(((safe_sub_func_uint8_t_u_u((*g_74), ((0x2BE2CEDFL < ((***l_1532) &= ((*g_116) , ((**g_1645) <= (safe_unary_minus_func_uint8_t_u(((l_2133[2][0] = l_2133[1][0]) == (g_2135 = (g_2134[0] , g_2135))))))))) , (**g_1645)))) ^ (*p_48)), (-1L))))) | 0UL))) , 0xC0AD4048L))))
                    { /* block id: 945 */
                        g_2143 = l_2140[1];
                        (*p_49) = p_48;
                    }
                    else
                    { /* block id: 948 */
                        uint16_t l_2146 = 0xE41CL;
                        int16_t ****l_2155 = &g_947;
                        int64_t l_2158 = 0xB4C4ABDC9AEADAABLL;
                        int32_t *l_2159 = &l_1820;
                        int32_t *l_2160[10][6][1] = {{{(void*)0},{&l_1512},{&l_1476[1]},{&g_77[2]},{&l_1950},{(void*)0}},{{&g_3},{(void*)0},{&l_1950},{&g_77[2]},{&l_1476[1]},{&l_1512}},{{(void*)0},{(void*)0},{&g_77[2]},{(void*)0},{&l_1512},{(void*)0}},{{(void*)0},{&l_1512},{(void*)0},{&g_77[2]},{(void*)0},{(void*)0}},{{&l_1512},{&l_1476[1]},{&g_77[2]},{&l_1950},{(void*)0},{&g_3}},{{(void*)0},{&l_1950},{&g_77[2]},{&l_1476[1]},{&l_1512},{(void*)0}},{{(void*)0},{&g_77[2]},{(void*)0},{&l_1512},{(void*)0},{(void*)0}},{{&l_1512},{(void*)0},{&g_77[2]},{(void*)0},{(void*)0},{&l_1512}},{{&l_1476[1]},{&g_77[2]},{&l_1950},{(void*)0},{&g_3},{(void*)0}},{{&l_1950},{&g_77[2]},{&l_1476[1]},{&l_1512},{(void*)0},{(void*)0}}};
                        int i, j, k;
                        (*p_49) = func_51(l_2146, l_2147);
                        l_1954[1][1][2] = func_51(((*p_48) = (((0xA10D3D71L && (*p_48)) <= (((((l_2156 |= (((safe_add_func_uint16_t_u_u(((safe_rshift_func_int8_t_s_u((((safe_rshift_func_uint8_t_u_u((1UL && (*p_50)), ((***g_1644) = ((l_2154 == (void*)0) == 0xA8A4D0A570A9D5F8LL)))) , ((void*)0 != l_2155)) & 1L), 7)) != (-1L)), (**l_2147))) < l_2146) >= l_1617)) == l_2146) > (**l_2147)) < 1L) & l_2157)) <= 1UL)), l_1560);
                        if (l_2158)
                            break;
                        --l_2170;
                    }
                }
            }
            else
            { /* block id: 958 */
                uint64_t ****l_2185 = (void*)0;
                uint64_t *****l_2186 = &l_1602;
                int64_t *l_2187[6][4] = {{&l_2162[3][0],&l_2162[3][0],&l_1996,&g_1064},{(void*)0,(void*)0,(void*)0,&l_1996},{(void*)0,&l_1996,&l_1996,(void*)0},{&l_2162[3][0],&l_1996,&g_1064,&l_1996},{&l_1996,(void*)0,&g_1064,&g_1064},{&l_2162[3][0],&l_2162[3][0],&l_1996,&g_1064}};
                int32_t l_2188 = 1L;
                int32_t l_2189 = 1L;
                const int64_t *l_2240 = &g_2241;
                uint32_t l_2246 = 0UL;
                int32_t l_2251 = 0x88C3F17CL;
                int16_t l_2252[10] = {0xF874L,0xF874L,0xF874L,0xF874L,0xF874L,0xF874L,0xF874L,0xF874L,0xF874L,0xF874L};
                uint64_t ***l_2286 = &l_2285;
                const uint64_t *l_2288 = (void*)0;
                const uint64_t **l_2287 = &l_2288;
                uint16_t *l_2289 = (void*)0;
                uint16_t *l_2290[10] = {(void*)0,&l_1735[1][5][1],(void*)0,&l_1855,&l_1855,(void*)0,&l_1735[1][5][1],(void*)0,&l_1855,&l_1855};
                uint8_t ***l_2331[6][9] = {{&g_1645,(void*)0,&g_1645,&g_1645,&g_1645,&g_1645,(void*)0,&g_1645,&g_1645},{&g_1645,(void*)0,(void*)0,&g_1645,&g_1645,&g_1645,(void*)0,(void*)0,&g_1645},{&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645},{(void*)0,&g_1645,&g_1645,&g_1645,&g_1645,(void*)0,&g_1645,&g_1645,&g_1645},{&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645,&g_1645},{&g_1645,&g_1645,&g_1645,(void*)0,(void*)0,&g_1645,&g_1645,&g_1645,(void*)0}};
                int32_t l_2338 = 1L;
                int64_t l_2409 = 0xB91385275570D38ALL;
                int i, j;
                if (((((safe_add_func_uint8_t_u_u((l_1476[0] |= (**g_1645)), (safe_sub_func_int64_t_s_s(((l_2165[3] & l_2165[8]) < (safe_mul_func_int64_t_s_s((*p_50), (*g_1256)))), (safe_lshift_func_int32_t_s_s((safe_mod_func_int32_t_s_s(((****g_2135) >= (((((((l_2188 = (safe_add_func_uint32_t_u_u((((*l_2186) = l_2185) != &g_1620), ((*p_48) = l_2162[2][1])))) > 0x7F3B6D882BC42698LL) >= (****g_2135)) & (**g_1634)) & 9L) < 0xD4L) , g_1654[2][0][1].f4)), l_2189)), l_2190)))))) , l_2191) != l_2192[0]) & 0xDDABL))
                { /* block id: 963 */
                    struct S0 *****l_2205 = &g_2143;
                    int16_t *l_2208 = &g_105;
                    uint8_t * const l_2209 = &g_210;
                    if (((safe_div_func_int8_t_s_s((safe_div_func_int64_t_s_s((**l_2147), (safe_mul_func_int16_t_s_s((**l_2147), ((*l_2208) |= ((safe_lshift_func_int64_t_s_u((l_2166[1][9] & (*g_1186)), 61)) , ((&g_2144 != ((*l_2205) = &g_2144)) | (safe_sub_func_int8_t_s_s(((*g_121) = 0xABL), 0x22L))))))))), l_2166[1][9])) == 0xDCL))
                    { /* block id: 967 */
                        (**g_2144) = (***g_2143);
                    }
                    else
                    { /* block id: 969 */
                        (*p_48) = (-1L);
                        return l_2209;
                    }
                }
                else
                { /* block id: 973 */
                    const int32_t l_2219 = (-1L);
                    int64_t *l_2236 = (void*)0;
                    uint8_t * const l_2249 = &g_210;
                    int32_t l_2250[3][7];
                    int8_t l_2253 = 0x8EL;
                    uint64_t l_2254[9];
                    int32_t **l_2268 = (void*)0;
                    const int64_t l_2269 = (-6L);
                    int i, j;
                    for (i = 0; i < 3; i++)
                    {
                        for (j = 0; j < 7; j++)
                            l_2250[i][j] = (-1L);
                    }
                    for (i = 0; i < 9; i++)
                        l_2254[i] = 4UL;
                    if ((*p_48))
                        break;
                    for (l_1920 = 0; (l_1920 < 54); ++l_1920)
                    { /* block id: 977 */
                        int32_t l_2212 = 0x6B5D6248L;
                        const int64_t *l_2238 = &g_2239;
                        const int64_t **l_2237[5][5];
                        int32_t l_2243 = (-1L);
                        int32_t l_2244 = 3L;
                        int32_t l_2245[8] = {0xB10143E7L,0xB10143E7L,(-4L),0xB10143E7L,0xB10143E7L,(-4L),0xB10143E7L,0xB10143E7L};
                        int i, j;
                        for (i = 0; i < 5; i++)
                        {
                            for (j = 0; j < 5; j++)
                                l_2237[i][j] = &l_2238;
                        }
                        l_2212 &= ((void*)0 == &g_1576);
                        l_1820 &= (g_2213 , ((((l_2166[1][4] < ((safe_mod_func_int8_t_s_s((~((safe_mod_func_uint16_t_u_u(0UL, l_2219)) & ((safe_mul_func_int8_t_s_s((((((safe_rshift_func_int32_t_s_s(0x7DED7F38L, 16)) , (l_2225 = g_2224)) != (l_2233 = l_2233)) == (safe_div_func_int64_t_s_s((l_2236 != (l_2240 = (p_50 = l_2236))), l_2188))) == l_2242), (*g_121))) != 0x84C47BE7L))), (*l_2232))) | (*l_2229))) ^ 2L) & 4294967294UL) ^ 0xAEB65C86021DACB2LL));
                        --l_2246;
                        return l_2249;
                    }
                    ++l_2254[7];
                    for (g_1378 = 9; (g_1378 >= 0); g_1378 -= 1)
                    { /* block id: 990 */
                        union U1 **l_2257 = (void*)0;
                        union U1 ***l_2258 = &g_778;
                        int i;
                        (*l_2232) |= (((((*l_2258) = l_2257) != l_2259[5][0][1]) > ((((**g_1185) = (safe_mod_func_int8_t_s_s(l_1539[g_1378], (safe_add_func_int64_t_s_s((l_2250[2][6] | (safe_mul_func_uint64_t_u_u(((0xF66D27FCL & ((((safe_lshift_func_uint8_t_u_u((&g_772 != (void*)0), (((((**g_1634) = (((p_49 = l_2268) == (g_464 , &p_48)) , (**l_2147))) != (**l_2147)) | 0xA53D8A6AAD7136A8LL) || g_2213.f0))) == 0x62C1511CL) || l_2254[7]) , l_2269)) , 3UL), 0x07CBFC547EE5EE2ELL))), 0x92B572C4A94FECE2LL))))) || (*p_48)) >= l_1539[g_1378])) || (***g_1644));
                        return (**g_1644);
                    }
                }
                (*p_48) = ((safe_sub_func_int32_t_s_s(((safe_unary_minus_func_int64_t_s((safe_sub_func_uint8_t_u_u(((g_140 = (((safe_rshift_func_int32_t_s_u((*p_48), (safe_lshift_func_uint32_t_u_s((((safe_sub_func_uint64_t_u_u((*l_2229), (safe_mul_func_uint32_t_u_u(l_2251, l_2251)))) , (((g_1585[1][2] , (!((l_2252[2] , p_50) == (l_2284 = (*l_1803))))) , ((*l_2286) = l_2285)) != l_2287)) < 0x116969CEL), 27)))) , (**l_2147)) | 0xEA32724CCD06496BLL)) , (**g_1645)), l_2252[7])))) , 0x04FE8148L), 8L)) , 1L);
                if ((l_2189 , (safe_rshift_func_uint32_t_u_u(((*g_1186) &= ((safe_mul_func_uint32_t_u_u(((*p_50) || (l_2189 = (safe_div_func_uint32_t_u_u((g_4[1][0][1] , (safe_mul_func_int16_t_s_s(((*l_1653) , l_2252[3]), ((-1L) != ((safe_add_func_uint64_t_u_u((*l_2229), (((l_2310 ^= (safe_sub_func_uint16_t_u_u(((safe_add_func_uint16_t_u_u(l_2251, ((safe_mod_func_int8_t_s_s((safe_sub_func_uint64_t_u_u((safe_unary_minus_func_uint32_t_u((((*p_48) = (((254UL > (*g_74)) >= (*p_50)) >= 65530UL)) | (-6L)))), (**g_1634))), 255UL)) | 0x31L))) != 0x5FDDL), l_2246))) , l_2188) <= (**g_1634)))) == 0UL))))), 0x18768A36L)))), (**l_2147))) , 0xE268766BL)), 15))))
                { /* block id: 1007 */
                    uint8_t l_2332 = 0UL;
                    int32_t l_2333[3];
                    int32_t l_2334 = (-6L);
                    uint8_t l_2339 = 0UL;
                    int8_t ***l_2357 = &l_2018;
                    int8_t ****l_2356 = &l_2357;
                    int8_t ***l_2359[8][7];
                    int8_t ****l_2358 = &l_2359[3][4];
                    int i, j;
                    for (i = 0; i < 3; i++)
                        l_2333[i] = (-4L);
                    for (i = 0; i < 8; i++)
                    {
                        for (j = 0; j < 7; j++)
                            l_2359[i][j] = &l_2018;
                    }
                    for (l_1538 = 0; (l_1538 < (-26)); --l_1538)
                    { /* block id: 1010 */
                        int64_t l_2318 = 9L;
                        int32_t l_2337 = (-1L);
                        l_2251 = (l_2336 ^= (g_2313[2] , (safe_mod_func_uint16_t_u_u((safe_sub_func_uint32_t_u_u(((((&g_2115 != (void*)0) , (l_2318 && (l_2188 = (l_2334 = (l_2333[0] = (!(safe_rshift_func_uint8_t_u_s(((**g_1645) = (*l_2232)), (safe_div_func_int16_t_s_s((+(((safe_rshift_func_int32_t_s_u(((**l_2147) <= ((*p_48) = (((safe_div_func_int16_t_s_s((((**l_1803) = ((((l_2331[1][1] != l_1647[1]) | l_2189) == (*g_121)) | (-2L))) , 0x8D66L), (-1L))) ^ 0xA54FB506L) > (**l_2147)))), 7)) | l_2189) , l_2251)), l_2332)))))))))) , g_2335) , (**g_1185)), l_2251)), (***g_2136)))));
                        l_2339--;
                    }
                    (*l_2231) &= ((safe_add_func_int16_t_s_s((((safe_div_func_int16_t_s_s(((*g_121) || (safe_unary_minus_func_uint64_t_u(((g_1585[0][3] , ((+(((0x7ED358AF57639C2DLL != (safe_sub_func_uint64_t_u_u((g_832.f2 , ((*g_121) & ((safe_mod_func_uint64_t_u_u(((safe_sub_func_uint8_t_u_u((0x63F24CB5290F2295LL <= l_2354), (safe_unary_minus_func_int32_t_s((((*l_2356) = &g_271) != ((*l_2358) = &g_271)))))) , l_2252[3]), (**g_1634))) >= 0x5920L))), (*p_50)))) || 6L) > (*p_50))) , 0x2676L)) == 0x48CDL)))), g_77[4])) <= l_2334) | l_2251), (*g_2138))) | (***g_1644));
                }
                else
                { /* block id: 1024 */
                    int16_t l_2374 = 0L;
                    int32_t l_2391[4][1][10] = {{{0x99B91A17L,0xBEA8C966L,0x99B91A17L,0xF6366DF0L,4L,0x943EBBC4L,0xCBBB6F53L,0xFDFACC60L,0xFDFACC60L,0xCBBB6F53L}},{{4L,0x68DF39AEL,0x943EBBC4L,0x943EBBC4L,0x68DF39AEL,4L,0L,0xFDFACC60L,0xEBD1ECC0L,0L}},{{0xBEA8C966L,0L,0x99B91A17L,(-1L),0xFDFACC60L,(-1L),0x99B91A17L,0L,0xBEA8C966L,4L}},{{0xBEA8C966L,0x943EBBC4L,0x1483770EL,0L,(-1L),4L,4L,(-1L),0L,0x1483770EL}}};
                    int i, j, k;
                    if ((*p_48))
                        break;
                    if (((safe_add_func_int16_t_s_s(l_2338, (g_4[3][0][2] = ((safe_sub_func_uint8_t_u_u(((**g_1645) = l_2364), (((*p_48) = (((safe_mod_func_int64_t_s_s(((~((safe_mod_func_uint16_t_u_u(((l_2374 |= (g_2370 , (((safe_lshift_func_int8_t_s_s((-9L), ((*g_121) >= (((void*)0 == l_2373) <= ((&l_1603 == (void*)0) >= 6L))))) < (*p_50)) ^ l_1825))) || l_2338), l_2375)) | (*g_31))) > 1UL), 0x56C63871D712F0C6LL)) ^ 0x59E5EE75L) != g_2376)) <= 7UL))) , g_3)))) && (**l_2147)))
                    { /* block id: 1030 */
                        uint32_t l_2392 = 6UL;
                        uint16_t l_2393 = 0x7CA3L;
                        uint16_t l_2410 = 1UL;
                        l_1954[0][1][2] = func_51((safe_add_func_uint16_t_u_u((246UL | (safe_div_func_uint8_t_u_u((l_1821 && (g_2196.f3 || ((!(safe_sub_func_int64_t_s_s((l_2251 , ((l_2188 = ((l_2251 = (!(!(((****l_1929)++) < (((l_2252[4] ^ ((((((((l_2374 & (((**l_2147) == ((g_2390[0] , (l_2374 || 250UL)) != l_2374)) <= l_2374)) , l_2391[2][0][2]) == 0x723292F76B47DC20LL) , l_2392) | 0x5F1E54EEL) , 0x74L) >= 255UL) , l_2391[3][0][6])) == l_2392) != l_2392))))) & 0xC7A6L)) ^ l_2393)), l_2392))) < l_2391[2][0][5]))), l_2252[3]))), g_2394)), l_2147);
                        (*l_2229) &= ((safe_rshift_func_uint8_t_u_u((((*l_2232) = (*p_48)) <= ((((safe_add_func_int16_t_s_s((****g_2135), 0xE860L)) || ((safe_div_func_int8_t_s_s(((safe_lshift_func_uint64_t_u_s(((((((**l_2147) <= (***g_1644)) > (l_2188 = (((**g_1943) , ((safe_mul_func_int64_t_s_s(((l_2018 == l_2018) > (safe_div_func_int32_t_s_s((safe_lshift_func_uint32_t_u_u(((**l_2147) > l_2252[3]), (*g_294))), 0x2D064BD1L))), 2UL)) <= l_2374)) <= (*p_48)))) > l_2391[2][0][2]) || l_2409) >= l_2393), 9)) && l_2410), (*g_121))) == l_2189)) || (-1L)) , 0x513D33F7L)), 7)) && 0xC321EA0FL);
                    }
                    else
                    { /* block id: 1038 */
                        return (**g_1644);
                    }
                }
            }
            (*l_2232) = (safe_div_func_uint32_t_u_u((safe_mul_func_int64_t_s_s(((void*)0 == &g_121), (safe_rshift_func_uint64_t_u_s((0xFC7CDB4D052CBAECLL ^ (((((safe_rshift_func_uint64_t_u_u(((*l_2284) = (((*l_2419) = 65535UL) >= (((safe_sub_func_uint32_t_u_u(((***g_1576) = (safe_rshift_func_int16_t_s_u((safe_mul_func_int32_t_s_s((*p_48), 8UL)), 9))), (safe_rshift_func_uint64_t_u_u((l_1622 ^= ((((safe_div_func_int8_t_s_s((safe_mod_func_uint16_t_u_u(l_1670, ((safe_mod_func_int8_t_s_s(((((((((*p_48) != (safe_rshift_func_uint16_t_u_u((**l_2147), 6))) == 0xC1L) & (**l_2147)) & l_1512) , (void*)0) != l_1929) & (*p_50)), (*l_2229))) , g_382))), (*g_121))) & (*p_50)) ^ (**g_1645)) || 18446744073709551615UL)), 4)))) > l_1512) >= 0L))), (**l_2147))) , l_2438) != &l_1929) | (*l_2232)) , (*p_50))), 30)))), 0x0DFA0148L));
        }
        l_2440[4][1][1] = l_2440[1][0][8];
    }
    (*g_2443) = (*l_2147);
    ++l_2444;
    return (*g_1645);
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t * func_51(int32_t  p_52, int32_t * const * p_53)
{ /* block id: 628 */
    uint32_t l_1446 = 0x6DD14AC2L;
    int32_t l_1447 = 0L;
    int32_t *l_1448 = &g_77[3];
    l_1447 &= l_1446;
    return l_1448;
}


/* ------------------------------------------ */
/* 
 * reads : g_105 g_1185 g_1006 g_1007 g_1186 g_3 g_116 g_117 g_257 g_338 g_121 g_1257 g_74 g_75 g_1288 g_30 g_31 g_1068 g_1069 g_9 g_778 g_77 g_1170 g_785.f6 g_1256 g_294 g_295 g_689.f3 g_832.f6 g_283 g_785.f2 g_33 g_113 g_1064 g_1378 g_990 g_563.f0 g_1430 g_1438 g_65
 * writes: g_105 g_75 g_1185 g_257 g_464.f1 g_283 g_33 g_113 g_1255 g_210 g_779 g_295 g_106 g_1170 g_77 g_1064 g_65 g_117 g_563.f0 g_397
 */
static int32_t ** func_54(int8_t  p_55, const int32_t * p_56, int32_t  p_57, uint8_t * p_58, int8_t  p_59)
{ /* block id: 503 */
    uint32_t l_1178 = 7UL;
    int32_t l_1201 = (-1L);
    int32_t l_1202[3];
    int32_t *l_1293 = &g_77[4];
    int16_t l_1310[5] = {6L,6L,6L,6L,6L};
    int16_t *l_1318 = &g_105;
    uint16_t *l_1319 = (void*)0;
    uint16_t *l_1320 = &g_563.f1;
    uint16_t *l_1321 = &g_1170;
    uint64_t l_1324 = 0x0FF0BB42FF84D128LL;
    uint8_t l_1352 = 0UL;
    int16_t l_1353 = (-6L);
    int32_t *l_1355 = &g_77[1];
    int32_t **l_1440 = &g_397;
    int32_t **l_1441[7][3] = {{&g_31,(void*)0,&g_397},{&g_397,&g_397,&g_397},{&g_31,&g_31,&g_397},{&l_1355,&l_1355,&g_397},{&l_1355,&g_31,&g_31},{&g_397,&g_397,&l_1355},{&l_1355,(void*)0,&l_1355}};
    int32_t **l_1442 = &g_397;
    int32_t **l_1444 = &l_1293;
    int32_t **l_1445 = &g_31;
    int i, j;
    for (i = 0; i < 3; i++)
        l_1202[i] = (-1L);
    for (g_105 = 8; (g_105 >= 28); g_105++)
    { /* block id: 506 */
        uint64_t *l_1182 = (void*)0;
        uint64_t **l_1181 = &l_1182;
        uint32_t ***l_1187 = (void*)0;
        uint32_t ***l_1188 = &g_1185;
        int16_t l_1189 = 0L;
        int32_t l_1196 = (-1L);
        int32_t l_1198 = 1L;
        int32_t l_1205 = 1L;
        int32_t l_1206 = 0x98AF79E4L;
        int32_t l_1207 = 0x283FEFD2L;
        int32_t l_1208 = (-1L);
        int32_t l_1209[2][4] = {{1L,1L,1L,1L},{1L,1L,1L,1L}};
        uint8_t l_1211 = 1UL;
        const int8_t l_1244 = 0xAAL;
        int i, j;
        if ((safe_rshift_func_uint32_t_u_u(4294967291UL, ((*g_1186) = ((l_1178 != ((*p_58) = 0x6AL)) != (((safe_div_func_int8_t_s_s(((l_1181 == &g_1069) != ((safe_div_func_int32_t_s_s((((*l_1188) = g_1185) != (*g_1006)), 1L)) & ((p_59 , p_59) & g_105))), l_1189)) , l_1178) >= p_59))))))
        { /* block id: 510 */
            int16_t l_1195 = 0x4EA4L;
            int64_t l_1197 = 1L;
            int32_t l_1199 = (-8L);
            int32_t l_1200 = 6L;
            int32_t l_1203[8][6] = {{5L,5L,0xFF482019L,0xFF482019L,5L,5L},{5L,0xFF482019L,0xFF482019L,5L,5L,0xFF482019L},{5L,5L,0xFF482019L,0xFF482019L,5L,5L},{5L,0xFF482019L,0xFF482019L,5L,5L,0xFF482019L},{5L,5L,0xFF482019L,0xFF482019L,5L,5L},{5L,0xFF482019L,0xFF482019L,5L,5L,0xFF482019L},{5L,5L,0xFF482019L,0xFF482019L,5L,5L},{5L,0xFF482019L,0xFF482019L,5L,5L,0xFF482019L}};
            uint64_t l_1245[7] = {18446744073709551615UL,0x894850335FFF9C17LL,0x894850335FFF9C17LL,18446744073709551615UL,0x894850335FFF9C17LL,0x894850335FFF9C17LL,18446744073709551615UL};
            int32_t **l_1259[2][1][9] = {{{&g_397,&g_31,&g_397,&g_31,&g_397,&g_31,&g_397,&g_31,&g_397}},{{&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397,&g_397}}};
            struct S0 *l_1290[4][7][5] = {{{&g_689,(void*)0,&g_689,&g_689,(void*)0},{&g_689,(void*)0,(void*)0,&g_689,&g_689},{&g_689,(void*)0,&g_689,(void*)0,&g_689},{(void*)0,&g_689,(void*)0,&g_689,&g_689},{&g_689,(void*)0,(void*)0,&g_689,&g_689},{&g_689,&g_689,(void*)0,&g_689,&g_689},{&g_689,&g_689,&g_689,&g_689,&g_689}},{{&g_689,(void*)0,&g_689,&g_689,&g_689},{&g_689,&g_689,&g_689,&g_689,(void*)0},{(void*)0,&g_689,&g_689,&g_689,&g_689},{(void*)0,(void*)0,&g_689,(void*)0,&g_689},{&g_689,&g_689,(void*)0,&g_689,&g_689},{&g_689,&g_689,(void*)0,&g_689,&g_689},{&g_689,(void*)0,(void*)0,&g_689,&g_689}},{{(void*)0,&g_689,&g_689,&g_689,&g_689},{(void*)0,&g_689,(void*)0,&g_689,&g_689},{&g_689,(void*)0,&g_689,&g_689,&g_689},{&g_689,&g_689,(void*)0,&g_689,&g_689},{&g_689,(void*)0,&g_689,&g_689,(void*)0},{&g_689,(void*)0,(void*)0,&g_689,&g_689},{&g_689,(void*)0,&g_689,(void*)0,&g_689}},{{(void*)0,&g_689,(void*)0,&g_689,&g_689},{&g_689,(void*)0,(void*)0,&g_689,&g_689},{&g_689,&g_689,(void*)0,&g_689,&g_689},{&g_689,&g_689,&g_689,&g_689,&g_689},{&g_689,(void*)0,&g_689,&g_689,&g_689},{&g_689,&g_689,&g_689,&g_689,(void*)0},{(void*)0,&g_689,&g_689,&g_689,&g_689}}};
            struct S0 **l_1289 = &l_1290[0][5][0];
            int i, j, k;
            for (g_464.f1 = (-9); (g_464.f1 >= 57); ++g_464.f1)
            { /* block id: 513 */
                int32_t l_1204 = 0xCC5F4D43L;
                int32_t l_1210[2][10] = {{0x41C06E4AL,0xA18A80F7L,0xA18A80F7L,0x41C06E4AL,0xA18A80F7L,0xA18A80F7L,0x41C06E4AL,0xA18A80F7L,0xA18A80F7L,0x41C06E4AL},{0xA18A80F7L,0x41C06E4AL,0xA18A80F7L,0xA18A80F7L,0x41C06E4AL,0xA18A80F7L,0xA18A80F7L,0x41C06E4AL,0xA18A80F7L,0xA18A80F7L}};
                union U1 *l_1216 = &g_464;
                int32_t **l_1294 = (void*)0;
                int i, j;
                for (g_283 = (-26); (g_283 < 48); g_283 = safe_add_func_uint32_t_u_u(g_283, 7))
                { /* block id: 516 */
                    int32_t *l_1194[9][8] = {{&g_3,&g_3,&g_117,&g_117,&g_3,&g_77[1],&g_117,(void*)0},{&g_77[3],&g_117,&g_117,&g_77[1],&g_117,&g_117,&g_3,&g_117},{&g_77[3],(void*)0,&g_77[1],&g_3,&g_117,&g_3,&g_77[3],&g_3},{&g_117,&g_117,&g_77[0],&g_77[3],&g_77[3],&g_77[3],&g_77[3],&g_77[0]},{&g_77[3],&g_77[3],&g_77[1],&g_3,&g_117,&g_77[2],&g_3,&g_3},{&g_117,&g_77[2],&g_3,&g_3,&g_117,&g_77[0],&g_117,&g_3},{&g_77[2],&g_77[1],&g_77[2],&g_3,(void*)0,&g_117,&g_117,&g_77[0]},{&g_3,&g_117,&g_3,&g_77[3],&g_3,(void*)0,(void*)0,&g_3},{&g_3,&g_117,&g_117,&g_3,(void*)0,&g_77[3],&g_3,&g_117}};
                    uint16_t l_1222 = 0UL;
                    int i, j;
                    l_1211++;
                    if (l_1210[1][1])
                        break;
                    if ((*p_56))
                        continue;
                    for (l_1206 = 1; (l_1206 < (-13)); l_1206 = safe_sub_func_int32_t_s_s(l_1206, 9))
                    { /* block id: 522 */
                        union U1 *l_1217 = &g_563;
                        int32_t l_1218 = 0L;
                        int32_t l_1219 = 2L;
                        int32_t l_1220 = 0xD122E924L;
                        int32_t l_1221[8] = {0L,0L,0L,0L,0L,0L,0L,0L};
                        int i;
                        l_1217 = l_1216;
                        l_1222--;
                    }
                }
                for (l_1204 = 0; (l_1204 == 16); l_1204 = safe_add_func_int64_t_s_s(l_1204, 7))
                { /* block id: 529 */
                    int8_t l_1264 = 0x1FL;
                    struct S0 ***l_1291 = &l_1289;
                    uint8_t *l_1292 = &g_210;
                    if (((safe_mul_func_int64_t_s_s((safe_sub_func_uint16_t_u_u(((safe_mul_func_int8_t_s_s(((*g_121) = (((safe_sub_func_uint16_t_u_u(l_1201, ((safe_sub_func_uint64_t_u_u((l_1203[7][2] &= 0x0BA55AFC50E344DBLL), (l_1204 || (safe_mul_func_int64_t_s_s(((*g_116) | (**g_1185)), (safe_unary_minus_func_int32_t_s((safe_mod_func_uint8_t_u_u(((safe_mul_func_uint32_t_u_u(((((-1L) != 7UL) == (l_1244 <= p_57)) , 0x8808992DL), (*g_1186))) | 0xEB9DE5A2L), 0x16L))))))))) != g_338[0]))) ^ l_1196) ^ 0x9D9111ADEB872065LL)), p_55)) >= 18446744073709551611UL), 0L)), 0x0DDD4A204800B84ALL)) > l_1245[3]))
                    { /* block id: 532 */
                        int32_t *l_1246 = &l_1209[1][1];
                        int32_t *l_1247 = &l_1207;
                        int32_t *l_1248 = &l_1209[0][2];
                        int32_t *l_1249[5];
                        uint16_t l_1250[2][7][9] = {{{0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L},{65535UL,0UL,65535UL,65535UL,0UL,65535UL,65535UL,0UL,65535UL},{0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L},{65535UL,0UL,65535UL,65535UL,0UL,65535UL,65535UL,0UL,65535UL},{0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L},{65535UL,0UL,65535UL,65535UL,0UL,65535UL,65535UL,0UL,65535UL},{0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L}},{{65535UL,0UL,65535UL,65535UL,0UL,65535UL,65535UL,0UL,65535UL},{0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L},{65535UL,0UL,65535UL,65535UL,0UL,65535UL,65535UL,0UL,65535UL},{0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L},{65535UL,0UL,65535UL,65535UL,0UL,65535UL,65535UL,0UL,65535UL},{0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L,0xB983L,0x8A08L,0xB983L},{65535UL,0UL,65535UL,65535UL,0UL,65535UL,65535UL,65535UL,0x8B82L}}};
                        uint64_t **l_1253 = &l_1182;
                        uint64_t ***l_1254[2][2][6] = {{{&l_1253,&l_1253,&l_1253,&l_1253,&l_1253,&l_1253},{&l_1253,&l_1253,&l_1253,&l_1181,&l_1253,&l_1253}},{{&l_1253,&l_1253,&l_1181,&l_1181,&l_1253,&l_1253},{&l_1253,&l_1253,&l_1181,&l_1253,&l_1253,&l_1253}}};
                        int i, j, k;
                        for (i = 0; i < 5; i++)
                            l_1249[i] = &l_1203[2][1];
                        l_1250[0][5][2]++;
                        (*l_1248) = ((((*p_58) = (((l_1206 , p_57) , p_55) & ((g_1255 = l_1253) != &l_1182))) , g_1257) == &g_1258);
                        return l_1259[1][0][3];
                    }
                    else
                    { /* block id: 538 */
                        int16_t l_1267 = 0x7BACL;
                        int32_t l_1271[8][6][3] = {{{0xA28D4A5BL,0xF229F288L,0x10291036L},{0x10291036L,0xEA8D0E1FL,0L},{0xA28D4A5BL,0x0D704DDCL,(-10L)},{0L,0xF229F288L,0xF1B47480L},{0L,0x11F0ACCCL,(-1L)},{0xA28D4A5BL,0x8F44FC29L,0x86F0F757L}},{{0x10291036L,0L,0xF1B47480L},{0xA28D4A5BL,0xEA8D0E1FL,(-1L)},{0L,0x8F44FC29L,0x31AAFE63L},{0L,0x9D3B7BFAL,0x10291036L},{0xA28D4A5BL,0L,(-1L)},{0x10291036L,0x0D704DDCL,0x31AAFE63L}},{{0xA28D4A5BL,0L,0xA28D4A5BL},{0L,0L,0L},{0L,0L,0x86F0F757L},{0xA28D4A5BL,0xF229F288L,0x10291036L},{0x10291036L,0xEA8D0E1FL,0L},{0xA28D4A5BL,0x0D704DDCL,(-10L)}},{{0L,0xF229F288L,0xF1B47480L},{0L,0x11F0ACCCL,(-1L)},{0xA28D4A5BL,0x8F44FC29L,0x86F0F757L},{0x10291036L,0L,0xF1B47480L},{0xA28D4A5BL,0xEA8D0E1FL,(-1L)},{0L,0x8F44FC29L,0x31AAFE63L}},{{0L,0x9D3B7BFAL,0x10291036L},{0xA28D4A5BL,0L,(-1L)},{0x10291036L,0x0D704DDCL,0x31AAFE63L},{0xA28D4A5BL,0L,0xA28D4A5BL},{0L,0L,0L},{0L,0L,0x86F0F757L}},{{0xA28D4A5BL,0xF229F288L,0x10291036L},{0x10291036L,0xEA8D0E1FL,0L},{0xA28D4A5BL,0x0D704DDCL,(-10L)},{0L,0xF229F288L,0xF1B47480L},{0L,0x11F0ACCCL,(-1L)},{0xA28D4A5BL,0x8F44FC29L,0x86F0F757L}},{{0x10291036L,0L,0xF1B47480L},{0xA28D4A5BL,0xEA8D0E1FL,(-1L)},{0L,0x8F44FC29L,0x31AAFE63L},{0L,0x9D3B7BFAL,0x10291036L},{0xA28D4A5BL,0L,(-1L)},{0x10291036L,0x0D704DDCL,0x31AAFE63L}},{{0xA28D4A5BL,0L,0xA28D4A5BL},{0L,0L,0L},{0L,0L,0x86F0F757L},{0xA28D4A5BL,0xF229F288L,0x10291036L},{0x10291036L,0xEA8D0E1FL,0L},{0xA28D4A5BL,0x0D704DDCL,(-10L)}}};
                        int i, j, k;
                        l_1271[3][1][0] &= (safe_mul_func_int32_t_s_s(((((p_59 > ((l_1264 &= (255UL & p_59)) < 4L)) | (safe_mod_func_int64_t_s_s(0L, 0x15B951D31CD640DBLL))) <= ((((*p_56) && l_1267) >= (safe_lshift_func_int8_t_s_s((+(*g_74)), l_1267))) | 0xEE4E2A28DF4E0B35LL)) , l_1267), (*p_56)));
                    }
                    l_1293 = ((((safe_mul_func_int32_t_s_s(1L, (((*l_1292) = ((*p_58) = (safe_sub_func_int16_t_s_s((safe_mul_func_uint32_t_u_u((safe_sub_func_int8_t_s_s(p_57, (*p_58))), ((**g_1185) ^= 4294967288UL))), (safe_rshift_func_int8_t_s_u((safe_sub_func_int16_t_s_s((safe_mod_func_int8_t_s_s(0xA6L, p_59)), ((safe_sub_func_uint32_t_u_u((l_1208 |= (g_1288 != ((*l_1291) = l_1289))), (*p_56))) , p_59))), 3)))))) , (**g_30)))) <= 0x0849A8E0L) < (**g_1068)) , &p_57);
                    if (l_1264)
                        break;
                    return l_1294;
                }
                (*g_778) = l_1216;
                for (l_1189 = (-12); (l_1189 != 13); ++l_1189)
                { /* block id: 554 */
                    for (g_295 = 0; g_295 < 7; g_295 += 1)
                    {
                        g_106[g_295] = &g_117;
                    }
                }
            }
        }
        else
        { /* block id: 558 */
            union U1 **l_1299 = &g_779[0];
            p_57 = (safe_rshift_func_int64_t_s_s(l_1205, (&g_779[0] != l_1299)));
        }
    }
    if ((safe_mul_func_int8_t_s_s(0x82L, ((safe_mod_func_uint64_t_u_u((*l_1293), (safe_mod_func_uint32_t_u_u(p_57, (safe_lshift_func_int8_t_s_s((safe_mod_func_int16_t_s_s(l_1310[3], (safe_add_func_uint64_t_u_u(((*g_1256) = (safe_sub_func_uint8_t_u_u((*l_1293), (((*l_1321) |= (safe_add_func_int16_t_s_s(p_59, ((((*l_1318) = ((*l_1293) <= (((((!(0x6A34L && (*l_1293))) , 0x77B8497CL) , p_55) , (void*)0) != &p_56))) != (*l_1293)) & p_57)))) > g_785.f6)))), (*l_1293))))), (*l_1293))))))) , 2L))))
    { /* block id: 565 */
        int16_t l_1329 = 0x6477L;
        int32_t * const ****l_1350 = (void*)0;
        int32_t l_1407 = 1L;
        int32_t **l_1437 = &g_397;
        (*l_1293) = (*g_31);
        if (((((0xE7312579L & ((*l_1293) &= ((safe_div_func_uint8_t_u_u(l_1324, p_55)) , (*p_56)))) , 0x2CL) == ((((void*)0 != &g_1006) && (l_1329 = (safe_mul_func_uint64_t_u_u(((0UL & (safe_add_func_int32_t_s_s((g_117 & 0x49DBL), 0x50BC44F2L))) & (-6L)), p_55)))) || (*g_294))) ^ 1L))
        { /* block id: 569 */
            int8_t l_1332 = 0x4FL;
            int32_t *****l_1351 = &g_890;
            int32_t l_1354 = 6L;
lbl_1360:
            l_1354 = ((*l_1293) = (safe_div_func_int32_t_s_s((l_1332 <= (((((safe_div_func_int8_t_s_s((l_1332 || (g_689.f3 && (safe_rshift_func_uint16_t_u_u(g_832.f6, 4)))), (*l_1293))) , (*p_56)) == ((((((*l_1318) = ((safe_rshift_func_int16_t_s_s((((safe_unary_minus_func_int64_t_s(((safe_sub_func_uint64_t_u_u((((((safe_add_func_int16_t_s_s(((safe_mod_func_uint8_t_u_u((safe_mod_func_int8_t_s_s(((safe_sub_func_int32_t_s_s(((p_55 , l_1350) == (l_1351 = &g_890)), l_1352)) , p_55), 0x15L)), l_1353)) | l_1332), p_55)) ^ (*g_74)) & 0x4AL) >= l_1332) , (*g_1256)), g_785.f2)) < p_55))) , (*g_121)) | (*g_74)), p_59)) & p_55)) , 0x0B7AL) , (*g_74)) , 5L) <= 4294967295UL)) | p_59) > 0UL)), 0xEA409A64L)));
lbl_1429:
            l_1355 = &p_57;
            for (g_1064 = 27; (g_1064 < (-21)); g_1064 = safe_sub_func_int16_t_s_s(g_1064, 1))
            { /* block id: 577 */
                int32_t l_1392 = 0xB946084DL;
                int16_t l_1431 = 0x09E7L;
                if ((*g_31))
                { /* block id: 578 */
                    uint8_t l_1371[8][5][6] = {{{0xA2L,254UL,0x08L,0UL,0xF0L,0xB7L},{0xA2L,0xA4L,0xC5L,0xC5L,0xA4L,0xA2L},{0x08L,0xB6L,0x9DL,0xC5L,255UL,7UL},{0xA2L,249UL,1UL,7UL,0xA8L,252UL},{1UL,0UL,7UL,255UL,0UL,248UL}},{{248UL,0xFDL,0x61L,255UL,0x08L,255UL},{1UL,0x9DL,1UL,7UL,0xB7L,255UL},{1UL,0xC5L,255UL,255UL,0xC5L,1UL},{248UL,0x08L,252UL,255UL,0xA2L,7UL},{1UL,0xA8L,248UL,7UL,0x9DL,0x61L}},{{1UL,7UL,255UL,255UL,7UL,1UL},{248UL,0xA2L,255UL,255UL,0xFDL,255UL},{1UL,0xB7L,1UL,7UL,0xA8L,252UL},{1UL,0UL,7UL,255UL,0UL,248UL},{248UL,0xFDL,0x61L,255UL,0x08L,255UL}},{{1UL,0x9DL,1UL,7UL,0xB7L,255UL},{1UL,0xC5L,255UL,255UL,0xC5L,1UL},{248UL,0x08L,252UL,255UL,0xA2L,7UL},{1UL,0xA8L,248UL,7UL,0x9DL,0x61L},{1UL,7UL,255UL,255UL,7UL,1UL}},{{248UL,0xA2L,255UL,255UL,0xFDL,255UL},{1UL,0xB7L,1UL,7UL,0xA8L,252UL},{1UL,0UL,7UL,255UL,0UL,248UL},{248UL,0xFDL,0x61L,255UL,0x08L,255UL},{1UL,0x9DL,1UL,7UL,0xB7L,255UL}},{{1UL,0xC5L,255UL,255UL,0xC5L,1UL},{248UL,0x08L,252UL,255UL,0xA2L,7UL},{1UL,0xA8L,248UL,7UL,0x9DL,0x61L},{1UL,7UL,255UL,255UL,7UL,1UL},{248UL,0xA2L,255UL,255UL,0xFDL,255UL}},{{1UL,0xB7L,1UL,7UL,0xA8L,252UL},{1UL,0UL,7UL,255UL,0UL,248UL},{248UL,0xFDL,0x61L,255UL,0x08L,255UL},{1UL,0x9DL,1UL,7UL,0xB7L,255UL},{1UL,0xC5L,255UL,255UL,0xC5L,1UL}},{{248UL,248UL,0xB6L,0xF0L,1UL,249UL},{0x91L,252UL,1UL,249UL,255UL,255UL},{0x91L,255UL,0xF0L,0xF0L,255UL,0x91L},{1UL,1UL,255UL,0xF0L,1UL,254UL},{0x91L,0x61L,0xA4L,249UL,252UL,0xB6L}}};
                    int32_t l_1389 = 0L;
                    int32_t l_1397 = 9L;
                    int8_t l_1404 = (-1L);
                    int i, j, k;
                    for (g_65 = 0; (g_65 <= (-27)); g_65 = safe_sub_func_uint16_t_u_u(g_65, 1))
                    { /* block id: 581 */
                        int32_t *l_1361 = &l_1202[2];
                        int32_t *l_1362 = &l_1354;
                        int32_t *l_1363 = &g_117;
                        int32_t *l_1364 = &l_1202[0];
                        int32_t *l_1365 = &l_1202[1];
                        int32_t *l_1366 = &g_77[3];
                        int32_t *l_1367 = &g_77[3];
                        int32_t *l_1368 = &g_117;
                        int32_t *l_1369 = &l_1202[2];
                        int32_t *l_1370 = (void*)0;
                        if (g_1064)
                            goto lbl_1360;
                        --l_1371[3][4][5];
                        l_1397 |= (safe_sub_func_int16_t_s_s(((*p_56) & (safe_mul_func_int8_t_s_s(((0x03CC8E36L || g_1378) && ((safe_rshift_func_int16_t_s_s((safe_mul_func_int64_t_s_s(p_57, (safe_add_func_uint32_t_u_u((*l_1369), ((*l_1355) | (safe_sub_func_int16_t_s_s((safe_mul_func_uint32_t_u_u(((**g_1185)--), l_1392)), p_55))))))), 8)) , (safe_rshift_func_uint64_t_u_s(((l_1389 = (0xFC8CEDE852938992LL < l_1371[5][2][0])) != 0UL), l_1371[1][0][3])))), (*l_1355)))), 0xE64AL));
                        p_57 = ((*l_1367) |= ((((*l_1365) = ((*l_1363) = ((**g_1185) & ((*l_1362) ^= (*p_56))))) , (safe_mod_func_int16_t_s_s((safe_lshift_func_uint8_t_u_u(0UL, 1)), p_57))) , ((*g_121) == ((safe_div_func_uint16_t_u_u(((*g_74) >= 8UL), ((*g_1069) || l_1404))) , 0xB6L))));
                    }
                    if (l_1392)
                        break;
                    for (p_59 = 0; (p_59 >= (-5)); p_59 = safe_sub_func_int8_t_s_s(p_59, 9))
                    { /* block id: 596 */
                        uint32_t l_1408[2];
                        int i;
                        for (i = 0; i < 2; i++)
                            l_1408[i] = 1UL;
                        ++l_1408[0];
                    }
                }
                else
                { /* block id: 599 */
                    int32_t *l_1411 = &l_1202[2];
                    (*g_990) = l_1411;
                    for (g_563.f0 = (-25); (g_563.f0 < 54); ++g_563.f0)
                    { /* block id: 603 */
                        p_57 = ((safe_div_func_uint16_t_u_u(((*l_1321)--), p_57)) < ((*g_294) ^ (safe_lshift_func_int64_t_s_s(p_55, (safe_div_func_int8_t_s_s((((*l_1318) &= (~(safe_div_func_int32_t_s_s(0x02320053L, (*l_1411))))) | ((0x19FC7612ED5C6CA1LL ^ (0x1481L > (safe_lshift_func_uint64_t_u_s(((*l_1411) , (safe_rshift_func_int16_t_s_s(0x7364L, (*l_1355)))), 21)))) <= 65531UL)), l_1392))))));
                        if (g_3)
                            goto lbl_1429;
                        if ((*p_56))
                            continue;
                        p_57 ^= g_1430[1][3];
                    }
                }
                l_1431 = (((void*)0 != &g_1006) == (*g_31));
            }
        }
        else
        { /* block id: 614 */
            uint64_t l_1434 = 0UL;
            for (p_55 = 0; (p_55 <= 11); p_55 = safe_add_func_uint16_t_u_u(p_55, 3))
            { /* block id: 617 */
                ++l_1434;
            }
        }
        return l_1437;
    }
    else
    { /* block id: 622 */
        (*g_1438) = (l_1355 = &p_57);
    }
    (*l_1440) = &p_57;
    return l_1445;
}


/* ------------------------------------------ */
/* 
 * reads : g_9 g_65 g_74 g_75 g_31 g_3 g_106 g_30 g_4 g_77 g_116 g_117 g_140 g_115 g_113 g_64 g_121 g_213 g_210 g_105 g_234 g_257 g_283 g_271 g_293 g_318 g_294 g_295 g_33 g_382 g_396 g_402 g_397 g_464 g_474 g_563 g_571 g_620 g_563.f2 g_649 g_689 g_620.f0 g_777 g_778 g_785 g_832 g_595 g_880 g_889 g_947 g_777.f0 g_990 g_1064 g_1068 g_1109 g_779 g_890 g_891 g_1069 g_563.f0 g_709 g_710 g_1109.f0 g_1170 g_563.f1
 * writes: g_33 g_105 g_77 g_113 g_115 g_117 g_121 g_64 g_4 g_140 g_106 g_65 g_210 g_213 g_75 g_234 g_257 g_271 g_283 g_293 g_338 g_343 g_397 g_464.f0 g_464.f1 g_563.f2 g_464.f2 g_709 g_563.f1 g_689.f6 g_890 g_973 g_777.f1 g_777.f0 g_1068 g_563.f0 g_1170
 */
static uint8_t  func_61(int64_t * p_62, uint32_t  p_63)
{ /* block id: 15 */
    uint8_t *l_66 = &g_33;
    int32_t l_357[7][1][6] = {{{0xF825A526L,0xF825A526L,1L,(-1L),0x9B9C6CFBL,(-1L)}},{{7L,0xF825A526L,7L,2L,1L,1L}},{{1L,7L,7L,1L,0xF825A526L,(-1L)}},{{(-1L),1L,1L,1L,(-1L),2L}},{{1L,(-1L),2L,2L,(-1L),1L}},{{7L,1L,0xF825A526L,(-1L),0xF825A526L,1L}},{{0xF825A526L,7L,2L,1L,1L,2L}}};
    uint8_t l_367 = 1UL;
    int16_t *l_372 = (void*)0;
    int64_t **l_425[2];
    uint32_t *l_454 = &g_257;
    uint32_t **l_453 = &l_454;
    int32_t l_470 = 0xD909E156L;
    uint32_t l_503 = 0x2982E590L;
    uint64_t *l_554 = &g_464.f0;
    int64_t l_556 = 0x6CD342EA1EFF7FB2LL;
    int16_t l_601 = (-5L);
    int32_t *l_605[8] = {&g_117,&g_3,&g_117,&g_3,&g_117,&g_3,&g_117,&g_3};
    uint64_t l_609[3][10][8] = {{{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL}},{{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL}},{{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL},{0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL,0x640B099E0FE7AC9FLL,18446744073709551615UL,0UL,18446744073709551615UL}}};
    int32_t l_736[4];
    uint8_t l_761 = 7UL;
    uint64_t l_766 = 2UL;
    union U1 *l_773 = &g_464;
    int32_t l_800 = (-1L);
    uint8_t l_820 = 0x8BL;
    int64_t l_823 = 0xA2D238418C70801ELL;
    int64_t **l_830 = &g_64;
    int64_t *l_904[6] = {&l_556,&l_556,&l_556,&l_556,&l_556,&l_556};
    uint64_t l_936 = 0xD241E20565899662LL;
    int32_t l_974 = 0L;
    union U1 *l_979 = (void*)0;
    uint8_t l_1016 = 255UL;
    int8_t l_1033 = 0xDDL;
    int32_t l_1046 = 0L;
    const uint32_t *l_1054 = (void*)0;
    const uint32_t **l_1053 = &l_1054;
    int16_t ****l_1114[10] = {&g_947,&g_947,&g_947,&g_947,&g_947,&g_947,&g_947,&g_947,&g_947,&g_947};
    uint32_t l_1146 = 0x6958FF2AL;
    uint8_t l_1171 = 247UL;
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_425[i] = &g_64;
    for (i = 0; i < 4; i++)
        l_736[i] = 0x026E68E1L;
    if ((((*l_66) = (1UL < 18446744073709551615UL)) < (func_67(g_9, g_65, func_71(g_74, p_63)) & (safe_div_func_uint8_t_u_u((l_357[6][0][5] , l_357[6][0][5]), p_63)))))
    { /* block id: 141 */
        int8_t l_363 = 0x11L;
        int32_t l_364 = 0x724B2485L;
        int16_t l_365 = (-10L);
        int32_t l_366 = 7L;
        int64_t **l_392 = &g_64;
        const int16_t *l_404 = &g_213;
        const int16_t **l_403[3][6] = {{&l_404,&l_404,&l_404,&l_404,&l_404,&l_404},{&l_404,&l_404,&l_404,&l_404,&l_404,&l_404},{&l_404,&l_404,&l_404,&l_404,&l_404,&l_404}};
        uint32_t **l_467 = &l_454;
        int32_t l_508 = 7L;
        int32_t l_511[8][2] = {{0x79B8D36BL,(-10L)},{9L,0x79B8D36BL},{1L,1L},{1L,0x79B8D36BL},{9L,(-10L)},{0x79B8D36BL,(-10L)},{9L,0x79B8D36BL},{1L,1L}};
        uint32_t l_555 = 0xD4EFF098L;
        uint64_t l_606 = 0x53DF7DD08CF52F6FLL;
        int i, j;
        for (g_257 = (-14); (g_257 >= 18); g_257++)
        { /* block id: 144 */
            int32_t *l_360 = &l_357[6][0][5];
            int32_t *l_361 = &l_357[1][0][2];
            int32_t *l_362[8] = {&l_357[6][0][5],&l_357[6][0][5],&l_357[6][0][5],&l_357[6][0][5],&l_357[6][0][5],&l_357[6][0][5],&l_357[6][0][5],&l_357[6][0][5]};
            int16_t *l_374[10] = {&g_213,&l_365,&g_213,&g_213,&g_213,&g_105,&g_105,&g_213,&g_105,&g_105};
            int16_t **l_373 = &l_374[9];
            int64_t l_375[5][5][3] = {{{(-5L),0xAF348486F4876AAALL,(-8L)},{0xCA60A501B55A8B3DLL,0x1C496369D72CE77DLL,0x1C496369D72CE77DLL},{(-8L),0L,7L},{0xCA60A501B55A8B3DLL,1L,0xCA60A501B55A8B3DLL},{(-5L),0xB9B5C6D67A0BC8CELL,7L}},{{1L,1L,0x1C496369D72CE77DLL},{0xC2F6E37E5EE16EF4LL,0xB9B5C6D67A0BC8CELL,(-8L)},{0x1C496369D72CE77DLL,1L,(-1L)},{0xC2F6E37E5EE16EF4LL,0L,0xC2F6E37E5EE16EF4LL},{1L,0x1C496369D72CE77DLL,(-1L)}},{{(-5L),0xAF348486F4876AAALL,(-8L)},{0xCA60A501B55A8B3DLL,0x1C496369D72CE77DLL,0x1C496369D72CE77DLL},{(-8L),0L,7L},{0xCA60A501B55A8B3DLL,1L,0xCA60A501B55A8B3DLL},{(-5L),0xB9B5C6D67A0BC8CELL,7L}},{{1L,1L,0x1C496369D72CE77DLL},{0xC2F6E37E5EE16EF4LL,0xB9B5C6D67A0BC8CELL,(-8L)},{0x1C496369D72CE77DLL,1L,(-1L)},{0xC2F6E37E5EE16EF4LL,0L,0xC2F6E37E5EE16EF4LL},{1L,0x1C496369D72CE77DLL,(-1L)}},{{(-5L),0xAF348486F4876AAALL,(-8L)},{0xCA60A501B55A8B3DLL,0x1C496369D72CE77DLL,0x1C496369D72CE77DLL},{(-8L),0L,7L},{0xCA60A501B55A8B3DLL,1L,0xCA60A501B55A8B3DLL},{(-5L),0xB9B5C6D67A0BC8CELL,7L}}};
            int32_t * const l_378 = (void*)0;
            int8_t **l_379 = &g_121;
            int32_t *l_395 = &l_364;
            uint64_t **l_551 = (void*)0;
            uint64_t *l_553 = &g_115;
            uint64_t **l_552 = &l_553;
            int8_t l_557[1];
            const uint8_t *l_594 = &g_595[3];
            int i, j, k;
            for (i = 0; i < 1; i++)
                l_557[i] = 0xD8L;
            l_367++;
            if (((g_33 , ((*l_379) = (((!p_63) , (((+((((l_372 == ((*l_373) = &l_365)) != ((l_375[3][0][0] & ((*g_74) | 0xDDL)) < (p_63 & ((safe_lshift_func_uint32_t_u_u(2UL, 1)) > p_63)))) , l_378) == (*g_30))) != (*p_62)) | l_357[5][0][3])) , l_66))) == l_66))
            { /* block id: 148 */
                const uint32_t l_387[1] = {1UL};
                int64_t ***l_393 = &l_392;
                uint16_t *l_394 = &g_4[3][0][2];
                uint32_t **l_455 = &l_454;
                int32_t l_507[4] = {0x61496DCFL,0x61496DCFL,0x61496DCFL,0x61496DCFL};
                uint16_t l_516 = 3UL;
                int i;
                if ((g_382 | (((safe_rshift_func_uint16_t_u_u(6UL, (p_63 != 0x3005L))) == (safe_div_func_uint64_t_u_u((((((l_387[0] >= ((((**l_379) = (((safe_add_func_int8_t_s_s((safe_add_func_uint16_t_u_u((((*l_393) = l_392) != &p_62), ((*l_394) = 65526UL))), (*g_121))) == (*g_74)) && g_140)) == l_357[6][0][5]) ^ p_63)) , (*g_74)) >= 0x67L) >= g_257) | p_63), (*g_64)))) > 0x28L)))
                { /* block id: 152 */
                    const int8_t l_421[4] = {0x10L,0x10L,0x10L,0x10L};
                    int16_t *l_422 = &g_105;
                    uint64_t *l_423 = (void*)0;
                    uint64_t *l_424 = &g_115;
                    int8_t **l_471[7] = {&g_121,&g_121,&g_121,&g_121,&g_121,&g_121,&g_121};
                    int32_t l_500[7] = {0L,0L,0L,0L,0L,0L,0L};
                    int i;
                    (*g_396) = l_395;
                    (*l_395) = (safe_sub_func_int32_t_s_s((safe_sub_func_uint64_t_u_u(g_257, (p_63 , (g_402 , 18446744073709551607UL)))), (g_140 | p_63)));
                    if (((l_403[2][5] != (void*)0) < (((*l_424) = ((safe_div_func_int16_t_s_s(((*l_422) = (((safe_mod_func_int64_t_s_s(((safe_rshift_func_int16_t_s_s((safe_add_func_int64_t_s_s((*l_395), ((((((safe_add_func_int8_t_s_s(((((*p_62) ^= (safe_mul_func_uint8_t_u_u((p_63 > (safe_mul_func_int32_t_s_s(l_357[6][0][5], p_63))), (((*l_373) = &g_105) != &g_105)))) , ((safe_add_func_uint64_t_u_u(1UL, 1L)) && (*g_397))) , (*g_121)), l_387[0])) >= p_63) ^ 5UL) != 6L) != p_63) > 9UL))), 8)) > l_421[3]), g_33)) == 0x37A361F727BE67DALL) , (-5L))), p_63)) >= l_421[3])) <= l_357[1][0][3])))
                    { /* block id: 159 */
                        return p_63;
                    }
                    else
                    { /* block id: 161 */
                        uint64_t l_446 = 0x5EBCA2F60905694FLL;
                        int16_t ***l_447 = &l_373;
                        int16_t ****l_448 = &l_447;
                        uint32_t ***l_456 = &l_455;
                        int32_t **l_497 = &g_31;
                        (*l_395) = ((((l_425[0] != ((*l_393) = &p_62)) , p_63) == ((-1L) != (((safe_mul_func_uint32_t_u_u((safe_div_func_int16_t_s_s((safe_div_func_int32_t_s_s((safe_mod_func_uint8_t_u_u((safe_sub_func_int32_t_s_s((((l_366 < (safe_mod_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u(((4294967295UL < (*g_116)) > ((*l_394) = (l_365 | (((*p_62) = ((safe_mul_func_int16_t_s_s((-2L), g_77[3])) || p_63)) < 0xA0EBD3525AA44600LL)))), 0UL)), p_63))) > 0xE9E664B730BE3127LL) && p_63), g_115)), 0x05L)), l_357[6][0][5])), p_63)), l_446)) , 0xA0L) != 0x3BL))) ^ 0x1FL);
                        (*l_448) = l_447;
                        l_366 = (safe_div_func_uint8_t_u_u((safe_mul_func_int32_t_s_s(((((((*l_394) &= (((l_453 == ((*l_456) = l_455)) > (safe_lshift_func_uint8_t_u_u((safe_unary_minus_func_int32_t_s(((((*g_74) |= (!(l_470 = (((*l_422) = ((void*)0 == &g_33)) == (l_357[6][0][5] ^= (!((safe_add_func_uint16_t_u_u(((((((*l_395) = ((g_464 , (safe_sub_func_int64_t_s_s(((void*)0 == l_467), (-6L)))) ^ (safe_rshift_func_int16_t_s_u(0x3550L, p_63)))) | l_387[0]) < p_63) , l_365) == l_421[1]), l_366)) < l_421[3]))))))) > (*g_121)) < 0xF982CBECL))), p_63))) , g_3)) && g_295) == p_63) , l_471[0]) == l_471[0]), g_113)), 253UL));
                        l_366 = (safe_mod_func_int32_t_s_s((g_474 , ((safe_rshift_func_int64_t_s_u((safe_lshift_func_uint64_t_u_s((safe_div_func_uint8_t_u_u((safe_mul_func_uint32_t_u_u((**g_293), (g_117 |= ((0xA379538BAE10A693LL | (safe_rshift_func_uint32_t_u_s((((*g_64) = (((safe_rshift_func_uint32_t_u_u(((safe_mod_func_uint32_t_u_u((safe_rshift_func_int32_t_s_s((*l_361), 28)), (safe_mul_func_int32_t_s_s((safe_add_func_int8_t_s_s(((g_464.f0 = ((++(*l_394)) & (&l_360 == l_497))) || (((l_500[0] = ((safe_sub_func_int32_t_s_s(7L, l_364)) > g_77[3])) < (**l_497)) , 0UL)), (*g_121))), p_63)))) > p_63), 30)) && p_63) , l_364)) , 0x62000268L), p_63))) != 0xA1L)))), p_63)), p_63)), g_3)) , p_63)), p_63));
                    }
                    for (g_140 = 23; (g_140 < 32); g_140++)
                    { /* block id: 184 */
                        int64_t l_504 = 0x04A6633254CCA481LL;
                        int32_t l_505 = 9L;
                        int32_t l_506 = (-1L);
                        int32_t l_509 = 0L;
                        int32_t l_510 = (-9L);
                        int32_t l_512 = 8L;
                        int32_t l_513 = 0x176D4EB4L;
                        int32_t l_514 = 0x58B2C43FL;
                        int32_t l_515[7] = {0x244D6BB5L,0x244D6BB5L,0x244D6BB5L,0x244D6BB5L,0x244D6BB5L,0x244D6BB5L,0x244D6BB5L};
                        int i;
                        if (l_503)
                            break;
                        --l_516;
                        return l_363;
                    }
                }
                else
                { /* block id: 189 */
                    uint32_t l_521[10][1][7] = {{{0xD898D585L,0xD898D585L,1UL,8UL,0xD8696338L,1UL,0xD8696338L}},{{0x899A36CFL,1UL,1UL,0x899A36CFL,0x977AEBA9L,1UL,0x899A36CFL}},{{0xFEA21209L,0xD8696338L,0xBF2915EAL,0xBF2915EAL,0xD8696338L,0xFEA21209L,0x7B4CBE45L}},{{4294967295UL,0x899A36CFL,0xC561B2BCL,4294967287UL,4294967287UL,0xC561B2BCL,0x899A36CFL}},{{0xD8696338L,0x7B4CBE45L,0xFEA21209L,0xD8696338L,0xBF2915EAL,0xBF2915EAL,0xD8696338L}},{{1UL,0x899A36CFL,1UL,0x977AEBA9L,0x899A36CFL,1UL,1UL}},{{8UL,0xD8696338L,1UL,0xD8696338L,8UL,1UL,0xD898D585L}},{{4294967287UL,1UL,0x977AEBA9L,4294967287UL,0x977AEBA9L,1UL,4294967287UL}},{{0xFEA21209L,0xD898D585L,0x7B4CBE45L,0xBF2915EAL,0xD898D585L,0xBF2915EAL,0x7B4CBE45L}},{{4294967287UL,4294967287UL,0xC561B2BCL,0x899A36CFL,4294967295UL,0xC561B2BCL,4294967295UL}}};
                    int32_t l_522 = (-1L);
                    int i, j, k;
                    for (g_65 = 0; (g_65 <= 18); g_65 = safe_add_func_int16_t_s_s(g_65, 4))
                    { /* block id: 192 */
                        (*l_395) ^= l_521[3][0][1];
                        (*g_396) = &l_507[0];
                    }
                    l_522 = l_521[3][0][1];
                    if (p_63)
                        break;
                    return p_63;
                }
            }
            else
            { /* block id: 200 */
                uint32_t l_531[2][8];
                int i, j;
                for (i = 0; i < 2; i++)
                {
                    for (j = 0; j < 8; j++)
                        l_531[i][j] = 0x1BDBE346L;
                }
                for (g_33 = 0; (g_33 != 40); ++g_33)
                { /* block id: 203 */
                    for (g_113 = 0; (g_113 <= (-5)); g_113 = safe_sub_func_int16_t_s_s(g_113, 4))
                    { /* block id: 206 */
                        return (*g_74);
                    }
                }
                for (g_234 = (-12); (g_234 == 25); ++g_234)
                { /* block id: 212 */
                    for (g_115 = 26; (g_115 >= 14); --g_115)
                    { /* block id: 215 */
                        return p_63;
                    }
                    --l_531[0][1];
                }
            }
            if ((l_357[6][0][5] && (safe_rshift_func_int64_t_s_u(((safe_add_func_uint32_t_u_u((safe_div_func_uint16_t_u_u((safe_div_func_uint8_t_u_u((safe_div_func_int64_t_s_s((safe_mul_func_int16_t_s_s(((safe_sub_func_uint32_t_u_u((safe_lshift_func_uint16_t_u_u((g_402 , ((+(((*l_552) = &g_115) == (l_554 = p_62))) > ((*l_379) != l_66))), 1)), (l_555 , l_470))) < l_556), p_63)), l_557[0])), l_363)), p_63)), l_511[3][0])) <= 0xB7A29E45L), 23))))
            { /* block id: 223 */
                return (*g_74);
            }
            else
            { /* block id: 225 */
                uint32_t l_562[4][5] = {{0UL,0UL,4UL,4UL,0UL},{9UL,0x0153F5DAL,9UL,0x0153F5DAL,9UL},{0UL,4UL,4UL,0UL,0UL},{0UL,0x0153F5DAL,0UL,0x0153F5DAL,0UL}};
                int32_t l_577 = (-1L);
                int32_t l_578 = 0xB746EEE3L;
                uint8_t *l_598 = &g_33;
                int i, j;
                for (l_508 = 0; (l_508 != 11); l_508++)
                { /* block id: 228 */
                    uint32_t l_570 = 18446744073709551615UL;
                    int32_t l_574 = 0x6BDF84D0L;
                    int32_t l_604 = 9L;
                    if (((((((*l_379) = l_66) != (void*)0) != ((((safe_lshift_func_uint16_t_u_u((((*l_553) = l_357[6][0][5]) && l_562[0][1]), l_357[0][0][1])) | (g_563 , (safe_lshift_func_uint64_t_u_s(((safe_lshift_func_int32_t_s_s((safe_add_func_int32_t_s_s(4L, ((void*)0 == (*g_396)))), 4)) ^ 0x03L), l_570)))) , g_571[0][0]) != (void*)0)) && 0x3E7ECED4DCE4CCBDLL) , p_63))
                    { /* block id: 231 */
                        int8_t l_572 = 0x28L;
                        int32_t l_573 = 2L;
                        int32_t l_575 = (-1L);
                        int32_t l_576 = 1L;
                        uint64_t l_579 = 1UL;
                        l_579--;
                    }
                    else
                    { /* block id: 233 */
                        uint8_t l_602[3];
                        uint16_t *l_603 = &g_464.f1;
                        int i;
                        for (i = 0; i < 3; i++)
                            l_602[i] = 3UL;
                        l_604 |= (((safe_mod_func_int16_t_s_s((~(safe_unary_minus_func_uint32_t_u(p_63))), (p_63 || (((safe_add_func_uint16_t_u_u(((*l_603) = (safe_div_func_uint8_t_u_u((++(*g_74)), (((safe_div_func_int64_t_s_s(((l_594 = (void*)0) != (((safe_lshift_func_uint16_t_u_s((p_63 , 6UL), 7)) < (*p_62)) , l_598)), (l_511[1][1] = (safe_div_func_uint8_t_u_u((((*g_64) ^ l_601) <= p_63), l_574))))) > l_602[2]) , p_63)))), l_556)) , 0x97E68FD1L) , l_574)))) != p_63) >= (*p_62));
                    }
                    l_605[6] = l_360;
                    ++l_606;
                    l_605[6] = l_361;
                }
            }
        }
        if ((((l_609[1][8][1] || (~(-9L))) || ((*g_74) = (((*l_554) = (safe_mul_func_int64_t_s_s((&l_601 == &l_601), (safe_mod_func_int16_t_s_s((safe_sub_func_int32_t_s_s(((safe_rshift_func_int32_t_s_s((+(g_620 , 0x6CL)), 14)) , l_508), (safe_sub_func_int64_t_s_s(((((*g_121) = ((((safe_sub_func_int32_t_s_s((safe_sub_func_int32_t_s_s((0x61F3662BL | (safe_div_func_uint16_t_u_u(l_363, 65535UL))), 1UL)), p_63)) < p_63) && (*p_62)) > 0x5BL)) < (-3L)) > 1UL), 0xDF1E7491E24DE4D8LL)))), p_63))))) <= 1L))) , (-10L)))
        { /* block id: 249 */
            l_605[5] = (*g_30);
        }
        else
        { /* block id: 251 */
            uint16_t *l_631[9];
            int8_t *l_634 = &l_363;
            int16_t *l_641[3][9][9];
            int32_t l_646 = 0xA6C03CAEL;
            int32_t *l_653 = &g_77[3];
            int i, j, k;
            for (i = 0; i < 9; i++)
                l_631[i] = &g_563.f1;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 9; j++)
                {
                    for (k = 0; k < 9; k++)
                        l_641[i][j][k] = &g_213;
                }
            }
            g_77[3] ^= ((safe_mul_func_int32_t_s_s((l_364 = (((g_4[3][0][2]++) , l_511[1][1]) | (((*l_634) |= (*g_121)) , (0xEF5F4CF6L != l_508)))), ((safe_mod_func_uint64_t_u_u(0x9130D6AE2613E538LL, 18446744073709551614UL)) >= ((safe_sub_func_uint32_t_u_u((((safe_add_func_int64_t_s_s(((l_366 = p_63) <= (safe_sub_func_int64_t_s_s((((g_283 = ((*l_554) = l_508)) | ((p_63 != p_63) < l_511[2][0])) && l_511[1][1]), g_318))), p_63)) && (-4L)) | p_63), g_117)) ^ l_555)))) > l_646);
            for (g_563.f2 = 0; (g_563.f2 < 12); g_563.f2++)
            { /* block id: 261 */
                if (l_646)
                { /* block id: 262 */
                    (*g_649) = &l_511[3][1];
                    return p_63;
                }
                else
                { /* block id: 265 */
                    int64_t l_654 = 0x794A449189E6AD4BLL;
                    uint32_t **l_666 = &l_454;
                    uint64_t *l_669[4] = {&l_606,&l_606,&l_606,&l_606};
                    int32_t l_670 = 0x7DB7C0AEL;
                    int i;
                    for (g_113 = 0; (g_113 < (-16)); g_113 = safe_sub_func_uint32_t_u_u(g_113, 9))
                    { /* block id: 268 */
                        int32_t **l_652 = &g_397;
                        l_653 = ((*l_652) = &l_508);
                    }
                    (*l_653) = (*l_653);
                    (*l_653) = (l_654 > (safe_rshift_func_int16_t_s_s(1L, (l_670 &= (safe_div_func_int8_t_s_s((((*g_121) != (+(safe_lshift_func_int64_t_s_u(((*l_653) >= (((*l_554) = ((*l_653) == (p_63 != ((void*)0 == l_666)))) > (l_511[1][1] &= (safe_sub_func_uint16_t_u_u((8L ^ 0xA7L), 0x40C2L))))), 20)))) != l_364), (*g_74)))))));
                    (*g_116) |= ((*l_653) = (!l_670));
                }
            }
            for (l_367 = 0; (l_367 < 11); ++l_367)
            { /* block id: 283 */
                (*l_653) &= 0x3CA48F50L;
                (*l_653) &= p_63;
            }
            (*g_649) = &l_511[1][1];
        }
    }
    else
    { /* block id: 289 */
        uint16_t l_697 = 1UL;
        int16_t *l_698 = (void*)0;
        int32_t l_699 = 0x4313F6BCL;
        int32_t l_700 = 0xB7484187L;
        int32_t l_701 = 4L;
        uint8_t *l_702 = &g_464.f2;
        int16_t ** const l_708[2] = {(void*)0,(void*)0};
        int16_t ** const *l_707[6] = {&l_708[0],&l_708[0],&l_708[0],&l_708[0],&l_708[0],&l_708[0]};
        int32_t **l_758 = (void*)0;
        int32_t l_801 = 1L;
        int32_t l_802 = 5L;
        int32_t l_803 = 0x90A19D5FL;
        int32_t l_804 = 0xE3ED3CABL;
        int32_t l_807 = 0x8EA95384L;
        int32_t l_810 = 0x1D409EE5L;
        int32_t l_813 = 0L;
        int64_t l_815 = 0L;
        int32_t l_817 = 0L;
        int32_t l_818 = 0x40EF2C1FL;
        int32_t l_819 = 0x806607E2L;
        union U1 **l_867 = &l_773;
        int64_t l_868 = 0x984E23C8B14D5E26LL;
        int16_t **l_950[3][7] = {{&l_698,&l_698,&l_698,&l_698,&l_698,&l_698,&l_698},{&l_372,&l_372,&l_372,&l_372,&l_372,&l_372,&l_372},{&l_698,&l_698,&l_698,&l_698,&l_698,&l_698,&l_698}};
        int16_t ***l_949 = &l_950[1][6];
        int32_t *****l_972 = &g_890;
        uint32_t ***l_1015 = &l_453;
        uint32_t ****l_1014 = &l_1015;
        uint8_t l_1035 = 2UL;
        int32_t l_1065 = 0xA4DD7550L;
        int32_t * const l_1093 = &g_117;
        uint64_t l_1168 = 18446744073709551615UL;
        int i, j;
        if ((((((*l_702) = (safe_lshift_func_uint64_t_u_u((safe_div_func_uint16_t_u_u(((((**l_453) = (safe_mul_func_uint64_t_u_u((safe_mod_func_uint64_t_u_u((safe_div_func_int32_t_s_s((&l_425[0] != (g_474 , ((((safe_mod_func_uint16_t_u_u((safe_rshift_func_int8_t_s_s((safe_unary_minus_func_uint16_t_u(((g_689 , (void*)0) == ((((*g_74) |= ((*l_66) ^= ((-4L) < (l_699 ^= (((65533UL | 0x00F2L) || (safe_add_func_uint16_t_u_u(((safe_unary_minus_func_uint16_t_u(p_63)) ^ (l_697 &= (safe_rshift_func_int32_t_s_s((safe_div_func_int32_t_s_s(((*p_62) ^ (*g_64)), p_63)), (*g_31))))), p_63))) , l_697))))) , p_63) , (void*)0)))), 5)), l_700)) > l_701) <= l_701) , (void*)0))), l_701)), g_689.f2)), (*g_64)))) && 0UL) && 8UL), g_620.f0)), 62))) ^ (*g_121)) == 0x84352E30B2F2AA9ELL) == (*g_64)))
        { /* block id: 296 */
            uint16_t *l_715 = &g_4[0][0][2];
            int32_t l_735[3];
            uint16_t *l_737 = &g_563.f1;
            int32_t l_738[1][9][1];
            union U1 **l_780[8] = {&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0],&g_779[0]};
            uint16_t l_824 = 7UL;
            const union U1 *l_859 = &g_563;
            const union U1 **l_858[4][7] = {{&l_859,&l_859,&l_859,&l_859,&l_859,&l_859,&l_859},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0},{&l_859,&l_859,&l_859,&l_859,&l_859,&l_859,&l_859},{(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
            const uint32_t l_885 = 0UL;
            const int32_t l_905 = 4L;
            uint64_t **l_920 = &l_554;
            uint32_t l_996 = 18446744073709551611UL;
            int32_t *l_1000 = (void*)0;
            int8_t l_1027 = 0xD6L;
            int16_t l_1030 = 1L;
            const uint32_t ***l_1055 = &l_1053;
            int i, j, k;
            for (i = 0; i < 3; i++)
                l_735[i] = 0L;
            for (i = 0; i < 1; i++)
            {
                for (j = 0; j < 9; j++)
                {
                    for (k = 0; k < 1; k++)
                        l_738[i][j][k] = (-2L);
                }
            }
lbl_999:
            if ((safe_mod_func_uint8_t_u_u(((l_738[0][3][0] ^= (safe_mul_func_uint32_t_u_u(((l_707[3] != (g_709 = &l_708[1])) & (safe_div_func_uint64_t_u_u(((*l_554) = l_700), 0xF3D40BCE2E6084C4LL))), ((~(((*l_715)++) != (safe_mod_func_uint32_t_u_u((safe_div_func_uint16_t_u_u((safe_lshift_func_uint16_t_u_u((&g_140 == ((0x5534L || (safe_unary_minus_func_uint64_t_u((safe_lshift_func_uint16_t_u_u(p_63, (safe_div_func_int16_t_s_s(((safe_mul_func_uint8_t_u_u((safe_rshift_func_uint16_t_u_u(0xDE1EL, ((l_699 = (safe_rshift_func_int8_t_s_u(((4294967289UL < p_63) && (*g_64)), p_63))) | l_735[0]))), (*g_74))) > l_736[2]), p_63))))))) , (void*)0)), p_63)), p_63)), 0x43B1B653L)))) & 1L)))) & 0xA86EL), l_735[0])))
            { /* block id: 302 */
                int16_t *l_747 = &l_601;
                int32_t ***l_759 = (void*)0;
                int32_t ***l_760 = &l_758;
                int32_t l_799[5];
                uint8_t l_845[8][8] = {{8UL,8UL,0x07L,8UL,8UL,0x07L,8UL,8UL},{0x24L,8UL,0x24L,0x24L,8UL,0x24L,0x24L,8UL},{8UL,0x24L,0x24L,8UL,0x24L,0x24L,8UL,0x24L},{8UL,8UL,0x07L,8UL,8UL,0x07L,8UL,8UL},{0x24L,8UL,0x24L,0x24L,8UL,0x24L,0x24L,8UL},{8UL,0x24L,0x24L,8UL,0x24L,0x24L,8UL,0x24L},{8UL,8UL,0x07L,8UL,8UL,0x07L,8UL,8UL},{0x24L,8UL,0x24L,0x24L,8UL,0x24L,0x24L,8UL}};
                int i, j;
                for (i = 0; i < 5; i++)
                    l_799[i] = 6L;
                l_761 ^= ((safe_lshift_func_int8_t_s_u((+8L), 5)) & ((*l_737) = (0x835A041FL != (0x5AEC1136L > ((safe_add_func_int32_t_s_s((+(&l_601 != l_747)), 0L)) <= (safe_mod_func_uint16_t_u_u((0xBD22L && (safe_lshift_func_int8_t_s_u(0L, ((*l_702) = ((safe_add_func_int64_t_s_s((safe_lshift_func_int8_t_s_s(((*g_121) &= (safe_lshift_func_int32_t_s_s((((*l_760) = l_758) != &g_31), (**g_30)))), 7)), p_63)) || (*g_64)))))), p_63)))))));
                if ((safe_mod_func_int8_t_s_s((safe_mod_func_int16_t_s_s(l_738[0][3][0], l_766)), (0UL ^ (*g_121)))))
                { /* block id: 308 */
                    uint8_t l_767[6][6][6] = {{{0xCCL,0x6AL,0UL,1UL,0UL,0x83L},{0x59L,0UL,6UL,0x6AL,0x56L,0x83L},{0x6CL,254UL,0UL,0x6BL,1UL,0x59L},{0x56L,249UL,0UL,0xB3L,1UL,247UL},{0x17L,255UL,0x26L,0xF8L,0x5DL,0x30L},{0UL,5UL,246UL,0x39L,0x26L,254UL}},{{5UL,0x17L,0x10L,0UL,0UL,8UL},{5UL,246UL,0x4BL,0xBDL,0x7AL,0xBDL},{0x6BL,0UL,0xD6L,255UL,5UL,251UL},{1UL,249UL,0xD0L,253UL,0x1CL,255UL},{0UL,0x10L,0xCCL,246UL,0x83L,251UL},{0xCCL,3UL,249UL,255UL,246UL,0UL}},{{255UL,253UL,1UL,254UL,0x1AL,0x87L},{0xB1L,5UL,0UL,0xA7L,1UL,0xF8L},{0UL,0xBDL,3UL,0x8BL,0x26L,1UL},{0UL,255UL,0xBDL,255UL,4UL,4UL},{3UL,246UL,246UL,3UL,251UL,0UL},{0x1AL,1UL,0xAEL,0x6BL,253UL,0x30L}},{{246UL,0x17L,0xA7L,0x48L,253UL,255UL},{0xD0L,1UL,0x7AL,0x26L,251UL,0xF1L},{1UL,246UL,6UL,252UL,4UL,0UL},{0x8BL,255UL,246UL,255UL,0x26L,0xB3L},{0UL,0xBDL,252UL,0x87L,1UL,0x83L},{0xC6L,5UL,1UL,251UL,0x1AL,0xAEL}},{{254UL,253UL,255UL,0x7DL,246UL,249UL},{255UL,3UL,255UL,0UL,0x83L,0UL},{0UL,0x10L,0x17L,5UL,0x1CL,246UL},{246UL,249UL,1UL,0x1AL,5UL,0x39L},{0UL,0UL,0x30L,255UL,0xD0L,0UL},{0x6CL,0x53L,8UL,0UL,253UL,251UL}},{{0xBDL,0UL,1UL,0xD6L,255UL,0x31L},{0x1CL,0xA7L,0xF1L,0xA3L,0xBDL,246UL},{0x17L,0xF1L,0xA4L,0xBDL,0UL,0xBDL},{0x31L,251UL,0x31L,0x1AL,0x5DL,0x48L},{6UL,253UL,6UL,0UL,255UL,0xD0L},{0x83L,255UL,0x8BL,0UL,6UL,0x1AL}}};
                    int i, j, k;
                    l_767[5][5][5]++;
                    for (g_563.f1 = 1; (g_563.f1 <= 5); g_563.f1 += 1)
                    { /* block id: 312 */
                        int32_t **l_771 = &l_605[6];
                        (*l_771) = &l_470;
                    }
                    l_773 = &g_464;
                    if ((((l_735[0] , (((safe_sub_func_int8_t_s_s((safe_unary_minus_func_int64_t_s((l_735[0] || 65535UL))), 251UL)) || p_63) , l_767[5][5][5])) != l_767[1][2][3]) ^ (g_777 , l_767[3][5][3])))
                    { /* block id: 316 */
                        union U1 **l_782 = &l_773;
                        union U1 ***l_781 = &l_782;
                        (*g_116) ^= ((l_780[1] = g_778) != ((*l_781) = &g_779[0]));
                    }
                    else
                    { /* block id: 320 */
                        const int32_t **l_786 = (void*)0;
                        const int32_t *l_788 = &l_470;
                        const int32_t **l_787 = &l_788;
                        l_701 |= ((*p_62) < (safe_div_func_uint8_t_u_u(((*l_702) = p_63), 0x45L)));
                        (*l_787) = (g_785 , (g_106[3] = &l_735[2]));
                        (*l_787) = &l_735[1];
                        (*l_787) = &l_735[1];
                    }
                }
                else
                { /* block id: 328 */
                    int32_t l_791 = 0xD2E70A35L;
                    int32_t l_794 = 0x2816681EL;
                    int32_t l_796 = (-4L);
                    int32_t l_797 = 0x890B049DL;
                    int32_t l_798 = 0x8CE42476L;
                    int32_t l_808 = 0x39BA1684L;
                    int32_t l_809 = 0x966C4EF0L;
                    int32_t l_811 = 0xDAE1FEF3L;
                    int32_t l_812 = 1L;
                    int32_t l_814 = 8L;
                    int32_t l_816[7][3] = {{4L,4L,4L},{8L,8L,8L},{4L,4L,4L},{8L,8L,8L},{4L,4L,4L},{8L,8L,8L},{4L,4L,4L}};
                    uint8_t l_827 = 0x91L;
                    int i, j;
                    if ((safe_sub_func_int32_t_s_s(8L, (l_791 = 0x21298185L))))
                    { /* block id: 330 */
                        int16_t l_792 = (-1L);
                        int32_t l_793 = 1L;
                        int32_t l_795 = (-1L);
                        int32_t l_805 = 0xA902E0EAL;
                        int32_t l_806[8];
                        int i;
                        for (i = 0; i < 8; i++)
                            l_806[i] = (-1L);
                        l_820--;
                        l_824++;
                    }
                    else
                    { /* block id: 333 */
                        int16_t **l_842 = &g_711;
                        int16_t ***l_841 = &l_842;
                        int16_t ****l_843 = &l_841;
                        (*l_843) = ((l_827 || ((safe_rshift_func_uint32_t_u_s((l_830 != (void*)0), 7)) == (p_63 == (safe_unary_minus_func_int8_t_s((((g_832 , (safe_add_func_uint32_t_u_u((g_689.f6 = ((*l_454)++)), 0UL))) == (safe_sub_func_uint16_t_u_u(p_63, ((safe_div_func_uint64_t_u_u((((*g_74) |= (p_63 || p_63)) > p_63), g_595[1])) , 9UL)))) == p_63)))))) , l_841);
                        l_700 = (safe_unary_minus_func_int16_t_s(0x37B7L));
                        l_845[6][1]--;
                    }
                }
            }
            else
            { /* block id: 342 */
                int32_t *l_850 = &l_818;
                const union U1 ***l_860 = &l_858[0][2];
                int8_t l_869[3];
                int16_t l_884 = (-8L);
                int16_t l_921 = 0x10B3L;
                struct S0 *l_934 = &g_689;
                struct S0 **l_933 = &l_934;
                int32_t l_937 = 0xBEDE67A4L;
                int16_t **l_944 = &l_698;
                int16_t ***l_943 = &l_944;
                uint8_t l_960 = 0x38L;
                int i;
                for (i = 0; i < 3; i++)
                    l_869[i] = (-8L);
                if ((((safe_lshift_func_int32_t_s_u((l_850 != (((*g_74) <= ((((safe_unary_minus_func_uint64_t_u((safe_mul_func_int8_t_s_s((((p_63 == ((((*l_554) = g_33) > ((safe_add_func_int32_t_s_s((((*l_715) |= (5L || ((1UL < (((((safe_rshift_func_int8_t_s_s((((*l_860) = l_858[1][3]) != ((g_382 < ((**l_830) = ((((safe_mod_func_uint32_t_u_u(((safe_rshift_func_int64_t_s_u(((safe_add_func_int64_t_s_s(((-1L) != g_65), 1L)) & (**g_30)), (*l_850))) < (*l_850)), 8UL)) > (-2L)) || 0x22AFL) & 1UL))) , l_867)), p_63)) , l_802) & l_868) || 0x98F3L) || (*l_850))) , (*l_850)))) || l_869[1]), 0L)) ^ l_735[0])) , p_63)) != 18446744073709551613UL) , 3L), (*g_121))))) < 255UL) , (void*)0) != (void*)0)) , (void*)0)), 8)) != p_63) != 0xD84D7E49B52A1BE9LL))
                { /* block id: 347 */
                    int32_t l_883 = 0x14F1EB0AL;
                    int32_t ****l_888 = (void*)0;
                    int32_t l_907 = 0xF67CCE29L;
                    const uint8_t l_940 = 0xFAL;
                    int16_t **l_942 = &l_698;
                    int16_t ***l_941 = &l_942;
                    int16_t ****l_945 = (void*)0;
                    int16_t ****l_946 = &l_941;
                    int16_t ****l_948[2][4][6] = {{{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947}},{{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947},{&g_947,&g_947,&g_947,&g_947,&g_947,&g_947}}};
                    int32_t l_959[3][1];
                    int i, j, k;
                    for (i = 0; i < 3; i++)
                    {
                        for (j = 0; j < 1; j++)
                            l_959[i][j] = 0xE69B26A5L;
                    }
                    (*l_850) = (safe_add_func_int64_t_s_s((safe_lshift_func_uint16_t_u_s(((((*p_62) < l_738[0][3][0]) & (g_785.f4 & (safe_add_func_int16_t_s_s((safe_rshift_func_uint32_t_u_u(((safe_add_func_int64_t_s_s((*p_62), (g_880 , ((*p_62) && ((((((*l_66) |= (p_63 == (*g_74))) <= (((((((safe_mul_func_uint32_t_u_u(((p_63 && 1UL) > (*g_116)), 1UL)) > p_63) <= (*p_62)) != l_883) | 0x3761L) != l_884) ^ 0x8207DACEL)) | l_738[0][2][0]) | p_63) | p_63))))) | 0x14L), 2)), l_885)))) || l_735[0]), 4)), (*p_62)));
                    for (l_697 = 1; (l_697 == 56); ++l_697)
                    { /* block id: 352 */
                        const struct S0 *l_893[10][1] = {{(void*)0},{(void*)0},{&g_785},{&g_785},{&g_785},{(void*)0},{(void*)0},{&g_785},{&g_785},{&g_785}};
                        const struct S0 **l_892 = &l_893[2][0];
                        int i, j;
                        (*g_889) = l_888;
                        (*l_892) = (void*)0;
                    }
                    for (g_283 = 0; (g_283 != 55); ++g_283)
                    { /* block id: 358 */
                        int16_t l_906 = 0xA3FAL;
                        uint32_t ***l_914 = &l_453;
                        l_907 |= (((safe_mul_func_uint64_t_u_u((((*l_850) <= (safe_mod_func_int16_t_s_s(0x4046L, (*l_850)))) || (**g_293)), (safe_mul_func_uint64_t_u_u(g_33, (safe_mod_func_int8_t_s_s((((l_738[0][8][0] = p_63) , (((*l_830) = l_904[1]) == p_62)) || (*l_850)), l_905)))))) , l_906) ^ (*p_62));
                        l_921 = (safe_div_func_uint8_t_u_u((safe_mul_func_int32_t_s_s(p_63, (((*l_850) = (safe_sub_func_int8_t_s_s((p_63 > (((l_914 != (void*)0) < (!((safe_mul_func_uint8_t_u_u(p_63, (safe_mul_func_int32_t_s_s(((*p_62) | (l_920 != &l_554)), (*g_294))))) ^ p_63))) ^ p_63)), (*g_74)))) < g_689.f4))), p_63));
                        l_937 ^= (safe_mul_func_uint64_t_u_u(((*l_554) = (safe_unary_minus_func_uint16_t_u(p_63))), (((((safe_unary_minus_func_int16_t_s((g_832 , (+(((*l_850) = p_63) != (safe_mod_func_uint16_t_u_u((1L < (-1L)), (l_906 || ((safe_sub_func_uint8_t_u_u((((void*)0 != l_933) , ((((((safe_unary_minus_func_int8_t_s((*g_121))) && p_63) , 0xA811050EL) < (-3L)) != l_824) != p_63)), p_63)) != (*g_74)))))))))) || p_63) ^ p_63) , (**g_293)) >= l_936)));
                    }
                    (*l_850) = ((((((**l_920) = (safe_lshift_func_int64_t_s_u((((*l_946) = (l_943 = (l_940 , l_941))) != (l_949 = g_947)), 50))) | p_63) >= 5L) & (l_735[1] ^= (p_63 & ((safe_lshift_func_int32_t_s_s((((safe_add_func_int64_t_s_s(((safe_add_func_int32_t_s_s(((((*l_454) = (safe_mod_func_int32_t_s_s((p_63 > ((void*)0 != l_888)), l_959[2][0]))) , (-8L)) || (*g_64)), (*l_850))) == l_960), l_824)) > p_63) == 1UL), 30)) != 3L)))) <= (-4L));
                }
                else
                { /* block id: 375 */
                    int64_t l_963 = 0x9E8D2777811C3F7FLL;
                    l_817 = (*g_116);
                    l_963 = (safe_mul_func_uint64_t_u_u(((g_785.f0 , (*p_62)) == (*p_62)), 0xC43DEF318FC1D319LL));
                    return p_63;
                }
            }
            if ((((g_777.f1 = (((&l_697 != (void*)0) < (((((safe_sub_func_int32_t_s_s((~p_63), ((l_818 = (+(((*l_454)--) | 0x653B8815L))) ^ 0UL))) || (((g_973 = l_972) == (void*)0) > (l_974 >= (safe_div_func_int64_t_s_s(((*p_62) &= (safe_add_func_int8_t_s_s(((-7L) || l_735[0]), 8UL))), (-2L)))))) | 1UL) , (-1L)) && (-5L))) && 5L)) >= l_885) & p_63))
            { /* block id: 386 */
                l_979 = (void*)0;
            }
            else
            { /* block id: 388 */
                uint32_t ***l_986 = &l_453;
                uint32_t **** const l_985 = &l_986;
                const int32_t * const l_989[9] = {&l_735[0],(void*)0,&l_735[0],&l_735[0],(void*)0,&l_735[0],&l_735[0],(void*)0,&l_735[0]};
                int32_t l_991 = 0L;
                int32_t l_992[7];
                int16_t l_1023[6];
                int i;
                for (i = 0; i < 7; i++)
                    l_992[i] = 0L;
                for (i = 0; i < 6; i++)
                    l_1023[i] = 0xED0AL;
                for (g_777.f0 = 0; (g_777.f0 != 51); g_777.f0++)
                { /* block id: 391 */
                    int32_t l_982 = 0x6C9A1BD9L;
                    int32_t l_993 = 2L;
                    int32_t l_994 = 0L;
                    int32_t l_995 = 0xC73E5067L;
                    l_982 = p_63;
                    for (g_117 = (-28); (g_117 <= 5); ++g_117)
                    { /* block id: 395 */
                        uint32_t ****l_988 = &l_986;
                        uint32_t *****l_987 = &l_988;
                        (*l_987) = l_985;
                        (*g_990) = l_989[7];
                    }
                    ++l_996;
                    if (g_257)
                        goto lbl_999;
                }
                l_1000 = &l_357[2][0][5];
                (*l_1000) ^= (p_63 <= ((*l_715) |= g_832.f3));
                for (g_140 = 0; (g_140 <= 4); g_140 += 1)
                { /* block id: 407 */
                    int32_t *l_1001 = &l_992[0];
                    int32_t **l_1002 = &l_605[1];
                    uint8_t **l_1018 = &g_74;
                    uint8_t ***l_1017 = &l_1018;
                    int32_t l_1020 = 0x94470EBFL;
                    int32_t l_1022 = 7L;
                    int32_t l_1024 = 0x15BEF33BL;
                    int32_t l_1026 = (-2L);
                    int32_t l_1029 = 0xD1EB78F8L;
                    int32_t l_1032 = 0xCE5FBD18L;
                    int32_t l_1034[5][9] = {{0x20C40B4FL,(-1L),0xA43D46D0L,(-1L),0x20C40B4FL,(-1L),0xA43D46D0L,(-1L),0x20C40B4FL},{0x98FCC890L,0x794F557EL,0x794F557EL,0x98FCC890L,0L,8L,8L,0L,0x98FCC890L},{(-2L),(-1L),(-2L),0L,(-2L),(-1L),(-2L),0L,(-2L)},{0x98FCC890L,0x98FCC890L,8L,0x794F557EL,0L,0L,0x794F557EL,8L,0x98FCC890L},{0x20C40B4FL,0L,0xA43D46D0L,0L,0x20C40B4FL,0L,0xA43D46D0L,0L,0x20C40B4FL}};
                    int i, j;
                    (*l_1002) = l_1001;
                }
            }
            (*g_116) = (l_735[0] &= (safe_unary_minus_func_int64_t_s(((l_738[0][3][0] = ((safe_rshift_func_uint32_t_u_s((safe_mod_func_int16_t_s_s(((*l_1015) == ((*l_1055) = l_1053)), 0xA3C5L)), 29)) || (safe_lshift_func_int32_t_s_s(p_63, 15)))) , (safe_mod_func_int8_t_s_s((&p_63 == (void*)0), (safe_add_func_uint16_t_u_u((0x366F5847L | (((safe_add_func_uint16_t_u_u(0x7B13L, ((&l_1030 != &l_1030) > (*g_121)))) >= (-8L)) , g_1064)), l_1065))))))));
            for (l_813 = 0; (l_813 > 26); l_813 = safe_add_func_uint32_t_u_u(l_813, 9))
            { /* block id: 437 */
                volatile uint64_t ***l_1070 = &g_1068;
                l_807 = ((void*)0 == &g_9);
                (*l_1070) = g_1068;
            }
        }
        else
        { /* block id: 441 */
            uint64_t *l_1084[1];
            int32_t l_1089[9] = {0x24DC737EL,0x3853D96CL,0x24DC737EL,0x24DC737EL,0x3853D96CL,0x24DC737EL,0x24DC737EL,0x3853D96CL,0x24DC737EL};
            struct S0 **l_1134 = (void*)0;
            uint32_t ****l_1142 = (void*)0;
            uint64_t l_1167 = 18446744073709551615UL;
            int i;
            for (i = 0; i < 1; i++)
                l_1084[i] = &l_936;
            for (l_697 = 0; (l_697 < 52); l_697 = safe_add_func_int32_t_s_s(l_697, 3))
            { /* block id: 444 */
                struct S0 *l_1073[5][2] = {{&g_689,&g_689},{&g_689,&g_689},{&g_689,&g_689},{&g_689,&g_689},{&g_689,&g_689}};
                struct S0 **l_1074 = (void*)0;
                struct S0 **l_1075 = &l_1073[0][0];
                int32_t l_1076 = 0xDE36BB04L;
                uint64_t **l_1111 = &l_1084[0];
                uint64_t ***l_1110 = &l_1111;
                int16_t ****l_1113 = &g_947;
                int i, j;
                (*l_1075) = l_1073[1][0];
                l_1076 = 0x1EC5BE5BL;
                for (l_800 = (-24); (l_800 >= 2); l_800++)
                { /* block id: 449 */
                    uint64_t **l_1083 = &l_554;
                    uint16_t *l_1085 = &g_777.f1;
                    uint16_t *l_1086 = &g_4[3][0][2];
                    int32_t **l_1090 = &l_605[0];
                    l_1089[3] = (safe_add_func_uint32_t_u_u(((((*l_1083) = &g_115) != l_1084[0]) < ((-8L) == ((*l_1086)--))), l_1089[3]));
                    (*l_1090) = (void*)0;
                    for (l_1035 = 0; (l_1035 == 29); l_1035 = safe_add_func_int16_t_s_s(l_1035, 2))
                    { /* block id: 456 */
                        int32_t **l_1095 = (void*)0;
                        int32_t **l_1096 = &l_605[7];
                        (*l_1096) = l_1093;
                    }
                }
                for (g_65 = 0; (g_65 < 22); g_65 = safe_add_func_int8_t_s_s(g_65, 9))
                { /* block id: 462 */
                    uint64_t **l_1107 = &l_554;
                    uint64_t ***l_1106 = &l_1107;
                    for (g_117 = 26; (g_117 != (-9)); --g_117)
                    { /* block id: 465 */
                        uint8_t l_1101 = 255UL;
                        uint64_t ****l_1108 = &l_1106;
                        int16_t ****l_1112 = &l_949;
                        int16_t *****l_1115 = &l_1114[0];
                        if (p_63)
                            break;
                        l_1101--;
                        l_801 ^= ((safe_mul_func_int32_t_s_s(((((*l_1108) = l_1106) == (g_1109 , l_1110)) <= (((*l_1112) = (void*)0) == ((((l_1113 == ((*l_1115) = ((p_62 != p_62) , l_1114[0]))) <= ((0x06B0306AL == p_63) ^ 0x45F8L)) || g_105) , &g_710))), 0x90A591FFL)) ^ (-1L));
                    }
                    if (p_63)
                        continue;
                }
            }
            (*l_1093) = (((safe_add_func_uint64_t_u_u(((((void*)0 == l_972) >= p_63) & (safe_add_func_uint8_t_u_u(((*l_702) = ((safe_lshift_func_int8_t_s_s((safe_sub_func_int64_t_s_s(((((p_63 || ((((void*)0 == (*g_778)) != (safe_div_func_int32_t_s_s((*g_31), (safe_lshift_func_uint32_t_u_s((safe_unary_minus_func_uint8_t_u(((safe_add_func_int32_t_s_s(((safe_add_func_int32_t_s_s(p_63, (!((*****l_972) < p_63)))) , p_63), p_63)) , p_63))), 26))))) >= 4UL)) , (void*)0) != l_1134) & (*g_1069)), (*g_64))), (*l_1093))) < (-1L))), (*g_121)))), (*l_1093))) , 0xEA4252CFL) , p_63);
            for (l_800 = 0; (l_800 <= 2); l_800 += 1)
            { /* block id: 480 */
                uint64_t l_1135 = 0xE81204C34D9B77D6LL;
                int32_t *l_1138 = &g_3;
                ++l_1135;
                for (p_63 = 0; (p_63 <= 2); p_63 += 1)
                { /* block id: 484 */
                    int32_t *l_1139 = &l_807;
                    int32_t l_1151 = 0x34B9AE57L;
                    int16_t * const *l_1166[3];
                    int i;
                    for (i = 0; i < 3; i++)
                        l_1166[i] = &l_372;
                    l_1139 = l_1138;
                    for (g_75 = 0; (g_75 <= 0); g_75 += 1)
                    { /* block id: 488 */
                        uint32_t ****l_1143 = (void*)0;
                        uint64_t **l_1165 = &l_1084[0];
                        uint16_t *l_1169 = &g_140;
                        int i, j, k;
                        l_1151 = (safe_div_func_uint16_t_u_u(((((p_63 | (((l_1142 != l_1143) && (safe_add_func_int32_t_s_s(((((((l_1146 > (((g_402 , ((g_563.f0 ^= (++l_609[(g_75 + 2)][(p_63 + 1)][(p_63 + 3)])) <= (6L ^ (safe_mul_func_uint64_t_u_u(((l_1089[1] && ((((*l_1139) <= p_63) , p_62) == &g_234)) & (**g_293)), 0xF5B2E310AB3BA50ELL))))) , g_880) , (*l_1139))) ^ (-4L)) > (*l_1138)) == p_63) != p_63) && 0x9A86B718L), p_63))) < (*l_1139))) | 255UL) , l_609[(g_75 + 2)][(p_63 + 1)][(p_63 + 3)]) <= 0xA4AF8F2059770168LL), p_63));
                        g_1170 &= (safe_mul_func_uint8_t_u_u(0UL, (!(((safe_sub_func_uint32_t_u_u((safe_add_func_uint64_t_u_u((safe_add_func_uint32_t_u_u((safe_mod_func_int16_t_s_s(l_1089[3], (p_63 & ((((*l_1169) = ((safe_mod_func_uint32_t_u_u((((1UL > ((*g_121) != (((*l_1165) = (void*)0) == (((*g_709) == (g_1109.f0 , l_1166[2])) , (void*)0)))) == (*p_62)) > l_1167), l_1168)) , 0x269AL)) , 0x63C3L) <= p_63)))), (*l_1139))), 0xB26170E8C612F3CDLL)), 0x6F8F26D0L)) == p_63) , p_63))));
                    }
                }
            }
            l_1171++;
        }
        l_605[4] = (void*)0;
    }
    return (*g_74);
}


/* ------------------------------------------ */
/* 
 * reads : g_31 g_3 g_106 g_30 g_75 g_74 g_4 g_77 g_116 g_117 g_9 g_140 g_115 g_113 g_64 g_65 g_121 g_213 g_210 g_105 g_234 g_257 g_283 g_271 g_293 g_318 g_294 g_295
 * writes: g_105 g_77 g_113 g_115 g_117 g_121 g_64 g_4 g_140 g_106 g_65 g_210 g_213 g_75 g_234 g_257 g_271 g_283 g_293 g_338 g_343
 */
static uint32_t  func_67(uint32_t  p_68, int8_t  p_69, int8_t  p_70)
{ /* block id: 22 */
    int16_t *l_104 = &g_105;
    int32_t l_107 = 2L;
    int32_t *l_108 = &g_77[3];
    int8_t *l_111 = (void*)0;
    int8_t *l_112 = &g_113;
    uint64_t *l_114 = &g_115;
    int8_t **l_120[1][3][2] = {{{(void*)0,(void*)0},{&l_112,(void*)0},{(void*)0,&l_112}}};
    int64_t **l_128[5];
    int64_t *l_129 = &g_65;
    uint16_t *l_139[1][6] = {{(void*)0,(void*)0,&g_140,(void*)0,(void*)0,&g_140}};
    int32_t *l_141 = &g_117;
    uint32_t l_181[10][7] = {{1UL,4294967287UL,4294967287UL,1UL,6UL,1UL,4294967287UL},{0xEA34FD0DL,0xEA34FD0DL,4294967287UL,0x0E15510CL,4294967287UL,0xEA34FD0DL,0xEA34FD0DL},{0xEA34FD0DL,4294967287UL,0x0E15510CL,4294967287UL,0xEA34FD0DL,0xEA34FD0DL,4294967287UL},{1UL,6UL,1UL,4294967287UL,4294967287UL,1UL,6UL},{4294967287UL,6UL,0x0E15510CL,0x0E15510CL,6UL,4294967287UL,6UL},{1UL,4294967287UL,4294967287UL,1UL,6UL,1UL,4294967287UL},{0xEA34FD0DL,0xEA34FD0DL,4294967287UL,0x0E15510CL,4294967287UL,0xEA34FD0DL,0xEA34FD0DL},{4294967287UL,1UL,6UL,1UL,4294967287UL,4294967287UL,1UL},{0x0E15510CL,0xEA34FD0DL,0x0E15510CL,1UL,1UL,0x0E15510CL,0xEA34FD0DL},{1UL,0xEA34FD0DL,6UL,6UL,0xEA34FD0DL,1UL,0xEA34FD0DL}};
    int8_t **l_188 = (void*)0;
    int32_t l_244 = (-1L);
    int32_t l_245 = 6L;
    int32_t l_246 = 0x7999FF8BL;
    uint16_t l_248 = 0x424FL;
    int64_t *l_347 = &g_234;
    uint32_t l_354 = 18446744073709551609UL;
    int i, j, k;
    for (i = 0; i < 5; i++)
        l_128[i] = &g_64;
    (*g_116) = (safe_div_func_uint16_t_u_u((safe_sub_func_uint64_t_u_u((safe_div_func_uint8_t_u_u(0x5DL, (safe_mod_func_uint16_t_u_u((safe_mul_func_int8_t_s_s((safe_add_func_int64_t_s_s(((safe_unary_minus_func_int8_t_s((safe_div_func_int32_t_s_s(1L, (((*l_114) = (((((((*l_104) = (!(*g_31))) , g_106[3]) == (((l_107 ^ ((*l_108) = (**g_30))) == ((*l_112) = (((safe_mul_func_int8_t_s_s(1L, ((g_75 <= ((*g_74) != (*g_74))) >= g_3))) , g_75) , g_4[3][2][0]))) , &l_107)) | (*g_31)) , (*l_108)) >= l_107)) , 1UL))))) , 1L), 1UL)), 1L)), p_69)))), l_107)), 0xC24AL));
    (*l_108) = (safe_add_func_uint64_t_u_u(((g_121 = l_112) != (void*)0), (*l_108)));
    for (l_107 = 0; (l_107 == (-22)); l_107--)
    { /* block id: 32 */
        for (g_117 = 0; (g_117 > 1); g_117 = safe_add_func_int16_t_s_s(g_117, 3))
        { /* block id: 35 */
            return g_117;
        }
    }
    if ((safe_add_func_int32_t_s_s((((g_64 = (l_129 = &g_65)) == &g_65) != (-6L)), ((((safe_lshift_func_int8_t_s_u((&g_105 != (void*)0), 6)) & (((safe_mul_func_int8_t_s_s((1L | ((((((safe_add_func_uint64_t_u_u(((*l_108) & (g_140 = (+(++g_4[1][3][2])))), (((*l_141) = ((((((0x9A20D7CEEFDE0CEELL == (l_139[0][5] != (void*)0)) != 0L) == (*l_108)) || (*l_108)) | p_69) < p_68)) == p_70))) || p_70) || g_9) < p_68) <= p_69) || (*l_141))), 0x59L)) , g_77[1]) , 0x092CE275991FC229LL)) <= (*l_108)) || g_4[3][0][2]))))
    { /* block id: 44 */
        uint32_t l_154 = 0xA6E9923EL;
        const int32_t **l_163 = &g_106[3];
        int32_t l_211[6];
        const int8_t *l_273 = &g_113;
        const int8_t **l_272 = &l_273;
        uint32_t l_281[9] = {0xB85FCF2FL,0x1C2E1E14L,0x1C2E1E14L,0xB85FCF2FL,0x1C2E1E14L,0x1C2E1E14L,0xB85FCF2FL,0x1C2E1E14L,0x1C2E1E14L};
        int i;
        for (i = 0; i < 6; i++)
            l_211[i] = 0xACD7A26FL;
        for (l_107 = 6; (l_107 >= 2); l_107 -= 1)
        { /* block id: 47 */
            int i;
            g_106[l_107] = g_106[l_107];
        }
        if ((safe_add_func_uint32_t_u_u(((safe_sub_func_int16_t_s_s((safe_rshift_func_int32_t_s_s(p_69, (g_140 ^ 0xE658E48FED42C185LL))), ((safe_sub_func_int32_t_s_s((safe_sub_func_int8_t_s_s(((safe_mul_func_uint64_t_u_u((((l_154 , ((((*l_129) = ((safe_mod_func_uint32_t_u_u((safe_div_func_uint32_t_u_u(((65534UL & (safe_lshift_func_int32_t_s_s(1L, (safe_mul_func_uint8_t_u_u((*g_74), ((void*)0 != l_163)))))) == g_117), (-1L))), 1UL)) <= (*l_108))) || (*l_141)) <= g_140)) != g_140) || g_77[1]), (*l_141))) && g_9), p_68)), (*l_108))) || 255UL))) && 0x3FC8L), (*l_108))))
        { /* block id: 51 */
            int32_t *l_164 = &g_3;
            uint32_t *l_180 = &l_154;
            int32_t *l_189 = &l_107;
            uint32_t l_194 = 0x1AE8C0A6L;
            int32_t l_236 = 1L;
            int32_t l_241 = (-1L);
            int64_t **l_280[3][2];
            int i, j;
            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 2; j++)
                    l_280[i][j] = &g_64;
            }
            l_141 = l_164;
            (*l_189) ^= (p_68 | (safe_div_func_int32_t_s_s(((safe_mul_func_uint32_t_u_u((safe_add_func_uint32_t_u_u((safe_div_func_uint8_t_u_u((safe_mod_func_uint8_t_u_u((safe_mod_func_uint64_t_u_u(((*l_108) ^ (((safe_add_func_uint8_t_u_u(((((*l_180) &= (+p_70)) >= l_181[1][5]) ^ ((safe_add_func_int32_t_s_s(p_68, 0xD9F3A56AL)) == p_68)), ((((p_69 != (safe_mod_func_uint16_t_u_u((safe_div_func_uint8_t_u_u(((8UL == g_115) < p_69), p_68)), g_113))) , &l_111) != l_188) && g_140))) , (*g_64)) | (*g_64))), (-1L))), (*g_121))), 0xE9L)), p_68)), 1UL)) , (*g_116)), 4294967295UL)));
            for (g_65 = 0; (g_65 >= 0); g_65 -= 1)
            { /* block id: 57 */
                uint16_t l_205 = 0x7A14L;
                int32_t l_240 = 0x7FCF7A0FL;
                int32_t l_242[4][6][10] = {{{6L,1L,0x8E0E80E6L,(-1L),6L,6L,(-1L),0x8E0E80E6L,1L,6L},{6L,(-1L),0x8E0E80E6L,1L,6L,0x41A536D6L,(-1L),1L,1L,0x41A536D6L},{6L,1L,0x8E0E80E6L,(-1L),6L,6L,(-1L),0x8E0E80E6L,1L,6L},{6L,(-1L),0x8E0E80E6L,1L,6L,0x41A536D6L,(-1L),1L,1L,0x41A536D6L},{6L,1L,0x8E0E80E6L,(-1L),6L,6L,(-1L),0x8E0E80E6L,1L,6L},{6L,(-1L),0x8E0E80E6L,1L,6L,0x41A536D6L,(-1L),1L,1L,0x41A536D6L}},{{6L,1L,0x8E0E80E6L,(-1L),6L,6L,(-1L),0x8E0E80E6L,1L,6L},{6L,(-1L),0x8E0E80E6L,1L,6L,0x41A536D6L,(-1L),1L,1L,0x41A536D6L},{6L,1L,0x8E0E80E6L,(-1L),6L,6L,(-1L),0x8E0E80E6L,1L,6L},{6L,(-1L),0x8E0E80E6L,1L,6L,0x41A536D6L,(-1L),1L,1L,0x41A536D6L},{6L,1L,0x8E0E80E6L,(-1L),6L,6L,(-1L),0x8E0E80E6L,1L,6L},{6L,(-1L),0x8E0E80E6L,1L,6L,0x41A536D6L,(-1L),1L,1L,0x41A536D6L}},{{6L,1L,0x8E0E80E6L,(-1L),6L,6L,(-1L),0x8E0E80E6L,1L,6L},{6L,(-1L),0x8E0E80E6L,1L,6L,0x41A536D6L,(-1L),1L,1L,0x41A536D6L},{6L,1L,0x8E0E80E6L,(-1L),6L,6L,(-1L),0x8E0E80E6L,1L,6L},{6L,(-1L),0x8E0E80E6L,1L,6L,0x41A536D6L,(-1L),1L,1L,0x41A536D6L},{1L,0x033F47E5L,(-1L),0x8F8F8D08L,1L,1L,0x8F8F8D08L,(-1L),0x033F47E5L,1L},{1L,0x8F8F8D08L,(-1L),0x033F47E5L,1L,(-1L),0x8F8F8D08L,0x1922A5CAL,0x033F47E5L,(-1L)}},{{1L,0x033F47E5L,(-1L),0x8F8F8D08L,1L,1L,0x8F8F8D08L,(-1L),0x033F47E5L,1L},{1L,0x8F8F8D08L,(-1L),0x033F47E5L,1L,(-1L),0x8F8F8D08L,0x1922A5CAL,0x033F47E5L,(-1L)},{1L,0x033F47E5L,(-1L),0x8F8F8D08L,1L,1L,0x8F8F8D08L,(-1L),0x033F47E5L,1L},{1L,0x8F8F8D08L,(-1L),0x033F47E5L,1L,(-1L),0x8F8F8D08L,0x1922A5CAL,0x033F47E5L,(-1L)},{1L,0x033F47E5L,(-1L),0x8F8F8D08L,1L,1L,0x8F8F8D08L,(-1L),0x033F47E5L,1L},{1L,0x8F8F8D08L,(-1L),0x033F47E5L,1L,(-1L),0x8F8F8D08L,0x1922A5CAL,0x033F47E5L,(-1L)}}};
                volatile uint32_t * volatile **l_296 = &g_293;
                int32_t l_317 = 0xE74730E4L;
                int i, j, k;
                if ((safe_div_func_int16_t_s_s(5L, (((((((safe_sub_func_uint64_t_u_u(p_68, ((*l_114) = g_3))) >= (*g_74)) != 0L) && (g_113 ^ p_70)) && l_194) < (((safe_lshift_func_int64_t_s_s(3L, 24)) , (*l_108)) <= p_68)) , 6L))))
                { /* block id: 59 */
                    int16_t *l_212 = &g_213;
                    int32_t l_233 = 1L;
                    int32_t l_243 = 1L;
                    int32_t l_247 = 0xAC6DAB7EL;
                    int8_t **l_270 = &l_111;
                    uint64_t *l_282 = &g_283;
                    if ((g_77[3] , ((*l_189) = ((g_4[3][0][2] = p_69) <= (safe_lshift_func_uint64_t_u_s((safe_mul_func_uint64_t_u_u((((safe_lshift_func_uint16_t_u_s((safe_lshift_func_int8_t_s_u((*g_121), ((l_205 == (0L | ((*l_180) = (p_68 == p_70)))) > (*g_121)))), 10)) <= ((((*l_212) &= ((*l_104) = (safe_mod_func_uint32_t_u_u((safe_lshift_func_int16_t_s_u(((((g_210 = ((*g_116) | g_77[3])) , (void*)0) == (void*)0) >= 0x288FB31FL), l_211[4])), p_69)))) || p_70) & 255UL)) == (-1L)), p_70)), (*g_64)))))))
                    { /* block id: 66 */
                        int32_t l_216 = 0x11E99CA7L;
                        uint64_t * const l_221 = &g_115;
                        int32_t *l_235 = &g_77[2];
                        int32_t *l_237 = &l_233;
                        int32_t *l_238 = &l_236;
                        int32_t *l_239[1][10] = {{(void*)0,&l_233,&g_3,&l_233,(void*)0,(void*)0,&l_233,&g_3,&l_233,(void*)0}};
                        int i, j;
                        (*l_189) = (((((safe_mul_func_int32_t_s_s(l_216, ((*l_164) || p_68))) & (safe_add_func_int64_t_s_s(((g_140 |= ((g_234 &= (safe_add_func_uint32_t_u_u(((void*)0 == l_221), (safe_add_func_int64_t_s_s((safe_add_func_uint32_t_u_u(g_210, (safe_rshift_func_int64_t_s_s(((safe_rshift_func_uint8_t_u_u(((*g_74) = (p_68 > ((safe_mul_func_uint64_t_u_u((~l_216), (((-4L) <= g_105) <= g_113))) , l_233))), 6)) , (*g_64)), 34)))), (*l_164)))))) < g_3)) == g_113), (*l_164)))) && p_68) > 8L) ^ 3L);
                        l_248--;
                    }
                    else
                    { /* block id: 72 */
                        (*l_189) |= (safe_rshift_func_uint8_t_u_s(p_69, 4));
                    }
                    l_233 &= (safe_mod_func_uint8_t_u_u((safe_div_func_uint64_t_u_u(((g_257 |= p_70) == (((*g_74) = (safe_add_func_int8_t_s_s((*l_164), (*g_74)))) == ((safe_rshift_func_uint64_t_u_s(((*l_282) ^= ((*l_114) |= ((((((*l_189) = p_69) , ((safe_mul_func_uint16_t_u_u((safe_mul_func_int8_t_s_s(((safe_sub_func_uint64_t_u_u(p_69, (g_234 |= ((((safe_lshift_func_uint32_t_u_s(((((*g_121) = ((g_271 = (l_270 = l_270)) != l_272)) | ((((*g_64) || (((*l_108) = (safe_div_func_int16_t_s_s((((((*l_180) ^= (safe_lshift_func_int8_t_s_s((safe_lshift_func_uint32_t_u_u(((void*)0 != l_280[2][1]), 30)), 5))) != g_4[3][0][2]) || (*l_189)) & (*g_31)), g_65))) , 1L)) && g_4[3][0][2]) && l_281[8])) & (*l_141)), 29)) , 0x37102725FF4A1B50LL) && p_68) & (*g_64))))) | (*l_164)), p_68)), 0xCF6FL)) , (void*)0)) == &g_105) == (-1L)) ^ g_105))), 24)) > g_65))), g_117)), l_242[3][0][8]));
                }
                else
                { /* block id: 87 */
                    uint8_t l_292 = 8UL;
                    (*l_189) ^= (4294967294UL ^ (safe_add_func_int32_t_s_s(((g_115 = (((g_234 = ((void*)0 != &l_154)) < (safe_mod_func_int16_t_s_s(4L, g_283))) || (safe_lshift_func_uint16_t_u_u((*l_108), (((*l_108) < (*l_141)) ^ (((*g_74) = ((safe_mod_func_uint8_t_u_u(((((((*g_31) == 4294967294UL) < l_292) , 1L) , &p_69) == (*g_271)), (*g_74))) != l_292)) , l_292)))))) && (*l_141)), 1L)));
                }
                (*l_296) = g_293;
                if ((*g_116))
                    break;
                for (l_107 = 0; (l_107 <= 0); l_107 += 1)
                { /* block id: 97 */
                    (*l_108) = l_242[2][4][3];
                    for (g_257 = 0; (g_257 <= 0); g_257 += 1)
                    { /* block id: 101 */
                        int16_t l_319 = 0x7C3CL;
                        l_240 = (((safe_sub_func_int64_t_s_s((safe_add_func_int32_t_s_s(l_205, (safe_rshift_func_uint8_t_u_u((safe_sub_func_uint16_t_u_u((((*l_180) = (safe_div_func_int32_t_s_s(((((safe_rshift_func_uint64_t_u_u((safe_mul_func_int16_t_s_s(((*g_30) != &l_107), g_3)), 7)) >= l_240) == 0xB9E0243BL) >= ((safe_add_func_int16_t_s_s((1UL && (safe_rshift_func_uint16_t_u_u(((*l_141) | ((*l_114) = (safe_rshift_func_int16_t_s_s(0x7170L, 4)))), 12))), g_234)) > 1UL)), l_317))) & g_318), g_210)), 1)))), (*l_189))) ^ g_117) , 9L);
                        if (l_319)
                            break;
                    }
                }
            }
            (*l_108) |= (safe_rshift_func_int8_t_s_s(((7L > p_68) ^ ((*l_164) <= ((-1L) ^ p_69))), 0));
        }
        else
        { /* block id: 110 */
            int64_t l_337 = 1L;
            int32_t *l_339 = &l_107;
            (*l_339) &= ((*g_116) = (((p_68 || (((safe_sub_func_uint64_t_u_u(p_69, (((g_4[0][4][0] = ((safe_lshift_func_int16_t_s_u(1L, 4)) > (**g_271))) != (g_338[0] = (g_140 = ((safe_mul_func_int8_t_s_s((l_211[4] = (&g_294 == ((0x35L >= (0xD7D0L && (safe_lshift_func_uint32_t_u_u((safe_mul_func_int8_t_s_s((p_70 = (safe_lshift_func_int64_t_s_s(((safe_unary_minus_func_int8_t_s(((((((((*g_293) == (void*)0) != p_70) == (*l_108)) == l_337) || 0UL) & p_68) < (*g_64)))) < 1UL), p_69))), (-1L))), p_68)))) , (void*)0))), p_68)) , 0x1CC5L)))) , p_70))) < p_68) != p_69)) , g_65) > 18446744073709551608UL));
        }
    }
    else
    { /* block id: 119 */
        uint16_t *l_342 = &l_248;
        int64_t *l_346 = &g_234;
        int32_t l_348 = 0L;
        int32_t *l_349[4][10] = {{(void*)0,&g_77[3],&l_107,&l_244,&g_3,(void*)0,&g_77[1],&g_77[1],(void*)0,&g_3},{&g_77[3],&g_77[3],&g_77[3],&g_77[3],(void*)0,(void*)0,(void*)0,&g_3,(void*)0,&g_3},{&l_107,&g_77[3],(void*)0,(void*)0,&g_77[3],&l_244,&g_77[3],(void*)0,(void*)0,&g_77[3]},{&g_3,&g_77[1],&l_245,&g_77[3],(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0}};
        int i, j;
        for (g_75 = (-15); (g_75 >= 28); g_75 = safe_add_func_uint8_t_u_u(g_75, 7))
        { /* block id: 122 */
            return (*l_108);
        }
        (*l_141) |= (((g_343 = l_342) != &l_248) < ((safe_div_func_uint32_t_u_u((((l_348 = (l_346 != l_347)) & ((*l_346) = ((&l_346 == (void*)0) , ((*g_30) != l_349[3][4])))) == (0x4B0B36D9B1EDB3D1LL ^ 0UL)), (*l_108))) > (**g_293)));
        for (g_115 = 0; (g_115 != 54); g_115 = safe_add_func_uint64_t_u_u(g_115, 2))
        { /* block id: 131 */
            l_349[3][4] = &l_348;
        }
        for (g_283 = 0; (g_283 != 32); g_283 = safe_add_func_int8_t_s_s(g_283, 8))
        { /* block id: 136 */
            return l_354;
        }
    }
    return p_70;
}


/* ------------------------------------------ */
/* 
 * reads : g_75
 * writes:
 */
static int8_t  func_71(uint8_t * p_72, int32_t  p_73)
{ /* block id: 17 */
    int32_t *l_76 = &g_77[3];
    int32_t *l_78 = &g_77[3];
    int32_t *l_79 = &g_77[3];
    int32_t *l_80 = &g_77[0];
    int32_t *l_81 = &g_77[3];
    int32_t *l_82 = &g_77[3];
    int32_t *l_83[7];
    uint32_t l_84 = 8UL;
    int i;
    for (i = 0; i < 7; i++)
        l_83[i] = &g_77[0];
    p_73 = p_73;
    if (p_73)
        goto lbl_87;
lbl_87:
    l_84--;
    return g_75;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_3, "g_3", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_4[i][j][k], "g_4[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_9, "g_9", print_hash_value);
    transparent_crc(g_18, "g_18", print_hash_value);
    transparent_crc(g_22, "g_22", print_hash_value);
    transparent_crc(g_33, "g_33", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_39[i][j], "g_39[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_41[i], "g_41[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_65, "g_65", print_hash_value);
    transparent_crc(g_75, "g_75", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_77[i], "g_77[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_105, "g_105", print_hash_value);
    transparent_crc(g_113, "g_113", print_hash_value);
    transparent_crc(g_115, "g_115", print_hash_value);
    transparent_crc(g_117, "g_117", print_hash_value);
    transparent_crc(g_140, "g_140", print_hash_value);
    transparent_crc(g_210, "g_210", print_hash_value);
    transparent_crc(g_213, "g_213", print_hash_value);
    transparent_crc(g_234, "g_234", print_hash_value);
    transparent_crc(g_257, "g_257", print_hash_value);
    transparent_crc(g_283, "g_283", print_hash_value);
    transparent_crc(g_295, "g_295", print_hash_value);
    transparent_crc(g_318, "g_318", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        transparent_crc(g_338[i], "g_338[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_382, "g_382", print_hash_value);
    transparent_crc(g_402.f0, "g_402.f0", print_hash_value);
    transparent_crc(g_464.f0, "g_464.f0", print_hash_value);
    transparent_crc(g_474.f0, "g_474.f0", print_hash_value);
    transparent_crc(g_474.f1, "g_474.f1", print_hash_value);
    transparent_crc(g_474.f2, "g_474.f2", print_hash_value);
    transparent_crc(g_474.f3, "g_474.f3", print_hash_value);
    transparent_crc(g_474.f4, "g_474.f4", print_hash_value);
    transparent_crc(g_474.f5, "g_474.f5", print_hash_value);
    transparent_crc(g_474.f6, "g_474.f6", print_hash_value);
    transparent_crc(g_474.f7, "g_474.f7", print_hash_value);
    transparent_crc(g_563.f0, "g_563.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_595[i], "g_595[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_620.f0, "g_620.f0", print_hash_value);
    transparent_crc(g_689.f0, "g_689.f0", print_hash_value);
    transparent_crc(g_689.f1, "g_689.f1", print_hash_value);
    transparent_crc(g_689.f2, "g_689.f2", print_hash_value);
    transparent_crc(g_689.f3, "g_689.f3", print_hash_value);
    transparent_crc(g_689.f4, "g_689.f4", print_hash_value);
    transparent_crc(g_689.f5, "g_689.f5", print_hash_value);
    transparent_crc(g_689.f6, "g_689.f6", print_hash_value);
    transparent_crc(g_689.f7, "g_689.f7", print_hash_value);
    transparent_crc(g_777.f0, "g_777.f0", print_hash_value);
    transparent_crc(g_785.f0, "g_785.f0", print_hash_value);
    transparent_crc(g_785.f1, "g_785.f1", print_hash_value);
    transparent_crc(g_785.f2, "g_785.f2", print_hash_value);
    transparent_crc(g_785.f3, "g_785.f3", print_hash_value);
    transparent_crc(g_785.f4, "g_785.f4", print_hash_value);
    transparent_crc(g_785.f5, "g_785.f5", print_hash_value);
    transparent_crc(g_785.f6, "g_785.f6", print_hash_value);
    transparent_crc(g_785.f7, "g_785.f7", print_hash_value);
    transparent_crc(g_832.f0, "g_832.f0", print_hash_value);
    transparent_crc(g_832.f1, "g_832.f1", print_hash_value);
    transparent_crc(g_832.f2, "g_832.f2", print_hash_value);
    transparent_crc(g_832.f3, "g_832.f3", print_hash_value);
    transparent_crc(g_832.f4, "g_832.f4", print_hash_value);
    transparent_crc(g_832.f5, "g_832.f5", print_hash_value);
    transparent_crc(g_832.f6, "g_832.f6", print_hash_value);
    transparent_crc(g_832.f7, "g_832.f7", print_hash_value);
    transparent_crc(g_880.f0, "g_880.f0", print_hash_value);
    transparent_crc(g_1064, "g_1064", print_hash_value);
    transparent_crc(g_1109.f0, "g_1109.f0", print_hash_value);
    transparent_crc(g_1170, "g_1170", print_hash_value);
    transparent_crc(g_1378, "g_1378", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_1430[i][j], "g_1430[i][j]", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1466.f0, "g_1466.f0", print_hash_value);
    transparent_crc(g_1502.f0, "g_1502.f0", print_hash_value);
    transparent_crc(g_1578.f0, "g_1578.f0", print_hash_value);
    transparent_crc(g_1578.f1, "g_1578.f1", print_hash_value);
    transparent_crc(g_1578.f2, "g_1578.f2", print_hash_value);
    transparent_crc(g_1578.f3, "g_1578.f3", print_hash_value);
    transparent_crc(g_1578.f4, "g_1578.f4", print_hash_value);
    transparent_crc(g_1578.f5, "g_1578.f5", print_hash_value);
    transparent_crc(g_1578.f6, "g_1578.f6", print_hash_value);
    transparent_crc(g_1578.f7, "g_1578.f7", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            transparent_crc(g_1585[i][j].f0, "g_1585[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1586, "g_1586", print_hash_value);
    transparent_crc(g_1599.f0, "g_1599.f0", print_hash_value);
    transparent_crc(g_1599.f1, "g_1599.f1", print_hash_value);
    transparent_crc(g_1599.f2, "g_1599.f2", print_hash_value);
    transparent_crc(g_1599.f3, "g_1599.f3", print_hash_value);
    transparent_crc(g_1599.f4, "g_1599.f4", print_hash_value);
    transparent_crc(g_1599.f5, "g_1599.f5", print_hash_value);
    transparent_crc(g_1599.f6, "g_1599.f6", print_hash_value);
    transparent_crc(g_1599.f7, "g_1599.f7", print_hash_value);
    transparent_crc(g_1627.f0, "g_1627.f0", print_hash_value);
    transparent_crc(g_1627.f1, "g_1627.f1", print_hash_value);
    transparent_crc(g_1627.f2, "g_1627.f2", print_hash_value);
    transparent_crc(g_1627.f3, "g_1627.f3", print_hash_value);
    transparent_crc(g_1627.f4, "g_1627.f4", print_hash_value);
    transparent_crc(g_1627.f5, "g_1627.f5", print_hash_value);
    transparent_crc(g_1627.f6, "g_1627.f6", print_hash_value);
    transparent_crc(g_1627.f7, "g_1627.f7", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 5; k++)
            {
                transparent_crc(g_1654[i][j][k].f0, "g_1654[i][j][k].f0", print_hash_value);
                transparent_crc(g_1654[i][j][k].f1, "g_1654[i][j][k].f1", print_hash_value);
                transparent_crc(g_1654[i][j][k].f2, "g_1654[i][j][k].f2", print_hash_value);
                transparent_crc(g_1654[i][j][k].f3, "g_1654[i][j][k].f3", print_hash_value);
                transparent_crc(g_1654[i][j][k].f4, "g_1654[i][j][k].f4", print_hash_value);
                transparent_crc(g_1654[i][j][k].f5, "g_1654[i][j][k].f5", print_hash_value);
                transparent_crc(g_1654[i][j][k].f6, "g_1654[i][j][k].f6", print_hash_value);
                transparent_crc(g_1654[i][j][k].f7, "g_1654[i][j][k].f7", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1665, "g_1665", print_hash_value);
    transparent_crc(g_1666, "g_1666", print_hash_value);
    transparent_crc(g_1675.f0, "g_1675.f0", print_hash_value);
    transparent_crc(g_1675.f1, "g_1675.f1", print_hash_value);
    transparent_crc(g_1675.f2, "g_1675.f2", print_hash_value);
    transparent_crc(g_1675.f3, "g_1675.f3", print_hash_value);
    transparent_crc(g_1675.f4, "g_1675.f4", print_hash_value);
    transparent_crc(g_1675.f5, "g_1675.f5", print_hash_value);
    transparent_crc(g_1675.f6, "g_1675.f6", print_hash_value);
    transparent_crc(g_1675.f7, "g_1675.f7", print_hash_value);
    transparent_crc(g_1689, "g_1689", print_hash_value);
    transparent_crc(g_1717, "g_1717", print_hash_value);
    transparent_crc(g_1981, "g_1981", print_hash_value);
    transparent_crc(g_1987.f0, "g_1987.f0", print_hash_value);
    transparent_crc(g_1987.f1, "g_1987.f1", print_hash_value);
    transparent_crc(g_1987.f2, "g_1987.f2", print_hash_value);
    transparent_crc(g_1987.f3, "g_1987.f3", print_hash_value);
    transparent_crc(g_1987.f4, "g_1987.f4", print_hash_value);
    transparent_crc(g_1987.f5, "g_1987.f5", print_hash_value);
    transparent_crc(g_1987.f6, "g_1987.f6", print_hash_value);
    transparent_crc(g_1987.f7, "g_1987.f7", print_hash_value);
    transparent_crc(g_2078.f0, "g_2078.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_2134[i].f0, "g_2134[i].f0", print_hash_value);
        transparent_crc(g_2134[i].f1, "g_2134[i].f1", print_hash_value);
        transparent_crc(g_2134[i].f2, "g_2134[i].f2", print_hash_value);
        transparent_crc(g_2134[i].f3, "g_2134[i].f3", print_hash_value);
        transparent_crc(g_2134[i].f4, "g_2134[i].f4", print_hash_value);
        transparent_crc(g_2134[i].f5, "g_2134[i].f5", print_hash_value);
        transparent_crc(g_2134[i].f6, "g_2134[i].f6", print_hash_value);
        transparent_crc(g_2134[i].f7, "g_2134[i].f7", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2196.f0, "g_2196.f0", print_hash_value);
    transparent_crc(g_2196.f1, "g_2196.f1", print_hash_value);
    transparent_crc(g_2196.f2, "g_2196.f2", print_hash_value);
    transparent_crc(g_2196.f3, "g_2196.f3", print_hash_value);
    transparent_crc(g_2196.f4, "g_2196.f4", print_hash_value);
    transparent_crc(g_2196.f5, "g_2196.f5", print_hash_value);
    transparent_crc(g_2196.f6, "g_2196.f6", print_hash_value);
    transparent_crc(g_2196.f7, "g_2196.f7", print_hash_value);
    transparent_crc(g_2213.f0, "g_2213.f0", print_hash_value);
    transparent_crc(g_2239, "g_2239", print_hash_value);
    transparent_crc(g_2241, "g_2241", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2313[i].f0, "g_2313[i].f0", print_hash_value);
        transparent_crc(g_2313[i].f1, "g_2313[i].f1", print_hash_value);
        transparent_crc(g_2313[i].f2, "g_2313[i].f2", print_hash_value);
        transparent_crc(g_2313[i].f3, "g_2313[i].f3", print_hash_value);
        transparent_crc(g_2313[i].f4, "g_2313[i].f4", print_hash_value);
        transparent_crc(g_2313[i].f5, "g_2313[i].f5", print_hash_value);
        transparent_crc(g_2313[i].f6, "g_2313[i].f6", print_hash_value);
        transparent_crc(g_2313[i].f7, "g_2313[i].f7", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2335.f0, "g_2335.f0", print_hash_value);
    transparent_crc(g_2335.f1, "g_2335.f1", print_hash_value);
    transparent_crc(g_2335.f2, "g_2335.f2", print_hash_value);
    transparent_crc(g_2335.f3, "g_2335.f3", print_hash_value);
    transparent_crc(g_2335.f4, "g_2335.f4", print_hash_value);
    transparent_crc(g_2335.f5, "g_2335.f5", print_hash_value);
    transparent_crc(g_2335.f6, "g_2335.f6", print_hash_value);
    transparent_crc(g_2335.f7, "g_2335.f7", print_hash_value);
    transparent_crc(g_2370.f0, "g_2370.f0", print_hash_value);
    transparent_crc(g_2370.f1, "g_2370.f1", print_hash_value);
    transparent_crc(g_2370.f2, "g_2370.f2", print_hash_value);
    transparent_crc(g_2370.f3, "g_2370.f3", print_hash_value);
    transparent_crc(g_2370.f4, "g_2370.f4", print_hash_value);
    transparent_crc(g_2370.f5, "g_2370.f5", print_hash_value);
    transparent_crc(g_2370.f6, "g_2370.f6", print_hash_value);
    transparent_crc(g_2370.f7, "g_2370.f7", print_hash_value);
    transparent_crc(g_2376, "g_2376", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_2390[i].f0, "g_2390[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2394, "g_2394", print_hash_value);
    transparent_crc(g_2538.f0, "g_2538.f0", print_hash_value);
    transparent_crc(g_2538.f1, "g_2538.f1", print_hash_value);
    transparent_crc(g_2538.f2, "g_2538.f2", print_hash_value);
    transparent_crc(g_2538.f3, "g_2538.f3", print_hash_value);
    transparent_crc(g_2538.f4, "g_2538.f4", print_hash_value);
    transparent_crc(g_2538.f5, "g_2538.f5", print_hash_value);
    transparent_crc(g_2538.f6, "g_2538.f6", print_hash_value);
    transparent_crc(g_2538.f7, "g_2538.f7", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_2579[i][j][k].f0, "g_2579[i][j][k].f0", print_hash_value);
                transparent_crc(g_2579[i][j][k].f1, "g_2579[i][j][k].f1", print_hash_value);
                transparent_crc(g_2579[i][j][k].f2, "g_2579[i][j][k].f2", print_hash_value);
                transparent_crc(g_2579[i][j][k].f3, "g_2579[i][j][k].f3", print_hash_value);
                transparent_crc(g_2579[i][j][k].f4, "g_2579[i][j][k].f4", print_hash_value);
                transparent_crc(g_2579[i][j][k].f5, "g_2579[i][j][k].f5", print_hash_value);
                transparent_crc(g_2579[i][j][k].f6, "g_2579[i][j][k].f6", print_hash_value);
                transparent_crc(g_2579[i][j][k].f7, "g_2579[i][j][k].f7", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2593.f0, "g_2593.f0", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 1
breakdown:
   depth: 0, occurrence: 652
   depth: 1, occurrence: 15
XXX total union variables: 14

XXX non-zero bitfields defined in structs: 8
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 1
XXX volatile bitfields defined in structs: 1
XXX structs with bitfields in the program: 26
breakdown:
   indirect level: 0, occurrence: 15
   indirect level: 1, occurrence: 3
   indirect level: 2, occurrence: 4
   indirect level: 3, occurrence: 0
   indirect level: 4, occurrence: 4
XXX full-bitfields structs in the program: 15
breakdown:
   indirect level: 0, occurrence: 15
XXX times a bitfields struct's address is taken: 27
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 20
XXX times a single bitfield on LHS: 1
XXX times a single bitfield on RHS: 25

XXX max expression depth: 46
breakdown:
   depth: 1, occurrence: 416
   depth: 2, occurrence: 87
   depth: 3, occurrence: 13
   depth: 4, occurrence: 6
   depth: 5, occurrence: 2
   depth: 6, occurrence: 3
   depth: 7, occurrence: 2
   depth: 9, occurrence: 4
   depth: 10, occurrence: 1
   depth: 12, occurrence: 2
   depth: 13, occurrence: 1
   depth: 14, occurrence: 4
   depth: 15, occurrence: 3
   depth: 16, occurrence: 1
   depth: 17, occurrence: 4
   depth: 18, occurrence: 6
   depth: 19, occurrence: 5
   depth: 20, occurrence: 4
   depth: 21, occurrence: 1
   depth: 22, occurrence: 5
   depth: 23, occurrence: 4
   depth: 24, occurrence: 5
   depth: 25, occurrence: 5
   depth: 26, occurrence: 4
   depth: 27, occurrence: 4
   depth: 28, occurrence: 5
   depth: 29, occurrence: 5
   depth: 30, occurrence: 3
   depth: 31, occurrence: 1
   depth: 32, occurrence: 4
   depth: 33, occurrence: 3
   depth: 34, occurrence: 1
   depth: 36, occurrence: 1
   depth: 37, occurrence: 2
   depth: 39, occurrence: 1
   depth: 42, occurrence: 1
   depth: 43, occurrence: 1
   depth: 46, occurrence: 1

XXX total number of pointers: 542

XXX times a variable address is taken: 1252
XXX times a pointer is dereferenced on RHS: 433
breakdown:
   depth: 1, occurrence: 341
   depth: 2, occurrence: 77
   depth: 3, occurrence: 11
   depth: 4, occurrence: 3
   depth: 5, occurrence: 1
XXX times a pointer is dereferenced on LHS: 322
breakdown:
   depth: 1, occurrence: 289
   depth: 2, occurrence: 22
   depth: 3, occurrence: 9
   depth: 4, occurrence: 2
XXX times a pointer is compared with null: 44
XXX times a pointer is compared with address of another variable: 10
XXX times a pointer is compared with another pointer: 12
XXX times a pointer is qualified to be dereferenced: 8096

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 1586
   level: 2, occurrence: 598
   level: 3, occurrence: 109
   level: 4, occurrence: 73
   level: 5, occurrence: 89
XXX number of pointers point to pointers: 308
XXX number of pointers point to scalars: 218
XXX number of pointers point to structs: 8
XXX percent of pointers has null in alias set: 26
XXX average alias set size: 1.41

XXX times a non-volatile is read: 2135
XXX times a non-volatile is write: 1003
XXX times a volatile is read: 105
XXX    times read thru a pointer: 34
XXX times a volatile is write: 23
XXX    times written thru a pointer: 2
XXX times a volatile is available for access: 5.28e+03
XXX percentage of non-volatile access: 96.1

XXX forward jumps: 2
XXX backward jumps: 6

XXX stmts: 412
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 34
   depth: 1, occurrence: 28
   depth: 2, occurrence: 49
   depth: 3, occurrence: 67
   depth: 4, occurrence: 103
   depth: 5, occurrence: 131

XXX percentage a fresh-made variable is used: 16.7
XXX percentage an existing variable is used: 83.3
FYI: the random generator makes assumptions about the integer size. See platform.info for more details.
XXX total OOB instances added: 0
********************* end of statistics **********************/

