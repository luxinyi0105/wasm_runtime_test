/*
 * This is a RANDOMLY GENERATED PROGRAM.
 *
 * Generator: csmith 2.4.0
 * Git version: 92069e4
 * Options:   (none)
 * Seed:      1254905818
 */

#include "csmith.h"


static long __undefined;

/* --- Struct/Union Declarations --- */
union U0 {
   volatile uint32_t  f0;
   int64_t  f1;
   volatile uint64_t  f2;
};

union U1 {
   const volatile int8_t  f0;
   uint32_t  f1;
   uint32_t  f2;
};

union U2 {
   uint32_t  f0;
   const int16_t  f1;
   uint64_t  f2;
   volatile uint32_t  f3;
};

/* --- GLOBAL VARIABLES --- */
static int8_t g_10 = (-1L);
static volatile union U1 g_74 = {1L};/* VOLATILE GLOBAL g_74 */
static int32_t g_86[10] = {(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L),(-1L)};
static int32_t g_88 = (-7L);
static int32_t g_90 = 1L;
static volatile int32_t * const g_93 = (void*)0;
static int32_t g_95 = (-1L);
static int32_t *g_94 = &g_95;
static int64_t g_98 = (-4L);
static int32_t g_124 = 0x4FF8C8F4L;
static int32_t ** volatile g_141 = &g_94;/* VOLATILE GLOBAL g_141 */
static uint16_t g_143 = 0UL;
static uint16_t * const g_142 = &g_143;
static uint64_t g_154 = 0UL;
static union U1 g_157[6] = {{-10L},{-10L},{0L},{-10L},{-10L},{0L}};
static volatile union U1 g_161[9] = {{0x75L},{0x75L},{0x75L},{0x75L},{0x75L},{0x75L},{0x75L},{0x75L},{0x75L}};
static int64_t **g_172 = (void*)0;
static int64_t ***g_171 = &g_172;
static int64_t **** volatile g_170[9][2][1] = {{{&g_171},{&g_171}},{{&g_171},{&g_171}},{{&g_171},{&g_171}},{{&g_171},{&g_171}},{{&g_171},{&g_171}},{{&g_171},{&g_171}},{{&g_171},{&g_171}},{{&g_171},{&g_171}},{{&g_171},{&g_171}}};
static int64_t **** volatile g_173[4][4] = {{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,(void*)0}};
static const union U0 g_180 = {18446744073709551614UL};/* VOLATILE GLOBAL g_180 */
static const union U0 *g_182 = &g_180;
static const union U0 ** volatile g_181 = &g_182;/* VOLATILE GLOBAL g_181 */
static int32_t ** const  volatile g_186 = &g_94;/* VOLATILE GLOBAL g_186 */
static int32_t ** volatile g_196[6][10][4] = {{{(void*)0,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,(void*)0,&g_94},{&g_94,&g_94,&g_94,&g_94},{(void*)0,(void*)0,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,(void*)0,&g_94},{&g_94,&g_94,&g_94,&g_94}},{{&g_94,(void*)0,&g_94,&g_94},{&g_94,&g_94,(void*)0,&g_94},{&g_94,&g_94,&g_94,&g_94},{(void*)0,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,(void*)0},{&g_94,&g_94,&g_94,(void*)0},{&g_94,(void*)0,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94}},{{(void*)0,&g_94,&g_94,&g_94},{&g_94,&g_94,(void*)0,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,(void*)0},{&g_94,&g_94,(void*)0,&g_94},{&g_94,(void*)0,&g_94,&g_94},{&g_94,&g_94,&g_94,(void*)0},{&g_94,&g_94,&g_94,&g_94},{(void*)0,&g_94,&g_94,&g_94},{&g_94,&g_94,(void*)0,&g_94}},{{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,(void*)0,&g_94,(void*)0},{(void*)0,&g_94,&g_94,(void*)0},{(void*)0,&g_94,&g_94,&g_94},{(void*)0,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,(void*)0,&g_94},{&g_94,&g_94,&g_94,&g_94}},{{(void*)0,(void*)0,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,&g_94,(void*)0,&g_94},{&g_94,&g_94,&g_94,&g_94},{(void*)0,&g_94,&g_94,&g_94},{(void*)0,&g_94,&g_94,&g_94},{&g_94,(void*)0,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{(void*)0,(void*)0,&g_94,&g_94}},{{&g_94,(void*)0,&g_94,&g_94},{&g_94,&g_94,&g_94,(void*)0},{&g_94,(void*)0,&g_94,&g_94},{&g_94,(void*)0,&g_94,&g_94},{(void*)0,(void*)0,&g_94,&g_94},{&g_94,&g_94,&g_94,&g_94},{&g_94,(void*)0,&g_94,&g_94},{(void*)0,&g_94,&g_94,(void*)0},{(void*)0,&g_94,&g_94,(void*)0},{&g_94,(void*)0,&g_94,&g_94}}};
static uint8_t g_199[10][1][10] = {{{0xF6L,0xCDL,0UL,0x52L,0x37L,0x08L,0x53L,0x08L,0x37L,0x52L}},{{0xB2L,0xFDL,0xB2L,0x0FL,1UL,0xA6L,7UL,0xD4L,0x92L,0x2AL}},{{7UL,0x1CL,0x37L,0x94L,0x42L,0xC5L,0UL,0xD4L,253UL,0x03L}},{{252UL,8UL,0xB2L,249UL,0x92L,251UL,0x94L,0x08L,0x39L,0xA6L}},{{255UL,0x42L,0UL,0xC5L,0xC6L,0x46L,249UL,251UL,0x52L,0xB2L}},{{0xF0L,0xC6L,7UL,0x46L,0xCDL,0xCDL,0x46L,7UL,0xC6L,0xF0L}},{{0x3BL,0x08L,1UL,0UL,249UL,0x4DL,0xAAL,0x92L,0xB4L,0xD4L}},{{0xFDL,253UL,0x42L,0x08L,249UL,253UL,252UL,0x7FL,0x94L,0xF0L}},{{249UL,0xAAL,253UL,0x36L,0xCDL,0x92L,0x1CL,0x46L,0UL,0xB2L}},{{0x7FL,0x2AL,0x0FL,0x3BL,0xC6L,249UL,0xCDL,0xA6L,0UL,0xA6L}}};
static union U0 g_203 = {0x2BFBAC01L};/* VOLATILE GLOBAL g_203 */
static union U0 g_204[1][10] = {{{0UL},{0UL},{0UL},{0UL},{0UL},{0UL},{0UL},{0UL},{0UL},{0UL}}};
static union U0 g_248[1] = {{8UL}};
static union U0 g_249 = {0x0049AFEDL};/* VOLATILE GLOBAL g_249 */
static union U1 g_252 = {0x89L};/* VOLATILE GLOBAL g_252 */
static union U0 g_264[2][4][9] = {{{{0xA3FB0C44L},{0x97D91556L},{3UL},{18446744073709551615UL},{0xEE0BA4ECL},{18446744073709551612UL},{0xEE343D5BL},{18446744073709551615UL},{5UL}},{{3UL},{0x851DF562L},{0x4FFF7F3BL},{1UL},{1UL},{0x4FFF7F3BL},{0x851DF562L},{3UL},{18446744073709551615UL}},{{0xB9D081BBL},{1UL},{3UL},{3UL},{0UL},{0xAA2CB44AL},{0x2B4CE385L},{18446744073709551615UL},{0xEE0BA4ECL}},{{1UL},{3UL},{0xE45BC0E4L},{0xEE343D5BL},{18446744073709551615UL},{18446744073709551615UL},{0xA3FB0C44L},{18446744073709551615UL},{18446744073709551615UL}}},{{{5UL},{1UL},{1UL},{5UL},{0xEE343D5BL},{0x4FFF7F3BL},{0xA3FB0C44L},{0xB9D081BBL},{0xAA2CB44AL}},{{0xEE343D5BL},{0xE45BC0E4L},{3UL},{1UL},{1UL},{3UL},{0x2B4CE385L},{0x97D91556L},{18446744073709551615UL}},{{3UL},{3UL},{1UL},{0xB9D081BBL},{0xEE343D5BL},{0xB9D081BBL},{1UL},{3UL},{3UL}},{{18446744073709551615UL},{0xEE343D5BL},{1UL},{0x851DF562L},{18446744073709551615UL},{18446744073709551612UL},{1UL},{18446744073709551615UL},{0xB9D081BBL}}}};
static uint16_t g_267 = 1UL;
static int32_t ** volatile g_289 = &g_94;/* VOLATILE GLOBAL g_289 */
static volatile union U2 g_305 = {0x15367F6BL};/* VOLATILE GLOBAL g_305 */
static union U0 *g_311 = (void*)0;
static uint16_t g_328 = 0xB938L;
static volatile union U1 g_356 = {0xB9L};/* VOLATILE GLOBAL g_356 */
static union U1 * volatile *g_360 = (void*)0;
static const union U1 g_363 = {0L};/* VOLATILE GLOBAL g_363 */
static volatile uint16_t g_375 = 1UL;/* VOLATILE GLOBAL g_375 */
static int16_t g_381 = 0x9659L;
static int32_t ** volatile g_400 = &g_94;/* VOLATILE GLOBAL g_400 */
static int32_t ** volatile g_419 = &g_94;/* VOLATILE GLOBAL g_419 */
static int16_t g_430[5][6][1] = {{{0x7E8CL},{0L},{(-2L)},{0L},{2L},{0x7E8CL}},{{0x7E8CL},{2L},{0L},{(-2L)},{0L},{0x7E8CL}},{{(-2L)},{0xAEDCL},{(-2L)},{0x7E8CL},{0L},{(-2L)}},{{0L},{2L},{0x7E8CL},{0x7E8CL},{2L},{0L}},{{(-2L)},{0L},{0x7E8CL},{(-2L)},{0xAEDCL},{(-2L)}}};
static int32_t g_434 = 0x5F2B56A5L;
static int32_t ** const  volatile g_435 = &g_94;/* VOLATILE GLOBAL g_435 */
static volatile union U1 g_482 = {0x6BL};/* VOLATILE GLOBAL g_482 */
static int32_t ** const  volatile g_516 = &g_94;/* VOLATILE GLOBAL g_516 */
static union U2 g_531 = {0x35D013DCL};/* VOLATILE GLOBAL g_531 */
static volatile union U2 g_552 = {0x4477C670L};/* VOLATILE GLOBAL g_552 */
static volatile union U2 g_555 = {1UL};/* VOLATILE GLOBAL g_555 */
static int32_t ** volatile g_570 = &g_94;/* VOLATILE GLOBAL g_570 */
static volatile union U2 g_608[10][3] = {{{9UL},{0x5E270E97L},{0x5E270E97L}},{{3UL},{1UL},{1UL}},{{9UL},{0x5E270E97L},{0x5E270E97L}},{{3UL},{1UL},{1UL}},{{9UL},{0x5E270E97L},{0x5E270E97L}},{{3UL},{1UL},{1UL}},{{9UL},{0x5E270E97L},{0x5E270E97L}},{{3UL},{1UL},{1UL}},{{9UL},{0x5E270E97L},{0x5E270E97L}},{{3UL},{1UL},{1UL}}};
static uint32_t g_613 = 4294967295UL;
static union U1 g_636[10] = {{6L},{-4L},{-4L},{6L},{6L},{6L},{-4L},{-4L},{6L},{6L}};
static union U1 *g_635 = &g_636[3];
static union U1 **g_634 = &g_635;
static union U1 ***g_633 = &g_634;
static union U2 g_683 = {18446744073709551606UL};/* VOLATILE GLOBAL g_683 */
static int32_t g_728 = 1L;
static volatile union U1 g_744[6][10][4] = {{{{0L},{0x34L},{0xFEL},{0L}},{{0xF5L},{0xE0L},{0x80L},{0L}},{{0x0AL},{0x80L},{-10L},{0x02L}},{{0L},{0x0AL},{0x0BL},{0x0AL}},{{0x47L},{0xDDL},{0x50L},{0x95L}},{{-1L},{-7L},{0xE0L},{5L}},{{0x8CL},{0L},{0x49L},{0x0BL}},{{0x8CL},{3L},{0xE0L},{1L}},{{-1L},{0x0BL},{0x50L},{1L}},{{0x47L},{0L},{0x0BL},{0xF7L}}},{{{0L},{-1L},{-10L},{0x40L}},{{0x0AL},{-1L},{0x80L},{0x50L}},{{0xF5L},{-10L},{0xFEL},{-1L}},{{0L},{-9L},{-1L},{-1L}},{{0xA4L},{0x49L},{-6L},{1L}},{{0xFEL},{-1L},{-1L},{0x82L}},{{0xF7L},{-1L},{0x0BL},{0x80L}},{{0x0AL},{0L},{0x8CL},{0x95L}},{{0L},{1L},{0xF7L},{0x80L}},{{1L},{0x34L},{0xDDL},{0x82L}}},{{{0x93L},{1L},{1L},{0x93L}},{{0x2FL},{0x6AL},{0xE0L},{-10L}},{{-10L},{0x8CL},{1L},{-1L}},{{0xDDL},{1L},{0x4BL},{-1L}},{{0x34L},{0x8CL},{-1L},{-10L}},{{1L},{0x6AL},{0x80L},{0x93L}},{{1L},{1L},{-7L},{0x82L}},{{0x33L},{0x34L},{-10L},{0x80L}},{{0xE0L},{1L},{0x4BL},{0x95L}},{{1L},{0L},{0x47L},{0x80L}}},{{{0x02L},{0xDDL},{0x2FL},{1L}},{{-1L},{0x58L},{0L},{1L}},{{1L},{5L},{-1L},{0L}},{{-10L},{-1L},{0xFEL},{0x33L}},{{0x58L},{0x2FL},{0x02L},{0L}},{{-10L},{-10L},{-1L},{-1L}},{{0L},{0x4BL},{0L},{0x8CL}},{{0x49L},{0x80L},{0x49L},{0x4BL}},{{0x82L},{0xF7L},{-1L},{0x86L}},{{0x4BL},{-1L},{0xF5L},{0xF7L}}},{{{0xC5L},{0x0AL},{0xF5L},{-1L}},{{0x4BL},{-9L},{-1L},{0x88L}},{{0x82L},{0x93L},{0x49L},{0x40L}},{{0x49L},{0x40L},{0L},{0xE0L}},{{0L},{0xFBL},{-1L},{0L}},{{-10L},{1L},{0x02L},{0xA4L}},{{0x58L},{-4L},{0xFEL},{0L}},{{-10L},{0x80L},{-1L},{-10L}},{{1L},{-10L},{0L},{1L}},{{-1L},{0xFEL},{0x2FL},{1L}}},{{{0x02L},{0x86L},{0x47L},{0xFBL}},{{1L},{0x0BL},{0x4BL},{0xC5L}},{{0xE0L},{0x49L},{-10L},{-1L}},{{0x33L},{0x4BL},{-7L},{-7L}},{{1L},{1L},{0x80L},{0x47L}},{{1L},{-1L},{-1L},{0x6AL}},{{0x34L},{-10L},{0x4BL},{-1L}},{{0xDDL},{-10L},{1L},{0x6AL}},{{-10L},{-1L},{0xE0L},{0x47L}},{{0x2FL},{1L},{1L},{-7L}}}};
static int16_t g_765 = 0xE1DCL;
static int16_t *g_783 = &g_765;
static int16_t **g_782 = &g_783;
static int16_t *** volatile g_781[1] = {&g_782};
static int16_t *** volatile g_784 = &g_782;/* VOLATILE GLOBAL g_784 */
static const union U1 *g_795 = &g_363;
static const union U1 **g_794 = &g_795;
static const union U1 ***g_793[3][2] = {{&g_794,&g_794},{&g_794,&g_794},{&g_794,&g_794}};
static int32_t *g_804 = &g_86[3];
static int32_t ** volatile g_808 = &g_804;/* VOLATILE GLOBAL g_808 */
static const uint64_t g_818 = 0x68A132CB696002A4LL;
static volatile union U2 g_834[4] = {{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL},{18446744073709551615UL}};
static uint64_t * volatile g_843 = &g_154;/* VOLATILE GLOBAL g_843 */
static uint64_t * volatile *g_842 = &g_843;
static union U2 g_867 = {0x9CDEA494L};/* VOLATILE GLOBAL g_867 */
static uint32_t * const g_887[7][5][5] = {{{&g_613,(void*)0,(void*)0,(void*)0,&g_613},{&g_613,&g_613,&g_613,(void*)0,(void*)0},{&g_613,&g_613,&g_613,&g_613,(void*)0},{&g_613,&g_613,&g_613,&g_613,&g_613},{&g_613,&g_613,&g_613,&g_613,&g_613}},{{(void*)0,&g_613,&g_613,&g_613,&g_613},{&g_613,&g_613,&g_613,(void*)0,(void*)0},{&g_613,&g_613,&g_613,(void*)0,&g_613},{&g_613,&g_613,&g_613,(void*)0,&g_613},{&g_613,&g_613,&g_613,&g_613,(void*)0}},{{(void*)0,(void*)0,&g_613,&g_613,&g_613},{&g_613,&g_613,&g_613,(void*)0,(void*)0},{&g_613,&g_613,&g_613,&g_613,(void*)0},{&g_613,&g_613,&g_613,&g_613,&g_613},{&g_613,&g_613,&g_613,&g_613,&g_613}},{{(void*)0,&g_613,&g_613,&g_613,&g_613},{&g_613,&g_613,&g_613,(void*)0,(void*)0},{&g_613,&g_613,&g_613,(void*)0,&g_613},{&g_613,&g_613,&g_613,(void*)0,&g_613},{&g_613,&g_613,&g_613,&g_613,(void*)0}},{{(void*)0,(void*)0,&g_613,&g_613,&g_613},{&g_613,&g_613,&g_613,(void*)0,(void*)0},{&g_613,&g_613,&g_613,&g_613,(void*)0},{&g_613,&g_613,&g_613,&g_613,&g_613},{&g_613,&g_613,&g_613,&g_613,&g_613}},{{(void*)0,&g_613,&g_613,&g_613,&g_613},{&g_613,&g_613,&g_613,(void*)0,(void*)0},{&g_613,&g_613,&g_613,(void*)0,&g_613},{&g_613,&g_613,&g_613,(void*)0,&g_613},{&g_613,&g_613,&g_613,&g_613,(void*)0}},{{(void*)0,(void*)0,&g_613,&g_613,&g_613},{&g_613,&g_613,&g_613,(void*)0,(void*)0},{&g_613,&g_613,&g_613,&g_613,(void*)0},{&g_613,&g_613,&g_613,&g_613,&g_613},{&g_613,&g_613,&g_613,&g_613,&g_613}}};
static uint32_t * const * volatile g_886 = &g_887[1][3][4];/* VOLATILE GLOBAL g_886 */
static union U2 g_910 = {0x48752DE2L};/* VOLATILE GLOBAL g_910 */
static uint32_t *** volatile g_964 = (void*)0;/* VOLATILE GLOBAL g_964 */
static union U1 g_991 = {0x7BL};/* VOLATILE GLOBAL g_991 */
static int32_t ** volatile g_994 = (void*)0;/* VOLATILE GLOBAL g_994 */
static int32_t ** volatile g_1003 = &g_94;/* VOLATILE GLOBAL g_1003 */
static volatile union U2 g_1029 = {8UL};/* VOLATILE GLOBAL g_1029 */
static int32_t ** volatile g_1045 = &g_94;/* VOLATILE GLOBAL g_1045 */
static volatile uint32_t g_1067 = 0x1C627A97L;/* VOLATILE GLOBAL g_1067 */
static volatile uint32_t *g_1066 = &g_1067;
static volatile uint32_t * volatile *g_1065 = &g_1066;
static volatile uint32_t * volatile **g_1064[7][10] = {{&g_1065,&g_1065,&g_1065,&g_1065,(void*)0,&g_1065,&g_1065,(void*)0,&g_1065,&g_1065},{(void*)0,&g_1065,&g_1065,(void*)0,(void*)0,&g_1065,&g_1065,(void*)0,&g_1065,(void*)0},{(void*)0,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,(void*)0,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065},{&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065,&g_1065}};
static int8_t *g_1124 = &g_10;
static int8_t **g_1123 = &g_1124;
static int8_t *** const  volatile g_1122 = &g_1123;/* VOLATILE GLOBAL g_1122 */
static union U1 ****g_1127[6] = {&g_633,&g_633,(void*)0,&g_633,&g_633,(void*)0};
static uint32_t ***g_1145[2] = {(void*)0,(void*)0};
static const union U0 ***g_1157 = (void*)0;
static uint8_t *g_1181 = &g_199[3][0][8];
static volatile union U2 g_1193 = {0x4F4DFE11L};/* VOLATILE GLOBAL g_1193 */
static uint32_t g_1237 = 18446744073709551608UL;
static int32_t ** volatile g_1248 = &g_94;/* VOLATILE GLOBAL g_1248 */
static union U0 g_1255 = {0xE8D0272EL};/* VOLATILE GLOBAL g_1255 */
static volatile union U2 g_1261 = {1UL};/* VOLATILE GLOBAL g_1261 */
static volatile union U2 g_1272[6][7] = {{{0x72B83284L},{4UL},{0x8D177526L},{4UL},{0x72B83284L},{0UL},{0UL}},{{18446744073709551615UL},{18446744073709551606UL},{0UL},{18446744073709551606UL},{18446744073709551615UL},{0x32ED89A5L},{0x32ED89A5L}},{{0x72B83284L},{4UL},{0x8D177526L},{4UL},{0x72B83284L},{0UL},{0UL}},{{18446744073709551615UL},{18446744073709551606UL},{0UL},{18446744073709551606UL},{18446744073709551615UL},{0x32ED89A5L},{0x32ED89A5L}},{{0x72B83284L},{4UL},{0x8D177526L},{4UL},{0x72B83284L},{0UL},{0UL}},{{18446744073709551615UL},{18446744073709551606UL},{0UL},{18446744073709551606UL},{18446744073709551615UL},{0x32ED89A5L},{0x32ED89A5L}}};
static int32_t g_1320 = 0L;
static uint8_t g_1378[7][9][4] = {{{0xD9L,0xA8L,0xFAL,0xA8L},{0xB9L,0x1CL,4UL,0xFAL},{0xA8L,0x1CL,0x1CL,0xA8L},{0x1CL,0xA8L,0xB9L,0xD9L},{0x1CL,0xB9L,0x1CL,4UL},{0xA8L,0xD9L,4UL,4UL},{0xB9L,0xB9L,0xFAL,0xD9L},{0xD9L,0xA8L,0xFAL,0xA8L},{0xB9L,0x1CL,4UL,0xFAL}},{{0xA8L,0x1CL,0x1CL,0xA8L},{0x1CL,0xA8L,0xB9L,0xD9L},{0x1CL,0xB9L,0x1CL,4UL},{0xA8L,0xD9L,4UL,4UL},{0xB9L,0xB9L,0xFAL,0xD9L},{0xD9L,0xA8L,0xFAL,0xA8L},{0xB9L,0x1CL,4UL,0xFAL},{0xA8L,0x1CL,0x1CL,0xA8L},{0x1CL,0xA8L,0xB9L,0xD9L}},{{0x1CL,0xB9L,0x1CL,4UL},{0xA8L,0xD9L,4UL,4UL},{0xB9L,0xB9L,0xFAL,0xD9L},{0xD9L,0xA8L,0xFAL,0xA8L},{0xB9L,0x1CL,4UL,0xFAL},{0x1CL,0xD9L,0xD9L,0x1CL},{0xD9L,0x1CL,0x7FL,4UL},{0xD9L,0x7FL,0xD9L,0xFAL},{0x1CL,4UL,0xFAL,0xFAL}},{{0x7FL,0x7FL,0xB9L,4UL},{4UL,0x1CL,0xB9L,0x1CL},{0x7FL,0xD9L,0xFAL,0xB9L},{0x1CL,0xD9L,0xD9L,0x1CL},{0xD9L,0x1CL,0x7FL,4UL},{0xD9L,0x7FL,0xD9L,0xFAL},{0x1CL,4UL,0xFAL,0xFAL},{0x7FL,0x7FL,0xB9L,4UL},{4UL,0x1CL,0xB9L,0x1CL}},{{0x7FL,0xD9L,0xFAL,0xB9L},{0x1CL,0xD9L,0xD9L,0x1CL},{0xD9L,0x1CL,0x7FL,4UL},{0xD9L,0x7FL,0xD9L,0xFAL},{0x1CL,4UL,0xFAL,0xFAL},{0x7FL,0x7FL,0xB9L,4UL},{4UL,0x1CL,0xB9L,0x1CL},{0x7FL,0xD9L,0xFAL,0xB9L},{0x1CL,0xD9L,0xD9L,0x1CL}},{{0xD9L,0x1CL,0x7FL,4UL},{0xD9L,0x7FL,0xD9L,0xFAL},{0x1CL,4UL,0xFAL,0xFAL},{0x7FL,0x7FL,0xB9L,4UL},{4UL,0x1CL,0xB9L,0x1CL},{0x7FL,0xD9L,0xFAL,0xB9L},{0x1CL,0xD9L,0xD9L,0x1CL},{0xD9L,0x1CL,0x7FL,4UL},{0xD9L,0x7FL,0xD9L,0xFAL}},{{0x1CL,4UL,0xFAL,0xFAL},{0x7FL,0x7FL,0xB9L,4UL},{4UL,0x1CL,0xB9L,0x1CL},{0x7FL,0xD9L,0xFAL,0xB9L},{0x1CL,0xD9L,0xD9L,0x1CL},{0xD9L,0x1CL,0x7FL,4UL},{0xD9L,0x7FL,0xD9L,0xFAL},{0x1CL,4UL,0xFAL,0xFAL},{0x7FL,0x7FL,0xB9L,4UL}}};
static volatile union U0 g_1398 = {0x2066B00BL};/* VOLATILE GLOBAL g_1398 */
static union U1 g_1409 = {0L};/* VOLATILE GLOBAL g_1409 */
static int8_t **g_1436 = &g_1124;
static const union U2 g_1437[8] = {{18446744073709551612UL},{18446744073709551612UL},{18446744073709551612UL},{18446744073709551612UL},{18446744073709551612UL},{18446744073709551612UL},{18446744073709551612UL},{18446744073709551612UL}};
static volatile uint32_t g_1443 = 4294967295UL;/* VOLATILE GLOBAL g_1443 */
static union U1 g_1497 = {0xD4L};/* VOLATILE GLOBAL g_1497 */
static uint8_t * const *g_1550 = (void*)0;
static uint8_t * const **g_1549[9][6][4] = {{{(void*)0,(void*)0,&g_1550,&g_1550},{(void*)0,(void*)0,&g_1550,(void*)0},{&g_1550,&g_1550,&g_1550,&g_1550},{&g_1550,&g_1550,&g_1550,(void*)0},{&g_1550,(void*)0,(void*)0,&g_1550},{&g_1550,(void*)0,(void*)0,(void*)0}},{{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1550},{(void*)0,&g_1550,(void*)0,&g_1550},{(void*)0,(void*)0,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,(void*)0}},{{&g_1550,&g_1550,(void*)0,&g_1550},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1550},{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,&g_1550,&g_1550,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_1550},{(void*)0,&g_1550,(void*)0,&g_1550},{(void*)0,(void*)0,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,&g_1550}},{{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1550},{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1550}},{{(void*)0,&g_1550,(void*)0,&g_1550},{(void*)0,(void*)0,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,&g_1550},{(void*)0,(void*)0,(void*)0,(void*)0}},{{(void*)0,(void*)0,(void*)0,&g_1550},{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1550},{(void*)0,&g_1550,(void*)0,&g_1550}},{{(void*)0,(void*)0,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,(void*)0},{&g_1550,&g_1550,(void*)0,&g_1550},{(void*)0,(void*)0,(void*)0,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1550}},{{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,&g_1550,&g_1550,(void*)0},{(void*)0,(void*)0,(void*)0,&g_1550},{(void*)0,&g_1550,(void*)0,&g_1550},{(void*)0,(void*)0,&g_1550,&g_1550}}};
static uint8_t * const *** volatile g_1548 = &g_1549[5][2][3];/* VOLATILE GLOBAL g_1548 */
static volatile union U0 g_1576 = {18446744073709551615UL};/* VOLATILE GLOBAL g_1576 */
static int8_t g_1604 = 0x07L;
static int64_t g_1635[3][4][6] = {{{(-4L),(-10L),0x81E5DF400AD4BDA8LL,0x81E5DF400AD4BDA8LL,(-10L),(-4L)},{0x81E5DF400AD4BDA8LL,(-10L),(-4L),0x2AA1D7486BCDD598LL,0L,0x0C8841235B71CD50LL},{0x0C8841235B71CD50LL,1L,0L,1L,0x0C8841235B71CD50LL,(-10L)},{0x0C8841235B71CD50LL,0x81E5DF400AD4BDA8LL,1L,0x2AA1D7486BCDD598LL,0x523B6C5023708B8BLL,0x523B6C5023708B8BLL}},{{0x81E5DF400AD4BDA8LL,0L,0L,0x81E5DF400AD4BDA8LL,0L,0x523B6C5023708B8BLL},{(-4L),0x523B6C5023708B8BLL,1L,(-10L),0x2AA1D7486BCDD598LL,(-10L)},{0L,0xEF988468233BF1BBLL,0L,0xB5DEE0744A39E833LL,0x2AA1D7486BCDD598LL,0x0C8841235B71CD50LL},{1L,0x523B6C5023708B8BLL,(-4L),0L,0L,(-4L)}},{{0L,0L,0x81E5DF400AD4BDA8LL,0L,0x523B6C5023708B8BLL,0xB5DEE0744A39E833LL},{1L,0x81E5DF400AD4BDA8LL,0x0C8841235B71CD50LL,0xB5DEE0744A39E833LL,0x0C8841235B71CD50LL,0x81E5DF400AD4BDA8LL},{0L,1L,0x0C8841235B71CD50LL,(-10L),0L,0xB5DEE0744A39E833LL},{(-4L),(-10L),0x81E5DF400AD4BDA8LL,0x81E5DF400AD4BDA8LL,(-10L),(-4L)}}};
static uint64_t g_1653[2] = {18446744073709551611UL,18446744073709551611UL};
static volatile union U0 g_1698 = {1UL};/* VOLATILE GLOBAL g_1698 */
static union U0 g_1783 = {18446744073709551606UL};/* VOLATILE GLOBAL g_1783 */
static union U2 g_1784 = {0xDCF62163L};/* VOLATILE GLOBAL g_1784 */
static union U0 g_1839 = {5UL};/* VOLATILE GLOBAL g_1839 */
static uint32_t g_1848[8] = {18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL,18446744073709551615UL};
static union U2 g_1850 = {0x7B77BFC6L};/* VOLATILE GLOBAL g_1850 */
static union U2 *g_1854 = (void*)0;
static union U2 ** volatile g_1853[1] = {&g_1854};
static union U2 ** volatile g_1855 = &g_1854;/* VOLATILE GLOBAL g_1855 */
static union U2 g_1887[5] = {{0xE0FAB42AL},{0xE0FAB42AL},{0xE0FAB42AL},{0xE0FAB42AL},{0xE0FAB42AL}};
static const union U2 g_1940 = {18446744073709551611UL};/* VOLATILE GLOBAL g_1940 */
static volatile union U2 g_1966 = {7UL};/* VOLATILE GLOBAL g_1966 */
static uint32_t *g_1997 = &g_613;
static uint32_t **g_1996[6] = {&g_1997,&g_1997,&g_1997,&g_1997,&g_1997,&g_1997};
static volatile union U2 g_2020[9][3] = {{{0x0D630376L},{1UL},{1UL}},{{18446744073709551607UL},{0xBBDA010BL},{18446744073709551607UL}},{{0x0D630376L},{0x0D630376L},{1UL}},{{18446744073709551613UL},{0xBBDA010BL},{18446744073709551613UL}},{{0x0D630376L},{1UL},{1UL}},{{18446744073709551607UL},{0xBBDA010BL},{18446744073709551607UL}},{{0x0D630376L},{0x0D630376L},{1UL}},{{18446744073709551613UL},{0xBBDA010BL},{18446744073709551613UL}},{{0x0D630376L},{1UL},{1UL}}};
static int32_t g_2115 = 0x43BB3191L;
static const union U2 g_2127[4] = {{0x5AAA7A68L},{0x5AAA7A68L},{0x5AAA7A68L},{0x5AAA7A68L}};
static volatile union U1 g_2128 = {0x4BL};/* VOLATILE GLOBAL g_2128 */
static volatile union U1 g_2142 = {-10L};/* VOLATILE GLOBAL g_2142 */
static union U1 g_2172 = {0xFAL};/* VOLATILE GLOBAL g_2172 */
static int16_t g_2200 = (-6L);
static uint32_t *g_2236 = &g_1848[5];
static uint32_t ** volatile g_2235[3][2] = {{&g_2236,&g_2236},{&g_2236,&g_2236},{&g_2236,&g_2236}};
static uint32_t ** volatile * const  volatile g_2234 = &g_2235[0][1];/* VOLATILE GLOBAL g_2234 */
static uint32_t ** volatile * const  volatile *g_2233[1][2] = {{&g_2234,&g_2234}};
static uint32_t ** volatile * const  volatile **g_2232 = &g_2233[0][1];
static union U2 ** volatile g_2247 = &g_1854;/* VOLATILE GLOBAL g_2247 */
static int32_t ** volatile g_2249 = &g_94;/* VOLATILE GLOBAL g_2249 */
static const uint32_t *g_2253 = &g_1940.f0;
static const uint32_t **g_2252 = &g_2253;
static union U2 g_2258 = {0xBC5021C3L};/* VOLATILE GLOBAL g_2258 */
static union U0 g_2273[8] = {{18446744073709551608UL},{18446744073709551608UL},{18446744073709551608UL},{18446744073709551608UL},{18446744073709551608UL},{18446744073709551608UL},{18446744073709551608UL},{18446744073709551608UL}};
static const int8_t g_2279 = 4L;
static int32_t **g_2330[7] = {&g_804,&g_94,&g_94,&g_804,&g_94,&g_94,&g_804};
static int32_t ***g_2329 = &g_2330[6];
static int32_t ****g_2328 = &g_2329;
static int32_t ***** volatile g_2327[3] = {&g_2328,&g_2328,&g_2328};
static int32_t g_2333 = 0xC324F1CCL;
static volatile union U1 g_2347[3][10][7] = {{{{0x50L},{1L},{-1L},{-1L},{1L},{0x50L},{0x95L}},{{1L},{0L},{0x0CL},{0x10L},{0x10L},{0x0CL},{0L}},{{1L},{0x95L},{0x50L},{1L},{-1L},{-1L},{1L}},{{0xBEL},{0L},{0xBEL},{0x3DL},{0L},{0x60L},{0x60L}},{{0L},{1L},{-10L},{1L},{0L},{-10L},{-1L}},{{0x10L},{0x60L},{0x3BL},{0xBEL},{0x3BL},{0x0CL},{0xBEL}},{{0x65L},{0x50L},{-10L},{0x13L},{0x50L},{0x13L},{-10L}},{{0xBEL},{0xBEL},{0x10L},{0x60L},{0x3DL},{0x10L},{0x3DL}},{{0x95L},{-10L},{-10L},{0x95L},{0x13L},{0x65L},{0x95L}},{{0x68L},{0x3DL},{0x3BL},{0x3BL},{0x3DL},{0x68L},{0x0CL}}},{{{-1L},{0x95L},{-1L},{0x50L},{0x50L},{-1L},{0x95L}},{{0x3DL},{0x0CL},{0x68L},{0x3DL},{0x3BL},{0x3BL},{0x3DL}},{{0x65L},{0x95L},{0x65L},{0x13L},{0x95L},{-10L},{-10L}},{{0x60L},{0x3DL},{0x10L},{0x3DL},{0x60L},{0x10L},{0xBEL}},{{0x50L},{-10L},{0x13L},{0x50L},{0x13L},{-10L},{0x50L}},{{0x68L},{0xBEL},{0x0CL},{0x3BL},{0xBEL},{0x3BL},{0x0CL}},{{0x50L},{0x50L},{-1L},{0x95L},{-1L},{-1L},{-1L}},{{0x60L},{0x0CL},{0x0CL},{0x60L},{0x3BL},{0x68L},{0x60L}},{{0x65L},{-1L},{0x13L},{0x13L},{-1L},{0x65L},{-10L}},{{0x3DL},{0x60L},{0x10L},{0xBEL},{0xBEL},{0x10L},{0x60L}}},{{{-1L},{-10L},{0x65L},{-1L},{0x13L},{0x13L},{-1L}},{{0x68L},{0x60L},{0x68L},{0x3BL},{0x60L},{0x0CL},{0x0CL}},{{0x95L},{-1L},{-1L},{-1L},{0x95L},{-1L},{0x50L}},{{0xBEL},{0x0CL},{0x3BL},{0xBEL},{0x3BL},{0x0CL},{0xBEL}},{{0x65L},{0x50L},{-10L},{0x13L},{0x50L},{0x13L},{-10L}},{{0xBEL},{0xBEL},{0x10L},{0x60L},{0x3DL},{0x10L},{0x3DL}},{{0x95L},{-10L},{-10L},{0x95L},{0x13L},{0x65L},{0x95L}},{{0x68L},{0x3DL},{0x3BL},{0x3BL},{0x3DL},{0x68L},{0x0CL}},{{-1L},{0x95L},{-1L},{0x50L},{0x50L},{-1L},{0x95L}},{{0x3DL},{0x0CL},{0x68L},{0x3DL},{0x3BL},{0x3BL},{0x3DL}}}};
static int64_t *****g_2359 = (void*)0;
static int16_t ***g_2387 = (void*)0;
static int16_t ****g_2386 = &g_2387;
static uint32_t g_2392 = 0UL;
static union U1 g_2447 = {0xD0L};/* VOLATILE GLOBAL g_2447 */
static union U1 g_2473 = {0x00L};/* VOLATILE GLOBAL g_2473 */
static uint32_t ***g_2481[8][4] = {{&g_1996[3],(void*)0,&g_1996[3],(void*)0},{&g_1996[3],(void*)0,&g_1996[3],(void*)0},{&g_1996[3],(void*)0,&g_1996[3],(void*)0},{&g_1996[3],(void*)0,&g_1996[3],(void*)0},{&g_1996[3],(void*)0,&g_1996[3],(void*)0},{&g_1996[3],(void*)0,&g_1996[3],(void*)0},{&g_1996[3],(void*)0,&g_1996[3],(void*)0},{&g_1996[3],(void*)0,&g_1996[3],(void*)0}};
static uint32_t ****g_2480 = &g_2481[7][1];
static union U1 g_2514 = {0L};/* VOLATILE GLOBAL g_2514 */
static volatile union U0 g_2595[7] = {{0x1109C8A9L},{0x1109C8A9L},{0x1109C8A9L},{0x1109C8A9L},{0x1109C8A9L},{0x1109C8A9L},{0x1109C8A9L}};
static union U2 g_2601 = {0x69470128L};/* VOLATILE GLOBAL g_2601 */
static volatile uint32_t g_2618 = 18446744073709551615UL;/* VOLATILE GLOBAL g_2618 */
static volatile union U0 g_2627 = {0xF8677968L};/* VOLATILE GLOBAL g_2627 */
static volatile union U2 g_2710 = {0x301268F1L};/* VOLATILE GLOBAL g_2710 */
static const union U1 g_2738 = {0xEBL};/* VOLATILE GLOBAL g_2738 */
static volatile union U1 g_2799 = {1L};/* VOLATILE GLOBAL g_2799 */
static union U1 g_2845 = {-1L};/* VOLATILE GLOBAL g_2845 */
static union U1 g_2878 = {7L};/* VOLATILE GLOBAL g_2878 */
static volatile union U2 g_2893 = {18446744073709551615UL};/* VOLATILE GLOBAL g_2893 */
static volatile int32_t *g_2895 = (void*)0;
static volatile int32_t **g_2894 = &g_2895;
static int8_t ***g_2911 = &g_1123;
static int8_t ****g_2910 = &g_2911;
static int8_t ***** volatile g_2909 = &g_2910;/* VOLATILE GLOBAL g_2909 */
static volatile union U2 g_2975 = {0x6D759138L};/* VOLATILE GLOBAL g_2975 */
static const volatile int64_t **g_3050 = (void*)0;
static union U1 g_3067 = {0xAAL};/* VOLATILE GLOBAL g_3067 */
static const volatile uint32_t * volatile g_3071 = (void*)0;/* VOLATILE GLOBAL g_3071 */
static int32_t * volatile g_3107[9][4][7] = {{{&g_86[5],&g_95,&g_88,&g_86[3],&g_86[3],&g_86[3],&g_88},{&g_88,&g_88,&g_88,&g_88,&g_95,&g_95,(void*)0},{&g_88,&g_90,(void*)0,&g_95,(void*)0,&g_88,&g_86[9]},{(void*)0,&g_90,&g_95,&g_86[4],&g_95,(void*)0,&g_86[5]}},{{&g_90,&g_90,&g_88,&g_88,&g_86[3],(void*)0,&g_88},{(void*)0,&g_95,&g_95,&g_88,(void*)0,&g_88,&g_90},{&g_95,&g_90,&g_86[4],(void*)0,&g_86[3],(void*)0,&g_88},{&g_95,&g_88,(void*)0,(void*)0,&g_88,&g_86[3],&g_88}},{{&g_88,&g_86[5],&g_95,&g_86[3],&g_86[3],&g_86[3],&g_95},{&g_86[4],&g_95,&g_95,&g_86[4],&g_86[3],(void*)0,&g_86[3]},{(void*)0,&g_88,(void*)0,&g_95,&g_90,&g_88,(void*)0},{&g_88,&g_95,&g_86[4],&g_95,&g_86[5],&g_86[3],&g_86[3]}},{{&g_88,&g_86[9],&g_95,&g_86[3],&g_90,&g_86[3],&g_86[3]},{&g_86[7],&g_88,&g_88,&g_88,&g_86[7],&g_90,&g_88},{&g_95,&g_95,&g_95,&g_95,&g_86[4],&g_88,&g_95},{&g_88,&g_86[7],(void*)0,&g_95,&g_95,&g_86[5],&g_86[4]}},{{&g_95,&g_95,&g_88,&g_95,(void*)0,&g_86[9],&g_88},{&g_86[7],&g_88,&g_88,&g_86[3],&g_88,(void*)0,&g_88},{&g_88,&g_95,(void*)0,(void*)0,&g_95,&g_86[4],(void*)0},{&g_88,&g_90,&g_95,&g_86[9],&g_90,&g_88,(void*)0}},{{(void*)0,&g_88,&g_86[3],&g_88,(void*)0,&g_88,&g_86[3]},{&g_86[4],(void*)0,&g_90,&g_88,&g_90,&g_88,&g_86[4]},{&g_88,&g_95,&g_90,&g_90,&g_88,&g_88,&g_95},{&g_95,(void*)0,(void*)0,&g_95,&g_88,&g_86[4],&g_95}},{{&g_95,(void*)0,&g_95,(void*)0,&g_86[3],&g_90,&g_86[3]},{&g_88,&g_88,&g_90,&g_95,&g_95,&g_90,&g_88},{&g_95,&g_90,&g_95,(void*)0,&g_86[3],&g_86[3],&g_95},{(void*)0,(void*)0,&g_86[3],&g_95,&g_86[3],&g_90,&g_88}},{{&g_88,&g_90,&g_88,(void*)0,&g_95,&g_88,&g_90},{&g_86[4],&g_88,&g_86[4],&g_95,(void*)0,&g_90,&g_86[3]},{&g_86[3],&g_86[4],(void*)0,(void*)0,&g_88,&g_86[3],(void*)0},{&g_88,&g_88,&g_86[3],&g_95,(void*)0,&g_88,&g_95}},{{(void*)0,(void*)0,&g_95,&g_86[3],&g_86[3],&g_90,&g_86[4]},{&g_90,&g_88,&g_95,&g_95,(void*)0,(void*)0,&g_95},{&g_88,&g_88,&g_95,&g_86[4],&g_95,&g_90,&g_86[3]},{(void*)0,(void*)0,&g_86[9],&g_95,&g_86[4],(void*)0,&g_95}}};
static int32_t * volatile g_3108 = &g_88;/* VOLATILE GLOBAL g_3108 */
static const union U0 ** volatile *g_3143 = &g_181;
static const union U0 ** volatile ** volatile g_3142[9] = {&g_3143,&g_3143,&g_3143,&g_3143,&g_3143,&g_3143,&g_3143,&g_3143,&g_3143};
static uint64_t *g_3194 = &g_1653[0];
static uint64_t **g_3193[3][8] = {{&g_3194,&g_3194,&g_3194,&g_3194,&g_3194,&g_3194,&g_3194,&g_3194},{&g_3194,&g_3194,&g_3194,&g_3194,&g_3194,&g_3194,&g_3194,&g_3194},{(void*)0,&g_3194,&g_3194,&g_3194,(void*)0,(void*)0,&g_3194,&g_3194}};
static uint8_t ***g_3212 = (void*)0;
static uint8_t ****g_3211 = &g_3212;
static const union U0 g_3221 = {1UL};/* VOLATILE GLOBAL g_3221 */
static volatile union U0 g_3222 = {0x96DCC6A6L};/* VOLATILE GLOBAL g_3222 */
static volatile union U2 g_3247 = {0x19EFD49FL};/* VOLATILE GLOBAL g_3247 */
static union U1 g_3290 = {-3L};/* VOLATILE GLOBAL g_3290 */
static union U2 g_3295 = {0xAEA13C7BL};/* VOLATILE GLOBAL g_3295 */
static union U1 g_3308[2] = {{0xABL},{0xABL}};
static uint8_t g_3350 = 255UL;
static volatile union U1 g_3373 = {0L};/* VOLATILE GLOBAL g_3373 */
static const volatile union U2 g_3418 = {0xED1972BDL};/* VOLATILE GLOBAL g_3418 */
static uint8_t *g_3518 = (void*)0;
static uint8_t *g_3519 = &g_1378[2][7][2];
static uint8_t *g_3520 = &g_199[1][0][6];
static uint8_t *g_3521 = &g_1378[1][0][1];
static uint8_t *g_3522 = (void*)0;
static uint8_t ** const g_3517[8][7][1] = {{{&g_3520},{&g_3519},{&g_3520},{&g_3518},{&g_3522},{&g_3518},{&g_3520}},{{&g_3519},{&g_3520},{&g_3518},{&g_3522},{&g_3518},{&g_3520},{&g_3519}},{{&g_3520},{&g_3518},{&g_3522},{&g_3518},{&g_3520},{&g_3519},{&g_3520}},{{&g_3518},{&g_3522},{&g_3518},{&g_3520},{&g_3519},{&g_3520},{&g_3518}},{{&g_3522},{&g_3518},{&g_3520},{&g_3519},{&g_3520},{&g_3518},{&g_3522}},{{&g_3518},{&g_3520},{&g_3519},{&g_3520},{&g_3518},{&g_3522},{&g_3518}},{{&g_3520},{&g_3519},{&g_3520},{&g_3518},{&g_3522},{&g_3518},{&g_3520}},{{&g_3519},{&g_3520},{&g_3518},{&g_3522},{&g_3518},{&g_3520},{&g_3519}}};
static uint8_t ** const *g_3516 = &g_3517[6][0][0];
static uint8_t ** const **g_3515 = &g_3516;
static const volatile union U1 g_3575 = {0x08L};/* VOLATILE GLOBAL g_3575 */
static volatile union U0 g_3576 = {18446744073709551608UL};/* VOLATILE GLOBAL g_3576 */
static const int32_t ****g_3619 = (void*)0;
static const int32_t g_3626 = 0xD2963135L;
static const int32_t *g_3627 = &g_88;
static const union U2 *g_3629 = &g_1887[1];
static const union U2 ** const  volatile g_3628[3][8][7] = {{{(void*)0,&g_3629,(void*)0,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{(void*)0,&g_3629,(void*)0,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{(void*)0,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{(void*)0,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629}},{{(void*)0,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{(void*)0,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{(void*)0,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{(void*)0,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629}},{{(void*)0,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{(void*)0,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{(void*)0,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{(void*)0,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629},{&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629,&g_3629}}};
static const union U2 *g_3631 = (void*)0;
static volatile union U0 g_3766 = {0UL};/* VOLATILE GLOBAL g_3766 */
static int16_t g_3768 = 2L;
static union U2 g_3775 = {0x4371795DL};/* VOLATILE GLOBAL g_3775 */
static union U0 **g_3786 = &g_311;
static union U0 ***g_3785 = &g_3786;
static union U0 ****g_3784[6] = {&g_3785,&g_3785,&g_3785,&g_3785,&g_3785,&g_3785};
static volatile union U2 g_3825[5][1][7] = {{{{0x0CCD5C63L},{0x71D2ED27L},{0x0CCD5C63L},{0x71D2ED27L},{0x0CCD5C63L},{0x71D2ED27L},{0x0CCD5C63L}}},{{{18446744073709551611UL},{18446744073709551611UL},{0x35CD649FL},{0x35CD649FL},{18446744073709551611UL},{18446744073709551611UL},{0x35CD649FL}}},{{{3UL},{0x71D2ED27L},{3UL},{0x71D2ED27L},{3UL},{0x71D2ED27L},{3UL}}},{{{18446744073709551611UL},{0x35CD649FL},{0x35CD649FL},{18446744073709551611UL},{18446744073709551611UL},{0x35CD649FL},{0x35CD649FL}}},{{{0x0CCD5C63L},{0x71D2ED27L},{0x0CCD5C63L},{0x71D2ED27L},{0x0CCD5C63L},{0x71D2ED27L},{0x0CCD5C63L}}}};
static volatile union U1 g_3847[6][9][4] = {{{{-1L},{-1L},{0L},{0xE7L}},{{0x7AL},{3L},{0xB6L},{0xD6L}},{{0x61L},{0L},{8L},{0xD6L}},{{0xC3L},{3L},{1L},{0xE7L}},{{1L},{-1L},{0L},{3L}},{{-7L},{0xE6L},{-1L},{0x61L}},{{0L},{0xF8L},{1L},{-1L}},{{0x70L},{0x7AL},{-1L},{0x7AL}},{{0x61L},{1L},{0xC3L},{-1L}}},{{{1L},{0xF8L},{0L},{8L}},{{3L},{-7L},{0xA1L},{3L}},{{3L},{-1L},{0L},{0x4CL}},{{1L},{3L},{0xC3L},{-9L}},{{0x61L},{0xA2L},{-1L},{0xD6L}},{{0x70L},{-1L},{1L},{0x4CL}},{{0L},{-1L},{-1L},{-1L}},{{-7L},{-7L},{0L},{0x61L}},{{1L},{0L},{1L},{-1L}}},{{{0xC3L},{0x7AL},{8L},{1L}},{{0x61L},{0x7AL},{0xB6L},{-1L}},{{0x7AL},{0L},{0L},{0x61L}},{{-1L},{-7L},{0xE6L},{-1L}},{{3L},{-1L},{0xC8L},{0x4CL}},{{0x7AL},{-1L},{0xC3L},{0xD6L}},{{8L},{0xA2L},{8L},{-9L}},{{0x70L},{3L},{0xC5L},{0x4CL}},{{1L},{-1L},{-1L},{3L}}},{{{0xE6L},{-7L},{-1L},{8L}},{{1L},{0xF8L},{0xC5L},{-1L}},{{0x70L},{1L},{8L},{0x7AL}},{{8L},{0x7AL},{0xC3L},{-1L}},{{0x7AL},{0xF8L},{0xC8L},{0x61L}},{{3L},{0xE6L},{0xE6L},{3L}},{{-1L},{-1L},{0L},{0xE7L}},{{0x7AL},{3L},{0xB6L},{0xD6L}},{{0x61L},{0L},{8L},{0xD6L}}},{{{0xC3L},{3L},{1L},{0xE7L}},{{1L},{-1L},{0L},{3L}},{{-7L},{0xE6L},{-1L},{0x61L}},{{0L},{0xF8L},{1L},{-1L}},{{0x70L},{0x7AL},{-1L},{0x7AL}},{{0x61L},{1L},{0xC3L},{-1L}},{{1L},{0xF8L},{0L},{8L}},{{3L},{-7L},{0xA1L},{3L}},{{3L},{-1L},{0L},{0x4CL}}},{{{1L},{3L},{0xC3L},{-9L}},{{0x61L},{0xA2L},{-1L},{0xD6L}},{{0x70L},{-1L},{8L},{0L}},{{-1L},{-1L},{0xA1L},{0xA1L}},{{-9L},{-9L},{-7L},{-1L}},{{8L},{0xB6L},{8L},{-1L}},{{0xC8L},{0L},{-7L},{8L}},{{-1L},{0L},{1L},{-1L}},{{0L},{0xB6L},{-1L},{-1L}}}};
static uint64_t g_3848 = 1UL;
static volatile union U0 g_3895 = {18446744073709551615UL};/* VOLATILE GLOBAL g_3895 */
static int16_t g_3923 = 0x9D4EL;
static int8_t ** volatile * volatile g_3969 = (void*)0;/* VOLATILE GLOBAL g_3969 */
static int8_t ** volatile * volatile * volatile g_3968 = &g_3969;/* VOLATILE GLOBAL g_3968 */
static int8_t ** volatile * volatile * volatile *g_3967 = &g_3968;
static union U2 g_3978 = {1UL};/* VOLATILE GLOBAL g_3978 */
static uint32_t g_3983 = 18446744073709551615UL;
static volatile union U1 g_3990[9][8][3] = {{{{-1L},{0L},{0L}},{{3L},{0x26L},{0x1CL}},{{9L},{0xD0L},{0x89L}},{{0xBAL},{3L},{0x1CL}},{{7L},{-9L},{0L}},{{0x5BL},{-5L},{-7L}},{{0x51L},{-5L},{0xF2L}},{{0x0EL},{0x67L},{0x06L}}},{{{-9L},{0x51L},{0xD3L}},{{0x4BL},{0xBAL},{0xC6L}},{{-1L},{-1L},{-1L}},{{0xC6L},{-5L},{6L}},{{-4L},{0xD0L},{0xD8L}},{{0xBBL},{0xC6L},{0L}},{{0x32L},{0x6CL},{0L}},{{-3L},{0xC6L},{3L}}},{{{-1L},{0xD0L},{1L}},{{0x0EL},{-5L},{-3L}},{{7L},{-1L},{0xDEL}},{{0xC9L},{0xBAL},{-7L}},{{0x89L},{0x51L},{0x93L}},{{-5L},{0x67L},{6L}},{{9L},{-5L},{9L}},{{0x4BL},{-5L},{1L}}},{{{0x32L},{-9L},{-1L}},{{0xA3L},{3L},{0x1CL}},{{0L},{0xD0L},{0xF2L}},{{0xA3L},{0x26L},{-8L}},{{0x32L},{0L},{0xDEL}},{{0x4BL},{0xBBL},{3L}},{{9L},{0x60L},{0x51L}},{{-5L},{-5L},{0x1CL}}},{{{0x89L},{0x36L},{0x0DL}},{{0xC9L},{-5L},{0L}},{{7L},{7L},{0x93L}},{{0x0EL},{-8L},{0x1CL}},{{-1L},{-5L},{0xD3L}},{{-3L},{0xA2L},{0xA3L}},{{0x32L},{-1L},{0xD3L}},{{0xBBL},{0x4BL},{0x1CL}}},{{{-4L},{0x60L},{0x93L}},{{0xC6L},{0x26L},{0L}},{{-1L},{8L},{0x0DL}},{{0x4BL},{0xC6L},{0x1CL}},{{-9L},{0x32L},{0x51L}},{{0x0EL},{3L},{3L}},{{0x51L},{0x36L},{0xDEL}},{{0x5BL},{0xA2L},{-8L}}},{{{7L},{0x51L},{0xF2L}},{{0xBAL},{0xC9L},{0x1CL}},{{9L},{0x51L},{-1L}},{{3L},{0xA2L},{1L}},{{-1L},{0x36L},{9L}},{{0xBBL},{3L},{6L}},{{0x6CL},{0x32L},{0x93L}},{{0L},{1L},{0xA3L}}},{{{9L},{5L},{-1L}},{{0xDFL},{0x4CL},{0xDFL}},{{0L},{9L},{0x6CL}},{{3L},{-8L},{0x5BL}},{{-1L},{-4L},{0xD8L}},{{0x06L},{0x4BL},{0x26L}},{{-1L},{6L},{1L}},{{3L},{0x06L},{0x5DL}}},{{{0L},{0L},{-4L}},{{0xDFL},{-3L},{1L}},{{9L},{0x6CL},{8L}},{{0L},{0xC9L},{0L}},{{0L},{9L},{-5L}},{{0xF9L},{0xF9L},{0xA3L}},{{0xD3L},{0x0DL},{0xD8L}},{{0x5BL},{0x4CL},{0x67L}}}};
static union U0 g_4013 = {1UL};/* VOLATILE GLOBAL g_4013 */
static union U2 g_4017 = {0x579DDE1DL};/* VOLATILE GLOBAL g_4017 */


/* --- FORWARD DECLARATIONS --- */
static union U2  func_1(void);
static int32_t * func_2(int64_t  p_3);
static uint16_t  func_13(uint32_t  p_14, int32_t * p_15, int64_t  p_16, int32_t * p_17, uint64_t  p_18);
static int32_t * func_19(uint32_t  p_20, int32_t * p_21, int8_t  p_22, int64_t  p_23, uint32_t  p_24);
static int32_t  func_27(uint32_t  p_28, const int8_t  p_29, uint32_t  p_30, int8_t  p_31, uint16_t  p_32);
static int16_t  func_36(uint32_t  p_37);
static int32_t * func_38(int8_t  p_39, int32_t * p_40, int8_t  p_41);
static union U0  func_42(int32_t * p_43, uint32_t  p_44, uint32_t  p_45, int32_t * p_46, int32_t * p_47);
static int32_t * func_48(uint32_t  p_49, int32_t  p_50, int32_t * p_51, uint16_t  p_52);
static int32_t * func_59(uint64_t  p_60);


/* --- FUNCTIONS --- */
/* ------------------------------------------ */
/* 
 * reads : g_4017
 * writes:
 */
static union U2  func_1(void)
{ /* block id: 0 */
    int32_t l_11 = 6L;
    int16_t l_12 = 3L;
    const int16_t l_33 = (-2L);
    uint32_t *l_2209 = &g_1850.f0;
    uint8_t l_3691 = 0xDBL;
    int32_t l_3699[4];
    uint64_t *l_3713 = &g_154;
    uint64_t **l_3746 = &g_3194;
    int32_t l_3774[1][1];
    uint16_t l_3853 = 0xF602L;
    int8_t l_3879 = 7L;
    uint32_t l_3952 = 0xE8BE8316L;
    int8_t l_3966 = 0x18L;
    int32_t *l_3971[10][9] = {{&g_88,&g_95,&l_3699[3],&g_86[5],&g_86[5],&l_3699[3],&g_95,&g_88,&g_86[0]},{&g_86[3],&g_90,(void*)0,&g_95,&l_3699[0],&l_3699[0],&g_95,(void*)0,&g_90},{&g_86[5],&g_88,&g_88,&g_86[0],(void*)0,&g_86[3],&g_86[3],(void*)0,&g_86[0]},{&g_86[1],&g_90,&g_86[1],&l_3774[0][0],&g_95,&g_86[3],&g_88,&g_88,&g_86[3]},{&g_88,&g_88,&g_86[5],&g_88,&g_88,&g_86[0],(void*)0,&g_86[3],&g_86[3]},{(void*)0,&g_90,&g_86[3],&l_3774[0][0],&g_86[3],&g_90,(void*)0,&g_95,&l_3699[0]},{&l_3699[3],&g_95,&g_88,&g_86[0],(void*)0,&g_86[0],&g_88,&g_95,&l_3699[3]},{&g_90,&g_86[7],&g_88,&g_95,&l_3774[0][0],&g_86[3],&l_3774[0][0],&g_95,&g_88},{(void*)0,(void*)0,&l_3699[3],&g_86[5],&g_95,&g_86[3],&l_3699[3],&g_86[3],&g_95},{&g_90,&l_3774[0][0],&l_3774[0][0],&g_90,&g_86[1],&l_3699[0],&l_3774[0][0],&g_88,&l_3774[0][0]}};
    int64_t l_4000 = 6L;
    int i, j;
    for (i = 0; i < 4; i++)
        l_3699[i] = 1L;
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 1; j++)
            l_3774[i][j] = (-1L);
    }
    return g_4017;
}


/* ------------------------------------------ */
/* 
 * reads : g_2115 g_782 g_783 g_765 g_1122 g_1123 g_1124 g_10 g_252.f2
 * writes: g_2115 g_252.f2
 */
static int32_t * func_2(int64_t  p_3)
{ /* block id: 1617 */
    uint32_t l_3634[3][10][5] = {{{0xE494DEFFL,0UL,0x262A1A58L,0x17578368L,0xAF96790CL},{0x19840658L,0xD2D302D6L,1UL,9UL,0UL},{0xEC816826L,0xAF96790CL,1UL,0UL,0xEC816826L},{0xE2B0905EL,0x8D611B1CL,0UL,0xAD67D9BDL,0xC9037898L},{0xEC816826L,0x011EEB7EL,0x011EEB7EL,0xEC816826L,0x17578368L},{0x19840658L,0x1586A3A0L,1UL,0x8D611B1CL,0xF5742774L},{0xE494DEFFL,0xEC816826L,18446744073709551609UL,0x262A1A58L,0xEC816826L},{0xC9037898L,0xD2D302D6L,0x22111F6AL,0x8D611B1CL,0x22111F6AL},{4UL,5UL,1UL,0xEC816826L,0xAF96790CL},{1UL,9UL,0UL,0xAD67D9BDL,0UL}},{{0x17578368L,18446744073709551614UL,18446744073709551606UL,0x262A1A58L,18446744073709551610UL},{0UL,0xAD67D9BDL,0xC9037898L,0xAD67D9BDL,0UL},{18446744073709551615UL,18446744073709551609UL,1UL,18446744073709551610UL,0xE494DEFFL},{0UL,0xA4151B09L,1UL,0xD2D302D6L,0x45AEE899L},{0x17578368L,18446744073709551611UL,5UL,18446744073709551609UL,0xE494DEFFL},{0xC28752BBL,0xD2D302D6L,0xC28752BBL,0x37F70200L,0UL},{0xE494DEFFL,1UL,0x4AD5BBD2L,0xE494DEFFL,18446744073709551610UL},{1UL,0x148553A0L,0xF5742774L,0xD2D302D6L,0UL},{18446744073709551615UL,0x17578368L,0x4AD5BBD2L,0x4AD5BBD2L,0x17578368L},{0x22111F6AL,0xA4151B09L,0xC28752BBL,0xAD67D9BDL,0xA4754866L}},{{18446744073709551611UL,0x262A1A58L,5UL,0x17578368L,18446744073709551611UL},{18446744073709551609UL,0x148553A0L,1UL,0x37F70200L,1UL},{18446744073709551611UL,18446744073709551614UL,1UL,0x011EEB7EL,18446744073709551610UL},{0x22111F6AL,0xD2D302D6L,0xC9037898L,0x148553A0L,0xE2B0905EL},{18446744073709551615UL,0x011EEB7EL,18446744073709551606UL,18446744073709551610UL,18446744073709551611UL},{1UL,0xA4151B09L,0x45AEE899L,0x148553A0L,0x45AEE899L},{0xE494DEFFL,0xE494DEFFL,5UL,0x011EEB7EL,0x17578368L},{0xC28752BBL,0xAD67D9BDL,0xA4754866L,0x37F70200L,0x22111F6AL},{0x17578368L,1UL,18446744073709551606UL,0x17578368L,18446744073709551610UL},{0UL,0xAD67D9BDL,0xF5742774L,0xAD67D9BDL,0UL}}};
    int8_t ***l_3648 = &g_1436;
    uint32_t **l_3657[7] = {&g_1997,(void*)0,&g_1997,&g_1997,(void*)0,&g_1997,&g_1997};
    int32_t l_3659 = 0x406C0F10L;
    int32_t *l_3660 = &g_86[3];
    int i, j, k;
    for (g_2115 = (-19); (g_2115 != 23); g_2115 = safe_add_func_uint16_t_u_u(g_2115, 7))
    { /* block id: 1620 */
        uint64_t l_3641 = 0x23BFC5D0D6AAAD39LL;
        int8_t * const *l_3651 = &g_1124;
        int8_t * const ** const l_3650 = &l_3651;
        int8_t * const ** const *l_3649 = &l_3650;
        int8_t *l_3652[5] = {&g_10,&g_10,&g_10,&g_10,&g_10};
        int32_t l_3653 = 1L;
        int i;
        if ((l_3634[2][0][4] || (safe_rshift_func_int16_t_s_u((**g_782), ((safe_lshift_func_int8_t_s_u(0x15L, 0)) | (+(((+p_3) , ((***g_1122) < (p_3 , l_3641))) ^ (l_3641 & (l_3653 |= (safe_mul_func_uint8_t_u_u(((safe_mod_func_uint8_t_u_u((safe_add_func_uint8_t_u_u((((((l_3641 , (void*)0) == l_3648) , p_3) , l_3649) != (void*)0), l_3634[0][0][0])), l_3641)) != l_3634[1][0][0]), 1UL)))))))))))
        { /* block id: 1622 */
            int32_t *l_3656 = &g_88;
            uint32_t **l_3658[9][4] = {{&g_1997,&g_1997,&g_1997,&g_1997},{&g_1997,&g_1997,&g_1997,&g_1997},{&g_1997,&g_1997,&g_1997,&g_1997},{&g_1997,&g_1997,&g_1997,&g_1997},{&g_1997,&g_1997,&g_1997,&g_1997},{&g_1997,&g_1997,&g_1997,&g_1997},{&g_1997,&g_1997,&g_1997,&g_1997},{&g_1997,&g_1997,&g_1997,&g_1997},{&g_1997,&g_1997,&g_1997,&g_1997}};
            int i, j;
            for (g_252.f2 = (-9); (g_252.f2 >= 28); ++g_252.f2)
            { /* block id: 1625 */
                return l_3656;
            }
            l_3658[2][0] = l_3657[3];
            l_3659 = p_3;
        }
        else
        { /* block id: 1630 */
            if (p_3)
                break;
        }
    }
    return l_3660;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static uint16_t  func_13(uint32_t  p_14, int32_t * p_15, int64_t  p_16, int32_t * p_17, uint64_t  p_18)
{ /* block id: 1614 */
    return p_14;
}


/* ------------------------------------------ */
/* 
 * reads : g_843 g_154 g_1436 g_1124 g_10 g_94 g_2115 g_783 g_765 g_782 g_124 g_2328 g_2329 g_2330 g_3222 g_90 g_3143 g_181 g_842 g_1181 g_199 g_142 g_143 g_3247 g_2601.f0 g_482 g_1653 g_834 g_2911 g_1123 g_3194 g_633 g_634 g_635 g_252.f2 g_3295 g_2910 g_1997 g_804 g_2447.f2 g_784 g_95 g_86 g_1839.f1 g_3418 g_613 g_1122 g_1854 g_289 g_1003 g_3108 g_88
 * writes: g_90 g_95 g_10 g_991.f2 g_2115 g_765 g_124 g_94 g_804 g_311 g_182 g_143 g_1653 g_1784.f2 g_252.f2 g_613 g_86 g_2447.f2 g_98 g_1839.f1 g_3067.f2 g_199 g_1604 g_3515 g_3627 g_3631
 */
static int32_t * func_19(uint32_t  p_20, int32_t * p_21, int8_t  p_22, int64_t  p_23, uint32_t  p_24)
{ /* block id: 1065 */
    uint16_t l_2212 = 0x1642L;
    uint8_t *l_2226 = (void*)0;
    int8_t l_2239[6][4] = {{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}};
    const uint32_t *l_2245 = (void*)0;
    const uint32_t **l_2244 = &l_2245;
    const uint32_t *** const l_2243[3] = {&l_2244,&l_2244,&l_2244};
    const uint32_t *** const *l_2242[10][1] = {{&l_2243[1]},{&l_2243[1]},{&l_2243[1]},{&l_2243[1]},{&l_2243[1]},{&l_2243[1]},{&l_2243[1]},{&l_2243[1]},{&l_2243[1]},{&l_2243[1]}};
    const uint32_t *** const **l_2241[6][2][3] = {{{&l_2242[1][0],&l_2242[1][0],&l_2242[1][0]},{&l_2242[8][0],&l_2242[1][0],&l_2242[1][0]}},{{&l_2242[1][0],&l_2242[1][0],&l_2242[1][0]},{(void*)0,(void*)0,&l_2242[8][0]}},{{&l_2242[1][0],&l_2242[1][0],&l_2242[1][0]},{&l_2242[1][0],(void*)0,&l_2242[1][0]}},{{(void*)0,&l_2242[1][0],&l_2242[1][0]},{&l_2242[1][0],&l_2242[1][0],&l_2242[1][0]}},{{&l_2242[1][0],(void*)0,&l_2242[1][0]},{(void*)0,&l_2242[1][0],&l_2242[8][0]}},{{&l_2242[1][0],&l_2242[1][0],&l_2242[1][0]},{&l_2242[1][0],(void*)0,&l_2242[1][0]}}};
    int32_t l_2332 = 6L;
    int8_t ***l_2353 = &g_1123;
    int8_t **** const l_2352[3][4] = {{&l_2353,&l_2353,(void*)0,&l_2353},{&l_2353,(void*)0,(void*)0,&l_2353},{(void*)0,&l_2353,(void*)0,(void*)0}};
    union U1 * const l_2446 = &g_2447;
    union U1 * const *l_2445[2];
    union U1 * const **l_2444[8][4][7] = {{{(void*)0,&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[0]},{&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[0],&l_2445[1],&l_2445[1]},{&l_2445[0],&l_2445[1],(void*)0,&l_2445[1],&l_2445[0],&l_2445[0],&l_2445[0]},{&l_2445[0],&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[0],&l_2445[1],&l_2445[1]}},{{&l_2445[1],&l_2445[0],(void*)0,&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1]},{&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[1],&l_2445[1],(void*)0},{&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[0]},{&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[1],(void*)0,&l_2445[1],&l_2445[1]}},{{&l_2445[0],&l_2445[0],(void*)0,&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1]},{&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[1]},{(void*)0,&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[1]},{&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1]}},{{&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[1]},{&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1]},{&l_2445[1],(void*)0,&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[1],&l_2445[0]},{&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1],(void*)0,(void*)0}},{{&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[1]},{&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1],(void*)0,&l_2445[1]},{(void*)0,&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[0]},{(void*)0,&l_2445[1],(void*)0,&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1]}},{{&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[0]},{&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[1]},{&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[0],&l_2445[1]},{&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[1],(void*)0}},{{&l_2445[1],&l_2445[1],(void*)0,&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1]},{&l_2445[1],&l_2445[1],(void*)0,&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1]},{&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1],&l_2445[1]},{&l_2445[1],&l_2445[1],&l_2445[1],(void*)0,&l_2445[0],&l_2445[0],&l_2445[0]}},{{&l_2445[0],&l_2445[1],&l_2445[1],&l_2445[0],&l_2445[1],(void*)0,&l_2445[1]},{&l_2445[1],&l_2445[1],&l_2445[0],(void*)0,&l_2445[1],&l_2445[1],&l_2445[1]},{&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[1],&l_2445[0],&l_2445[0],&l_2445[1]},{&l_2445[1],(void*)0,&l_2445[0],&l_2445[1],(void*)0,&l_2445[0],&l_2445[1]}}};
    union U1 * const ***l_2443 = &l_2444[1][0][3];
    const int64_t *l_2469[10][8] = {{&g_98,&g_1783.f1,&g_98,&g_1783.f1,&g_1635[2][1][0],(void*)0,&g_98,&g_1635[2][1][0]},{&g_98,&g_98,&g_98,&g_98,&g_1783.f1,(void*)0,&g_1635[2][1][0],&g_98},{&g_98,&g_1635[1][3][0],&g_1635[2][1][0],&g_1635[2][1][0],&g_1635[2][1][0],&g_1635[2][3][2],&g_1783.f1,&g_1783.f1},{&g_98,&g_1783.f1,&g_1635[2][1][0],&g_1635[2][1][0],&g_1783.f1,&g_98,&g_98,&g_1635[2][1][0]},{&g_1783.f1,&g_98,&g_1783.f1,(void*)0,&g_1635[2][1][0],&g_98,&g_1783.f1,&g_1783.f1},{&g_1783.f1,&g_1635[2][1][0],&g_1635[2][1][0],(void*)0,&g_1783.f1,&g_1635[2][1][0],&g_98,&g_1635[2][1][0]},{&g_1783.f1,&g_1783.f1,&g_98,&g_1635[2][1][0],&g_1783.f1,&g_1635[2][1][0],&g_98,&g_1783.f1},{&g_1635[1][3][0],&g_98,&g_1783.f1,&g_1635[2][1][0],&g_1635[2][1][0],&g_1783.f1,&g_1635[2][1][0],&g_98},{(void*)0,&g_1783.f1,&g_1635[2][3][2],&g_98,&g_1635[1][3][0],&g_1635[2][1][0],&g_1635[2][1][0],&g_1635[2][1][0]},{&g_98,&g_98,&g_1783.f1,&g_1783.f1,&g_1783.f1,&g_98,&g_98,&g_1783.f1}};
    const int64_t **l_2468 = &l_2469[6][4];
    const int64_t ** const *l_2467[8];
    const int64_t ** const * const *l_2466 = &l_2467[6];
    uint8_t l_2505[5][3][4] = {{{1UL,0UL,0x8AL,255UL},{0UL,0UL,0x8AL,0UL},{1UL,247UL,1UL,0UL}},{{0x36L,247UL,0xC3L,0UL},{0xC3L,0UL,1UL,255UL},{0xC3L,0UL,0xC3L,0x8BL}},{{0x36L,255UL,1UL,0x8BL},{1UL,0UL,0x8AL,255UL},{0UL,0UL,1UL,247UL}},{{0x9CL,255UL,0x8AL,0UL},{0xC3L,255UL,0UL,247UL},{0UL,247UL,0x9CL,0x8BL}},{{0UL,255UL,0UL,0UL},{0xC3L,0x8BL,0x8AL,0UL},{0x9CL,255UL,1UL,0x8BL}}};
    int32_t l_2555 = 0x328853CAL;
    const union U2 *l_2609 = (void*)0;
    int32_t l_2610[2];
    int32_t *l_2624 = &g_124;
    int16_t **l_2635 = (void*)0;
    uint8_t l_2721[5][2][9] = {{{0xC8L,0x18L,1UL,0x6AL,1UL,0x18L,0xC8L,0x18L,1UL},{0xCAL,255UL,255UL,0xCAL,255UL,255UL,0xCAL,255UL,255UL}},{{0xC8L,0x18L,1UL,0x6AL,1UL,0x18L,0xC8L,0x18L,1UL},{0xCAL,255UL,255UL,0xCAL,255UL,255UL,0xCAL,255UL,255UL}},{{0xC8L,0x18L,1UL,0x6AL,1UL,0x18L,0xC8L,0x18L,1UL},{0xCAL,255UL,255UL,0xCAL,255UL,255UL,0xCAL,255UL,255UL}},{{0xC8L,0x18L,1UL,0x6AL,1UL,0x18L,0xC8L,0x18L,1UL},{0xCAL,255UL,255UL,0xCAL,255UL,255UL,0xCAL,255UL,255UL}},{{0xC8L,0x18L,1UL,0x6AL,1UL,0x18L,0xC8L,0x18L,1UL},{0xCAL,255UL,255UL,0xCAL,255UL,255UL,0xCAL,255UL,255UL}}};
    int16_t l_2968 = 0x79D4L;
    const int8_t l_3023 = 1L;
    uint64_t *l_3056 = &g_1653[0];
    uint64_t **l_3055 = &l_3056;
    uint32_t l_3076 = 0x322C5E59L;
    uint8_t l_3160 = 1UL;
    uint32_t l_3228 = 0xD47D58A7L;
    uint8_t l_3304 = 255UL;
    int32_t **** const *l_3324 = &g_2328;
    int32_t l_3361 = 0x6196EAF5L;
    uint32_t l_3441 = 0x2D494EC6L;
    uint64_t ***l_3488[2];
    uint8_t ** const l_3514 = (void*)0;
    uint8_t ** const *l_3513 = &l_3514;
    uint8_t ** const **l_3512 = &l_3513;
    int32_t l_3552[7];
    union U0 **l_3574 = &g_311;
    union U0 ***l_3573[2][7][8] = {{{(void*)0,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574},{&l_3574,(void*)0,&l_3574,(void*)0,&l_3574,&l_3574,&l_3574,&l_3574},{&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,(void*)0},{&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574},{&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574},{&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574},{&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574}},{{(void*)0,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,(void*)0},{&l_3574,(void*)0,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574},{(void*)0,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574},{&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574},{&l_3574,&l_3574,(void*)0,&l_3574,&l_3574,&l_3574,(void*)0,&l_3574},{&l_3574,&l_3574,&l_3574,&l_3574,(void*)0,&l_3574,&l_3574,&l_3574},{&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574,&l_3574}}};
    union U0 ****l_3572 = &l_3573[0][0][5];
    union U1 ****l_3607 = &g_633;
    uint64_t l_3615 = 0x1F7D1331AAA37F5DLL;
    int32_t l_3616 = (-6L);
    int32_t l_3617 = (-1L);
    int32_t l_3618 = 0xC4F7DC57L;
    int32_t *l_3622 = (void*)0;
    const union U2 **l_3630[1][10] = {{(void*)0,&l_2609,&l_2609,(void*)0,&l_2609,(void*)0,&l_2609,&l_2609,(void*)0,&l_2609}};
    int i, j, k;
    for (i = 0; i < 2; i++)
        l_2445[i] = &l_2446;
    for (i = 0; i < 8; i++)
        l_2467[i] = &l_2468;
    for (i = 0; i < 2; i++)
        l_2610[i] = 0L;
    for (i = 0; i < 2; i++)
        l_3488[i] = &l_3055;
    for (i = 0; i < 7; i++)
        l_3552[i] = 0x9382E4CDL;
    if (((*g_94) = ((((safe_mod_func_int8_t_s_s(l_2212, ((safe_mul_func_int32_t_s_s((safe_div_func_int64_t_s_s(p_24, (*g_843))), (safe_div_func_int32_t_s_s(((*p_21) = (safe_lshift_func_uint64_t_u_u(l_2212, ((safe_mod_func_int16_t_s_s((((safe_div_func_uint64_t_u_u((safe_unary_minus_func_int64_t_s((l_2212 & (&p_21 != &g_93)))), ((l_2226 != l_2226) , g_154))) <= p_20) != l_2212), p_22)) , l_2212)))), 0x1D2771ADL)))) | 0xE1DEL))) > (**g_1436)) != 0xD0L) >= l_2212)))
    { /* block id: 1068 */
        uint32_t l_2227 = 0x0FE7BBDBL;
        uint64_t *l_2240 = &g_1887[4].f2;
        uint32_t **l_2251 = &g_2236;
        const uint32_t **l_2254 = &l_2245;
        int32_t l_2322 = 0xF0D54DF9L;
        int64_t *l_2349 = &g_98;
        int64_t **l_2348 = &l_2349;
        int64_t ****l_2358 = &g_171;
        int64_t *****l_2357 = &l_2358;
        int16_t ***l_2385 = &g_782;
        int16_t ****l_2384 = &l_2385;
        const union U0 ** const l_2421 = &g_182;
        const union U0 ** const *l_2420[8][7][1] = {{{&l_2421},{&l_2421},{&l_2421},{&l_2421},{(void*)0},{&l_2421},{(void*)0}},{{&l_2421},{&l_2421},{&l_2421},{&l_2421},{(void*)0},{&l_2421},{(void*)0}},{{&l_2421},{&l_2421},{&l_2421},{&l_2421},{(void*)0},{&l_2421},{(void*)0}},{{&l_2421},{&l_2421},{&l_2421},{&l_2421},{(void*)0},{&l_2421},{(void*)0}},{{&l_2421},{&l_2421},{&l_2421},{&l_2421},{(void*)0},{&l_2421},{(void*)0}},{{&l_2421},{&l_2421},{&l_2421},{&l_2421},{(void*)0},{&l_2421},{(void*)0}},{{&l_2421},{&l_2421},{&l_2421},{&l_2421},{(void*)0},{&l_2421},{(void*)0}},{{&l_2421},{&l_2421},{&l_2421},{&l_2421},{(void*)0},{&l_2421},{(void*)0}}};
        union U1 * const *l_2442 = &g_635;
        union U1 * const **l_2441[3];
        union U1 * const ***l_2440 = &l_2441[0];
        uint16_t l_2454[10][6] = {{1UL,0x90CDL,1UL,0x90CDL,1UL,0x90CDL},{1UL,0x90CDL,1UL,0x90CDL,1UL,0x90CDL},{1UL,0x90CDL,1UL,0x90CDL,1UL,0x90CDL},{1UL,0x90CDL,1UL,0x90CDL,1UL,0x90CDL},{1UL,0x90CDL,1UL,0x90CDL,1UL,0x90CDL},{1UL,0x90CDL,1UL,0x90CDL,1UL,0x90CDL},{1UL,0x90CDL,1UL,0x90CDL,1UL,0x90CDL},{1UL,0x90CDL,1UL,0x90CDL,1UL,0x90CDL},{1UL,0x90CDL,1UL,0x90CDL,1UL,0x90CDL},{1UL,0x90CDL,1UL,0x90CDL,1UL,0x90CDL}};
        int32_t ****l_2536 = (void*)0;
        const int16_t l_2538 = 7L;
        int16_t l_2569 = 0x1C3CL;
        uint8_t l_2592 = 0xB4L;
        uint32_t l_2615 = 1UL;
        int8_t *l_2645 = (void*)0;
        uint32_t ***l_2816[4][10][6] = {{{(void*)0,&g_1996[3],&g_1996[2],&g_1996[0],&g_1996[3],&g_1996[4]},{(void*)0,&g_1996[4],&g_1996[3],&g_1996[3],(void*)0,(void*)0},{(void*)0,&g_1996[4],&g_1996[3],(void*)0,&g_1996[2],&g_1996[5]},{&g_1996[3],&g_1996[3],&g_1996[2],&g_1996[3],&g_1996[1],&g_1996[3]},{&g_1996[3],&g_1996[3],&g_1996[3],(void*)0,&g_1996[0],(void*)0},{&g_1996[3],&g_1996[2],&g_1996[3],&g_1996[3],&g_1996[3],&g_1996[3]},{&g_1996[2],&g_1996[0],&g_1996[4],&g_1996[3],&g_1996[2],&g_1996[3]},{&g_1996[3],&g_1996[0],(void*)0,&g_1996[3],&g_1996[2],&g_1996[4]},{&g_1996[2],&g_1996[3],(void*)0,&g_1996[2],&g_1996[0],&g_1996[0]},{&g_1996[3],&g_1996[3],&g_1996[3],&g_1996[3],&g_1996[5],&g_1996[3]}},{{&g_1996[1],&g_1996[0],&g_1996[3],&g_1996[2],&g_1996[4],&g_1996[5]},{&g_1996[1],&g_1996[3],&g_1996[3],&g_1996[3],(void*)0,(void*)0},{&g_1996[0],&g_1996[1],&g_1996[1],&g_1996[0],&g_1996[3],(void*)0},{&g_1996[2],(void*)0,&g_1996[3],&g_1996[3],&g_1996[5],&g_1996[3]},{&g_1996[4],&g_1996[0],&g_1996[2],&g_1996[3],&g_1996[5],&g_1996[3]},{&g_1996[3],(void*)0,(void*)0,&g_1996[5],&g_1996[3],&g_1996[3]},{&g_1996[3],&g_1996[1],&g_1996[3],&g_1996[3],(void*)0,&g_1996[4]},{(void*)0,&g_1996[3],&g_1996[0],&g_1996[3],&g_1996[4],&g_1996[0]},{&g_1996[3],&g_1996[0],&g_1996[3],(void*)0,&g_1996[5],(void*)0},{(void*)0,&g_1996[3],&g_1996[3],(void*)0,&g_1996[0],&g_1996[5]}},{{&g_1996[2],&g_1996[3],&g_1996[5],&g_1996[3],&g_1996[2],(void*)0},{(void*)0,&g_1996[0],&g_1996[3],&g_1996[2],&g_1996[2],&g_1996[3]},{&g_1996[3],&g_1996[0],(void*)0,&g_1996[0],&g_1996[3],&g_1996[3]},{&g_1996[3],&g_1996[2],&g_1996[3],&g_1996[3],&g_1996[0],(void*)0},{&g_1996[3],(void*)0,&g_1996[5],(void*)0,&g_1996[4],&g_1996[5]},{&g_1996[3],&g_1996[3],&g_1996[3],&g_1996[4],&g_1996[3],(void*)0},{&g_1996[3],&g_1996[3],&g_1996[3],(void*)0,&g_1996[1],&g_1996[0]},{&g_1996[2],&g_1996[3],&g_1996[0],&g_1996[4],(void*)0,&g_1996[4]},{&g_1996[3],&g_1996[0],&g_1996[3],&g_1996[3],&g_1996[0],&g_1996[3]},{&g_1996[3],&g_1996[3],(void*)0,&g_1996[5],&g_1996[3],&g_1996[3]}},{{&g_1996[0],&g_1996[3],&g_1996[2],&g_1996[3],&g_1996[4],&g_1996[3]},{&g_1996[0],&g_1996[1],&g_1996[3],&g_1996[5],&g_1996[4],(void*)0},{&g_1996[3],&g_1996[3],&g_1996[1],&g_1996[3],&g_1996[3],(void*)0},{&g_1996[3],&g_1996[3],&g_1996[3],&g_1996[4],&g_1996[3],&g_1996[5]},{&g_1996[2],(void*)0,&g_1996[3],(void*)0,&g_1996[5],&g_1996[3]},{&g_1996[3],&g_1996[0],&g_1996[3],&g_1996[4],&g_1996[3],&g_1996[0]},{&g_1996[3],&g_1996[4],(void*)0,&g_1996[3],(void*)0,&g_1996[3]},{(void*)0,&g_1996[2],&g_1996[3],&g_1996[3],(void*)0,&g_1996[0]},{&g_1996[3],(void*)0,&g_1996[0],&g_1996[3],(void*)0,&g_1996[4]},{&g_1996[2],(void*)0,&g_1996[0],&g_1996[3],(void*)0,&g_1996[1]}}};
        int32_t l_2823 = 0x38E24748L;
        int32_t l_2824[2];
        int32_t l_2844 = 0xF15702E9L;
        int16_t * const *l_2897[9] = {&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783,&g_783};
        int16_t * const **l_2896 = &l_2897[7];
        int16_t * const **l_2899[9] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
        uint32_t l_2945 = 0xF4689D75L;
        int8_t l_2964 = (-1L);
        uint8_t l_3024[9][2][9] = {{{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL},{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL}},{{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL},{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL}},{{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL},{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL}},{{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL},{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL}},{{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL},{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL}},{{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL},{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL}},{{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL},{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL}},{{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL},{252UL,255UL,252UL,252UL,255UL,252UL,252UL,255UL,252UL}},{{252UL,255UL,252UL,252UL,255UL,252UL,252UL,252UL,0x09L},{0x09L,252UL,0x09L,0x09L,252UL,0x09L,0x09L,252UL,0x09L}}};
        int32_t l_3106 = 0x1FDA36EEL;
        int64_t l_3148[10][6] = {{1L,0L,1L,0x44972B378252D0B0LL,6L,1L},{0x972E4BCA2648CA53LL,0xC980708730856637LL,0x44972B378252D0B0LL,(-9L),6L,0x972E4BCA2648CA53LL},{0x44972B378252D0B0LL,0L,(-9L),(-9L),0L,0x44972B378252D0B0LL},{0x972E4BCA2648CA53LL,6L,(-9L),0x44972B378252D0B0LL,0xC980708730856637LL,0x972E4BCA2648CA53LL},{1L,6L,0x44972B378252D0B0LL,1L,0L,1L},{1L,0L,1L,0x44972B378252D0B0LL,6L,1L},{0x972E4BCA2648CA53LL,0xC980708730856637LL,0x44972B378252D0B0LL,(-9L),6L,0x972E4BCA2648CA53LL},{0x44972B378252D0B0LL,0L,(-9L),(-9L),0L,0x44972B378252D0B0LL},{0x972E4BCA2648CA53LL,6L,(-9L),0x44972B378252D0B0LL,0xC980708730856637LL,0x972E4BCA2648CA53LL},{1L,6L,0x44972B378252D0B0LL,1L,0L,1L}};
        int8_t l_3151 = 0x82L;
        int i, j, k;
        for (i = 0; i < 3; i++)
            l_2441[i] = &l_2442;
        for (i = 0; i < 2; i++)
            l_2824[i] = 0L;
    }
    else
    { /* block id: 1438 */
        int16_t **l_3163[2];
        int32_t l_3164[2][6][6] = {{{(-7L),0L,2L,(-1L),0x7BE39AD4L,0L},{0L,2L,0L,(-1L),(-7L),(-7L)},{(-7L),0x4F80A946L,0x4F80A946L,(-7L),0xADB666B6L,0x88634839L},{0xAEC92536L,0L,0L,2L,0L,0x590C56C0L},{(-6L),(-1L),0xD56DEA37L,0x7150F918L,0L,0L},{0xADB666B6L,0L,(-7L),0L,0xADB666B6L,0x7150F918L}},{{0xD56DEA37L,0x4F80A946L,0xD9CBCBEBL,0x88634839L,(-7L),(-6L)},{0xD9CBCBEBL,2L,0xADB666B6L,0x4F80A946L,0x7BE39AD4L,(-6L)},{0x7150F918L,0L,0xD9CBCBEBL,0xD9CBCBEBL,0L,0x7150F918L},{0x7BE39AD4L,2L,(-7L),0L,0xD56DEA37L,0L},{2L,0xADB666B6L,0xD56DEA37L,0L,(-1L),0x590C56C0L},{2L,0x88634839L,0L,0L,0L,0x88634839L}}};
        int32_t *l_3179[6][10] = {{(void*)0,&l_3164[0][3][0],(void*)0,&g_88,&l_2610[0],&l_2610[1],&l_3164[0][5][4],(void*)0,&g_88,&g_86[3]},{&l_2610[1],&l_3164[0][5][4],(void*)0,&g_88,&g_86[3],&g_86[3],&g_88,(void*)0,&l_3164[0][5][4],&l_2610[1]},{&g_90,&l_2610[1],(void*)0,&g_124,&g_88,&l_3164[0][5][4],&g_86[3],&l_3164[0][3][0],&l_2610[1],&l_3164[0][3][0]},{&g_86[3],(void*)0,&g_88,&l_2610[1],&g_88,(void*)0,&g_86[3],&g_86[3],&g_95,&l_2610[1]},{&g_88,&g_86[3],(void*)0,(void*)0,&g_86[3],&l_2610[0],&g_124,&g_124,&l_3164[0][3][0],&g_88},{&g_86[3],&g_95,&g_95,&g_86[3],&l_3164[0][3][0],&g_86[3],&l_2610[1],&g_124,(void*)0,&l_2610[1]}};
        uint64_t **l_3191 = &l_3056;
        int64_t ***l_3277 = &g_172;
        uint32_t ***l_3340 = &g_1996[3];
        int8_t l_3358 = 0xBCL;
        int8_t l_3360 = 0xAAL;
        uint8_t l_3381 = 0xEAL;
        int32_t l_3382 = 0xCF7BA3B5L;
        int16_t l_3459 = 5L;
        uint8_t l_3497 = 1UL;
        uint8_t ** const l_3510 = &l_2226;
        uint8_t ** const *l_3509 = &l_3510;
        uint8_t ** const **l_3508 = &l_3509;
        union U1 **** const l_3577 = &g_633;
        uint8_t l_3578 = 0x27L;
        int32_t ****l_3606[8] = {&g_2329,&g_2329,&g_2329,&g_2329,&g_2329,&g_2329,&g_2329,&g_2329};
        int32_t *l_3621 = &l_3164[0][4][0];
        int i, j, k;
        for (i = 0; i < 2; i++)
            l_3163[i] = &g_783;
        l_3163[1] = l_2635;
        if (l_3164[0][5][4])
        { /* block id: 1440 */
            uint64_t l_3180 = 0x56F92042570DBE32LL;
            int32_t l_3251[7][9] = {{(-1L),(-3L),(-1L),0x9EE0D182L,0x57E39C86L,0x0753AB8BL,0x45E94C0EL,0L,(-1L)},{4L,(-1L),0xD6063C51L,0x377CF3ABL,(-1L),0L,(-1L),0x377CF3ABL,0xD6063C51L},{(-1L),(-1L),(-3L),0x9EE0D182L,4L,(-1L),0xD6063C51L,0x377CF3ABL,(-1L)},{0x0753AB8BL,0x45E94C0EL,0L,(-1L),1L,1L,(-1L),0L,0x45E94C0EL},{1L,6L,(-3L),0xCFA31887L,6L,0x9EE0D182L,(-1L),0xD6063C51L,0x57E39C86L},{0x377CF3ABL,0x0753AB8BL,0xD6063C51L,0x45E94C0EL,0x87CC8303L,0x45E94C0EL,0xD6063C51L,0x0753AB8BL,0x377CF3ABL},{6L,6L,(-1L),0x87CC8303L,(-1L),0x45E94C0EL,(-1L),(-3L),0x0753AB8BL}};
            uint8_t l_3264 = 6UL;
            int64_t ***l_3274 = &g_172;
            int i, j;
            for (g_10 = 0; (g_10 <= 6); g_10 = safe_add_func_uint64_t_u_u(g_10, 9))
            { /* block id: 1443 */
                int64_t ** const *l_3174 = &g_172;
                int64_t ** const **l_3173 = &l_3174;
                uint64_t **l_3192 = &l_3056;
                uint8_t ***l_3210 = (void*)0;
                uint8_t ****l_3209 = &l_3210;
                int32_t l_3215 = 1L;
                int32_t *l_3240 = &l_2555;
                uint64_t l_3250 = 0xDEF84CC6A15C986CLL;
                int64_t * const *l_3279 = (void*)0;
                int64_t * const **l_3278 = &l_3279;
                for (g_991.f2 = 12; (g_991.f2 > 38); g_991.f2 = safe_add_func_int8_t_s_s(g_991.f2, 4))
                { /* block id: 1446 */
                    uint32_t l_3175 = 5UL;
                    int32_t *l_3176 = &g_2115;
                    int32_t l_3232 = 0x811D22D3L;
                    (*l_2624) &= ((safe_lshift_func_int64_t_s_u((((*l_3176) ^= ((safe_add_func_int64_t_s_s(((void*)0 != l_3173), l_3175)) , g_10)) , p_24), 8)) || ((((((**g_782) = ((safe_sub_func_uint16_t_u_u(0xC0EEL, (0xFA6B7C5C84E44348LL < p_23))) > (*g_783))) <= p_22) ^ p_22) == 0x1DL) , p_20));
                    (***g_2328) = l_3179[1][7];
                    if (l_3180)
                        break;
                    if ((safe_add_func_int8_t_s_s(((safe_rshift_func_int64_t_s_s((safe_mul_func_int8_t_s_s((safe_lshift_func_uint32_t_u_u(4294967288UL, 21)), (((g_3222 , p_22) || (*p_21)) > 0UL))), p_24)) >= l_3215), 0L)))
                    { /* block id: 1457 */
                        union U0 **l_3223[6][4] = {{&g_311,&g_311,&g_311,&g_311},{&g_311,&g_311,&g_311,&g_311},{&g_311,&g_311,&g_311,&g_311},{&g_311,&g_311,&g_311,&g_311},{&g_311,&g_311,&g_311,&g_311},{&g_311,&g_311,&g_311,&g_311}};
                        int32_t l_3239 = (-1L);
                        int i, j;
                        (**g_3143) = (g_311 = (void*)0);
                        (*p_21) ^= (((((safe_rshift_func_uint64_t_u_s((((((safe_add_func_uint64_t_u_u((l_3228 || ((l_3232 = (safe_mul_func_uint16_t_u_u(((**g_1436) , (safe_unary_minus_func_uint16_t_u(65528UL))), (&l_2609 != (void*)0)))) ^ (*l_2624))), 0x0746E9C816AD29C3LL)) , (safe_sub_func_int32_t_s_s(((safe_lshift_func_uint64_t_u_s(((safe_mul_func_int32_t_s_s((((&g_3212 == &g_1549[4][0][1]) ^ 0xFB75C1F4L) && (**g_842)), l_3239)) >= 0xC73F9F1AL), 8)) ^ l_3175), 0x0499131AL))) , (*g_1181)) < p_23) == 0x6EL), 15)) > 0xEF49L) == p_24) >= (*l_2624)) == 0xC1DB9516L);
                        if ((*p_21))
                            continue;
                        if ((*p_21))
                            break;
                    }
                    else
                    { /* block id: 1464 */
                        return p_21;
                    }
                }
                if ((safe_sub_func_uint32_t_u_u((251UL || (safe_mod_func_uint8_t_u_u((safe_unary_minus_func_int64_t_s(((l_3251[1][6] |= (((-1L) & ((*l_3240) = ((((*g_142) ^= (~p_20)) , g_3247) , (1UL | l_3180)))) , ((*g_783) &= (l_3250 = (safe_mul_func_uint8_t_u_u((*l_3240), 0x5BL)))))) > g_2601.f0))), (-7L)))), (-1L))))
                { /* block id: 1473 */
                    uint16_t l_3252 = 65535UL;
                    l_3252--;
                    (*p_21) ^= (safe_add_func_uint64_t_u_u(((**l_3055) &= (safe_mul_func_int8_t_s_s((safe_rshift_func_int8_t_s_s((((safe_unary_minus_func_int64_t_s((safe_lshift_func_uint64_t_u_u((p_23 < (l_3264 , (safe_div_func_uint16_t_u_u((p_22 && ((safe_rshift_func_uint32_t_u_s(4294967295UL, 5)) , p_20)), (safe_mod_func_uint16_t_u_u(p_20, 0xD81CL)))))), l_3251[1][6])))) ^ (g_482 , l_3252)) <= 0xBDA3L), 0)), (*l_2624)))), 0xA18447849B69B4F6LL));
                }
                else
                { /* block id: 1477 */
                    int64_t ***l_3275[9][7] = {{&g_172,&g_172,&g_172,&g_172,&g_172,&g_172,&g_172},{&g_172,&g_172,&g_172,&g_172,&g_172,&g_172,&g_172},{&g_172,&g_172,&g_172,&g_172,&g_172,&g_172,&g_172},{&g_172,&g_172,&g_172,&g_172,&g_172,&g_172,&g_172},{&g_172,&g_172,&g_172,&g_172,&g_172,&g_172,&g_172},{&g_172,&g_172,&g_172,&g_172,&g_172,&g_172,&g_172},{&g_172,&g_172,&g_172,&g_172,&g_172,&g_172,&g_172},{&g_172,&g_172,&g_172,&g_172,&g_172,&g_172,&g_172},{&g_172,&g_172,&g_172,&g_172,&g_172,&g_172,&g_172}};
                    int64_t ****l_3276[8][9][3] = {{{&l_3275[2][4],&l_3275[7][6],(void*)0},{(void*)0,&l_3275[4][5],&g_171},{(void*)0,&l_3275[5][0],&l_3275[2][4]},{&l_3275[2][4],(void*)0,&l_3274},{&g_171,&g_171,&g_171},{&l_3275[2][4],&l_3275[2][4],&l_3275[0][4]},{&l_3275[2][4],&l_3275[2][4],&g_171},{(void*)0,&g_171,&l_3274},{&l_3275[2][4],&l_3275[2][4],&l_3275[8][5]}},{{&l_3275[2][4],&l_3274,(void*)0},{&g_171,&l_3275[2][4],&l_3274},{(void*)0,&l_3275[8][3],&g_171},{&l_3275[2][4],(void*)0,&l_3275[2][4]},{&g_171,&g_171,&l_3274},{(void*)0,(void*)0,&g_171},{&l_3275[2][4],&l_3275[3][3],(void*)0},{&l_3274,&l_3274,&l_3274},{&g_171,&l_3275[2][4],(void*)0}},{{(void*)0,&l_3275[6][5],&g_171},{&l_3275[2][4],&l_3274,&l_3274},{(void*)0,&l_3274,&l_3275[2][4]},{&l_3275[2][4],&g_171,&g_171},{&l_3275[7][6],(void*)0,&l_3274},{&g_171,(void*)0,(void*)0},{(void*)0,&l_3275[7][6],&l_3275[8][5]},{&l_3275[3][3],&l_3275[2][4],&l_3274},{&l_3275[2][4],&l_3274,&g_171}},{{&g_171,&l_3275[2][4],&l_3275[8][3]},{&l_3274,(void*)0,(void*)0},{&g_171,(void*)0,&g_171},{&l_3275[8][5],&l_3275[3][4],&l_3274},{&l_3274,&g_171,&l_3275[2][4]},{&l_3275[2][4],&l_3274,(void*)0},{&l_3275[2][4],&l_3275[2][4],&l_3275[2][4]},{&l_3275[2][4],&g_171,&l_3275[2][4]},{&l_3274,&g_171,(void*)0}},{{&l_3275[8][5],(void*)0,&l_3274},{&g_171,(void*)0,(void*)0},{&l_3274,&l_3275[8][5],&l_3275[2][4]},{&g_171,&l_3275[2][4],&g_171},{&l_3275[2][4],(void*)0,&l_3275[2][4]},{&l_3275[3][3],&l_3274,&l_3275[2][4]},{(void*)0,(void*)0,&l_3275[8][4]},{&g_171,&l_3275[2][4],&l_3275[2][4]},{&l_3275[7][6],&l_3274,&l_3274}},{{&l_3275[2][4],&g_171,&g_171},{(void*)0,&l_3274,&l_3275[3][5]},{&l_3275[2][4],(void*)0,&l_3275[4][5]},{(void*)0,(void*)0,&l_3275[7][2]},{&g_171,&g_171,&l_3275[0][4]},{&l_3274,(void*)0,&l_3275[7][6]},{&l_3275[2][4],(void*)0,(void*)0},{(void*)0,&l_3274,&l_3275[6][5]},{&g_171,&g_171,(void*)0}},{{&l_3275[2][4],&l_3274,(void*)0},{(void*)0,&l_3275[2][4],&l_3275[2][4]},{&g_171,(void*)0,&g_171},{&l_3275[2][4],&l_3274,&l_3275[8][3]},{&l_3275[2][4],(void*)0,&l_3274},{(void*)0,&l_3275[2][4],&l_3275[2][4]},{&l_3274,&l_3275[8][5],(void*)0},{&l_3275[2][4],(void*)0,&l_3275[2][0]},{(void*)0,(void*)0,&l_3274}},{{&l_3274,&g_171,&l_3275[5][0]},{&l_3274,&g_171,&l_3274},{(void*)0,&l_3275[2][4],(void*)0},{&l_3274,&l_3274,&l_3274},{&l_3275[2][4],&g_171,&l_3275[5][0]},{&l_3275[2][4],&l_3275[3][4],&l_3274},{&l_3275[2][4],(void*)0,&l_3275[2][0]},{&l_3274,&g_171,&l_3275[2][4]},{&g_171,&g_171,&l_3275[2][4]}}};
                    uint8_t l_3286 = 253UL;
                    int i, j, k;
                    (*l_3240) = (((safe_mod_func_uint64_t_u_u(((!(l_3274 == (l_3277 = l_3275[2][4]))) != (l_3278 != ((1L ^ (g_834[1] , ((safe_sub_func_uint16_t_u_u((safe_mul_func_int64_t_s_s((safe_div_func_uint8_t_u_u(((((**g_782) = p_22) >= (*l_3240)) , (0xC585F1BBF2DCE6F4LL != (l_3286 = ((p_23 = ((p_23 ^ 0xAA493D6DL) , 0x4355FD78B5A6C0D2LL)) || p_20)))), (***g_2911))), (-1L))), (*g_142))) > l_3251[1][6]))) , l_3274))), (*g_3194))) > 1UL) <= 1UL);
                }
                for (g_1784.f2 = 0; (g_1784.f2 < 3); g_1784.f2++)
                { /* block id: 1486 */
                    union U1 *l_3289 = &g_3290;
                    l_3289 = (**g_633);
                }
            }
            for (g_252.f2 = 0; (g_252.f2 > 42); g_252.f2 = safe_add_func_int32_t_s_s(g_252.f2, 6))
            { /* block id: 1492 */
                (*p_21) = ((*l_2624) | ((**g_782) = 0x6E3EL));
            }
        }
        else
        { /* block id: 1496 */
            int8_t l_3305 = 1L;
            union U1 *l_3307[2];
            int32_t l_3310 = 0x19DD23ECL;
            int32_t l_3311 = 0x04F8E256L;
            int32_t l_3312 = 0xBF9DFDE9L;
            int32_t l_3313 = 0xCAC599C4L;
            int32_t l_3314 = (-2L);
            int32_t l_3315 = 9L;
            uint32_t ***l_3319 = &g_1996[3];
            uint32_t l_3338 = 0x8B8A26C1L;
            int32_t l_3362 = (-1L);
            int32_t l_3363[1];
            int32_t *l_3385 = &l_3310;
            uint16_t l_3439 = 1UL;
            int8_t l_3444 = 0x24L;
            int64_t l_3451 = (-1L);
            int64_t *l_3523[2];
            int8_t ***l_3532 = &g_1436;
            int i;
            for (i = 0; i < 2; i++)
                l_3307[i] = &g_3308[1];
            for (i = 0; i < 1; i++)
                l_3363[i] = 0xEBFBE925L;
            for (i = 0; i < 2; i++)
                l_3523[i] = &g_1255.f1;
            if ((safe_sub_func_int32_t_s_s((g_3295 , 0xC73733B6L), ((safe_lshift_func_uint8_t_u_u((((((p_20 == p_23) != 0x4476L) == ((*l_2624) = (*g_142))) != (safe_mul_func_uint32_t_u_u(((~p_23) & (*g_783)), (safe_unary_minus_func_int64_t_s(((safe_mod_func_uint32_t_u_u(((void*)0 != (*g_2910)), l_3304)) > 0UL)))))) <= (**g_782)), l_3305)) <= 0xF251D43429780A6FLL))))
            { /* block id: 1498 */
                union U1 *l_3306 = &g_1409;
                int32_t l_3309[5];
                uint64_t l_3316 = 6UL;
                int64_t l_3339 = (-8L);
                int i;
                for (i = 0; i < 5; i++)
                    l_3309[i] = 0xA16F4947L;
                l_3307[1] = l_3306;
                ++l_3316;
                (*****l_3324) = ((l_3319 != ((safe_div_func_uint32_t_u_u(l_3316, (0x3BL || (safe_mod_func_uint32_t_u_u((l_3324 != l_3324), ((~(((safe_mod_func_uint16_t_u_u((((*g_1997) = (safe_mul_func_int32_t_s_s(((*g_3194) <= (safe_lshift_func_uint16_t_u_s(65535UL, ((safe_sub_func_uint16_t_u_u((*g_142), (safe_mod_func_uint8_t_u_u((l_3311 = (((((safe_sub_func_uint8_t_u_u(0x7AL, (*g_1181))) , l_3338) , (void*)0) == (void*)0) , 0xCBL)), l_3339)))) < p_23)))), 0x335D5048L))) ^ 1L), 0x7E82L)) < (**g_842)) , l_3315)) && p_24)))))) , l_3340)) > (**g_1123));
            }
            else
            { /* block id: 1504 */
                int32_t l_3343[8][9][3] = {{{0x7066AF12L,0L,0L},{(-1L),0xC95506F8L,0xC95506F8L},{0x4751E30FL,0xD62423FCL,0L},{(-1L),(-3L),(-10L)},{0x7066AF12L,0L,(-5L)},{0L,0L,0xC95506F8L},{0L,0L,0x4751E30FL},{0L,(-3L),0x955D3C58L},{0x0D8762FCL,0xD62423FCL,0x0D8762FCL}},{{0L,0xC95506F8L,0x955D3C58L},{0xFBB40263L,0L,0x4751E30FL},{(-1L),0L,0xC95506F8L},{0L,0xD62423FCL,(-5L)},{(-1L),0L,(-10L)},{0xFBB40263L,0L,0L},{0L,0L,0xC95506F8L},{0x0D8762FCL,0L,0L},{0L,0L,0x955D3C58L}},{{0L,0xD62423FCL,0L},{0L,0L,0x955D3C58L},{0x7066AF12L,0L,0L},{(-1L),0xC95506F8L,0xC95506F8L},{0x4751E30FL,0xD62423FCL,0L},{(-1L),(-3L),(-10L)},{0x7066AF12L,0L,(-5L)},{0L,0L,0xC95506F8L},{0L,0L,0x4751E30FL}},{{0L,(-3L),0x955D3C58L},{0x0D8762FCL,0xD62423FCL,0x0D8762FCL},{0L,0xC95506F8L,0x955D3C58L},{0xFBB40263L,0L,0x4751E30FL},{(-1L),0L,0xC95506F8L},{0L,0xD62423FCL,(-5L)},{(-1L),0L,(-10L)},{0xFBB40263L,0L,0L},{0L,0L,0xC95506F8L}},{{0x0D8762FCL,0L,0L},{0L,0L,0x955D3C58L},{0L,0xD62423FCL,0L},{0L,0L,0x955D3C58L},{0x7066AF12L,0L,0L},{(-1L),0xC95506F8L,0xC95506F8L},{0x4751E30FL,0xD62423FCL,0L},{(-1L),(-3L),(-10L)},{0x7066AF12L,0L,(-5L)}},{{0L,0L,0xC95506F8L},{0L,0L,0x4751E30FL},{0L,(-3L),0x955D3C58L},{0x0D8762FCL,0xD62423FCL,0x0D8762FCL},{0L,0xC95506F8L,0x955D3C58L},{0xFBB40263L,0L,0x4751E30FL},{(-1L),0L,0xC95506F8L},{0L,0xD62423FCL,(-5L)},{(-1L),0L,(-10L)}},{{0xFBB40263L,0L,0L},{0L,0L,0xC95506F8L},{0x0D8762FCL,0L,0L},{0L,0L,0x955D3C58L},{0L,0xD62423FCL,0L},{0L,0L,0x955D3C58L},{0x7066AF12L,0L,0L},{(-1L),0xC95506F8L,(-10L)},{0L,0L,0x95B2EA71L}},{{0xC158754FL,0L,0x955D3C58L},{0L,0x9A6820D2L,0xD5E776ACL},{0L,0xC95506F8L,(-10L)},{0L,0x9A6820D2L,0L},{(-1L),0L,0L},{(-5L),0L,(-5L)},{0L,(-10L),0L},{0x4751E30FL,0L,0L},{0xC158754FL,(-1L),(-10L)}}};
                const union U1 ** const l_3392 = (void*)0;
                int64_t *l_3399 = &g_98;
                int i, j, k;
                for (g_2447.f2 = 29; (g_2447.f2 > 8); g_2447.f2 = safe_sub_func_uint8_t_u_u(g_2447.f2, 5))
                { /* block id: 1507 */
                    int32_t l_3345 = (-1L);
                    int32_t l_3346 = 0x24350F51L;
                    int32_t l_3347 = 0xFAF96863L;
                    int32_t l_3348 = (-8L);
                    int32_t l_3349 = (-1L);
                    uint64_t l_3364 = 0xC355C7C6D78A4155LL;
                    int32_t *l_3383 = &l_3343[3][2][0];
                }
                (*l_2624) &= (safe_div_func_int8_t_s_s((safe_add_func_uint16_t_u_u(((***g_784) >= p_20), (((((l_3392 != (void*)0) == ((safe_sub_func_uint8_t_u_u(((((*****l_3324) , l_3343[2][7][2]) == ((*l_3385) = (4294967295UL <= ((safe_mul_func_int64_t_s_s(0x0E85692C630912D6LL, ((*l_3399) = (safe_div_func_uint64_t_u_u(p_24, l_3343[3][2][0]))))) != 0x16L)))) && 0x48L), (**g_1123))) | p_24)) ^ 0x831076D5L) <= (*p_21)) , (*g_783)))), p_24));
            }
            for (g_1839.f1 = 22; (g_1839.f1 >= 9); g_1839.f1 = safe_sub_func_uint32_t_u_u(g_1839.f1, 1))
            { /* block id: 1533 */
                uint32_t l_3415 = 1UL;
                int32_t l_3429 = 0xABE72F74L;
                int32_t l_3446 = 0xA33F6BD9L;
                int32_t l_3447[4][3][8] = {{{(-1L),(-1L),0xEC0F37AEL,0xEC0F37AEL,(-1L),(-1L),0x89AF7C33L,1L},{0xCDF77975L,1L,0x89A9EBE6L,1L,0xDEE33B40L,8L,0xEF58C15BL,3L},{0x13D57FD8L,0x3EACDC21L,0x40F4DD00L,1L,0x89AF7C33L,0xE828885FL,(-2L),1L}},{{0x92061367L,0x89AF7C33L,0xCDF77975L,0xEC0F37AEL,0xAD9EA9F9L,(-2L),0xAD9EA9F9L,0xEC0F37AEL},{1L,(-10L),1L,0x89AF7C33L,3L,(-1L),0xDEE33B40L,0x89A9EBE6L},{0xE828885FL,0x13D57FD8L,0x0D7234A5L,0xEF58C15BL,0x0700DBA2L,0xEC0F37AEL,3L,0x40F4DD00L}},{{0xE828885FL,0x66F2900EL,(-1L),(-2L),3L,(-3L),0x40F4DD00L,0xCDF77975L},{1L,0xE828885FL,0x05AB8D24L,0xAD9EA9F9L,0xAD9EA9F9L,0x05AB8D24L,0xE828885FL,1L},{0x92061367L,1L,0x55AF3429L,0xDEE33B40L,0x89AF7C33L,0x3EACDC21L,0xCDF77975L,0x0D7234A5L}},{{0x13D57FD8L,1L,0xE828885FL,3L,0xDEE33B40L,0x3EACDC21L,0L,(-1L)},{0xCDF77975L,1L,0x0700DBA2L,0x40F4DD00L,(-1L),0x05AB8D24L,0x55AF3429L,0x05AB8D24L},{(-1L),0xE828885FL,(-1L),0xE828885FL,(-1L),(-3L),0x66F2900EL,0x55AF3429L}}};
                uint64_t l_3456[3][2];
                const uint8_t l_3470 = 253UL;
                uint64_t ***l_3489 = (void*)0;
                uint8_t ** const ***l_3511[5];
                int8_t ***l_3533 = (void*)0;
                int i, j, k;
                for (i = 0; i < 3; i++)
                {
                    for (j = 0; j < 2; j++)
                        l_3456[i][j] = 7UL;
                }
                for (i = 0; i < 5; i++)
                    l_3511[i] = &l_3508;
                for (g_3067.f2 = 0; (g_3067.f2 >= 3); ++g_3067.f2)
                { /* block id: 1536 */
                    uint32_t *l_3438[7] = {&l_3338,&l_3338,&l_3338,&l_3338,&l_3338,&l_3338,&l_3338};
                    int32_t l_3440 = (-6L);
                    int32_t l_3442 = 1L;
                    int32_t l_3443 = (-8L);
                    int32_t l_3445[10];
                    int64_t l_3455 = 0xB96A8ABE4D1F7615LL;
                    int32_t ****l_3477[7] = {&g_2329,&g_2329,&g_2329,&g_2329,&g_2329,&g_2329,&g_2329};
                    uint64_t ***l_3490 = &l_3055;
                    int i;
                    for (i = 0; i < 10; i++)
                        l_3445[i] = 0xECA8F35DL;
                    if ((((safe_sub_func_uint64_t_u_u((safe_sub_func_uint32_t_u_u(((*l_3385) ^ 1UL), (((((!(safe_mul_func_uint8_t_u_u(((safe_mul_func_uint8_t_u_u(1UL, ((safe_sub_func_uint8_t_u_u(((*g_1181) = l_3415), ((***l_2353) = (-9L)))) & (safe_add_func_int64_t_s_s((g_3418 , (-10L)), ((safe_sub_func_uint16_t_u_u((~(((safe_div_func_uint64_t_u_u(((safe_lshift_func_uint32_t_u_s((((safe_div_func_int16_t_s_s(((!((g_1604 = (((*g_1997)--) ^ ((*****l_3324) = ((safe_rshift_func_int64_t_s_s((((safe_add_func_int64_t_s_s(0x580F7CC9A37F00AALL, (safe_mul_func_uint8_t_u_u(((((0xFCEDD9D4L && l_3415) , p_23) < p_24) & p_24), p_22)))) < p_24) == 18446744073709551612UL), 30)) < p_22)))) > l_3439)) >= p_20), p_23)) > 0x1AADL) , (*g_1997)), 29)) || l_3415), 0x28369DE77A02F408LL)) < (*g_142)) && 4L)), p_24)) <= (*g_142))))))) || p_20), p_22))) || 0x26L) == l_3415) ^ l_3440) <= l_3441))), (*g_3194))) || 0L) , 9L))
                    { /* block id: 1542 */
                        uint8_t l_3448[4];
                        int32_t l_3452 = (-8L);
                        int32_t l_3453 = 1L;
                        int32_t l_3454[10][1] = {{0x8755B575L},{0x30A55396L},{0x8755B575L},{0x30A55396L},{0x8755B575L},{0x30A55396L},{0x8755B575L},{0x30A55396L},{0x8755B575L},{0x30A55396L}};
                        int i, j;
                        for (i = 0; i < 4; i++)
                            l_3448[i] = 246UL;
                        l_3448[0]++;
                        l_3456[1][1]--;
                        if (l_3459)
                            continue;
                        (****g_2328) = (safe_sub_func_uint64_t_u_u(((safe_mod_func_int64_t_s_s((((safe_sub_func_int16_t_s_s((safe_mod_func_int64_t_s_s((safe_mul_func_uint32_t_u_u((*l_2624), l_3470)), (((safe_mod_func_int32_t_s_s(((*p_21) &= ((void*)0 == (*g_1122))), ((((((((0xDF03L && (safe_add_func_int32_t_s_s(((void*)0 != l_3477[2]), ((*g_1997) |= 0x4F3E2F97L)))) == (((((**l_3191)--) < ((safe_rshift_func_uint16_t_u_s((safe_div_func_int32_t_s_s(((***g_2329) , (*g_94)), 0x75162DB1L)), 1)) >= 0xECA888E3L)) , p_24) == 0UL)) > l_3447[1][2][3]) ^ 8L) && (*l_3385)) , g_1854) == (void*)0) ^ l_3448[2]))) || l_3470) , p_22))), p_23)) && p_24) , (-5L)), 3UL)) >= 0x5DCC4A81EDD6392BLL), 0UL));
                    }
                    else
                    { /* block id: 1550 */
                        (**g_2329) = ((0xA836L <= (safe_add_func_int64_t_s_s((((((safe_div_func_uint64_t_u_u(((l_3489 = (l_3488[0] = &g_3193[1][6])) != l_3490), (safe_mul_func_int32_t_s_s(((*g_142) , (safe_lshift_func_uint64_t_u_s(((((((p_23 == ((void*)0 == l_3277)) & ((*g_3194) &= ((*g_1124) != (1UL <= 0x1F4DC796CA07D05DLL)))) > l_3447[2][0][6]) ^ (-10L)) | 0x1DL) & p_22), 31))), p_22)))) , l_3497) > l_3415) > 0x739CL) >= p_20), 18446744073709551612UL))) , (*g_289));
                        return (*g_1003);
                    }
                }
                l_3315 ^= (safe_sub_func_uint64_t_u_u((((safe_lshift_func_int16_t_s_s((safe_div_func_uint8_t_u_u(((((*g_783) = (4294967289UL != (!(!(&g_1549[8][1][3] == (g_3515 = (l_3512 = l_3508))))))) == (&p_23 == (l_3523[0] = (void*)0))) >= (((l_3447[3][0][4] |= ((((*****l_3324) || ((safe_mul_func_uint32_t_u_u((safe_mod_func_uint8_t_u_u((((((safe_add_func_int64_t_s_s(((safe_mul_func_uint32_t_u_u(((*p_21) || p_23), 0UL)) <= p_20), 0x8DECDD392A38D4BFLL)) , (*g_1124)) <= (*l_3385)) , 0x6C269399L) | 0xFEB5C0DBL), (-10L))), (**g_289))) ^ 0x291E4ED9L)) , l_3532) != l_3533)) || 0x3A4A7168L) | (*l_2624))), 0x46L)), 9)) < (*g_1997)) , 0x3F1FD6FA07BE817ELL), p_20));
            }
            (*g_804) |= ((p_23 ^ p_24) <= (safe_rshift_func_int64_t_s_s((*l_2624), 13)));
            (****g_2328) = (*p_21);
        }
        if ((*l_2624))
        { /* block id: 1568 */
            int64_t l_3548 = (-3L);
            int32_t l_3555 = 0x17EFE1D2L;
            uint64_t l_3571 = 5UL;
        }
        else
        { /* block id: 1605 */
            const int32_t **l_3623 = (void*)0;
            const int32_t *l_3625[6][9][2] = {{{&g_3626,&g_3626},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_3626,&g_3626},{&g_3626,&g_3626},{(void*)0,&g_3626},{(void*)0,&g_3626},{&g_3626,&g_3626}},{{&g_3626,(void*)0},{(void*)0,(void*)0},{(void*)0,(void*)0},{(void*)0,&g_3626},{&g_3626,(void*)0},{&g_3626,(void*)0},{&g_3626,&g_3626},{(void*)0,(void*)0},{&g_3626,&g_3626}},{{&g_3626,&g_3626},{&g_3626,(void*)0},{&g_3626,(void*)0},{(void*)0,(void*)0},{(void*)0,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626}},{{&g_3626,&g_3626},{&g_3626,&g_3626},{(void*)0,&g_3626},{(void*)0,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626}},{{&g_3626,&g_3626},{(void*)0,(void*)0},{(void*)0,(void*)0},{&g_3626,&g_3626},{&g_3626,(void*)0},{(void*)0,(void*)0},{&g_3626,&g_3626},{&g_3626,(void*)0},{(void*)0,(void*)0}},{{(void*)0,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626},{&g_3626,&g_3626},{(void*)0,&g_3626},{(void*)0,&g_3626}}};
            const int32_t **l_3624 = &l_3625[1][1][0];
            int i, j, k;
            g_3627 = ((*l_3624) = p_21);
        }
    }
    (*l_2624) = ((*g_142) , (*g_3108));
    (****l_3324) = (void*)0;
    g_3631 = l_2609;
    return p_21;
}


/* ------------------------------------------ */
/* 
 * reads :
 * writes:
 */
static int32_t  func_27(uint32_t  p_28, const int8_t  p_29, uint32_t  p_30, int8_t  p_31, uint16_t  p_32)
{ /* block id: 1 */
    int8_t l_805 = 1L;
    int16_t l_807 = 0xBB48L;
    uint64_t *l_812 = &g_154;
    int32_t l_855 = (-4L);
    int32_t l_909 = 0L;
    uint32_t *l_958 = (void*)0;
    uint32_t **l_957[8] = {(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0,(void*)0};
    int16_t **l_959 = &g_783;
    uint32_t *l_963 = &g_531.f0;
    uint32_t **l_962 = &l_963;
    uint32_t l_1032 = 0x40AC1872L;
    int8_t l_1046[8] = {0x8DL,(-7L),0x8DL,(-7L),0x8DL,(-7L),0x8DL,(-7L)};
    int32_t l_1092 = 0xEA81B784L;
    int32_t l_1110 = (-1L);
    int32_t l_1111[7][3][4] = {{{0xC2C784E2L,(-2L),0L,0x529DAF1EL},{0x27509FD8L,0x36A54955L,0x99823A7EL,0x0D46D4A8L},{(-10L),1L,0x2A542AA2L,0x0D46D4A8L}},{{(-2L),0x36A54955L,0xBD04E8BFL,0x529DAF1EL},{(-1L),(-2L),(-1L),0L},{0x2A542AA2L,0x89A1C2AEL,8L,0x36A54955L}},{{0x0D46D4A8L,(-1L),0x529DAF1EL,0x89A1C2AEL},{0xD00C2C14L,0xF55B9547L,0x529DAF1EL,1L},{0x0D46D4A8L,0xA738AF71L,8L,8L}},{{0x2A542AA2L,0x2A542AA2L,(-1L),0xD00C2C14L},{(-1L),0xD00C2C14L,0xBD04E8BFL,(-2L)},{(-2L),0x27509FD8L,0x2A542AA2L,0xBD04E8BFL}},{{(-10L),0x27509FD8L,0x99823A7EL,(-2L)},{0x27509FD8L,0xD00C2C14L,0L,0xD00C2C14L},{0xC2C784E2L,0x2A542AA2L,0x89A1C2AEL,8L}},{{0L,0xA738AF71L,0xF55B9547L,1L},{8L,0xF55B9547L,0x27509FD8L,0x89A1C2AEL},{8L,(-1L),0xF55B9547L,0x36A54955L}},{{0L,0x89A1C2AEL,0x89A1C2AEL,0L},{0xC2C784E2L,(-2L),0L,0x529DAF1EL},{0x27509FD8L,0x36A54955L,0x99823A7EL,0x0D46D4A8L}}};
    union U0 *l_1133 = &g_264[0][2][6];
    int16_t l_1162[4][10][6] = {{{0x6B67L,(-4L),0x6B67L,0L,0xFF62L,0L},{0x6B67L,0x5E7BL,0L,0L,0x4F1CL,0x2C27L},{0x6B67L,0xE671L,(-1L),0L,(-1L),0L},{0x6B67L,(-4L),0x6B67L,0L,0xFF62L,0L},{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)},{0x2180L,0x2C27L,0x3619L,0x751EL,0x6B67L,0x751EL},{0x2180L,0L,0x2180L,0x751EL,(-1L),0L},{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)},{0x2180L,0x2C27L,0x3619L,0x751EL,0x6B67L,0x751EL},{0x2180L,0L,0x2180L,0x751EL,(-1L),0L}},{{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)},{0x2180L,0x2C27L,0x3619L,0x751EL,0x6B67L,0x751EL},{0x2180L,0L,0x2180L,0x751EL,(-1L),0L},{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)},{0x2180L,0x2C27L,0x3619L,0x751EL,0x6B67L,0x751EL},{0x2180L,0L,0x2180L,0x751EL,(-1L),0L},{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)},{0x2180L,0x2C27L,0x3619L,0x751EL,0x6B67L,0x751EL},{0x2180L,0L,0x2180L,0x751EL,(-1L),0L},{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)}},{{0x2180L,0x2C27L,0x3619L,0x751EL,0x6B67L,0x751EL},{0x2180L,0L,0x2180L,0x751EL,(-1L),0L},{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)},{0x2180L,0x2C27L,0x3619L,0x751EL,0x6B67L,0x751EL},{0x2180L,0L,0x2180L,0x751EL,(-1L),0L},{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)},{0x2180L,0x2C27L,0x3619L,0x751EL,0x6B67L,0x751EL},{0x2180L,0L,0x2180L,0x751EL,(-1L),0L},{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)},{0x2180L,0x2C27L,0x3619L,0x751EL,0x6B67L,0x751EL}},{{0x2180L,0L,0x2180L,0x751EL,(-1L),0L},{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)},{0x2180L,0x2C27L,0x3619L,0x751EL,0x6B67L,0x751EL},{0x2180L,0L,0x2180L,0x751EL,(-1L),0L},{0x2180L,0L,0x0A12L,0x751EL,0L,(-7L)},{0x2180L,0x2C27L,0x3619L,(-4L),0x2180L,(-4L)},{0x4F1CL,0L,0x4F1CL,(-4L),0x3619L,0xE671L},{0x4F1CL,0x751EL,0xFF62L,(-4L),0x0A12L,0x5E7BL},{0x4F1CL,(-7L),(-1L),(-4L),0x2180L,(-4L)},{0x4F1CL,0L,0x4F1CL,(-4L),0x3619L,0xE671L}}};
    int64_t l_1163[9];
    uint8_t *l_1182 = &g_199[6][0][5];
    int32_t l_1205 = 0x9049AFD6L;
    int32_t **l_1256[4];
    int8_t **l_1258[4];
    union U1 ***l_1372 = (void*)0;
    int16_t l_1444 = 0L;
    const int64_t *l_1449 = (void*)0;
    const int64_t * const *l_1448[8][3] = {{&l_1449,&l_1449,&l_1449},{&l_1449,&l_1449,&l_1449},{&l_1449,&l_1449,&l_1449},{&l_1449,&l_1449,&l_1449},{&l_1449,&l_1449,&l_1449},{&l_1449,&l_1449,&l_1449},{&l_1449,&l_1449,&l_1449},{&l_1449,&l_1449,&l_1449}};
    const int64_t * const **l_1447[4][7];
    uint8_t l_1458[10][10][2] = {{{0x03L,3UL},{3UL,2UL},{9UL,0UL},{252UL,0UL},{0UL,0xE1L},{0xD8L,0x5AL},{3UL,0x71L},{0x0BL,0x0FL},{0xF7L,1UL},{7UL,1UL}},{{0xF7L,0x0FL},{0x0BL,0x71L},{3UL,0x5AL},{0xD8L,0xE1L},{0UL,0UL},{252UL,0UL},{9UL,2UL},{3UL,3UL},{0x03L,0x43L},{0xF7L,0UL}},{{0xD3L,1UL},{252UL,3UL},{0x22L,0x54L},{0UL,0x5AL},{0x03L,0UL},{2UL,1UL},{251UL,3UL},{0x03L,0xF7L},{3UL,0x54L},{0x0BL,246UL}},{{252UL,0xD3L},{1UL,0UL},{3UL,3UL},{0x03L,0x71L},{0UL,2UL},{0xD3L,3UL},{252UL,0UL},{251UL,0xE1L},{9UL,3UL},{3UL,252UL}},{{0x22L,0x0FL},{3UL,0xD3L},{7UL,1UL},{0x5AL,0x0FL},{0x60L,3UL},{3UL,0xF7L},{0xD3L,0xE1L},{2UL,252UL},{252UL,0UL},{0xD8L,2UL}},{{0UL,252UL},{0x03L,246UL},{0x5AL,0UL},{1UL,1UL},{252UL,0x43L},{0x60L,0x54L},{0UL,3UL},{0x03L,0UL},{0UL,1UL},{0UL,0UL}},{{0x03L,3UL},{0UL,0x54L},{0x60L,0x43L},{252UL,1UL},{1UL,0UL},{0x5AL,246UL},{0x03L,252UL},{0UL,2UL},{0xD8L,0UL},{252UL,252UL}},{{0x0FL,0x71L},{0x03L,7UL},{0x72L,0x03L},{252UL,0x8CL},{0UL,9UL},{0x10L,0x75L},{255UL,0x8CL},{0xEFL,0x4CL},{0x72L,255UL},{0x2FL,0x71L}},{{0x9CL,0x2BL},{1UL,0x80L},{0x03L,254UL},{1UL,0xADL},{0UL,2UL},{255UL,0xDEL},{9UL,0x75L},{251UL,0UL},{9UL,0x9CL},{0x80L,7UL}},{{1UL,0x80L},{0x9CL,0x49L},{0x0FL,4UL},{1UL,0UL},{4UL,0x9CL},{0xEFL,2UL},{251UL,9UL},{0x75L,0xDEL},{7UL,252UL},{0UL,0x03L}}};
    uint8_t l_1478[9] = {0xBCL,0x50L,0xBCL,0x50L,0xBCL,0x50L,0xBCL,0x50L,0xBCL};
    int32_t l_1581 = (-1L);
    int64_t ***** const l_1588 = (void*)0;
    int32_t l_1685[4][4] = {{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L},{1L,1L,1L,1L}};
    int32_t l_1760 = 0L;
    uint32_t l_1807 = 0xB712F2A4L;
    uint32_t l_1933 = 0x2F43CFB5L;
    uint32_t l_1993 = 18446744073709551615UL;
    uint32_t ***l_2006 = &l_957[2];
    int32_t * const *l_2033 = (void*)0;
    uint64_t **l_2066[9][7][4] = {{{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,(void*)0,(void*)0},{&l_812,&l_812,(void*)0,&l_812}},{{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,&l_812}},{{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,(void*)0,(void*)0},{&l_812,&l_812,(void*)0,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812}},{{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812}},{{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812}},{{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,&l_812}},{{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812}},{{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,(void*)0},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812}},{{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,&l_812},{&l_812,&l_812,&l_812,(void*)0}}};
    uint64_t ***l_2065 = &l_2066[7][0][2];
    uint8_t * const * const **l_2083 = (void*)0;
    uint8_t * const * const ***l_2082 = &l_2083;
    int16_t *** const l_2126 = (void*)0;
    int32_t l_2138 = 0x187FDBBBL;
    uint8_t l_2154[7] = {250UL,250UL,250UL,250UL,250UL,250UL,250UL};
    int8_t l_2188[2][7][7] = {{{0x7FL,2L,0xC7L,2L,0x7FL,0x7FL,2L},{(-1L),0x38L,(-1L),2L,2L,(-1L),0x38L},{2L,0x38L,0xC7L,0xC7L,0x38L,2L,0x38L},{(-1L),2L,2L,(-1L),0x38L,(-1L),2L},{0x7FL,0x7FL,2L,0xC7L,2L,0x7FL,0x7FL},{0x7FL,2L,0x38L,(-1L),2L,2L,(-1L)},{0xC7L,0x7FL,0xC7L,(-1L),(-1L),0xC7L,0x7FL}},{{(-1L),0x7FL,0x38L,0x38L,0x7FL,(-1L),0x7FL},{0xC7L,(-1L),(-1L),0xC7L,0x7FL,0xC7L,(-1L)},{2L,2L,(-1L),0x38L,(-1L),2L,2L},{2L,(-1L),0x38L,(-1L),2L,2L,(-1L)},{0xC7L,0x7FL,0xC7L,(-1L),(-1L),0xC7L,0x7FL},{(-1L),0x7FL,0x38L,0x38L,0x7FL,(-1L),0x7FL},{0xC7L,(-1L),(-1L),0xC7L,0x7FL,0xC7L,(-1L)}}};
    int16_t l_2199 = 0x361AL;
    int i, j, k;
    for (i = 0; i < 9; i++)
        l_1163[i] = 3L;
    for (i = 0; i < 4; i++)
        l_1256[i] = &g_804;
    for (i = 0; i < 4; i++)
        l_1258[i] = &g_1124;
    for (i = 0; i < 4; i++)
    {
        for (j = 0; j < 7; j++)
            l_1447[i][j] = &l_1448[1][2];
    }
    return p_31;
}


/* ------------------------------------------ */
/* 
 * reads : g_10 g_74 g_74.f0 g_90 g_93 g_94 g_95 g_98 g_86 g_88 g_199 g_203 g_204 g_124 g_143 g_141 g_142 g_181 g_182 g_252.f0 g_267 g_289 g_305 g_328 g_204.f0 g_356 g_186 g_360 g_363 g_375 g_419 g_381 g_435 g_356.f0 g_531.f0 g_516 g_154 g_430 g_555.f0 g_608 g_400 g_633 g_613 g_305.f0 g_252.f1 g_804 g_783 g_765
 * writes: g_86 g_88 g_90 g_98 g_95 g_143 g_154 g_10 g_267 g_94 g_311 g_199 g_252.f1 g_375 g_381 g_430 g_434 g_531.f0 g_182 g_613 g_124 g_328
 */
static int16_t  func_36(uint32_t  p_37)
{ /* block id: 2 */
    int32_t l_63 = (-8L);
    int32_t l_75[9][4] = {{0x8A59C2D1L,0x6275F98AL,(-3L),0x746AC1DEL},{0x30A264F7L,0x7D63F7CEL,0x9FD593B8L,(-3L)},{(-3L),0x7D63F7CEL,0x90CFFAE3L,0x746AC1DEL},{0x7D63F7CEL,0x6275F98AL,0x7D63F7CEL,0xA1B4BC71L},{0xA615B38DL,0x90CFFAE3L,6L,0x30A264F7L},{0x8B108A66L,0xA615B38DL,0xA1B4BC71L,0x90CFFAE3L},{0x746AC1DEL,0x4D4A52D8L,0xA1B4BC71L,0L},{0x8B108A66L,6L,6L,0x8B108A66L},{0xA615B38DL,0x746AC1DEL,0x7D63F7CEL,(-9L)}};
    int32_t *l_92[10] = {&g_86[8],(void*)0,&g_86[8],&g_86[8],(void*)0,&g_86[8],(void*)0,&g_86[8],&g_86[8],(void*)0};
    int32_t **l_91 = &l_92[6];
    int32_t *l_123 = &g_124;
    int32_t *l_125 = &g_124;
    int i, j;
    (*l_91) = func_38(p_37, (func_42(func_48(g_10, (safe_mul_func_uint32_t_u_u((safe_rshift_func_uint8_t_u_s((safe_add_func_uint32_t_u_u((((*l_91) = func_59((safe_add_func_int8_t_s_s((((l_63 & (safe_mul_func_int16_t_s_s(p_37, ((safe_sub_func_uint32_t_u_u(1UL, (safe_lshift_func_int8_t_s_u((((safe_div_func_uint16_t_u_u((p_37 == p_37), (safe_sub_func_uint64_t_u_u((g_74 , (l_75[5][2] ^= 18446744073709551615UL)), g_10)))) && l_75[5][2]) , 0x6FL), g_10)))) <= g_10)))) & p_37) ^ g_10), l_63)))) != g_93), g_10)), l_63)), 0x5900A0D1L)), g_94, g_95), p_37, p_37, l_123, l_125) , (void*)0), (*l_125));
    return (*g_783);
}


/* ------------------------------------------ */
/* 
 * reads : g_143 g_141 g_94 g_86 g_95 g_142 g_181 g_182 g_252.f0 g_267 g_199 g_74.f0 g_10 g_90 g_289 g_305 g_328 g_203 g_88 g_204 g_204.f0 g_356 g_186 g_360 g_363 g_375 g_419 g_381 g_435 g_356.f0 g_531.f0 g_516 g_154 g_430 g_555.f0 g_124 g_98 g_74 g_608 g_400 g_633 g_613 g_305.f0 g_252.f1 g_804
 * writes: g_143 g_154 g_86 g_95 g_10 g_267 g_88 g_90 g_94 g_311 g_98 g_199 g_252.f1 g_375 g_381 g_430 g_434 g_531.f0 g_182 g_613 g_124 g_328
 */
static int32_t * func_38(int8_t  p_39, int32_t * p_40, int8_t  p_41)
{ /* block id: 62 */
    int8_t l_226 = 5L;
    int32_t l_233[4] = {0x73CDD720L,0x73CDD720L,0x73CDD720L,0x73CDD720L};
    union U1 * const l_251 = &g_252;
    union U1 * const *l_250 = &l_251;
    int64_t *l_275 = &g_98;
    int64_t **l_274 = &l_275;
    uint16_t l_302 = 65535UL;
    union U0 **l_343 = &g_311;
    int32_t l_358 = 0L;
    int8_t l_361 = 1L;
    const uint32_t l_362 = 0x873B4EECL;
    uint16_t l_399 = 0x0B22L;
    int16_t * const l_548 = &g_430[0][5][0];
    union U1 ***l_638[2][2][8] = {{{&g_634,&g_634,&g_634,&g_634,&g_634,&g_634,&g_634,&g_634},{&g_634,&g_634,&g_634,&g_634,&g_634,&g_634,&g_634,&g_634}},{{&g_634,&g_634,&g_634,&g_634,&g_634,&g_634,&g_634,&g_634},{&g_634,&g_634,&g_634,&g_634,&g_634,&g_634,&g_634,&g_634}}};
    const int32_t *l_642 = &g_88;
    const int32_t **l_641 = &l_642;
    int8_t *l_656 = &l_361;
    uint32_t *l_659 = &g_613;
    uint64_t *l_660 = &g_154;
    uint8_t l_721 = 0xECL;
    int32_t *l_800[3];
    uint8_t l_801 = 6UL;
    int i, j, k;
    for (i = 0; i < 3; i++)
        l_800[i] = &l_358;
    for (g_143 = 0; (g_143 <= 3); g_143 += 1)
    { /* block id: 65 */
        int64_t *l_223 = &g_98;
        int64_t **l_222 = &l_223;
        int32_t l_225[7] = {0x72028F88L,0x72028F88L,0x6AAEAA36L,0x72028F88L,0x72028F88L,0x6AAEAA36L,0x72028F88L};
        union U0 *l_263 = &g_264[1][0][2];
        union U0 **l_262[5] = {&l_263,&l_263,&l_263,&l_263,&l_263};
        int8_t l_332 = 0x24L;
        int64_t l_413 = 1L;
        uint8_t l_416 = 252UL;
        uint32_t l_528[9][9] = {{9UL,4UL,9UL,4UL,9UL,4UL,9UL,4UL,9UL},{0x20052A78L,0x20052A78L,0UL,0UL,0x20052A78L,0x20052A78L,0UL,0UL,0x20052A78L},{0xCBF7AA0FL,4UL,0xCBF7AA0FL,4UL,0xCBF7AA0FL,4UL,0xCBF7AA0FL,4UL,0xCBF7AA0FL},{0x20052A78L,0UL,0UL,0x20052A78L,0x20052A78L,0UL,0UL,0x20052A78L,0x20052A78L},{9UL,4UL,9UL,4UL,9UL,4UL,9UL,4UL,9UL},{0x20052A78L,0x20052A78L,0UL,0UL,0x20052A78L,0x20052A78L,0UL,0UL,0x20052A78L},{0xCBF7AA0FL,4UL,0xCBF7AA0FL,4UL,0xCBF7AA0FL,4UL,0xCBF7AA0FL,4UL,0xCBF7AA0FL},{0x20052A78L,0UL,0UL,0x20052A78L,0x20052A78L,0UL,0UL,0x20052A78L,0x20052A78L},{9UL,4UL,9UL,4UL,9UL,4UL,9UL,4UL,9UL}};
        int i, j;
        for (p_39 = 0; (p_39 <= 0); p_39 += 1)
        { /* block id: 68 */
            int32_t l_224 = 0xB2A87EBEL;
            uint64_t *l_227 = &g_154;
            int32_t l_234 = 0x2B1841E3L;
            int32_t l_235 = 0x2857B4A2L;
            int32_t l_236 = 0x6D0B68B8L;
            int32_t l_237 = 4L;
            int32_t l_238 = 0xDE274A18L;
            int32_t l_239[7][9] = {{(-1L),0x0E80A90BL,(-1L),(-1L),0x32907F09L,(-6L),1L,(-2L),1L},{(-1L),(-6L),(-1L),6L,(-1L),0x5766FAAAL,(-1L),6L,(-1L)},{(-6L),(-6L),0x3CDDC259L,(-2L),(-1L),0x3CE50976L,(-7L),0x5766FAAAL,0xD5E848DCL},{(-1L),0x0E80A90BL,0x05452BFEL,0L,0L,1L,1L,0x4E8FA73DL,(-8L)},{(-1L),1L,0x3CDDC259L,0xE2A525CEL,0x5A7F0FC9L,0x82F56F0CL,(-2L),0x82F56F0CL,0x5A7F0FC9L},{0xE2A525CEL,(-1L),(-1L),0xE2A525CEL,0x397170A3L,0x05452BFEL,0x5766FAAAL,0x0E80A90BL,(-2L)},{0x3CE50976L,0xD5E848DCL,(-1L),0L,0x3CDDC259L,6L,0x05452BFEL,0xE2A525CEL,0x82F56F0CL}};
            uint32_t l_298 = 1UL;
            union U0 * const l_310 = &g_264[0][3][5];
            uint64_t l_410 = 0UL;
            uint16_t l_446 = 0x459AL;
            int i, j;
            if (((safe_add_func_uint32_t_u_u(0xDA36ACC4L, (**g_141))) == ((safe_lshift_func_int32_t_s_u(0x6B0FEA9BL, 30)) , ((&g_172 != &g_172) > (((safe_lshift_func_int16_t_s_u((((((*l_227) = (safe_rshift_func_int32_t_s_s((!(safe_mod_func_uint16_t_u_u((safe_mod_func_int8_t_s_s(((p_39 && (safe_mod_func_uint8_t_u_u((safe_lshift_func_uint16_t_u_u(((void*)0 != l_222), 14)), p_41))) | l_224), g_86[2])), l_225[5]))), l_226))) & 0xADC50922C1D3B67BLL) ^ l_225[5]) <= 0x0B2EBA6A255FDD9BLL), (*g_142))) | p_41) > l_225[5])))))
            { /* block id: 70 */
                int32_t *l_228 = &g_95;
                int32_t *l_229 = &g_86[3];
                int32_t *l_230 = &l_224;
                int32_t *l_231 = &g_86[3];
                int32_t *l_232[8][5][6] = {{{&g_90,(void*)0,&l_224,(void*)0,&l_225[5],(void*)0},{&g_95,&g_90,&l_224,&g_86[6],(void*)0,&g_90},{&l_225[5],&g_86[6],(void*)0,&l_224,(void*)0,&g_90},{&l_224,(void*)0,&g_90,&l_225[5],(void*)0,&g_88},{&l_225[3],&l_225[5],&g_86[3],&g_88,&l_224,&g_86[2]}},{{&l_224,&l_224,&g_88,&g_90,(void*)0,&l_225[5]},{&g_86[6],&l_224,&g_90,&g_90,(void*)0,(void*)0},{&g_90,&g_90,(void*)0,&l_224,&g_90,&g_86[3]},{&l_225[5],(void*)0,&g_90,&g_124,&g_88,(void*)0},{&g_86[3],(void*)0,&l_224,(void*)0,&g_95,(void*)0}},{{(void*)0,&l_225[5],&l_225[5],&l_225[2],(void*)0,&l_225[2]},{(void*)0,&l_225[3],(void*)0,(void*)0,&g_90,&g_90},{(void*)0,&g_124,&g_90,&g_90,&g_88,&l_224},{(void*)0,&l_225[5],(void*)0,&g_90,(void*)0,&l_224},{(void*)0,&g_90,&l_225[5],&l_224,&l_225[5],&g_124}},{{(void*)0,&g_86[6],&g_90,&g_88,&g_90,&l_224},{(void*)0,&g_95,&g_86[3],&l_224,(void*)0,&g_90},{&l_225[5],&g_86[3],&g_124,(void*)0,&l_224,&g_95},{&g_86[3],&g_95,&g_90,&g_124,(void*)0,(void*)0},{&l_224,&g_86[2],&l_225[3],&g_90,&g_95,&l_225[5]}},{{&l_224,&g_90,&g_90,&l_225[5],&l_224,(void*)0},{&l_225[0],(void*)0,&g_86[3],(void*)0,(void*)0,&g_90},{(void*)0,&g_95,&l_225[0],&g_95,&g_95,&g_95},{&g_86[3],&g_90,&g_90,&g_86[3],(void*)0,&g_88},{&l_224,&g_90,(void*)0,&l_224,(void*)0,&l_225[5]}},{{&g_88,&g_90,&g_90,&l_224,(void*)0,(void*)0},{&g_86[5],&g_90,(void*)0,&g_90,(void*)0,&g_86[3]},{(void*)0,&g_90,&l_224,&g_90,&g_95,&g_90},{&g_90,&g_95,&l_225[5],(void*)0,(void*)0,&g_86[5]},{(void*)0,(void*)0,&l_224,&l_225[5],&l_224,&g_95}},{{(void*)0,&g_90,&l_225[5],(void*)0,&g_95,&l_225[5]},{&g_90,&g_86[2],(void*)0,&g_95,(void*)0,&g_90},{&g_88,&g_95,(void*)0,&l_225[2],&l_224,&g_95},{&g_90,&g_86[3],(void*)0,&g_90,(void*)0,&l_224},{&l_225[5],&g_95,&g_86[2],(void*)0,&g_90,(void*)0}},{{&l_225[5],&g_86[6],(void*)0,&g_86[6],&l_225[5],&g_90},{(void*)0,&g_90,(void*)0,&g_90,(void*)0,&g_95},{&l_224,&l_224,&g_86[6],&g_90,&g_124,&g_95},{&g_90,&g_90,(void*)0,&g_90,&g_90,&g_90},{&g_124,(void*)0,(void*)0,&g_90,&l_224,(void*)0}}};
                uint8_t l_240 = 0UL;
                union U0 *l_247[8] = {&g_249,&g_249,&g_249,&g_249,&g_249,&g_249,&g_249,&g_249};
                int i, j, k;
                --l_240;
                (*g_94) &= ((safe_add_func_int64_t_s_s(p_41, (safe_add_func_uint16_t_u_u(0x6513L, p_39)))) < (((*g_181) != l_247[3]) ^ (l_250 == &l_251)));
            }
            else
            { /* block id: 73 */
                int32_t *l_261 = (void*)0;
                uint16_t *l_265 = (void*)0;
                uint16_t *l_266 = &g_267;
                int32_t l_279 = 5L;
                int32_t l_281 = 0x4D869262L;
                int32_t l_282 = 8L;
                int16_t l_283 = (-1L);
                int64_t ***l_306 = &l_274;
                uint32_t l_312 = 0UL;
                int32_t *l_333 = &l_279;
                if ((safe_lshift_func_int8_t_s_u((((*l_266) |= ((safe_div_func_int8_t_s_s((p_39 , (g_10 = (safe_sub_func_int32_t_s_s(((*g_94) = (*g_94)), (l_234 ^= (l_239[4][2] = (l_235 = (safe_rshift_func_uint16_t_u_u(l_226, 4))))))))), g_252.f0)) & (l_262[1] == &l_263))) == ((6UL >= g_199[3][0][8]) != (safe_lshift_func_int8_t_s_s(((safe_lshift_func_uint64_t_u_u((g_143 == p_39), g_143)) , 0x0EL), 7)))), 7)))
                { /* block id: 80 */
                    const uint32_t l_276 = 4294967295UL;
                    int32_t l_280 = 0x9027E9D7L;
                    int32_t l_284 = 0xA0BE485BL;
                    uint32_t l_285[8][8] = {{0x98B52443L,0UL,1UL,4294967290UL,1UL,0UL,0x98B52443L,0x98B52443L},{0UL,4294967290UL,0x897DB634L,0x897DB634L,4294967290UL,0UL,0UL,0UL},{4294967290UL,0UL,0UL,0UL,4294967290UL,0x897DB634L,0x897DB634L,4294967290UL},{0UL,4294967290UL,4294967290UL,0x98B52443L,0xF0F9607CL,0x897DB634L,0xF0F9607CL,0x98B52443L},{4294967290UL,0xF0F9607CL,4294967290UL,0UL,1UL,1UL,0UL,4294967290UL},{0xF0F9607CL,0xF0F9607CL,1UL,0x897DB634L,0UL,0x897DB634L,1UL,0xF0F9607CL},{0xF0F9607CL,4294967290UL,0UL,1UL,1UL,0UL,4294967290UL,0xF0F9607CL},{4294967290UL,0x98B52443L,0xF0F9607CL,0x897DB634L,0xF0F9607CL,0x98B52443L,4294967290UL,4294967290UL}};
                    int32_t l_301 = 0xC505894CL;
                    int i, j;
                    (*g_94) ^= (safe_sub_func_uint64_t_u_u(p_41, (l_226 , ((void*)0 != l_274))));
                    if (l_276)
                    { /* block id: 82 */
                        int32_t *l_277 = &l_225[5];
                        int32_t *l_278[2][6][3] = {{{&g_86[3],&g_86[3],&g_86[1]},{&g_95,&l_234,&g_86[1]},{&l_234,(void*)0,&l_239[1][4]},{&g_95,(void*)0,&g_88},{&g_86[3],&l_234,&l_239[1][4]},{&g_86[3],&g_86[3],&g_86[1]}},{{&g_95,&l_234,&g_86[1]},{&l_234,(void*)0,&l_239[1][4]},{&g_95,(void*)0,&g_88},{&g_86[3],&l_234,&l_239[1][4]},{&g_86[3],&g_86[3],&g_86[1]},{&g_95,&l_234,&g_86[1]}}};
                        int i, j, k;
                        l_285[3][4]--;
                        return (*g_141);
                    }
                    else
                    { /* block id: 85 */
                        int32_t **l_288 = (void*)0;
                        int32_t *l_290 = (void*)0;
                        int32_t *l_291 = &l_238;
                        int32_t *l_292 = &l_224;
                        int32_t *l_293 = (void*)0;
                        int32_t *l_294 = &g_86[3];
                        int32_t *l_295 = &l_224;
                        int32_t *l_296 = &l_224;
                        int32_t *l_297[9] = {&g_88,&g_88,(void*)0,&g_88,&g_88,(void*)0,&g_88,&g_88,(void*)0};
                        int i;
                        (*g_289) = func_59(l_234);
                        l_298--;
                        l_302++;
                        if (l_225[4])
                            continue;
                    }
                    if ((((&l_274 != (g_305 , l_306)) , ((safe_rshift_func_int8_t_s_s(((!((l_312 = (l_310 == (g_311 = &g_248[0]))) & l_284)) > (safe_add_func_int8_t_s_s(l_281, (l_225[5] && ((!((safe_unary_minus_func_uint64_t_u((((safe_lshift_func_int16_t_s_s(0x0723L, 2)) > p_39) && l_233[0]))) == (-1L))) == 5UL))))), 2)) , (-7L))) > 4294967286UL))
                    { /* block id: 93 */
                        return p_40;
                    }
                    else
                    { /* block id: 95 */
                        (*g_94) = 1L;
                    }
                }
                else
                { /* block id: 98 */
                    uint16_t *l_331 = &g_143;
                    l_233[0] &= (safe_div_func_int64_t_s_s(((((safe_add_func_uint64_t_u_u((3L > (&g_154 != (void*)0)), ((safe_div_func_uint8_t_u_u((func_42((*g_141), (((~(0xADB1L > g_328)) | p_39) , (safe_mod_func_uint32_t_u_u(((void*)0 != l_331), 7UL))), l_332, &g_88, l_333) , 255UL), p_41)) < 0xBA3B6F34L))) && 0x88L) <= l_226) == 0xAB086092L), 0x1231886F5698E3EBLL));
                }
                if (((safe_sub_func_int32_t_s_s(((-1L) || (safe_mul_func_uint32_t_u_u((((~g_204[0][4].f0) ^ (g_199[5][0][7] > ((safe_lshift_func_int32_t_s_s((&l_310 == l_343), (safe_mul_func_uint32_t_u_u((((*l_333) = (safe_mul_func_uint8_t_u_u((l_298 == (((+(0xFB57526DL > p_41)) , (safe_mod_func_int32_t_s_s((-1L), l_239[2][8]))) || g_267)), l_302))) ^ 0UL), 0x639F2C87L)))) , p_39))) , 0x218ACDD3L), g_267))), (*g_94))) | l_226))
                { /* block id: 102 */
                    if (p_41)
                        break;
                    if (p_41)
                    { /* block id: 104 */
                        return (*g_289);
                    }
                    else
                    { /* block id: 106 */
                        int32_t l_354 = 0x7C6F90B0L;
                        uint8_t *l_355 = &g_199[3][0][8];
                        (*g_94) |= ((((*l_355) = (safe_sub_func_int32_t_s_s((!0xD85A1D1B10ED41A8LL), l_354))) || p_41) || (g_356 , (&g_267 != (void*)0)));
                        return p_40;
                    }
                }
                else
                { /* block id: 111 */
                    return (*g_186);
                }
            }
            (*g_94) = (((!l_233[1]) <= ((l_358 = p_39) || ((!(g_360 == (l_361 , (l_362 , (void*)0)))) < ((g_363 , (void*)0) == (void*)0)))) > p_41);
            for (l_238 = 0; (l_238 <= 3); l_238 += 1)
            { /* block id: 119 */
                int32_t l_369 = 0x215CE016L;
                int32_t l_404 = 0xC37F6B41L;
                int32_t l_405 = 0xB3282372L;
                int32_t l_406 = (-1L);
                int32_t l_408[4][9][6] = {{{0x9DADBE6AL,0x2CBD8DC3L,1L,1L,0x2CBD8DC3L,0x9DADBE6AL},{(-2L),0x07D325DCL,0x5C73ECC8L,(-7L),0L,0xE3FA67C5L},{0L,0xE3FA67C5L,1L,0x9626EB68L,1L,(-7L)},{0L,0x5B9E6084L,0x9626EB68L,(-7L),0x2599E311L,0L},{(-2L),0L,0x15F02B78L,1L,0L,1L},{0x9DADBE6AL,1L,0x2CBD8DC3L,1L,0x9DADBE6AL,2L},{0x5C73ECC8L,0x507879FDL,0x9DADBE6AL,0xD27AAE40L,0xE3FA67C5L,(-7L)},{0L,0x9DADBE6AL,0L,0x507879FDL,(-7L),(-7L)},{1L,(-1L),0x9DADBE6AL,1L,0L,2L}},{{(-7L),0x475CBAC1L,0x2CBD8DC3L,0x5C73ECC8L,1L,1L},{(-1L),0x15F02B78L,0x15F02B78L,(-1L),2L,0L},{0x15F02B78L,8L,0x9626EB68L,0x07D325DCL,(-7L),(-7L)},{0x2ABC9139L,(-1L),1L,0L,(-7L),0xE3FA67C5L},{0xE3FA67C5L,8L,0x5C73ECC8L,(-1L),2L,0x9DADBE6AL},{0L,0x15F02B78L,1L,0L,1L,0L},{8L,0x475CBAC1L,8L,0L,0L,0x2599E311L},{0xD27AAE40L,(-1L),1L,0x15F02B78L,(-7L),1L},{0x2599E311L,0x9DADBE6AL,0xC2D2A07EL,0x15F02B78L,0xE3FA67C5L,(-7L)}},{{0x15F02B78L,0xE3FA67C5L,0L,(-7L),0x5C73ECC8L,0x07D325DCL},{0x507879FDL,0x2599E311L,(-1L),(-1L),(-1L),(-1L)},{(-7L),(-7L),0x9DADBE6AL,0x2ABC9139L,(-7L),0x2599E311L},{0L,(-1L),0x5B9E6084L,8L,(-2L),0x9DADBE6AL},{0x2CBD8DC3L,0L,0x5B9E6084L,0x9626EB68L,(-7L),0x2599E311L},{0L,0x9626EB68L,0x9DADBE6AL,0x5B9E6084L,0x07D325DCL,(-1L)},{0x5B9E6084L,0x07D325DCL,(-1L),0xC2D2A07EL,(-1L),0x07D325DCL},{0x475CBAC1L,8L,0L,0L,0x2599E311L,(-7L)},{0x2599E311L,0x2CBD8DC3L,2L,0xE3FA67C5L,0x9DADBE6AL,(-2L)}},{{(-1L),0x2CBD8DC3L,0L,0x15F02B78L,0x2599E311L,(-7L)},{0xC2D2A07EL,8L,0x507879FDL,0x2599E311L,(-1L),(-1L)},{0x5C73ECC8L,0x07D325DCL,(-2L),(-2L),0x07D325DCL,0x5C73ECC8L},{0xD27AAE40L,0x9626EB68L,0xC2D2A07EL,1L,(-7L),0L},{0x9DADBE6AL,0L,0x2599E311L,(-1L),(-2L),0x475CBAC1L},{0x9DADBE6AL,(-1L),(-1L),1L,(-7L),8L},{0xD27AAE40L,(-7L),0L,(-2L),(-1L),0L},{0x5C73ECC8L,0x2599E311L,0x07D325DCL,0x2599E311L,0x5C73ECC8L,1L},{0xC2D2A07EL,0xE3FA67C5L,0x5C73ECC8L,0x15F02B78L,0L,1L}}};
                int64_t l_414 = (-1L);
                int8_t l_441 = 6L;
                int i, j, k;
                (*g_94) = (**g_141);
                if (l_239[3][2])
                    continue;
                for (l_302 = 0; (l_302 <= 0); l_302 += 1)
                { /* block id: 124 */
                    union U0 * const *l_384 = &l_310;
                    int32_t l_407 = 0xABB5229EL;
                    int32_t l_409 = 0x4E215B42L;
                    int32_t l_415 = 0L;
                    int32_t l_440 = (-1L);
                    int32_t l_442 = (-9L);
                    int32_t l_443 = 0x22DC87E9L;
                    int32_t l_444 = 7L;
                    int32_t l_445 = 9L;
                    int i;
                    for (g_252.f1 = 0; (g_252.f1 <= 1); g_252.f1 += 1)
                    { /* block id: 127 */
                        int32_t *l_364 = (void*)0;
                        int32_t *l_365 = &g_86[2];
                        int32_t *l_366 = &l_233[0];
                        int32_t *l_367 = (void*)0;
                        int32_t *l_368 = (void*)0;
                        int32_t *l_370 = &l_233[0];
                        int32_t *l_371 = &g_88;
                        int32_t *l_372 = (void*)0;
                        int32_t *l_373 = &l_236;
                        int32_t *l_374[6];
                        int16_t *l_380 = &g_381;
                        int i, j, k;
                        for (i = 0; i < 6; i++)
                            l_374[i] = &l_239[4][2];
                        g_375--;
                    }
                    if (g_86[(p_39 + 8)])
                    { /* block id: 135 */
                        int32_t *l_401 = &g_95;
                        int32_t *l_402 = &l_358;
                        int32_t *l_403[10] = {&l_235,&l_225[2],(void*)0,(void*)0,&l_225[2],&l_235,&l_225[2],(void*)0,(void*)0,&l_225[2]};
                        int i;
                        --l_410;
                        ++l_416;
                    }
                    else
                    { /* block id: 138 */
                        int8_t *l_424 = &l_332;
                        int8_t *l_427 = &l_226;
                        int16_t *l_428 = &g_381;
                        int16_t *l_429 = &g_430[0][5][0];
                        int32_t *l_436 = &l_408[3][5][4];
                        int32_t *l_437 = (void*)0;
                        int32_t *l_438 = (void*)0;
                        int32_t *l_439[1];
                        union U1 * volatile **l_450 = (void*)0;
                        union U1 * volatile ***l_449 = &l_450;
                        int i, j, k;
                        for (i = 0; i < 1; i++)
                            l_439[i] = &l_358;
                        (*g_419) = &g_86[(g_143 + 4)];
                        (*g_435) = func_59((safe_rshift_func_int64_t_s_s(((g_434 = ((g_10 = ((((*l_429) = ((*l_428) ^= (safe_mod_func_int16_t_s_s((((*l_424) = g_86[(l_302 + 1)]) == (l_407 , (0x5FL == ((*l_427) = (0xED3FL == (safe_mul_func_uint8_t_u_u(1UL, g_86[(g_143 + 4)]))))))), p_39)))) || l_415) , (+(safe_div_func_int16_t_s_s((((l_407 <= 65535UL) , l_225[5]) | 18446744073709551615UL), 0x98A7L))))) == l_414)) && (*g_142)), l_415)));
                        l_446--;
                        (*l_449) = &g_360;
                    }
                    for (l_415 = 0; (l_415 >= 0); l_415 -= 1)
                    { /* block id: 152 */
                        uint64_t l_451 = 0xAAC90CE0CF0AD12CLL;
                        if (l_451)
                            break;
                    }
                }
                return p_40;
            }
        }
        for (g_90 = 0; (g_90 >= 0); g_90 -= 1)
        { /* block id: 161 */
            uint32_t l_462 = 2UL;
            int32_t l_467 = (-7L);
            uint16_t *l_468 = &g_328;
            int16_t *l_475 = &g_430[0][5][0];
            int64_t * const l_547[3][8] = {{&g_98,&l_413,&g_98,&l_413,&l_413,&l_413,&l_413,&l_413},{&l_413,&g_98,&g_98,&g_98,&g_98,&l_413,&l_413,&g_98},{&l_413,&l_413,&l_413,&g_98,&l_413,&g_98,&l_413,&l_413}};
            int32_t l_558 = 0L;
            union U1 *l_567 = (void*)0;
            union U1 **l_566[10] = {&l_567,&l_567,&l_567,&l_567,&l_567,&l_567,&l_567,&l_567,&l_567,&l_567};
            union U1 ***l_565 = &l_566[1];
            int32_t *l_571[3];
            uint8_t l_572 = 1UL;
            int16_t l_579 = (-10L);
            int32_t l_611 = 0L;
            int i, j;
            for (i = 0; i < 3; i++)
                l_571[i] = &g_88;
            (*g_94) ^= (safe_sub_func_int16_t_s_s((safe_add_func_uint64_t_u_u((safe_rshift_func_uint8_t_u_u((safe_lshift_func_int64_t_s_s((safe_lshift_func_int64_t_s_s(l_462, 16)), ((safe_lshift_func_uint8_t_u_u((l_467 = g_356.f0), 2)) == (l_468 == (void*)0)))), l_462)), l_462)), ((*l_475) = (((safe_mod_func_int64_t_s_s(((safe_div_func_int32_t_s_s((safe_lshift_func_uint8_t_u_s(((p_39 & (g_267 == l_233[1])) > 0UL), 0)), 4294967295UL)) || 18446744073709551615UL), 0xB2DEBEFDAC357CDDLL)) > l_416) >= 0xEFBCL))));
            for (l_399 = 0; (l_399 <= 0); l_399 += 1)
            { /* block id: 167 */
                int32_t l_490 = 1L;
                int32_t *l_505 = &l_467;
                int32_t *l_506 = &l_233[0];
                uint8_t *l_541 = &g_199[3][0][8];
                union U0 ***l_546 = &l_262[2];
                int32_t l_549 = 0L;
                union U1 ***l_568[1][5] = {{&l_566[1],&l_566[1],&l_566[1],&l_566[1],&l_566[1]}};
                int32_t *l_569 = &l_225[2];
                int i, j, k;
            }
            --l_572;
            l_225[5] = ((safe_add_func_int16_t_s_s(g_90, 0xA692L)) <= (!((&g_94 != (void*)0) | ((p_41 && ((void*)0 == &g_199[3][0][8])) < (l_361 , l_416)))));
            for (l_467 = 0; (l_467 <= 3); l_467 += 1)
            { /* block id: 205 */
                int32_t l_578 = 0x224D6D7FL;
                int32_t l_580 = (-5L);
                union U1 ****l_637[3];
                uint64_t *l_643[8][9][3] = {{{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{(void*)0,&g_154,&g_154},{&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154}},{{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,(void*)0},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{(void*)0,(void*)0,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154}},{{&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,(void*)0},{(void*)0,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154}},{{&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,(void*)0},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_531.f2,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154}},{{&g_154,&g_154,&g_154},{&g_154,(void*)0,(void*)0},{(void*)0,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,(void*)0,&g_154},{(void*)0,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154}},{{&g_154,&g_154,&g_154},{&g_531.f2,(void*)0,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154}},{{&g_154,&g_154,&g_154},{&g_154,&g_154,(void*)0},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{(void*)0,(void*)0,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154}},{{&g_154,&g_154,(void*)0},{(void*)0,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154},{&g_154,&g_154,&g_154},{&g_154,(void*)0,&g_154},{&g_154,&g_154,&g_154}}};
                int i, j, k;
                for (i = 0; i < 3; i++)
                    l_637[i] = &g_633;
                for (g_531.f0 = 0; (g_531.f0 <= 3); g_531.f0 += 1)
                { /* block id: 208 */
                    uint8_t l_584 = 0UL;
                    int32_t *l_606 = &g_90;
                    (*g_181) = (void*)0;
                    for (l_462 = 0; (l_462 <= 3); l_462 += 1)
                    { /* block id: 212 */
                        int32_t l_581 = 1L;
                        int32_t l_582 = 1L;
                        int32_t l_583 = 8L;
                        int16_t *l_605 = &g_381;
                        int32_t **l_607 = &l_571[1];
                        uint32_t *l_612 = &g_613;
                        int i, j, k;
                        l_584--;
                        (*l_607) = func_48(p_41, ((~(l_580 > (safe_mod_func_uint16_t_u_u((((safe_rshift_func_int32_t_s_u(((**g_516) = (**g_289)), (safe_lshift_func_int32_t_s_s((&g_90 == (void*)0), 9)))) == g_154) , ((+((safe_sub_func_int16_t_s_s((safe_sub_func_uint64_t_u_u((((((p_41 && (((((*l_605) ^= (safe_div_func_int64_t_s_s((safe_rshift_func_int8_t_s_s((safe_lshift_func_int32_t_s_u((p_41 == ((&l_584 == &g_199[3][0][7]) > 0xBE333ABCL)), g_430[3][3][0])), g_555.f0)), l_361))) == p_41) > 248UL) && 0x5B20689F6E370B90LL)) > g_124) , (void*)0) != (void*)0) == (*g_94)), 0UL)), l_233[g_143])) , 18446744073709551611UL)) | g_98)), l_580)))) ^ l_578), l_606, (*g_142));
                        l_358 &= (**g_186);
                        g_124 |= ((g_608[4][0] , ((**g_400) = ((safe_lshift_func_uint16_t_u_u(0x21A0L, l_233[0])) , l_611))) <= ((*l_612) = 0x39DEBB58L));
                    }
                }
                l_578 ^= (safe_div_func_uint32_t_u_u(((((safe_add_func_int64_t_s_s(0x9D33B9203009B0B0LL, ((safe_div_func_int64_t_s_s((g_74.f0 != (((((safe_mul_func_uint32_t_u_u((safe_sub_func_uint64_t_u_u((l_233[0] = (safe_lshift_func_uint16_t_u_u(((*l_468) ^= (safe_lshift_func_uint8_t_u_s(0xBBL, (safe_add_func_int32_t_s_s(((((~((p_41 <= (safe_rshift_func_int16_t_s_u((((&g_360 == (l_638[0][1][5] = g_633)) , ((p_41 | ((((g_430[0][5][0] , &g_154) != &g_154) , g_430[0][3][0]) >= 0x25L)) && (*g_142))) >= g_143), 10))) < g_154)) >= (*g_142)) , l_641) == (void*)0), 2UL))))), 14))), g_199[3][0][8])), (*g_94))) , &g_613) != p_40) , l_580) > 255UL)), p_41)) < (*g_142)))) , 1UL) > p_39) != 18446744073709551610UL), g_613));
                return (*g_186);
            }
        }
        return (*g_141);
    }
    if ((((l_233[0] = (safe_lshift_func_int16_t_s_s(((*l_548) ^= g_328), 14))) ^ ((((safe_add_func_int8_t_s_s(((safe_div_func_int32_t_s_s((safe_rshift_func_uint32_t_u_s((safe_mul_func_uint64_t_u_u(0x8AD96C658E8D2FD6LL, p_39)), (*l_642))), (*l_642))) <= ((safe_mul_func_int8_t_s_s((p_41 = ((*l_656) = (*l_642))), p_39)) ^ (safe_sub_func_uint8_t_u_u(p_39, (((*l_660) &= ((((*l_659) = (func_42(&l_358, g_305.f0, g_10, p_40, &g_95) , g_95)) < (*l_642)) , 18446744073709551615UL)) & (*l_642)))))), g_143)) != 0x8EL) != 0xE1E28C4015BA1845LL) != g_124)) <= p_39))
    { /* block id: 238 */
        int32_t l_716 = 0xC20C5606L;
        int32_t l_717 = 0x73460722L;
        const int32_t *l_729 = &l_233[0];
        for (g_143 = 0; (g_143 <= 3); g_143 += 1)
        { /* block id: 241 */
            const union U0 **l_664[7][1] = {{&g_182},{&g_182},{&g_182},{&g_182},{&g_182},{&g_182},{&g_182}};
            const union U0 *** const l_663 = &l_664[0][0];
            int32_t l_665 = 0xF09924CDL;
            const union U1 * const l_688 = &g_252;
            const union U1 * const *l_687 = &l_688;
            const union U1 * const * const *l_686 = &l_687;
            const union U1 * const * const **l_685 = &l_686;
            int32_t l_724 = 2L;
            int i, j;
        }
    }
    else
    { /* block id: 322 */
        return p_40;
    }
    for (g_252.f1 = 1; (g_252.f1 >= 55); g_252.f1 = safe_add_func_int8_t_s_s(g_252.f1, 7))
    { /* block id: 327 */
        return p_40;
    }
    --l_801;
    return g_804;
}


/* ------------------------------------------ */
/* 
 * reads : g_90 g_98 g_199 g_95 g_74.f0 g_203 g_88 g_94 g_204
 * writes: g_90 g_98 g_95 g_86
 */
static union U0  func_42(int32_t * p_43, uint32_t  p_44, uint32_t  p_45, int32_t * p_46, int32_t * p_47)
{ /* block id: 20 */
    uint32_t l_136[1];
    int32_t *l_139[2][8][1] = {{{&g_88},{&g_90},{&g_124},{&g_95},{&g_124},{&g_90},{&g_88},{&g_90}},{{&g_124},{&g_95},{&g_124},{&g_90},{&g_88},{&g_90},{&g_124},{&g_95}}};
    int64_t *l_162 = (void*)0;
    int i, j, k;
    for (i = 0; i < 1; i++)
        l_136[i] = 0x2C4F7139L;
    for (g_90 = 9; (g_90 >= 0); g_90 -= 1)
    { /* block id: 23 */
        int64_t l_133 = 0x7A73C59DB3CA632BLL;
        int32_t l_135 = 0xC8C39940L;
        union U1 **l_176 = (void*)0;
        int32_t l_188 = 1L;
        int32_t l_189[8][3] = {{0xDC734EFBL,9L,0xDC734EFBL},{0L,0x7439DE11L,0x311AD503L},{0x28DDFECAL,0x28DDFECAL,0xEEA3259EL},{0xA5BBA217L,0x7439DE11L,0x7439DE11L},{0xEEA3259EL,9L,(-1L)},{0xA5BBA217L,0xD47A3A9AL,0xA5BBA217L},{0x28DDFECAL,0xEEA3259EL,(-1L)},{0L,0L,0x7439DE11L}};
        int i, j;
        for (g_98 = 9; (g_98 >= 3); g_98 -= 1)
        { /* block id: 26 */
            int32_t l_134[4][9] = {{0xC14278DBL,0L,0x3E4BC467L,0xC14278DBL,0x27E885CFL,0xEF88CBA7L,0L,0L,0xEF88CBA7L},{0x1CF2C337L,0L,(-2L),0L,0x1CF2C337L,0x2AFDD6AAL,0L,(-2L),0x3E4BC467L},{0L,0x27E885CFL,(-2L),(-2L),0x27E885CFL,0x3E4BC467L,0x27E885CFL,(-2L),(-2L)},{0x1CF2C337L,0x1CF2C337L,0x3E4BC467L,(-2L),0L,0x2AFDD6AAL,0x1CF2C337L,0L,(-2L)}};
            uint32_t l_155[1];
            union U1 *l_156 = &g_157[3];
            int64_t **l_169[5] = {&l_162,&l_162,&l_162,&l_162,&l_162};
            int64_t ***l_168 = &l_169[0];
            uint64_t l_193[3][6] = {{0x5A2B32743BDEAF15LL,18446744073709551615UL,0x5A2B32743BDEAF15LL,7UL,7UL,0x5A2B32743BDEAF15LL},{1UL,1UL,7UL,0x9D2C52D83404B277LL,7UL,1UL},{7UL,18446744073709551615UL,0x9D2C52D83404B277LL,0x9D2C52D83404B277LL,18446744073709551615UL,7UL}};
            int i, j;
            for (i = 0; i < 1; i++)
                l_155[i] = 0xD460A755L;
        }
    }
    (*g_94) = (g_199[3][0][8] > ((((~g_95) , (0x3EBA6D48C3AE247ELL | (safe_sub_func_uint64_t_u_u(((9L <= (g_74.f0 , (((g_203 , l_162) == (void*)0) != g_88))) , 1UL), p_44)))) && p_44) | p_45));
    return g_204[0][4];
}


/* ------------------------------------------ */
/* 
 * reads : g_74 g_98 g_90 g_94 g_95 g_74.f0 g_10 g_86 g_88
 * writes: g_98 g_95 g_88 g_86
 */
static int32_t * func_48(uint32_t  p_49, int32_t  p_50, int32_t * p_51, uint16_t  p_52)
{ /* block id: 11 */
    uint16_t l_96 = 0x959FL;
    int64_t *l_97[1];
    int32_t l_105[7];
    int32_t *l_106 = (void*)0;
    int32_t *l_111[4];
    int32_t **l_112 = &l_111[1];
    uint16_t *l_113 = &l_96;
    int32_t *l_122 = &g_88;
    int i;
    for (i = 0; i < 1; i++)
        l_97[i] = &g_98;
    for (i = 0; i < 7; i++)
        l_105[i] = 0x1F7D461CL;
    for (i = 0; i < 4; i++)
        l_111[i] = &l_105[2];
    (*g_94) |= (g_74 , (((g_98 ^= l_96) ^ (safe_rshift_func_uint8_t_u_u(((safe_rshift_func_uint64_t_u_s(l_96, 57)) < 1UL), 4))) & (((safe_mod_func_uint8_t_u_u(((l_105[2] = 1L) <= ((l_106 != &g_86[9]) & (((void*)0 == l_106) ^ p_49))), 0x1BL)) , p_49) & g_90)));
    (*l_122) |= (((safe_lshift_func_int32_t_s_u((safe_lshift_func_uint64_t_u_s((&g_88 == ((*l_112) = l_111[1])), 54)), 21)) != ((*l_113) ^= g_74.f0)) < (safe_add_func_int8_t_s_s((safe_sub_func_uint32_t_u_u((safe_rshift_func_int64_t_s_s(((((((((((g_98 = g_90) != p_50) < p_52) <= ((p_52 ^ (((&p_50 != &p_50) && l_105[2]) , p_52)) != g_10)) > g_86[5]) & p_52) & 0L) & p_52) != (*g_94)) > p_49), 45)), 0x5B33599DL)), 0x8AL)));
    return &g_90;
}


/* ------------------------------------------ */
/* 
 * reads : g_74.f0 g_10 g_90
 * writes: g_86 g_88 g_90
 */
static int32_t * func_59(uint64_t  p_60)
{ /* block id: 4 */
    int16_t l_80 = 0L;
    int32_t *l_85 = &g_86[3];
    int32_t *l_87 = &g_88;
    int32_t *l_89 = &g_90;
    (*l_89) &= ((*l_87) = ((*l_85) = (safe_add_func_int8_t_s_s((((safe_lshift_func_int64_t_s_s(l_80, (safe_div_func_int16_t_s_s(l_80, g_74.f0)))) == (g_10 , p_60)) && 1L), (safe_mod_func_uint64_t_u_u((l_80 || ((-1L) || p_60)), p_60))))));
    for (p_60 = 0; p_60 < 10; p_60 += 1)
    {
        g_86[p_60] = 4L;
    }
    return l_85;
}




/* ---------------------------------------- */
int main (int argc, char* argv[])
{
    int i, j, k;
    int print_hash_value = 0;
    if (argc == 2 && strcmp(argv[1], "1") == 0) print_hash_value = 1;
    platform_main_begin();
    crc32_gentab();
    func_1();
    transparent_crc(g_10, "g_10", print_hash_value);
    transparent_crc(g_74.f0, "g_74.f0", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_86[i], "g_86[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_88, "g_88", print_hash_value);
    transparent_crc(g_90, "g_90", print_hash_value);
    transparent_crc(g_95, "g_95", print_hash_value);
    transparent_crc(g_98, "g_98", print_hash_value);
    transparent_crc(g_124, "g_124", print_hash_value);
    transparent_crc(g_143, "g_143", print_hash_value);
    transparent_crc(g_154, "g_154", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        transparent_crc(g_157[i].f0, "g_157[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    for (i = 0; i < 9; i++)
    {
        transparent_crc(g_161[i].f0, "g_161[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_180.f0, "g_180.f0", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 10; k++)
            {
                transparent_crc(g_199[i][j][k], "g_199[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_203.f0, "g_203.f0", print_hash_value);
    for (i = 0; i < 1; i++)
    {
        for (j = 0; j < 10; j++)
        {
            transparent_crc(g_204[i][j].f0, "g_204[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    for (i = 0; i < 1; i++)
    {
        transparent_crc(g_248[i].f0, "g_248[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_249.f0, "g_249.f0", print_hash_value);
    transparent_crc(g_252.f0, "g_252.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 9; k++)
            {
                transparent_crc(g_264[i][j][k].f0, "g_264[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_267, "g_267", print_hash_value);
    transparent_crc(g_305.f0, "g_305.f0", print_hash_value);
    transparent_crc(g_328, "g_328", print_hash_value);
    transparent_crc(g_356.f0, "g_356.f0", print_hash_value);
    transparent_crc(g_363.f0, "g_363.f0", print_hash_value);
    transparent_crc(g_375, "g_375", print_hash_value);
    transparent_crc(g_381, "g_381", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 6; j++)
        {
            for (k = 0; k < 1; k++)
            {
                transparent_crc(g_430[i][j][k], "g_430[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_434, "g_434", print_hash_value);
    transparent_crc(g_482.f0, "g_482.f0", print_hash_value);
    transparent_crc(g_531.f0, "g_531.f0", print_hash_value);
    transparent_crc(g_552.f0, "g_552.f0", print_hash_value);
    transparent_crc(g_555.f0, "g_555.f0", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_608[i][j].f0, "g_608[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_613, "g_613", print_hash_value);
    for (i = 0; i < 10; i++)
    {
        transparent_crc(g_636[i].f0, "g_636[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_683.f0, "g_683.f0", print_hash_value);
    transparent_crc(g_728, "g_728", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_744[i][j][k].f0, "g_744[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_765, "g_765", print_hash_value);
    transparent_crc(g_818, "g_818", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_834[i].f0, "g_834[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_867.f0, "g_867.f0", print_hash_value);
    transparent_crc(g_910.f0, "g_910.f0", print_hash_value);
    transparent_crc(g_991.f0, "g_991.f0", print_hash_value);
    transparent_crc(g_1029.f0, "g_1029.f0", print_hash_value);
    transparent_crc(g_1067, "g_1067", print_hash_value);
    transparent_crc(g_1193.f0, "g_1193.f0", print_hash_value);
    transparent_crc(g_1237, "g_1237", print_hash_value);
    transparent_crc(g_1255.f0, "g_1255.f0", print_hash_value);
    transparent_crc(g_1261.f0, "g_1261.f0", print_hash_value);
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 7; j++)
        {
            transparent_crc(g_1272[i][j].f0, "g_1272[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_1320, "g_1320", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_1378[i][j][k], "g_1378[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_1398.f0, "g_1398.f0", print_hash_value);
    transparent_crc(g_1409.f0, "g_1409.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1437[i].f0, "g_1437[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1443, "g_1443", print_hash_value);
    transparent_crc(g_1497.f0, "g_1497.f0", print_hash_value);
    transparent_crc(g_1576.f0, "g_1576.f0", print_hash_value);
    transparent_crc(g_1604, "g_1604", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 4; j++)
        {
            for (k = 0; k < 6; k++)
            {
                transparent_crc(g_1635[i][j][k], "g_1635[i][j][k]", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_1653[i], "g_1653[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1698.f0, "g_1698.f0", print_hash_value);
    transparent_crc(g_1783.f0, "g_1783.f0", print_hash_value);
    transparent_crc(g_1784.f0, "g_1784.f0", print_hash_value);
    transparent_crc(g_1839.f0, "g_1839.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_1848[i], "g_1848[i]", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1850.f0, "g_1850.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        transparent_crc(g_1887[i].f0, "g_1887[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_1940.f0, "g_1940.f0", print_hash_value);
    transparent_crc(g_1966.f0, "g_1966.f0", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 3; j++)
        {
            transparent_crc(g_2020[i][j].f0, "g_2020[i][j].f0", print_hash_value);
            if (print_hash_value) printf("index = [%d][%d]\n", i, j);

        }
    }
    transparent_crc(g_2115, "g_2115", print_hash_value);
    for (i = 0; i < 4; i++)
    {
        transparent_crc(g_2127[i].f0, "g_2127[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2128.f0, "g_2128.f0", print_hash_value);
    transparent_crc(g_2142.f0, "g_2142.f0", print_hash_value);
    transparent_crc(g_2172.f0, "g_2172.f0", print_hash_value);
    transparent_crc(g_2200, "g_2200", print_hash_value);
    transparent_crc(g_2258.f0, "g_2258.f0", print_hash_value);
    for (i = 0; i < 8; i++)
    {
        transparent_crc(g_2273[i].f0, "g_2273[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2279, "g_2279", print_hash_value);
    transparent_crc(g_2333, "g_2333", print_hash_value);
    for (i = 0; i < 3; i++)
    {
        for (j = 0; j < 10; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_2347[i][j][k].f0, "g_2347[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_2392, "g_2392", print_hash_value);
    transparent_crc(g_2447.f0, "g_2447.f0", print_hash_value);
    transparent_crc(g_2473.f0, "g_2473.f0", print_hash_value);
    transparent_crc(g_2514.f0, "g_2514.f0", print_hash_value);
    for (i = 0; i < 7; i++)
    {
        transparent_crc(g_2595[i].f0, "g_2595[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_2601.f0, "g_2601.f0", print_hash_value);
    transparent_crc(g_2618, "g_2618", print_hash_value);
    transparent_crc(g_2627.f0, "g_2627.f0", print_hash_value);
    transparent_crc(g_2710.f0, "g_2710.f0", print_hash_value);
    transparent_crc(g_2738.f0, "g_2738.f0", print_hash_value);
    transparent_crc(g_2799.f0, "g_2799.f0", print_hash_value);
    transparent_crc(g_2845.f0, "g_2845.f0", print_hash_value);
    transparent_crc(g_2878.f0, "g_2878.f0", print_hash_value);
    transparent_crc(g_2893.f0, "g_2893.f0", print_hash_value);
    transparent_crc(g_2975.f0, "g_2975.f0", print_hash_value);
    transparent_crc(g_3067.f0, "g_3067.f0", print_hash_value);
    transparent_crc(g_3221.f0, "g_3221.f0", print_hash_value);
    transparent_crc(g_3222.f0, "g_3222.f0", print_hash_value);
    transparent_crc(g_3247.f0, "g_3247.f0", print_hash_value);
    transparent_crc(g_3290.f0, "g_3290.f0", print_hash_value);
    transparent_crc(g_3295.f0, "g_3295.f0", print_hash_value);
    for (i = 0; i < 2; i++)
    {
        transparent_crc(g_3308[i].f0, "g_3308[i].f0", print_hash_value);
        if (print_hash_value) printf("index = [%d]\n", i);

    }
    transparent_crc(g_3350, "g_3350", print_hash_value);
    transparent_crc(g_3373.f0, "g_3373.f0", print_hash_value);
    transparent_crc(g_3418.f0, "g_3418.f0", print_hash_value);
    transparent_crc(g_3575.f0, "g_3575.f0", print_hash_value);
    transparent_crc(g_3576.f0, "g_3576.f0", print_hash_value);
    transparent_crc(g_3626, "g_3626", print_hash_value);
    transparent_crc(g_3766.f0, "g_3766.f0", print_hash_value);
    transparent_crc(g_3768, "g_3768", print_hash_value);
    transparent_crc(g_3775.f0, "g_3775.f0", print_hash_value);
    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 1; j++)
        {
            for (k = 0; k < 7; k++)
            {
                transparent_crc(g_3825[i][j][k].f0, "g_3825[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    for (i = 0; i < 6; i++)
    {
        for (j = 0; j < 9; j++)
        {
            for (k = 0; k < 4; k++)
            {
                transparent_crc(g_3847[i][j][k].f0, "g_3847[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_3848, "g_3848", print_hash_value);
    transparent_crc(g_3895.f0, "g_3895.f0", print_hash_value);
    transparent_crc(g_3923, "g_3923", print_hash_value);
    transparent_crc(g_3978.f0, "g_3978.f0", print_hash_value);
    transparent_crc(g_3983, "g_3983", print_hash_value);
    for (i = 0; i < 9; i++)
    {
        for (j = 0; j < 8; j++)
        {
            for (k = 0; k < 3; k++)
            {
                transparent_crc(g_3990[i][j][k].f0, "g_3990[i][j][k].f0", print_hash_value);
                if (print_hash_value) printf("index = [%d][%d][%d]\n", i, j, k);

            }
        }
    }
    transparent_crc(g_4013.f0, "g_4013.f0", print_hash_value);
    transparent_crc(g_4017.f0, "g_4017.f0", print_hash_value);
    platform_main_end(crc32_context ^ 0xFFFFFFFFUL, print_hash_value);
    return 0;
}

/************************ statistics *************************
XXX max struct depth: 0
breakdown:
   depth: 0, occurrence: 990
XXX total union variables: 74

XXX non-zero bitfields defined in structs: 0
XXX zero bitfields defined in structs: 0
XXX const bitfields defined in structs: 0
XXX volatile bitfields defined in structs: 0
XXX structs with bitfields in the program: 0
breakdown:
XXX full-bitfields structs in the program: 0
breakdown:
XXX times a bitfields struct's address is taken: 0
XXX times a bitfields struct on LHS: 0
XXX times a bitfields struct on RHS: 0
XXX times a single bitfield on LHS: 0
XXX times a single bitfield on RHS: 0

XXX max expression depth: 45
breakdown:
   depth: 1, occurrence: 129
   depth: 2, occurrence: 28
   depth: 3, occurrence: 1
   depth: 4, occurrence: 2
   depth: 7, occurrence: 3
   depth: 9, occurrence: 2
   depth: 11, occurrence: 1
   depth: 12, occurrence: 1
   depth: 13, occurrence: 1
   depth: 16, occurrence: 4
   depth: 17, occurrence: 1
   depth: 19, occurrence: 1
   depth: 20, occurrence: 4
   depth: 21, occurrence: 3
   depth: 22, occurrence: 1
   depth: 23, occurrence: 1
   depth: 24, occurrence: 1
   depth: 25, occurrence: 2
   depth: 26, occurrence: 2
   depth: 30, occurrence: 1
   depth: 32, occurrence: 1
   depth: 33, occurrence: 2
   depth: 35, occurrence: 1
   depth: 36, occurrence: 1
   depth: 45, occurrence: 1

XXX total number of pointers: 814

XXX times a variable address is taken: 2410
XXX times a pointer is dereferenced on RHS: 619
breakdown:
   depth: 1, occurrence: 474
   depth: 2, occurrence: 123
   depth: 3, occurrence: 15
   depth: 4, occurrence: 3
   depth: 5, occurrence: 4
XXX times a pointer is dereferenced on LHS: 545
breakdown:
   depth: 1, occurrence: 435
   depth: 2, occurrence: 86
   depth: 3, occurrence: 14
   depth: 4, occurrence: 7
   depth: 5, occurrence: 3
XXX times a pointer is compared with null: 76
XXX times a pointer is compared with address of another variable: 25
XXX times a pointer is compared with another pointer: 25
XXX times a pointer is qualified to be dereferenced: 13373

XXX max dereference level: 5
breakdown:
   level: 0, occurrence: 0
   level: 1, occurrence: 2451
   level: 2, occurrence: 595
   level: 3, occurrence: 223
   level: 4, occurrence: 120
   level: 5, occurrence: 36
XXX number of pointers point to pointers: 438
XXX number of pointers point to scalars: 343
XXX number of pointers point to structs: 0
XXX percent of pointers has null in alias set: 28.6
XXX average alias set size: 1.46

XXX times a non-volatile is read: 3362
XXX times a non-volatile is write: 1673
XXX times a volatile is read: 232
XXX    times read thru a pointer: 22
XXX times a volatile is write: 64
XXX    times written thru a pointer: 18
XXX times a volatile is available for access: 9.34e+03
XXX percentage of non-volatile access: 94.4

XXX forward jumps: 0
XXX backward jumps: 11

XXX stmts: 134
XXX max block depth: 5
breakdown:
   depth: 0, occurrence: 26
   depth: 1, occurrence: 11
   depth: 2, occurrence: 19
   depth: 3, occurrence: 23
   depth: 4, occurrence: 21
   depth: 5, occurrence: 34

XXX percentage a fresh-made variable is used: 16.5
XXX percentage an existing variable is used: 83.5
XXX total OOB instances added: 0
********************* end of statistics **********************/

